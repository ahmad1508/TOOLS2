# Plateforme d’aide à la revue de configuration

## Méthode

La procédure comporte deux étapes :

1. L’extraction de la configuration grâce au script approprié présent dans le
   dossier `scripts` — Déposer le script sur la machine cible — L’exécuter —
   Récupérer le fichier de résultat (en nettoyant les traces)
2. L’exécution du moteur sur le fichier de résultat

*Note* : certaines technologies n’ont pas de script associées, mais un README
qui explique le mode opératoire pour effectuer l’extraction.

## Technologies supportées

**Cette liste peut ne pas être la plus à jour**. Pour avoir une liste la plus à
jour possible, utiliser la commande `./moteur.py --list-techs`

- Linux ;
- Windows ;
- OracleDB ;
- OracleDB OS ;
- Hadoop ;
- PaloAlto firewall
- FortiGate
- Forcepoint

## Utilisation

### Usage complet

```
usage: moteur.py [-h] [--list-techs | --list-templates | --list-formats]
                 [--type TYPE] [--input [NAME=]PATH [[NAME=]PATH ...]]
                 [--output OUTPUT] [--format FORMAT] [--language LANG]
                 [--template TEMPLATE] [--timing] [--quiet | --verbose]

Prend en entrée des extracts et la technologie utilisée (Linux, Windows, etc.)
et génère la plateforme d'audit correspondante.

optional arguments:
  -h, --help            show this help message and exit
  --list-techs          liste les technologies supportées par le moteur
  --list-templates      liste les templates et langues supportés la
                        technologie définie par --type ou toutes les
                        technologie si --type n’est pas spécifié
  --list-formats        liste les formats de sortie supportés par le moteur
  --type TYPE, -t TYPE  type de technologie à utiliser
  --input [NAME=]PATH [[NAME=]PATH ...], -i [NAME=]PATH [[NAME=]PATH ...]
                        fichiers d'extraction à analyser. Chaque chemin de
                        fichier peut être précédé par un nom et séparé par un
                        égal (=). Si le chemin comporte un égal, et que vous
                        ne souhaitez pas de nom, il faut faire commencer le
                        chemin par égal (c’est-à-dire avoir un nom vide).
  --output OUTPUT, -o OUTPUT
                        chemin du fichier de sortie
  --format FORMAT, -f FORMAT
                        type de fichier de sortie
  --language LANG, -l LANG
                        langue du rapport de sortie
  --template TEMPLATE, -m TEMPLATE
                        template du rapport de sortie
  --timing, -T          afficher des statistiques de temps
  --quiet, -q           suppress output
  --verbose, -v         increase verbosity

```

### Options principales

Les arguments suivants doivent être adapté en fonction des besoins des
auditeurs :

- **--type** : type de technologie auditée (Linux, Windows, etc.)

  - pour voir la liste complète des technologies utiliser `--list-techs`
  - \_exemple : linux

- **--input** : chemin(s) vers le fichier texte contenant les résultats
  d’extraction de configuration. **Il est possible de revoir plusieurs fichiers
  d’un coup** en fournissant plusieurs chemins à cet argument.

  - _exemple : Wavestone_Audit_Windows.res_

- **--output** : chemin vers le fichier de sortie désiré

  - _exemple : Rapport_linux.docx_

- **--format** : format du fichier désiré (`html`, `docx`, `csv` ou `all`)

  - pour voir la liste complète des formats utiliser `--list-formats`
  - s’il n’est pas fourni, le moteur essayera de le résoudre depuis l’extension
    du fichier de sortie
  - _exemple : docx_

- **--language** : langue de la revue de configuration (si supporté par la
  technologie)

  - parmis les langues usuels : `fr` pour le français, `en` pour l’anglais
  - s’elle n’est pas fournie, le moteur utilisera la langue par défaut de la
    technologie revue
  - pour voir la liste complète des langues d’une technologie, utiliser
    `--list-templates` avec l’option `--type`
  - _exemple : en_

- **--template** : modèle de rapport de la revue de configuration
  - parmis les modèles usuels : `full` pour le modèle complet
  - s’il n’est pas fourni, le moteur utilisera le modèle par défaut de la
    technologie revue
  - pour voir la liste complète des templates d’une technologie, utiliser
    `--list-templates` avec l’option `--type`
  - _exemple : full_

Pour une liste détaillée des options possibles, lancer :

```shell
./moteur.py --help
```

Voici quelques exemples de commandes pouvant être lancées depuis un **Linux** :

```shell
./moteur.py --type windows --input 'Example input/Wavestone_Audit_Windows.res' --output Rapport_windows.docx --format docx
./moteur.py --type linux --input 'Example input/linux/redhat.txt' --output Rapport_redhat.html
```

Elles peuvent également être lancées depuis un **Windows** :

```powershell
.\moteur.py --type windows --input 'Example input\Wavestone_Audit_Windows.res' --output Rapport_windows.docx --format docx
.\moteur.py --type linux --input 'Example input\linux\redhat.txt' --output Rapport_redhat.html
```

---

## Installation du moteur

Pour installer le moteur, il faut le télécharger, puis installer ses
dépendances en lançant la commande suivante :

```shell
python3 -m pip install -r requirements.txt
```

---

## Ajouter un type de technologie

Se référer à la [documentation dédiée](docs/add_technology.md).
