# -*- coding: utf-8 -*-

"""Handle the tests

Main program for running all unit tests
"""

# Standard libraries
import argparse
import importlib
import os

# Project imports
from tests.program import Program


def find_subprograms():
    """Try to find all subprograms

    To do so, it iterates over each packages in the directory
    and try to load the main.py module.
    If main.py was imported, it retrieve the main attribute
    """
    cur_pkg = ".".join(__name__.split(".")[:-1])
    base = os.path.dirname(__file__)
    ret = {}
    for entry in os.listdir(base):
        # skip all entries starting with "_"
        if entry[0] == "_":
            continue

        # keep all valid packages
        if (
            os.path.isdir(os.path.join(base, entry))
            and os.path.isfile(os.path.join(base, entry, "__init__.py"))
            and os.path.isfile(os.path.join(base, entry, "main.py"))
        ):
            # import the main packgage
            mod = importlib.import_module("%s.%s.main" % (cur_pkg, entry))
            # if main is defined, we store it
            if hasattr(mod, "main"):
                ret[entry] = mod.main

    # return list of subprograms
    return ret


class MainProgram(Program):
    """The command-line program which runs generation tests"""

    subprograms = find_subprograms()

    def get_argparser(self):
        """Create the argument parser with basic options"""
        # create parser
        parser = super(MainProgram, self).get_argparser()

        parser.description = "Run unit tests"
        parser.add_help = True
        return parser

    @classmethod
    def add_options(cls, parser):
        """Add options specific to this program to the ArgumentParser"""
        # create the subparsers section
        subparsers = parser.add_subparsers(
            dest="subprogram",
            title="Test suites",
            help="test suite to be run",
        )

        # Add `all` subcommand to run all tests
        subparsers.add_parser(
            "all",
            help="run all subcommands with default options (default action)",
        )
        # Add a subparser for every sub programs
        for sub in cls.subprograms:
            cmd_parser = subparsers.add_parser(
                sub,
                help="run commands for %s" % sub,
            )
            cls.subprograms[sub].add_options(cmd_parser)

    def run(self):
        """Run the program"""
        # if all was selected, run all tests
        if self.options.subprogram is None or self.options.subprogram == "all":
            # to keep track of return status
            ret = True
            for sub in self.subprograms:
                # create a new options with the defaults of the program
                # otherwise, we'll get an error when running the
                # subprogram
                options = argparse.Namespace()
                options.__dict__.update(self.subprograms[sub].default_options.__dict__)
                options.__dict__.update(self.options.__dict__)

                # instanciate the subprogram and run it
                prgm = self.subprograms[sub](
                    options=options,
                    do_verbosity=False,
                    do_run=False,
                )
                ret &= prgm.run()
            return ret
        else:
            # else run only the selected subprogram
            prgm = self.subprograms[self.options.subprogram](
                options=self.options,
                do_verbosity=False,
                do_run=False,
            )
            return prgm.run()


main = MainProgram
