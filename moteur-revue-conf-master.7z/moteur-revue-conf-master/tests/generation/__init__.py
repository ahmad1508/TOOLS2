# -*- coding: utf-8 -*-

"""Implement tests to generate reports

This package implements unit tests to ensure reports are properly
generated.

It contains a dedicated test cases (and a test suite to do a proxy) and
a associated TestRunner
"""

__all__ = ["test_generation", "runner"]
