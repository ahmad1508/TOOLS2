# -*- coding: utf-8 -*-

"""Implement generation tests

This module implements TestCase and TestSuite for the generation of any
available technology.

In this module are created:
 - A base TestCase to provide common generation functions
 - A TestSuite which should be the main interface to run generation
   tests

Per-technology TestCases are generated dynamically through
GenerationTestSuite.

A metaclass (GenerationMeta) create TestCases by extending
the base TestCase (GenerationTestCase). It create a new test unit for
each available extract and output format.

This metaclass is called from the TestSuite (GenerationTestSuite) during
initialization. Any tech given as parameter to the test suite will
force the creation of a new per-technology test cases, through
GenerationMeta.
"""


# Standard libraries
import os
import sys
import unittest

# Project imports
from engine import logger
from engine.core.engine import Engine
from engine.core.technology import Technology


class GenerationFilterException(Exception):
    """Exception for GenerationTestCase

    The exception is raised when a generation caused exceptions while
    filtering

    This Exception is supposed to groups all exceptions that the engine
    has generated while filtering extracts
    """

    def __init__(self, msg, errors):
        """Initialize the exception with all suberrors"""
        super(GenerationFilterException, self).__init__(msg)
        self.errors = errors


class GenerationMeta(type):
    """Metaclass for GenerationTestCase

    It is used to dynamically create test units based on available
    extractions
    """

    def __new__(cls, name, bases, dct):
        """Create the GenerationTestCase"""
        # Create a new test unit for every extraction file in the
        # technology directory
        if "tech_dir" in dct:

            def _gen(tname):
                return lambda self: self.generate(tname)

            for tname in os.listdir(dct["tech_dir"]):
                dct["test_%s" % tname] = _gen(tname)
        return super(GenerationMeta, cls).__new__(cls, name, bases, dct)


class GenerationTestCase(unittest.TestCase):
    """A base TestCase to generate reports"""

    def setUp(self):
        """Initialize objects for tests"""
        # disable the engine logger
        logger.setup(sys.stdout, logger.WARNING)
        # initialize an engine
        self.engine = Engine(self.tech, self.template, self.lang)

    def generate(self, in_name):
        """Generate a report for a given tech"""
        # generate report
        self.engine.review(
            ["=" + os.path.join(self.tech_dir, in_name)],
            self.get_output_path(in_name),
            self.out_format,
        )
        # add errors for every exceptions which occured within the
        # engine
        if any(rev.has_errors for rev in self.engine.reviewers):
            raise GenerationFilterException(
                "Errors occured during filtering",
                errors=[err for rev in self.engine.reviewers for err in rev.errors],
            )

    def get_output_path(self, in_name):
        """Generate the path to the output report"""
        curdir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(
            curdir,
            "..",
            "output",
            "%s_%s_python%s.%s%s.%s"
            % (
                self.tech,
                in_name,
                ".".join(map(str, sys.version_info)),
                self.template,
                ".%s" % self.lang.upper() if self.lang else "",
                self.out_format,
            ),
        )


class GenerationTestSuite(unittest.TestSuite):
    """TestSuite to generate all reports"""

    def __init__(self, techs=None, out_formats=None, langs=None, templates=None):
        """Initialize the test cases for given techs and formats

        If techs is None, all available techs are generated
        If out_format is None, all available formats are generated
        If langs is None, all available langs are generated
        If templates is None, all available templates are generated
        """
        # To keep track of test case instances
        self.test_case_classes = []
        # Loader for the test cases
        self.loader = unittest.TestLoader()

        # To keep track of all tests to be performed
        tests = []
        # list of techs
        available_techs = self.list_techs()
        # list of formats
        available_formats = [a[0] for a in Engine.get_available_formats()]

        # Generate a TestCase for each tech and format to be generated
        for tech, extract_dir in available_techs:
            # check whether tech is selected
            if techs is not None and tech not in techs:
                continue

            # ensure the technology exists in the engine
            t = Technology.get_by_name(tech)
            if t is None:
                continue

            for out_format in available_formats:
                # check whether format is selected
                if out_formats is not None and out_format not in out_formats:
                    continue

                # when "all" format is not explicitely selected, skip it
                if out_format == "all" and out_formats is None:
                    continue

                for tpl, tpl_langs in t.templates.items():
                    # check whether template is selected
                    if templates is not None and tpl not in templates:
                        continue

                    for lang in tpl_langs:
                        # check whether lang is selected
                        if langs is not None and lang not in langs:
                            continue

                        # create the test
                        tests.append(
                            self.load_test_case(
                                tech,
                                extract_dir,
                                out_format,
                                lang,
                                tpl,
                            ),
                        )

        super(GenerationTestSuite, self).__init__(tests)

    def load_test_case(self, tech, extract_dir, out_format, lang, tpl):
        """Create and load a GenerationTestCase"""
        # create the GenerationTestCase class
        cls = GenerationMeta(
            # name
            "%s%s%sTestCase"
            % (tech, out_format.capitalize(), (lang or "").capitalize()),
            # bases
            (GenerationTestCase,),
            # dict
            {
                "tech": tech,
                "tech_dir": extract_dir,
                "out_format": out_format,
                "lang": lang,
                "template": tpl,
            },
        )
        # save it in the GenerationTestCase list
        self.test_case_classes.append(cls)

        # Load all tests from the test case
        return self.loader.loadTestsFromTestCase(cls)

    @staticmethod
    def list_techs():
        """Retrieve a list of all techs and their directory"""
        ret = []
        # the extraction dir is located under
        # tests/generation/extractions
        extract_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "extractions",
        )
        # all subdirectories is this directory should be named after a
        # technology name
        for tech in os.listdir(extract_dir):
            ret.append((tech, os.path.join(extract_dir, tech)))
        return ret
