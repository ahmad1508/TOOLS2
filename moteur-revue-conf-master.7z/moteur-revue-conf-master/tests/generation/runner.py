# -*- coding: utf-8 -*-

"""Implements runner for generation tests

A runner dedicated to the GenerationTestCase to print timing statistics
and to display a table with failures and success

The runner should be used with the GenerationTestResult which keeps
track of global status and timing statistics
"""


# Standard libraries
import unittest

# Project imports
from tests.generation.test_generation import (
    GenerationFilterException,
    GenerationTestSuite,
)


class GenerationTestResult(unittest.TextTestResult):
    """TestResult used to update a GenerationTestCase global result"""

    def __init__(self, *args, **kargs):
        """Initialize the test result"""
        super(GenerationTestResult, self).__init__(*args, **kargs)
        # initialialize structure to keep track of all timing stats
        self._timings = {}
        # initialialize structure to keep track of all global results
        self._results = {}

    def get_key(self, test):
        """Retrieve the key for a given test"""
        return (
            test.tech
            + " - %s" % test.template
            + (" - " + test.lang.upper() if test.lang else ""),
            test.out_format,
        )

    def update_timing_stats(self, test):
        """Update the timing statistics based on the engine stats"""
        # retrieve the local timing and the engine timing
        key = self.get_key(test)
        if key in self._timings:
            loc_timing, count = self._timings[key]
        else:
            loc_timing, count = {"TOTAL": 0}, 0
        eng_timing = test.engine.timing

        # Update all timers
        for name in eng_timing.timings:
            loc_timing[name] = loc_timing.get(name, 0) + eng_timing.timings[name]

        # Update the total time
        eng_timing.end()
        loc_timing["TOTAL"] += eng_timing._stop - eng_timing._start
        count += 1

        # save the results
        self._timings[key] = (loc_timing, count)

    def update_results(self, val, test):
        """Update the global result"""
        key = self.get_key(test)
        self._results[key] = self._results.get(key, True) & val
        self.update_timing_stats(test)

    def addFailure(self, test, err):
        """Extend inherited method"""
        super(GenerationTestResult, self).addFailure(test, err)
        # mark the test as globally unsuccessful
        self.update_results(False, test)

    def addError(self, test, err):
        """Extend inherited method"""
        super(GenerationTestResult, self).addError(test, err)
        # mark the test as globally unsuccessful
        self.update_results(False, test)

    def addSuccess(self, test):
        """Extend inherited method"""
        super(GenerationTestResult, self).addSuccess(test)
        # mark the test as globally unsuccessful
        self.update_results(True, test)

    def printErrorList(self, flavour, errors):
        """Extend inherited method"""
        # override the TextTestResult function to handle the special
        # GenerationFilterException which groups all exceptions which
        # occurs during filtering
        for test, err in errors:
            # check whether the error is a GenerationFilterException
            if err[0] is GenerationFilterException:
                # we recurse on all sub exceptions
                self.printErrorList(
                    flavour,
                    map(
                        lambda e: (test, e),
                        err.errors,
                    ),
                )
            else:
                # in other cases, just do like the parent method
                self.stream.writeln(self.separator1)
                self.stream.writeln(
                    "%s: %s"
                    % (
                        flavour,
                        self.getDescription(test),
                    ),
                )
                self.stream.writeln(self.separator2)
                self.stream.writeln("%s" % err)

    def _exc_info_to_string(self, err, test):
        # Overide the generation of exc_info strings to have traceback
        # of all errors for GenerationFilterException
        if err[0] is GenerationFilterException:
            ret = []
            for e in err[1].errors:
                ret.append(
                    super(GenerationTestResult, self)._exc_info_to_string(e, test),
                )
            return (self.separator2 + "\n").join(ret)
        else:
            return super(GenerationTestResult, self)._exc_info_to_string(err, test)


class GenerationTestRunner(unittest.TextTestRunner):
    """TestRunner used to print a global status table and stastistics"""

    def __init__(self, *args, timing=False, **kwargs):
        """Initialize the runner"""
        super().__init__(
            resultclass=GenerationTestResult,
            *args,
            **kwargs,
        )
        # whether to print timings
        self.with_timings = timing

        # check whether to enable colors
        self._use_colors = self.stream.isatty()

    def run(self, test):
        """Extend inherited method to print results"""
        # fail safe
        if not isinstance(test, GenerationTestSuite):
            raise RuntimeError(
                "GenerationTestRunner needs to be used with " "GenerationTestSuite",
            )
        result = super(GenerationTestRunner, self).run(test)

        # print the table of results
        if self.verbosity > 0:
            self.stream.writeln(
                self.format_results_table(result),
            )

        return result

    def format_timings(self, timings):
        """Format the timings for the table"""
        # manage case where timing should not be added
        if not self.with_timings:
            return ""
        # else add each timing in order
        timing, cnt = timings
        return " (%0.1f|%s)" % (
            timing["TOTAL"] / cnt,
            "-".join(["%0.1f" % (t / cnt) for n, t in timing.items() if n != "TOTAL"]),
        )

    def get_results_as_table(self, result):
        """Retrive the results as a table"""
        # lists to keep track of all headers
        rows = []
        cols = []

        # first transform into a dict of dict
        tmp = {}
        for key in result._results:
            row, col = key
            # update rows & cols if needed
            if row not in rows:
                rows.append(row)
                tmp[row] = {}
            if col not in cols:
                cols.append(col)
            # add the result to the temp dict
            # also add additional data, like timings
            tmp[row][col] = (
                result._results[key],
                self.format_timings(result._timings[key]),
            )

        # Then use the temp dict to create the array
        # sort the cols and rows
        rows.sort()
        cols.sort()
        ret = [[("", "")] + list(map(lambda c: (c, ""), cols))]
        for row in rows:
            ret.append([(row, "")])
            for col in cols:
                ret[-1].append(tmp[row][col])

        return ret

    def format_results_table(self, result):
        """Return a string representation of the results"""
        # retrieve a table representation of the results
        tbl = self.get_results_as_table(result)

        # ensure at least 1 generation occured
        if len(tbl) <= 1:
            return "No report were generated"

        # first compute the width of each columns
        widths = [0 for _ in range(len(tbl[0]))]
        for i, row in enumerate(tbl):
            for j, (cell, additional) in enumerate(row):
                # transform boolean results to OK or KO
                if not isinstance(cell, str):
                    cell = "OK" if cell else "KO"
                    tbl[i][j] = (cell, additional)
                widths[j] = max(widths[j], len(cell) + len(additional))

        # Create the text table and color it
        ret = []
        # create the first edge line
        ret.append(" " * widths[0] + " +")
        for i in range(1, len(tbl[0])):
            ret[-1] += "-" * widths[i] + "+"
        # for each row, create the colored content & the bottom sep line
        for i, row in enumerate(tbl):
            line = "|" if i > 0 else " "
            sep = "+"
            for j, (cell, additional) in enumerate(row):
                if j == 0 or i == 0:
                    # header cell
                    line += (
                        self._format_header(
                            "{0:^{w}}".format(cell, w=widths[j]),
                        )
                        + "|"
                    )
                elif cell == "OK":
                    line += (
                        self._format_success(
                            "{0:^{w}}".format(cell + additional, w=widths[j]),
                        )
                        + "|"
                    )
                elif cell == "KO":
                    line += (
                        self._format_failure(
                            "{0:^{w}}".format(cell + additional, w=widths[j]),
                        )
                        + "|"
                    )
                else:
                    # default to an empty cell
                    line += " " * widths[j] + "|"
                sep += "-" * widths[j] + "+"
            # append both line & sep
            ret.append(line)
            ret.append(sep)
        # return the table
        return "\n".join(ret)

    def _add_console_code(self, pre, post, txt):
        """Prepend and append txt with console codes"""
        if self._use_colors:
            return "\x1b[%dm%s\x1b[%dm" % (pre, txt, post)
        else:
            return txt

    def _format_header(self, txt):
        """Return the text formated as a header"""
        return self._add_console_code(1, 0, txt)

    def _format_failure(self, txt):
        """Return the text formated as a failure"""
        return self._add_console_code(31, 0, txt)

    def _format_success(self, txt):
        """Return the text formated as a success"""
        return self._add_console_code(32, 0, txt)
