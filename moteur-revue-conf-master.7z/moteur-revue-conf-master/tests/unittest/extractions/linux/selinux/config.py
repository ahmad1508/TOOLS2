# -*- coding: utf-8 -*-

"""Configure tests."""


def configure(lang):
    """Return configuration for the current lang"""
    return {
        "allowed_filters": [
            "selinux",
        ],
        "template": """
{%- import "common.jinja" as common -%}
{%- include "linux/"""
        + ("fr" if lang == "C" else lang)
        + """/config.jinja" -%}

{%- call(tech) common.review(techs) -%}
{{ common.oldstyle_review(tech, 'selinux', 'Configuration des LSM - SELinux') }}
{% endcall %}
""",
    }
