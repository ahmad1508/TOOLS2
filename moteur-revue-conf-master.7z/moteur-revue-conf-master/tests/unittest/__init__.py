# -*- coding: utf-8 -*-

"""Implement tests to perform unit tests generation on some sections

This package implements unit tests to ensure sections can correctly be
generated.

It contains a dedicated test cases (and a test suite to do a proxy) and
a associated TestRunner
"""

__all__ = ["test_generation", "runner"]
