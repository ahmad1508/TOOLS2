# -*- coding: utf-8 -*-

"""Handle the tests

Main program for generation unittests
"""

# Standard libraries
import argparse

# Project imports
from engine.core.engine import Engine
from tests.program import Program
from tests.unittest.runner import UnittestGenerationTestRunner
from tests.unittest.test_generation import UnittestGenerationTestSuite


class UnittestGenerationProgram(Program):
    """The command-line program which runs generation tests"""

    # defaults values
    default_options = argparse.Namespace(
        techs=None,
        formats=None,
        languages=None,
        sections=None,
        timing=False,
    )

    def get_argparser(self):
        """Create the argument parser with basic options"""
        # create parser
        parser = super(UnittestGenerationProgram, self).get_argparser()

        parser.description = "Run unit tests which generate specific sections"
        parser.add_help = True
        return parser

    @classmethod
    def add_options(cls, parser):
        """Add options specific to this program to the ArgumentParser"""
        # add technology options
        parser.add_argument(
            "--techs",
            "-t",
            nargs="+",
            choices=Engine.get_available_techs(),
            metavar="TECH",
            help="filter on the selected technologies",
        )

        # add format options
        parser.add_argument(
            "--formats",
            "-f",
            nargs="+",
            choices=[a for b in Engine.get_available_formats() for a in b],
            metavar="FORMAT",
            help="filter on the selected output formats",
        )

        # add lang options
        parser.add_argument(
            "--languages",
            "-l",
            nargs="+",
            choices=Engine.get_available_languages(),
            metavar="LANG",
            help="filter on the selected languages",
        )

        # add section options
        parser.add_argument(
            "--sections",
            "-s",
            nargs="+",
            help="filter on the selected sections",
        )

        # add timing options
        parser.add_argument(
            "--timing",
            "-T",
            action="store_true",
            help="whether to print timing stats",
        )

    def run(self):
        """Run the program"""
        print(self.options)
        # create the runner
        runner = UnittestGenerationTestRunner(
            verbosity=self.options.verbosity,
            timing=self.options.timing,
        )

        # Get TestSuite correctly filtered
        suite = UnittestGenerationTestSuite(
            techs=self.options.techs,
            out_formats=self.options.formats,
            langs=self.options.languages,
            sections=self.options.sections,
        )

        # run tests
        self.results = runner.run(suite)
        return self.results.wasSuccessful()


main = UnittestGenerationProgram
