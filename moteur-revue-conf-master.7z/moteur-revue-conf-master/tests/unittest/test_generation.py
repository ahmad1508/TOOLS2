# -*- coding: utf-8 -*-

"""Implement generation tests

This module implements TestCase and TestSuite for the generation of any
available technology.

In this module are created:
 - A base TestCase to provide common generation functions
 - A TestSuite which should be the main interface to run generation
   tests

Per-technology TestCases are generated dynamically through
GenerationTestSuite.

A metaclass (GenerationMeta) create TestCases by extending
the base TestCase (GenerationTestCase). It create a new test unit for
each available extract and output format.

This metaclass is called from the TestSuite (GenerationTestSuite) during
initialization. Any tech given as parameter to the test suite will
force the creation of a new per-technology test cases, through
GenerationMeta.
"""


# Standard libraries
import importlib.util
import os
import sys
import unittest

# Project imports
from engine import logger
from engine.core.engine import Engine
from engine.core.technology import Technology, TechnologyV1


class UnittestGenerationFilterException(Exception):
    """Exception for UnittestGenerationTestCase

    The exception is raised when a generation caused exceptions while
    filtering

    This Exception is supposed to groups all exceptions that the engine
    has generated while filtering extracts
    """

    def __init__(self, msg, errors):
        """Initialize the exception with all suberrors"""
        super(UnittestGenerationFilterException, self).__init__(msg)
        self.errors = errors


class UnittestGenerationMeta(type):
    """Metaclass for UnittestGenerationTestCase

    It is used to dynamically create test units based on available
    extractions
    """

    def __new__(cls, name, bases, dct):
        """Create the UnittestGenerationTestCase"""
        # Create a new test unit for every extraction file in the
        # technology directory
        if "extract_dir" in dct:

            def _gen(fname):
                return lambda self: self.generate(fname)

            for fname in os.listdir(dct["extract_dir"]):
                if fname not in [
                    "config.py",
                    "config.pyc",
                    "__pycache__",
                ] and not fname.endswith(".expected"):
                    dct[f"test_{fname}"] = _gen(fname)
        return super(UnittestGenerationMeta, cls).__new__(cls, name, bases, dct)


class UnittestGenerationTestCase(unittest.TestCase):
    """A base TestCase to generate reports"""

    def setUp(self):
        """Initialize objects for tests"""
        # disable the engine logger
        logger.setup(sys.stdout, logger.WARNING)
        # initialize an engine
        self.engine = Engine(self.tech, None, None if self.lang == "C" else self.lang)

        self.current_file = None

        # try to load config.py
        self.config = {
            "allowed_filters": [],
            "template": "",
        }
        config_path = os.path.join(self.extract_dir, "config.py")
        if os.path.isfile(config_path):
            try:
                spec = importlib.util.spec_from_file_location("config", config_path)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                self.config = mod.configure(self.lang)
            except Exception:  # nosec
                pass

        # keep track of wether filter was called
        self.filter_called = False

        def filter_called_cb():
            self.filter_called = True

        # update the wrapper
        self.engine.tech.orig_wrapper = self.engine.tech.wrapper
        self.engine.tech.wrapper = property(
            lambda s: TechnologyProxy(
                s.orig_wrapper,
                self.config["allowed_filters"],
                filter_called_cb,
            )
        )

        # update the template
        if self.config["template"]:
            self.engine.template.template = (
                self.engine.template.environment.from_string(self.config["template"])
            )

    def tearDown(self):
        """Deinitialize objects for tests"""
        # restore original wrapper for future tests
        self.engine.tech.wrapper = self.engine.tech.orig_wrapper

    def generate(self, filename):
        """Generate a report for a given tech & section"""
        self.current_file = filename

        # generate report
        self.engine.review(
            ["=" + os.path.join(self.extract_dir, filename)],
            self.get_output_path(filename),
            self.out_format,
        )

        # add errors for every exceptions which occured within the
        # engine
        if any(rev.has_errors for rev in self.engine.reviewers):
            raise UnittestGenerationFilterException(
                "Errors occured during filtering",
                errors=[err for rev in self.engine.reviewers for err in rev.errors],
            )

        # assert at least 1 filter was called
        assert self.filter_called, "No filter was called"

        # For C lang, if an .expected file exists, check the results
        if (
            self.lang == "C"
            and self.out_format == "bbcode"
            and os.path.isfile(os.path.join(self.extract_dir, filename + ".expected"))
        ):
            with open(os.path.join(self.extract_dir, filename + ".expected")) as f:
                expected = f.read()
            with open(self.get_output_path(filename)) as f:
                result = f.read()
            assert expected == result, "Unexpected result for section %s file %s" % (
                self.section,
                filename,
            )

    def get_output_path(self, filename):
        """Generate the path to the output report"""
        curdir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(
            curdir,
            "..",
            "output",
            "%s_%s_%s_python%s%s.%s"
            % (
                self.tech,
                self.section,
                filename,
                ".".join(map(str, sys.version_info)),
                ".%s" % self.lang.upper() if self.lang else "",
                self.out_format,
            ),
        )


class TechnologyProxy:
    """Proxy to a technology limit allowed filters"""

    ALWAYS_ALLOWED = [
        "all_findings",
        "artifacts",
        "desc",
        "errors",
        "findings",
        "get_template",
        "hostname",
        "name",
        "parse_input",
        "preprocessors",
    ]

    def __init__(self, tech, allowed_filters, callback):
        self.tech = tech
        self.callback = callback
        self.allowed_filters = allowed_filters

    def __getattr__(self, key):
        # always allowed methods are just returned as such
        if key in self.ALWAYS_ALLOWED:
            return getattr(self.tech, key)
        # explicitly allowed methods are returned & callback called
        # if no method is allowed
        if key in self.allowed_filters or len(self.allowed_filters) == 0:
            self.callback()
            return getattr(self.tech, key)
        # handle filter for TechnologyV1 in a special way
        if isinstance(self.tech, TechnologyV1) and key == "run_filter":
            return self.run_filter
        # any other case return a dummy filter which does nothing
        return self.do_nothing

    @staticmethod
    def do_nothing(*_, **__):
        """Return an empty string"""
        return ""

    def run_filter(self, filter_name, extract_name):
        """Mimic run_filter of TechnologyV1"""
        if filter_name in self.allowed_filters or len(self.allowed_filters) == 0:
            self.callback()
            return self.tech.run_filter(filter_name, extract_name)
        return ""


class UnittestGenerationTestSuite(unittest.TestSuite):
    """TestSuite to generate all reports"""

    def __init__(self, techs=None, out_formats=None, langs=None, sections=None):
        """Initialize the test cases for given techs and formats

        If techs is None, all available techs are generated
        If out_format is None, all available formats are generated
        If langs is None, all available langs are generated
        If sections is None, all available sections are generated
        """
        # To keep track of test case instances
        self.test_case_classes = []
        # Loader for the test cases
        self.loader = unittest.TestLoader()

        # To keep track of all tests to be performed
        tests = []
        # list of techs
        available_techs = self.list_techs()
        # list of formats
        available_formats = [a[0] for a in Engine.get_available_formats()]

        # Generate a TestCase for each tech and format to be generated
        for tech, tech_dir in available_techs:
            # check whether tech is selected
            if techs is not None and tech not in techs:
                continue

            # ensure the technology exists in the engine
            t = Technology.get_by_name(tech)
            if t is None:
                continue

            for section, extract_dir in self.list_sections(tech_dir):
                # check whether section is selected
                if sections is not None and section not in sections:
                    continue

                for out_format in available_formats:
                    # check whether format is selected
                    if out_formats is not None and out_format not in out_formats:
                        continue

                    # when "all" format is not explicitely selected,
                    # skip it
                    if out_format == "all" and out_formats is None:
                        continue

                    for lang in Engine.get_available_languages() + ["C"]:
                        # check whether lang is selected
                        if langs is not None and lang not in langs:
                            continue

                        # create the test
                        tests.append(
                            self.load_test_case(
                                tech,
                                section,
                                extract_dir,
                                out_format,
                                lang,
                            ),
                        )

        super(UnittestGenerationTestSuite, self).__init__(tests)

    def load_test_case(self, tech, section, extract_dir, out_format, lang):
        """Create and load a UnittestGenerationTestCase"""
        # create the GenerationTestCase class
        cls = UnittestGenerationMeta(
            # name
            "%s%s%s%sTestCase"
            % (
                tech,
                section.capitalize(),
                out_format.capitalize(),
                (lang or "").capitalize(),
            ),
            # bases
            (UnittestGenerationTestCase,),
            # dict
            {
                "tech": tech,
                "section": section,
                "extract_dir": extract_dir,
                "out_format": out_format,
                "lang": lang,
            },
        )
        # save it in the GenerationTestCase list
        self.test_case_classes.append(cls)

        # Load all tests from the test case
        return self.loader.loadTestsFromTestCase(cls)

    @staticmethod
    def list_techs():
        """Retrieve a list of all techs and their directory"""
        ret = []
        # the extraction dir is located under
        # tests/generation/extractions
        extract_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "extractions",
        )
        # all subdirectories is this directory should be named after a
        # technology name
        for tech in os.listdir(extract_dir):
            ret.append((tech, os.path.join(extract_dir, tech)))
        return ret

    @staticmethod
    def list_sections(tech_dir):
        """Retrieve a list of all sections and their directory"""
        ret = []
        # all subdirectories in tech_dir is a section
        for section in os.listdir(tech_dir):
            ret.append((section, os.path.join(tech_dir, section)))
        return ret
