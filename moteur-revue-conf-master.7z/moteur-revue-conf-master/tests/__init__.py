# -*- coding: utf-8 -*-

"""Contain all unit tests for the engine"""

# TODO switch to nose test to improve tests (including multiprocessing)
#  It is solely compatible with Py3
