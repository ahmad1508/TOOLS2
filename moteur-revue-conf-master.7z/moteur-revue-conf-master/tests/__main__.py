# -*- coding: utf-8 -*-

"""Handle the tests

Main entry point of the package
"""

# Standard libraries
import sys

# Project imports
from tests.main import main

# We change sys.argv[0] to make help message more useful
# when run directly through __main__.py
if sys.argv[0].endswith("__main__.py"):
    # Standard libraries
    import os

    executable = os.path.basename(sys.executable)
    sys.argv[0] = executable + " -m tests"
    del os

main()
