# -*- coding: utf-8 -*-

"""Provide a class to create program

Classes
-------
ProgramMeta -- metaclass of Program
Program -- base program for running unittests
"""


# Standard libraries
import argparse
import sys


class ProgramMeta(type):
    """Metaclass for Program

    It extends default options with options of base classes
    """

    def __new__(cls, name, bases, dct):
        """Create an instance of Program"""
        return super(ProgramMeta, cls).__new__(cls, name, bases, dct)
        # merge options in the same order as MRO
        merged = argparse.Namespace()
        # First merge bases in reverse order
        for b in bases[::-1]:
            if hasattr(b, "options"):
                merged.__dict__.update(b.options.__dict__)
        # Then merge with class options
        if "options" in dct:
            merged.__dict__.update(dct["options"])

        # update the dict
        dct["options"] = merged

        return super(ProgramMeta, cls).__new__(cls, name, bases, dct)


class Program(object, metaclass=ProgramMeta):
    """Base program for implementing test programs"""

    # default empty options
    default_options = argparse.Namespace()

    def __init__(
        self,
        argv=None,
        options=None,
        do_verbosity=True,
        do_run=True,
        **kargs,
    ):
        """Initialize the program and run it

        Arguments
        ---------
        argv -- optional command-line arguments to use to run the
                program. If None is given, use sys.argv
        options -- optional parsed options to use. If one is provided,
                   command-line arguments won't be parsed again. This
                   is useful in case the program has to be run as a
                   sub-program
        do_verbosity -- Whether to handle verbosity option within this
                        class. This should be assign by sub-classes when
                        calling super(). Default: True
        do_run -- Whether to run the program after initialization.
                  Can be useful for meta-programs which may only want to
                  initialize the program to get argparse. Default: True
        **kargs -- Any other keyword arguments will be used to update
                   the options, even if options is provided

        """
        # use the options in parameters if one is given
        if options is not None:
            self.options = options
        else:
            # create options from the default options
            self.options = argparse.Namespace()
            self.options.__dict__.update(self.default_options.__dict__)

        # handle verbosity initialization
        self.do_verbosity = do_verbosity
        if self.do_verbosity:
            self.options.verbosity = 1

        # update default options with kargs
        for k in kargs:
            if hasattr(self.options, k):
                setattr(self.options, k, kargs[k])

        # parse args with argv
        if options is None:
            if argv is None:
                argv = sys.argv
            parser = self.get_argparser()
            self.add_options(parser)
            self.parse_args(parser, argv)

        # run the core of the program
        if do_run:
            sys.exit(0 if self.run() else 1)

    def get_argparser(self):
        """Create the argument parser with basic options"""
        parser = argparse.ArgumentParser()

        # handle verbosity options
        if self.do_verbosity:
            group = parser.add_mutually_exclusive_group()
            group.add_argument(
                "--quiet",
                "-q",
                action="store_true",
                help="suppress output",
            )
            group.add_argument(
                "--verbose",
                "-v",
                action="count",
                default=0,
                help="increase verbosity",
            )

        return parser

    @classmethod
    def add_options(cls, parser):
        """Add options specific to this program to the ArgumentParser"""
        pass

    def parse_args(self, parser, argv):
        """Parse arguments

        This is useful if a sub class need to do some special actions
        after parsing
        """
        parser.parse_args(argv[1:], self.options)

        # handle verbosity options
        if self.do_verbosity:
            if self.options.quiet:
                self.options.verbosity = 0
            else:
                self.options.verbosity = 1 + self.options.verbose

    def run(self):
        """Run the program"""
        pass
