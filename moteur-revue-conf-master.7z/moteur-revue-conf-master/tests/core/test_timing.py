# -*- coding: utf-8 -*-

"""Provide tests for engine.core.timing"""

# Standard libraries
import io
import sys
import unittest

# Project imports
from engine import logger
from engine.core import timing


class TimingTestCase(unittest.TestCase):
    """Test the Timing class"""

    def setUp(self):
        """Fix timing"""
        # disable logger
        logger.setup(None)

        # create a fake object which has a time function calling
        # the instance time() method
        timing.time = type("Clock", (object,), {"time": self.time})
        self.current_time = 0.0

        # Fix stdout
        self._orig_stdout = sys.stdout
        sys.stdout = io.StringIO()

        # Initialize a class
        self.timing = timing.Timing()

    def tearDown(self):
        """Restore original stdout"""
        sys.stdout = self._orig_stdout

    def time(self):
        """Return the fixed time"""
        return self.current_time

    def test_init(self):
        """Check initialization of the class"""
        self.assertIsInstance(self.timing.timings, dict)
        self.assertEqual(self.timing.timings, {})
        self.assertIsInstance(self.timing._timers, dict)
        self.assertEqual(self.timing._timers, {})
        self.assertEqual(self.timing._start, 0)

    def test_timer(self):
        """Check starting and stopping timers"""
        # start several timers
        self.timing.start("Timer 1")
        self.timing.start("Timer 2")
        self.timing.start("Timer 3")
        self.assertEqual(len(self.timing._timers), 3, msg="Timer not started")
        self.assertEqual(len(self.timing.timings), 0, msg="Additional timers ended")

        # stop timers
        self.current_time = 1.0
        self.timing.stop("Timer 1")
        self.current_time = 2.0
        self.timing.stop("Timer 2")
        self.current_time = 3.0
        self.timing.stop("Timer 3")

        # check all timings
        self.assertEqual(len(self.timing._timers), 0, msg="Timer not stopped")
        self.assertEqual(len(self.timing.timings), 3, msg="Timer not stopped")
        self.assertEqual(self.timing.timings["Timer 1"], 1)
        self.assertEqual(self.timing.timings["Timer 2"], 2)
        self.assertEqual(self.timing.timings["Timer 3"], 3)

        # check that timing do not start existing timers
        self.assertEqual(len(self.timing._timers), 0)
        self.timing.start("Timer 4")
        self.assertEqual(len(self.timing._timers), 1, msg="Timer not started")
        self.timing.start("Timer 4")
        self.assertEqual(len(self.timing._timers), 1, msg="Duplicate timer started")

        # check that stopping non existing timers do nothing
        self.assertEqual(len(self.timing.timings), 3)
        self.timing.stop("Timer 5")
        self.assertEqual(len(self.timing.timings), 3, msg="Non existing timer stopped")

        # check that end() stop all existing timers
        self.current_time = 4.0
        self.timing.start("Timer 5")
        self.assertEqual(len(self.timing._timers), 2)
        self.assertEqual(len(self.timing.timings), 3)
        self.current_time = 6.0
        self.timing.end()
        self.assertEqual(
            len(self.timing._timers),
            0,
            msg="Not all timers stopped with end()",
        )
        self.assertEqual(
            len(self.timing.timings),
            5,
            msg="Not all timers stopped with end()",
        )
        self.assertEqual(self.timing.timings["Timer 1"], 1)
        self.assertEqual(self.timing.timings["Timer 2"], 2)
        self.assertEqual(self.timing.timings["Timer 3"], 3)
        self.assertEqual(self.timing.timings["Timer 4"], 3)
        self.assertEqual(self.timing.timings["Timer 5"], 2)
        self.assertEqual(self.timing._stop, 6, msg="End time not stored after end()")

        # check that ended Timing cannot start new timers
        self.timing.start("Timer 6")
        self.timing.start("Timer 7")
        self.assertEqual(len(self.timing._timers), 0, msg="Timers started after end()")
        self.assertEqual(len(self.timing.timings), 5, msg="Timers started after end()")

        # check that ending Timing twice do nothing more
        self.current_time = 10.0
        self.timing.end()
        self.assertEqual(
            len(self.timing._timers),
            0,
            msg="Timers updated after second end()",
        )
        self.assertEqual(
            len(self.timing.timings),
            5,
            msg="Timers updated after second end()",
        )
        self.assertEqual(self.timing.timings["Timer 1"], 1)
        self.assertEqual(self.timing.timings["Timer 2"], 2)
        self.assertEqual(self.timing.timings["Timer 3"], 3)
        self.assertEqual(self.timing.timings["Timer 4"], 3)
        self.assertEqual(self.timing.timings["Timer 5"], 2)
        self.assertEqual(self.timing._stop, 6, msg="Timers updated after second end()")

    def test_format_time(self):
        """Check time formatting"""
        self.assertEqual(self.timing._format_time(0), "0ms")
        self.assertEqual(self.timing._format_time(0.5), "500ms")
        self.assertEqual(self.timing._format_time(0.999), "999ms")
        self.assertEqual(self.timing._format_time(1.0), "1.0s")
        self.assertEqual(self.timing._format_time(1.01), "1.0s")
        self.assertEqual(self.timing._format_time(1.04), "1.0s")
        self.assertEqual(self.timing._format_time(1.05), "1.1s")
        self.assertEqual(self.timing._format_time(1.09), "1.1s")
        self.assertEqual(self.timing._format_time(1.1), "1.1s")
        self.assertEqual(self.timing._format_time(100), "100.0s")

    def test_print_stats(self):
        """Check printing stats, including colors"""
        # add a timer
        self.timing.start("Timer")
        self.current_time = 1

        # Ensure print_stat() also end Timing
        self.assertEqual(len(self.timing._timers), 1)
        self.assertEqual(len(self.timing.timings), 0)
        self.timing.print_stat()
        self.assertEqual(
            len(self.timing._timers),
            0,
            msg="Printing stat did not end Timing",
        )
        self.assertEqual(
            len(self.timing.timings),
            1,
            msg="Printing stat did not end Timing",
        )
        sys.stdout = io.StringIO()

        # print with colors
        self.timing._use_colors = True
        self.timing.print_stat()
        self.assertIn("\x1b[", sys.stdout.getvalue())
        sys.stdout = io.StringIO()

        # print without colors
        self.timing._use_colors = False
        self.timing.print_stat()
        self.assertNotIn("\x1b[", sys.stdout.getvalue())
        sys.stdout = io.StringIO()

    def test_decorator(self):
        """Check the decorators from timing"""

        # wrap() decorator
        @self.timing.wrap("Timer wrap")
        def change_time(clock, unused=None, time=0):
            """Doc change_time"""
            clock.current_time = time

        # Ensure function was correctly decorated
        self.assertEqual(change_time.__name__, "change_time")
        self.assertEqual(change_time.__doc__, "Doc change_time")

        # Ensure a new timer is correctly created and stopped when
        # we run the decorated function
        self.current_time = 1
        change_time(self, time=5)
        self.assertIn("Timer wrap", self.timing.timings)
        self.assertEqual(self.timing.timings["Timer wrap"], 4)

        # self_wrap() decorator
        class TestClass(object):
            def __init__(self, clock):
                # create 2 timers for the tests
                self.timing1 = timing.Timing()
                self.timing2 = timing.Timing()
                self.clock = clock

            @timing.Timing.self_wrap("timing1", "Change timing1")
            def change1(self):
                """Doc change1"""
                self.clock.current_time += 2

            @timing.Timing.self_wrap("timing2", "Change timing2")
            def change2(self, clock, unused=None, time=0):
                """Doc change2"""
                clock.current_time = time

        test_inst = TestClass(self)

        # Ensure function was correctly decorated
        self.assertEqual(test_inst.change1.__name__, "change1")
        self.assertEqual(test_inst.change1.__doc__, "Doc change1")
        self.assertEqual(test_inst.change2.__name__, "change2")
        self.assertEqual(test_inst.change2.__doc__, "Doc change2")

        # Ensure a new timer is correctly created and stopped when
        # we run the decorated function
        self.current_time = 1
        test_inst.change1()
        self.assertEqual(self.current_time, 3)
        self.assertEqual(len(test_inst.timing1.timings), 1)
        self.assertEqual(len(test_inst.timing2.timings), 0)
        self.assertIn("Change timing1", test_inst.timing1.timings)
        self.assertEqual(test_inst.timing1.timings["Change timing1"], 2)

        test_inst.change2(self, time=6)
        self.assertEqual(self.current_time, 6)
        self.assertEqual(len(test_inst.timing1.timings), 1)
        self.assertEqual(len(test_inst.timing2.timings), 1)
        self.assertIn("Change timing2", test_inst.timing2.timings)
        self.assertEqual(test_inst.timing2.timings["Change timing2"], 3)
