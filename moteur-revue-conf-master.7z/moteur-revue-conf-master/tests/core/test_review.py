# -*- coding: utf-8 -*-

"""Provide tests for engine.core.review"""

# Standard libraries
import unittest

# Project imports
from engine import logger
from engine.core import review


class ReviewTestCase(unittest.TestCase):
    """Test the Review class"""

    def setUp(self):
        """Initialize a review"""
        # disable logger
        logger.setup(None)

        self.review = review.Review("Source", "Review")

    def test_init(self):
        """Check that initialization works as expected"""
        # Testing this class may seem a bit useless considering
        # the complexity of Review
        self.assertEqual(self.review.source, "Source")
        self.assertEqual(self.review.review, "Review")
