# -*- coding: utf-8 -*-

"""Provide tests for engine.core.layout"""

# Standard libraries
import json
import os
import unittest

# Project imports
from engine import logger
from engine.core import layout


class PartTestCase(unittest.TestCase):
    """Test the Part class"""

    def setUp(self):
        """Set up the tests"""
        # disable logger
        logger.setup(None)

    def test_init(self):
        """Ensure all ways of initializing a Part are functional"""
        # title only
        part = layout.Part("title")
        self.assertIsInstance(part, layout.Part)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.extra, {})

        # title + extra
        part = layout.Part("title", {"key": "value"})
        self.assertIsInstance(part, layout.Part)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.extra, {"key": "value"})

    def test_getattr(self):
        """Ensure getattr proxy extra dict"""
        part = layout.Part(
            "title",
            {
                "title": "fake title",
                "attr1": "value1",
                "attr2": "value2",
            },
        )
        self.assertEqual(part.attr1, "value1")
        self.assertEqual(part.attr2, "value2")
        self.assertEqual(part.title, "title")
        with self.assertRaises(AttributeError):
            part.non_existent


class SectionPartTestCase(unittest.TestCase):
    """Test the SectionPart class"""

    def setUp(self):
        """Set up the tests"""
        # disable logger
        logger.setup(None)

    def test_init(self):
        """Check all ways of initializing a SectionPart"""
        # title only
        part = layout.SectionPart("title")
        self.assertIsInstance(part, layout.SectionPart)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.content, [])
        self.assertEqual(part.extra, {})

        # title + extra
        part = layout.SectionPart("title", {"key": "value"})
        self.assertIsInstance(part, layout.SectionPart)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.content, [])
        self.assertEqual(part.extra, {"key": "value"})

    def test_content(self):
        """Check the management of content"""
        # Init parts
        section = layout.SectionPart("section")
        part1 = layout.Part("part1")
        part2 = layout.Part("part2")
        part3 = layout.Part("part3")
        extract = layout.ExtractPart("extract", "cmd", "filter")
        subsection = layout.SectionPart("subsection")
        subsection.append(part2)

        # Append the parts
        section.append(part1)
        self.assertEqual(section.content, [part1])
        section.append(extract)
        self.assertEqual(section.content, [part1, extract])
        section.append(subsection)
        self.assertEqual(section.content, [part1, extract, subsection])

        # Access content using array interfaces
        #  len
        self.assertEqual(len(section), 3)

        #  getitem
        self.assertIs(section[0], part1)
        self.assertIs(section[1], extract)
        self.assertIs(section[2], subsection)
        self.assertIs(section[2][0], part2)

        #  setitem
        section[0] = part3
        self.assertEqual(section.content, [part3, extract, subsection])

        #  delitem
        section.append(part1)
        self.assertEqual(section.content, [part3, extract, subsection, part1])
        del section[0]
        self.assertEqual(section.content, [extract, subsection, part1])
        del section[2]
        self.assertEqual(section.content, [extract, subsection])

        #  iter
        part_iter = iter(section)
        self.assertIs(next(part_iter), extract)
        self.assertIs(next(part_iter), subsection)
        with self.assertRaises(StopIteration):
            next(part_iter)

        # Ensure only Parts can be added
        self.assertRaises(RuntimeError, section.append, "not part")
        with self.assertRaises(RuntimeError):
            section[0] = "not part"


class ExtractPartTestCase(unittest.TestCase):
    """Test the ExtractPart class"""

    def setUp(self):
        """Set up the tests"""
        # disable logger
        logger.setup(None)

    def test_init(self):
        """Check all ways of initializing an ExtractPart"""
        # title only
        part = layout.ExtractPart("title", "cmd", "filter_name")
        self.assertIsInstance(part, layout.ExtractPart)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.cmd, "cmd")
        self.assertEqual(part.filter, "filter_name")
        self.assertEqual(part.target, "title")
        self.assertIs(part.review, None)
        self.assertEqual(part.extra, {})

        # title + extra
        part = layout.ExtractPart("title", "cmd", "filter_name", extra={"key": "value"})
        self.assertIsInstance(part, layout.ExtractPart)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.cmd, "cmd")
        self.assertEqual(part.filter, "filter_name")
        self.assertEqual(part.target, "title")
        self.assertIs(part.review, None)
        self.assertEqual(part.extra, {"key": "value"})

        # title + target
        part = layout.ExtractPart("title", "cmd", "filter_name", "target")
        self.assertIsInstance(part, layout.ExtractPart)
        self.assertEqual(part.title, "title")
        self.assertEqual(part.cmd, "cmd")
        self.assertEqual(part.filter, "filter_name")
        self.assertEqual(part.target, "target")
        self.assertIs(part.review, None)
        self.assertEqual(part.extra, {})


class LayoutTestCase(unittest.TestCase):
    """Test the Layout class"""

    def setUp(self):
        """Create a Layout object"""
        # disable logger
        logger.setup(None)

        # create a base layout
        self.layout = layout.Layout()

    def test_init(self):
        """Check initialization of Layout"""
        self.assertEqual(self.layout.content, [])

    def test_content(self):
        """Check the management of content"""
        # Init parts
        part1 = layout.Part("part1")
        part2 = layout.Part("part2")
        part3 = layout.Part("part3")
        extract = layout.ExtractPart("extract", "cmd", "filter")
        subsection = layout.SectionPart("subsection")
        subsection.append(part2)

        # Append the parts
        self.layout.append(part1)
        self.assertEqual(self.layout.content, [part1])
        self.layout.append(extract)
        self.assertEqual(self.layout.content, [part1, extract])
        self.layout.append(subsection)
        self.assertEqual(self.layout.content, [part1, extract, subsection])

        # Access content using array interfaces
        #  len
        self.assertEqual(len(self.layout), 3)

        #  getitem
        self.assertIs(self.layout[0], part1)
        self.assertIs(self.layout[1], extract)
        self.assertIs(self.layout[2], subsection)
        self.assertIs(self.layout[2][0], part2)

        #  setitem
        self.layout[0] = part3
        self.assertEqual(self.layout.content, [part3, extract, subsection])

        #  delitem
        self.layout.append(part1)
        self.assertEqual(self.layout.content, [part3, extract, subsection, part1])
        del self.layout[0]
        self.assertEqual(self.layout.content, [extract, subsection, part1])
        del self.layout[2]
        self.assertEqual(self.layout.content, [extract, subsection])

        #  iter
        part_iter = iter(self.layout)
        self.assertIs(next(part_iter), extract)
        self.assertIs(next(part_iter), subsection)
        with self.assertRaises(StopIteration):
            next(part_iter)

        # Ensure only Parts can be added
        self.assertRaises(RuntimeError, self.layout.append, "not part")
        with self.assertRaises(RuntimeError):
            self.layout[0] = "not part"

    def test_json_parsing(self):
        """Check parsing of report JSON files"""
        # parse file
        self.layout.parse_file(
            os.path.join(
                os.path.dirname(__file__),
                "assets",
                "layout.json",
            ),
        )
        # ensure parse file is what is expected
        self.assertEqual(len(self.layout), 2)

        # lvl 1 sections
        self.assertIsInstance(self.layout[0], layout.SectionPart)
        self.assertEqual(self.layout[0].title, "Section 1")
        self.assertEqual(self.layout[0].desc, "Description 1")
        self.assertEqual(len(self.layout[0]), 2)

        self.assertIsInstance(self.layout[1], layout.SectionPart)
        self.assertEqual(self.layout[1].title, "Section 2")
        self.assertEqual(len(self.layout[1]), 1)
        with self.assertRaises(AttributeError):
            self.layout[1].desc

        # lvl 2 sections
        self.assertIsInstance(self.layout[0][0], layout.SectionPart)
        self.assertEqual(self.layout[0][0].title, "Section 1.1")
        self.assertEqual(self.layout[0][0].desc, "Description 1.1")
        self.assertEqual(self.layout[0][0].analyze, "Analyze 1")
        self.assertEqual(self.layout[0][0].rec, "Rec 1")
        self.assertEqual(len(self.layout[0][0]), 2)

        self.assertIsInstance(self.layout[0][1], layout.SectionPart)
        self.assertEqual(self.layout[0][1].title, "Section 1.2")
        self.assertEqual(self.layout[0][1].desc, "Description 1.2")
        self.assertEqual(self.layout[0][1].analyze, "Analyze 2")
        self.assertEqual(self.layout[0][1].rec, "Rec 2")
        self.assertEqual(len(self.layout[0][1]), 1)

        self.assertIsInstance(self.layout[1][0], layout.SectionPart)
        self.assertEqual(self.layout[1][0].title, "Section 2.1")
        with self.assertRaises(AttributeError):
            self.layout[1][0].desc
        with self.assertRaises(AttributeError):
            self.layout[1][0].analyze
        with self.assertRaises(AttributeError):
            self.layout[1][0].rec
        self.assertEqual(len(self.layout[1][0]), 0)

        # lvl 3 extracts
        self.assertIsInstance(self.layout[0][0], layout.SectionPart)
        self.assertIsInstance(self.layout[0][0][0], layout.ExtractPart)
        self.assertEqual(self.layout[0][0][0].title, "Extract 1")
        self.assertEqual(self.layout[0][0][0].cmd, "Extract 1 cmd")
        self.assertEqual(self.layout[0][0][0].filter, "Filter 1")

        self.assertIsInstance(self.layout[0][0][1], layout.ExtractPart)
        self.assertEqual(self.layout[0][0][1].title, "Extract 2")
        self.assertEqual(self.layout[0][0][1].cmd, "Extract 2 cmd")
        self.assertEqual(self.layout[0][0][1].filter, "Filter 2")

        self.assertIsInstance(self.layout[0][1][0], layout.ExtractPart)
        self.assertEqual(self.layout[0][1][0].title, "Extract 3")
        self.assertEqual(self.layout[0][1][0].cmd, "Extract 3 cmd")
        self.assertEqual(self.layout[0][1][0].filter, "Filter 1")

        # Check parsing on invalid inputs
        self.layout = layout.Layout()
        with self.assertRaises(RuntimeError):
            self.layout.parse_json(json.loads("""{"key": "value"}"""))
