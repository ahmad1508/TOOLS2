# -*- coding: utf-8 -*-

"""Provide tests for engine.core.engine"""

# Standard libraries
import os
import unittest
from unittest import mock

# Project imports
from engine import logger
from engine.core import engine, extracts, layout, review


class EngineTestCase(unittest.TestCase):
    """Test the Engine class"""

    def setUp(self):
        """Set up for tests"""
        # disable logger
        logger.setup(None)

        # array to keep track of mocked functions/classes to restore
        # them on tearDown. Each item is a tuple
        # : (object, attribute, orig)
        self.mocked = []

        # patch tech
        self.mocked.append((engine.Technology, "plugins", engine.Technology.plugins))
        engine.Technology.plugins = mock.MagicMock(
            return_value=[mock.MagicMock(engine.Technology) for _ in range(3)],
        )
        for i, m in enumerate(engine.Technology.plugins()):
            m.name = "Tech%d" % i
            m.layout = {None: "/path/to/tech%d.json" % i}

        # patch renderer
        self.mocked.append((engine.Renderer, "plugins", engine.Renderer.plugins))
        engine.Renderer.plugins = mock.MagicMock(
            return_value=[mock.MagicMock(engine.Renderer) for _ in range(3)],
        )
        for i, m in enumerate(engine.Renderer.plugins()):
            m.extensions = ["fmt%d_%d" % (i, j) for j in range(i + 1)]

        # patch Layout
        self.mocked.append((engine, "Layout", engine.Layout))
        engine.Layout = mock.MagicMock(
            return_value=mock.MagicMock(
                spec=engine.Layout,
            ),
        )

    def tearDown(self):
        """Restore mocked functions/classes"""
        # do that in reverse order
        for obj, attr, orig in self.mocked[::-1]:
            setattr(obj, attr, orig)

    def test_available_plugins(self):
        """Check available techs and format"""
        self.assertCountEqual(
            engine.Engine.get_available_techs(),
            [
                "Tech0",
                "Tech1",
                "Tech2",
            ],
        )
        self.assertCountEqual(
            engine.Engine.get_available_formats(),
            [["fmt%d_%d" % (i, j) for j in range(i + 1)] for i in range(3)],
        )

    def test_init(self):
        """Check initialization of the engine"""
        # patch the get_by_name method to be sure to retrieve
        # a mocked tech
        orig = engine.Technology.get_by_name
        engine.Technology.get_by_name = mock.MagicMock(
            return_value=engine.Technology.plugins()[0],
        )

        # check normal initialization
        eng = engine.Engine("Tech1")
        # check loading
        engine.Technology.get_by_name.assert_called_with("Tech1")
        self.assertIn("layout", dir(eng))
        self.assertIn("tech", dir(eng))

        # restore the original method
        engine.Technology.get_by_name = orig

        # check an error is raised when the tech does not exist
        with self.assertRaises(RuntimeError):
            engine.Engine("Do not exist")

    def test_filtering(self):
        """Check the filtering of extracts"""
        # Initialize a static review
        rev = review.Review("a", "b")

        # Initialize an engine
        eng = engine.Engine("Tech1")
        # patch the reviewer
        eng.reviewer = mock.MagicMock(spec=["run_filter"])
        eng.reviewer.run_filter = mock.MagicMock(return_value=rev)

        # patch filter_extract to be able to know the number of call
        global count
        count = 0

        def test_filter(layout_parts):
            global count
            count += 1
            return engine.Engine.filter_extract(eng, layout_parts)

        eng.filter_extract = test_filter

        # check the behavior on ExtractPart
        eng.reviewer.run_filter.reset_mock()
        ext = layout.ExtractPart("title", "cmd", "filter")
        eng.filter_extract([ext])
        eng.reviewer.run_filter.assert_called_with("filter", "title")
        self.assertIs(ext.review, rev)
        self.assertEqual(count, 1)

        # check the behavior on SectionPart
        eng.reviewer.run_filter.reset_mock()
        ext = layout.SectionPart("title")
        ext.append(layout.ExtractPart("title", "cmd", "filter"))
        eng.filter_extract([ext])
        eng.reviewer.run_filter.assert_called_with("filter", "title")
        self.assertIs(ext[0].review, rev)
        self.assertEqual(count, 3)

        # check the behavior on SectionPart with no content
        eng.reviewer.run_filter.reset_mock()
        ext = layout.SectionPart("title")
        eng.filter_extract([ext])
        eng.reviewer.run_filter.assert_not_called()
        self.assertEqual(count, 5)

        # check an error is raised when the input is not a list
        with self.assertRaises(RuntimeError):
            eng.filter_extract("str")
        with self.assertRaises(RuntimeError):
            eng.filter_extract(("tuple",))
        with self.assertRaises(RuntimeError):
            eng.filter_extract({"dict": ""})
        with self.assertRaises(RuntimeError):
            eng.filter_extract(2)
        # check an error is raised when the input is not list of parts
        with self.assertRaises(RuntimeError):
            eng.filter_extract(["str"])
        with self.assertRaises(RuntimeError):
            eng.filter_extract([("tuple",)])
        with self.assertRaises(RuntimeError):
            eng.filter_extract([{"dict": ""}])
        with self.assertRaises(RuntimeError):
            eng.filter_extract([2])

    def test_load_extracts(self):
        """Check loading extracts"""
        # Initialize an engine
        eng = engine.Engine("Tech1")

        # Check the loading of extract do read and parse a file
        ext = eng.load_extracts(
            os.path.join(os.path.dirname(__file__), "assets", "extract.txt"),
        )
        self.assertIsInstance(ext, extracts.Extracts)
        self.assertEqual(len(ext), 4)

    def test_render(self):
        """Check rendering the review"""
        # initialize the engine
        eng = engine.Engine("Tech1")

        # Check rendering with explicit format specification
        # format should be case-insensitive
        for fmt in ("fmt1_0", "FmT1_1"):
            eng.render("/path/to/output", fmt)
            mock_renderer = engine.Renderer.get_by_extension(fmt)()
            mock_renderer.render_report.assert_called_with(
                "/path/to/output",
                "Tech1",
                eng.layout,
            )

        # Check rendering with implicit format specification
        # format should be case-insensitive
        for fmt in ("fmt2_0", "FmT2_1"):
            eng.render("/path/to/output.%s" % fmt)
            mock_renderer = engine.Renderer.get_by_extension(fmt)()
            mock_renderer.render_report.assert_called_with(
                "/path/to/output.%s" % fmt,
                "Tech1",
                eng.layout,
            )

        # Check rendering with invalid format spec
        with self.assertRaises(RuntimeError):
            eng.render("/path/to/output", "Invalid_format")
        with self.assertRaises(RuntimeError):
            eng.render("/path/to/output.Invalid_format")

    def test_review(self):
        """Check the whole reviewing process"""
        # initialize the engine
        eng = engine.Engine("Tech1")

        # patch some methods
        eng.filter_extract = mock.MagicMock()
        eng.timing.print_stat = mock.MagicMock()
        eng.render = mock.MagicMock()

        # check the review process
        eng.review(
            os.path.join(os.path.dirname(__file__), "assets", "extract.txt"),
            "output_name",
            "format",
            False,
        )
        engine.Technology.plugins()[1].assert_called()
        eng.filter_extract.assert_called()
        eng.render.assert_called()
        eng.timing.print_stat.assert_not_called()

        engine.Technology.plugins()[1].reset_mock()
        eng.filter_extract.reset_mock()
        eng.render.reset_mock()
        eng.timing.print_stat.reset_mock()

        # check the review process with stat
        eng.review(
            os.path.join(os.path.dirname(__file__), "assets", "extract.txt"),
            "output_name",
            "format",
            True,
        )
        engine.Technology.plugins()[1].assert_called()
        eng.filter_extract.assert_called()
        eng.render.assert_called()
        eng.timing.print_stat.assert_called()

        engine.Technology.plugins()[1].reset_mock()
        eng.filter_extract.reset_mock()
        eng.render.reset_mock()
        eng.timing.print_stat.reset_mock()

        # check the review process with defaul values
        eng.review(
            os.path.join(os.path.dirname(__file__), "assets", "extract.txt"),
            "output_name",
            "format",
        )
        engine.Technology.plugins()[1].assert_called()
        eng.filter_extract.assert_called()
        eng.render.assert_called()
        eng.timing.print_stat.assert_not_called()

        engine.Technology.plugins()[1].reset_mock()
        eng.filter_extract.reset_mock()
        eng.render.reset_mock()
        eng.timing.print_stat.reset_mock()
