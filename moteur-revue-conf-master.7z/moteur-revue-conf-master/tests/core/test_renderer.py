# -*- coding: utf-8 -*-

"""Provide tests for engine.core.renderer"""

# Standard libraries
import os
import tempfile
import unittest

# Project imports
from engine import logger
from engine.core import renderer


class RendererTestCase(unittest.TestCase):
    """Test the Renderer class"""

    def make_renderer(self, name, dct):
        """Create a new Renderer class or retrieve one"""
        # try to retrieve
        for cls in renderer.Renderer.plugins():
            if cls.__name__ == name:
                return cls

        # else create a new
        cls = type(name, (renderer.Renderer,), dct)
        # patch the class to make inspect identify the class
        # as being defined in this file
        cls.__module__ = self.__module__
        return cls

    def setUp(self):
        """Fix Renderer for testing purposes"""
        # disable logger
        logger.setup(None)

        # empty plugins for the test
        self.saved_plugins = renderer.Renderer.plugins()
        for p in self.saved_plugins:
            renderer.Renderer.unregister(p)

        self.test_class = self.make_renderer(
            "TestRenderer",
            {
                "render": lambda self, tech, layout: tech.encode("utf8"),
            },
        )
        self.test_instance = self.test_class()
        # create sub renderers
        self.renderer1 = self.make_renderer(
            "Ext",
            {
                "desc": {
                    "extensions": ["ext", "exte"],
                },
            },
        )
        self.renderer2 = self.make_renderer("auie", {})
        self.renderer3 = self.make_renderer("nrst", {})

    def tearDown(self):
        """Clear the test environment"""
        # restore the saved plugins
        for p in renderer.Renderer.plugins():
            renderer.Renderer.unregister(p)
        for p in self.saved_plugins:
            renderer.Renderer.register(p)

    def test_init(self):
        """Ensure the class is correctly initialized"""
        renderer = self.make_renderer("BaseRenderer", {})()
        self.assertTrue(hasattr(renderer, "render_report"))
        self.assertTrue(hasattr(renderer, "save"))
        self.assertTrue(hasattr(renderer, "render"))
        with self.assertRaises(NotImplementedError):
            renderer.render("tech", None)

    def test_extensions(self):
        """Check extensions of the renderer are correctly resolved"""
        # explicit extensions
        # extensions must returned in lower case
        cls = self.make_renderer(
            "Renderer",
            {
                "desc": {
                    "extensions": ["HTM", "html"],
                },
            },
        )
        self.assertEqual(cls.extensions, ["htm", "html"])

        # automatic resolution
        for name in ["Implicit", "ImplicitRenderer", "ImplicitRenderers"]:
            cls = self.make_renderer(name, {})
            self.assertEqual(cls.extensions, ["implicit"])

        # ensure no exception is raised when desc is present but not
        # the key name
        cls = self.make_renderer("Implicit", {"desc": {}})
        self.assertEqual(cls.extensions, ["implicit"])

    def test_get_by_extension(self):
        """Check the retrieval of a renderer from an extension"""
        # check the retrieval
        self.assertIs(
            renderer.Renderer.get_by_extension("ext"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("exte"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("ExTe"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("EXTE"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("auie"),
            self.renderer2,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("nrst"),
            self.renderer3,
        )
        self.assertIs(
            renderer.Renderer.get_by_extension("unknown"),
            None,
        )

    def test_get_by_filename(self):
        """Check the retrieval of a renderer from a filename"""
        # check the retrieval
        self.assertIs(
            renderer.Renderer.get_by_filename("file.ext"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.exte"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.ExTe"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.EXTE"),
            self.renderer1,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.auie"),
            self.renderer2,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.with.multiple.dot.auie"),
            self.renderer2,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("auie"),
            self.renderer2,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.nrst"),
            self.renderer3,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.unknown"),
            None,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("file.pdf.unknown"),
            None,
        )
        self.assertIs(
            renderer.Renderer.get_by_filename("unknown"),
            None,
        )

    def test_render_report(self):
        """Check render_report() and save()"""
        outfile_path = tempfile.mkstemp()[1]
        try:
            self.test_instance.render_report(outfile_path, "technology", None)
            result = open(outfile_path, "br").read()
        finally:
            os.remove(outfile_path)
        self.assertEqual(result, b"technology")

        # check an error is raised when render do not return bytes
        self.test_instance.render = lambda tech, layout: tech
        with self.assertRaises(RuntimeError):
            self.test_instance.render_report("path", "technology", None)
        self.test_instance.render = lambda tech, layout: [tech]
        with self.assertRaises(RuntimeError):
            self.test_instance.render_report("path", "technology", None)
