# -*- coding: utf-8 -*-

"""Provide tests for engine.core.plugable"""

# Standard libraries
import unittest

# Project imports
from engine import logger
from engine.core import plugable
from tests.core.assets.plugable import (
    PlugableAll,
    PlugableModule,
    PlugableMultipleList,
    PlugableMultipleTuple,
)


class PlugableTestCase(unittest.TestCase):
    """Test the Plugable class"""

    def setUp(self):
        """Set up a fixture plugable class"""
        # disable logger
        logger.setup(None)

        self.plugable = type("Plugable", (plugable.Plugable,), {})
        self.plugins = [type("Plugin", (self.plugable,), {}) for _ in range(5)]

    def test_metaclass(self):
        """Check the metaclass behavior"""
        self.assertTrue(hasattr(self.plugable, "_plugin_initialized"))
        self.assertTrue(hasattr(self.plugable, "_plugins"))
        # default value
        self.assertFalse(plugable.Plugable._plugin_initialized)
        self.assertFalse(self.plugable._plugin_initialized)

        # independance of _plugin_initialized between classes
        plugable.Plugable._plugin_initialized = True
        self.assertTrue(plugable.Plugable._plugin_initialized)
        self.assertFalse(self.plugable._plugin_initialized)
        plugable.Plugable._plugin_initialized = False

        # independance of _plugin_initialized between classes
        self.plugable._plugin_initialized = True
        self.assertFalse(plugable.Plugable._plugin_initialized)
        self.assertTrue(self.plugable._plugin_initialized)
        self.plugable._plugin_initialized = False

    def test_plugins(self):
        """Check the listing of plugins"""
        # when the package attribute is not defined, Plugable should not
        # try to import anything
        plugins = self.plugable.plugins()

        self.assertCountEqual(plugins, self.plugins)

        # plugins are automatically registered
        extra_plugin = type("ExtraPlugin", (self.plugable,), {})
        plugins = self.plugable.plugins()
        self.assertCountEqual(plugins, self.plugins + [extra_plugin])

        # plugins can be unregistered
        self.plugable.unregister(extra_plugin)
        plugins = self.plugable.plugins()
        self.assertCountEqual(plugins, self.plugins)

        # plugins can be registered again
        self.plugable.register(extra_plugin)
        plugins = self.plugable.plugins()
        self.assertCountEqual(plugins, self.plugins + [extra_plugin])

        # clean plugable
        self.plugable.unregister(extra_plugin)

    def test_loading_plugins(self):
        """Check how plugins are loaded"""
        # test Plugable with packages being a str
        plugins = PlugableModule.plugins()
        self.assertEqual(len(plugins), 2)
        for plugin in plugins:
            self.assertTrue(issubclass(plugin, PlugableModule))

        # test Plugable with packages being a list
        plugins = PlugableMultipleList.plugins()
        self.assertEqual(len(plugins), 2)
        for plugin in plugins:
            self.assertTrue(issubclass(plugin, PlugableMultipleList))

        # test Plugable with packages being a tuple
        plugins = PlugableMultipleTuple.plugins()
        self.assertEqual(len(plugins), 2)
        for plugin in plugins:
            self.assertTrue(issubclass(plugin, PlugableMultipleTuple))

        # test Plugable with packages being a package with __all__
        plugins = PlugableAll.plugins()
        self.assertEqual(len(plugins), 6)
        for plugin in plugins:
            self.assertTrue(issubclass(plugin, PlugableAll))
