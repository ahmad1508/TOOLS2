# -*- coding: utf-8 -*-

"""Contain assets to Plugable"""

# Project imports
from tests.core.assets.plugable import PlugableMultipleTuple


class Plugin(PlugableMultipleTuple):
    """Test plugin"""
