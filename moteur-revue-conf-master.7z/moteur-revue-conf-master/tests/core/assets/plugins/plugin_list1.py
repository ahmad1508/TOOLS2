# -*- coding: utf-8 -*-

"""Contain assets to Plugable"""

# Project imports
from tests.core.assets.plugable import PlugableMultipleList


class Plugin(PlugableMultipleList):
    """Test plugin"""
