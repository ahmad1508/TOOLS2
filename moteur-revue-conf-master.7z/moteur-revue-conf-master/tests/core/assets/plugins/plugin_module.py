# -*- coding: utf-8 -*-

"""Contain assets to Plugable"""

# Project imports
from tests.core.assets.plugable import PlugableModule


class Plugin1(PlugableModule):
    """Test plugin"""


class Plugin2(PlugableModule):
    """Test plugin"""
