# -*- coding: utf-8 -*-

"""Contain assets to test Plugable"""

# Project imports
# do some manual imports
from tests.core.assets.plugins import plugin_all1, plugin_all2  # noqa: F401

# add dynamic import
__all__ = [
    plugin_all1,
    "plugin_all3",
    "plugin_all4",
]
