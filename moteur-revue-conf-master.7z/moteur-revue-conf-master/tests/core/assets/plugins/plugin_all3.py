# -*- coding: utf-8 -*-

"""Contain assets to Plugable"""

# Project imports
from tests.core.assets.plugable import PlugableAll


class Plugin1(PlugableAll):
    """Test plugin"""


class Plugin2(PlugableAll):
    """Test plugin"""
