# -*- coding: utf-8 -*-

"""Contain assets to Plugable"""

# Project imports
from tests.core.assets.plugable import PlugableAll


class Plugin(PlugableAll):
    """Test plugin"""
