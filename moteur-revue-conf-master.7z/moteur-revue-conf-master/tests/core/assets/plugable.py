# -*- coding: utf-8 -*-

"""Contain classes to test Plugable"""

# Project imports
from engine.core.plugable import Plugable


class PlugableAll(Plugable):
    """Plugable which imports package with __all__"""

    packages = "tests.core.assets.plugins"


class PlugableModule(Plugable):
    """Plugable which imports a module with string"""

    packages = "tests.core.assets.plugins.plugin_module"


class PlugableMultipleList(Plugable):
    """Plugable which imports several module with a list"""

    packages = [
        "tests.core.assets.plugins.plugin_list1",
        "tests.core.assets.plugins.plugin_list2",
    ]


class PlugableMultipleTuple(Plugable):
    """Plugable which imports several module with a tuple"""

    packages = (
        "tests.core.assets.plugins.plugin_tuple1",
        "tests.core.assets.plugins.plugin_tuple2",
    )
