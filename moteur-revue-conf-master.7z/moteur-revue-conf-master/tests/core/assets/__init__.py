# -*- coding: utf-8 -*-

"""Contain assets for core component tests"""
