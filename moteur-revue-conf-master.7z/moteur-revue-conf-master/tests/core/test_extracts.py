# -*- coding: utf-8 -*-

"""Provide tests for engine.core.extract"""

# Standard libraries
from itertools import product
import unittest

# Project imports
from engine import logger
from engine.core import extracts


class ExtractsTestCase(unittest.TestCase):
    """Test the Extract class"""

    def setUp(self):
        """Set up an Extract with the test inputs"""
        # disable logger
        logger.setup(None)

        # Generate the test extract
        self.txt, self.sections = _generate_test()

        # Create the extract
        self.extract = extracts.Extracts(self.txt)

    def test_init_then_parse(self):
        """Check Extract initialization with no data then parsins"""
        nextract = extracts.Extracts()
        nextract.parse(self.txt)
        self.assertEqual(self.extract, nextract)

    def test_all_presence(self):
        """Check the ALL key exists and corresponds to the raw input"""
        self.assertIn("ALL", self.extract)
        self.assertEqual(self.extract["ALL"], self.txt)

    def test_parsing(self):
        """Check the parsing is done as expected"""
        # check manually all keys instead of using assertEqual,
        # to have a more detailled error description
        for k in self.sections:
            self.assertIn(k, self.extract, msg="Key '%s' not in parsed extract" % k)
            self.assertEqual(self.sections[k], self.extract[k])
        for k in self.extract:
            self.assertIn(
                k,
                self.sections,
                msg="Key '%s' not expected in parsed extract" % k,
            )

    def test_types(self):
        """Check the type of parsed data is as expected"""
        for k in self.extract:
            # utf8 for titles
            self.assertIsInstance(k, str)
            # bytes for parsed data
            self.assertIsInstance(self.extract[k], bytes)

    def test_override(self):
        """Check the override of titles"""
        # test override at same level
        extract = extracts.Extracts(
            b"===== override =====\n"
            b"Should not stay\n"
            b"===== override =====\n"
            b"Should stay\n",
        )
        self.assertEqual(extract["override"], b"Should stay\n")

        # test override at different level
        extract = extracts.Extracts(
            b"===== override =====\n"
            b"Should stay\n"
            b"===== title 1 =====\n"
            b"--=== override ===--\n"
            b"Should not stay\n",
        )
        self.assertEqual(extract["override"], b"Should stay\n")


def _generate_test_titles(base):
    """Generate a set of titles for tests"""
    return [
        # normal title
        base,
        # special UTF-8 characters
        "%s with specials éèêàôûïëöç  –—" % base,
    ]


# prefixes of titles
_TITLE_PREFIXES = ["=====", "--===", "--"]


def _generate_test_title_lines(lvl, base):
    """Generate a set of title lines for tests"""
    # find the prefix for the level
    prefix = _TITLE_PREFIXES[lvl]
    # spaces to use to add inconsistent spacing within titles
    spaces = [" ", "  ", "   "]
    # newlines at the end
    newlines = ["\n", "\r\n"]
    # line wrappers
    wrappers = ["", "'", '"']

    # Generate all test titles
    ret = {}
    i = 0
    for lwrap, rwrap, lsp, rsp, nl in product(
        wrappers,
        wrappers,
        spaces,
        spaces,
        newlines,
    ):
        for title in _generate_test_titles("%s %d" % (base, i)):
            ret[title] = "{lwr}{pre}{lsp}{title}{rsp}{suf}{rwr}{nl}".format(
                lwr=lwrap,
                rwr=rwrap,
                pre=prefix,
                suf=prefix[::-1],
                lsp=lsp,
                rsp=rsp,
                nl=nl,
                title=title,
            )
        i += 1
    return ret


def _generate_test_content():
    """Generate a set of section content"""
    # newlines to use
    newlines = [b"\n", b"\r\n"]
    # list of content lines
    contents = [
        # no content
        [],
        # empty content
        [b""],
        # single line content
        [b"single line"],
        # multi line
        [b"multi", b"line", b"content"],
        # special UTF-8
        ["éèêëáàâäóòôöíìîïúùûü’…  —–«»".encode("utf-8")],
        # binary content
        [b"".join(bytes([c]) for c in range(256))],
    ]
    # generate all test contents
    ret = []
    for nl, content in product(newlines, contents):
        ret.append(b"".join(c + nl for c in content))
    return ret


def _generate_tests_section(lvl, base):
    """Generate all tests for a given level section"""
    # for one level we create:
    #   - text before the first section
    #   - a section for each titles
    #   - a section for each contents
    #   - a section each subsection level, with level skips
    #
    # for each section, keep track of the text to parse and the
    # sections, as they should be onced parsed
    txt = b"Text before\n"
    sections = {}
    i = 0
    # create section for each title
    titles = _generate_test_title_lines(lvl, "%s %d" % (base, i))
    for title in titles:
        txt += titles[title].encode("utf-8") + b"Content\n"
        sections[title] = b"Content\n"
    i += 1

    # create section for each content
    for content in _generate_test_content():
        # only do it with one title otherwise the generation becomes
        # too long
        subbase = "%s %d" % (base, i)
        title = next(iter(_generate_test_title_lines(lvl, subbase).items()))
        txt += title[1].encode("utf-8") + content
        sections[title[0]] = content
        i += 1

    # create sections for each subsections
    for j in range(1, len(_TITLE_PREFIXES) - lvl):
        subbase = "%s %d" % (base, i)
        # only do it with one title otherwise the generation becomes
        # too long
        title = next(iter(_generate_test_title_lines(lvl, subbase).items()))
        content, subsections = _generate_tests_section(lvl + j, subbase)
        txt += title[1].encode("utf-8") + content
        sections[title[0]] = content
        sections.update(subsections)
        i += 1

    # return the text to parse and the expectations of the parsing
    return txt, sections


def _generate_test():
    """Generate the test string for parsing"""
    txt, sections = _generate_tests_section(0, "Title")
    # add the ALL key
    sections["ALL"] = txt
    return txt, sections
