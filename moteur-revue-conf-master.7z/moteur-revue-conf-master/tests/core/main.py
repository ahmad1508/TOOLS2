# -*- coding: utf-8 -*-

"""Handle the tests

Main program for tests core components
"""

# Standard libraries
import os
import unittest

# Project imports
from tests.program import Program


class CoreProgram(Program):
    """The command-line program which runs core tests"""

    def get_argparser(self):
        """Create the argument parser with basic options"""
        # create parser
        parser = super(CoreProgram, self).get_argparser()

        parser.description = "Run unit tests on core components"
        parser.add_help = True
        return parser

    def run(self):
        """Run the program"""
        # create the runner
        runner = unittest.TextTestRunner(
            verbosity=self.options.verbosity,
        )

        # automatically discover test cases in the package
        suite = unittest.TestLoader().discover(os.path.dirname(__file__))

        # run tests
        self.results = runner.run(suite)
        return self.results.wasSuccessful()


main = CoreProgram
