# -*- coding: utf-8 -*-

"""Provide tests for engine.core.technology"""

# Standard libraries
import os
import unittest

# Project imports
from engine import logger
from engine.core import extracts, review, technology


class TechnologyTestCase(unittest.TestCase):
    """Test the Technology class"""

    def make_tech(self, name, dct):
        """Create a new Technology class or retrieve one"""
        # try to retrieve
        for cls in technology.Technology.plugins():
            if cls.__name__ == name:
                return cls

        cls = type(name, (technology.Technology,), dct)
        # patch the class to make inspect identify the class
        # as being defined in this file
        cls.__module__ = self.__module__
        return cls

    def setUp(self):
        """Fix Technology for testing purposes"""
        # disable logger
        logger.setup(None)

        # create an extract for the test tech
        self.extracts = extracts.Extracts(
            b"""
===== Title 1 =====
--=== Title 1.1 ===--
Content 1.1
""",
        )

        # empty plugins for the test
        self.saved_plugins = technology.Technology.plugins()
        for p in self.saved_plugins:
            technology.Technology.unregister(p)

        def raise_exception():
            raise RuntimeError("Error in the filter")

        self.test_class = self.make_tech(
            "TestTech",
            {
                "raw": lambda self, ext: b"raw - " + ext,
                "decoder": lambda self, ext: "decoder - " + ext.decode("utf-8"),
                "error": lambda self, ext: raise_exception(),
            },
        )
        self.test_instance = self.test_class(self.extracts)

    def tearDown(self):
        """Clear the test environment"""
        # restore the saved plugins
        for p in technology.Technology.plugins():
            technology.Technology.unregister(p)
        for p in self.saved_plugins:
            technology.Technology.register(p)

    def test_init(self):
        """Ensure the class is correctly initialized"""
        self.assertEqual(self.test_instance.extracts, self.extracts)
        self.assertEqual(len(self.test_instance.errors), 0)

    def test_name(self):
        """Check the name of the tech is correctly resolved"""
        # explicit naming
        cls = self.make_tech("Tech", {"desc": {"name": "ExplicitName"}})
        self.assertEqual(cls.name, "ExplicitName")

        # automatic resolution
        for name in [
            "ImplicitName",
            "ImplicitNameTech",
            "ImplicitNameTechs",
            "ImplicitNameTechnology",
            "ImplicitNameTechnologies",
        ]:
            cls = self.make_tech(name, {})
            self.assertEqual(cls.name, "implicitname")

        # ensure no exception is raised when desc is present but not
        # the key name
        cls = self.make_tech("ImplicitName", {"desc": {}})
        self.assertEqual(cls.name, "implicitname")

    def test_get_by_name(self):
        """Check the retrieval of Technology from its name"""
        # create sub technologies
        tech1 = self.make_tech("Tech1", {})
        tech2 = self.make_tech("Tech2", {})
        tech3 = self.make_tech("Tech3", {})

        # check the retrieval
        self.assertIs(technology.Technology.get_by_name("tech1"), tech1)
        self.assertIs(technology.Technology.get_by_name("tech2"), tech2)
        self.assertIs(technology.Technology.get_by_name("tech3"), tech3)
        self.assertIs(technology.Technology.get_by_name("unknown"), None)

    def test_layout(self):
        """Check the layout of the tech is correctly resolved"""
        # retrieve the absolute path of the current directory
        path = os.path.abspath(os.path.dirname(__file__))

        # explicit relative definition
        cls = self.make_tech("Explicit1", {"desc": {"layout": "explicit"}})
        self.assertEqual(cls.layout, {None: os.path.join(path, "explicit")})
        # explicit absolute definition
        cls = self.make_tech(
            "Explicit2",
            {
                "desc": {
                    "layout": os.path.join(path, "Explicit", "path"),
                },
            },
        )
        self.assertEqual(cls.layout, {None: os.path.join(path, "Explicit", "path")})

        # automatic resolution
        cls = self.make_tech("Implicit1", {})
        self.assertEqual(cls.layout, {None: os.path.join(path, "implicit1.json")})

        # automatic resolution with explicit name
        cls = self.make_tech("ExplicitN", {"desc": {"name": "explicitname"}})
        self.assertEqual(cls.layout, {None: os.path.join(path, "explicitname.json")})

        # ensure no exception is raised when desc is present but not
        # the key layout
        cls = self.make_tech("Implicit2", {"desc": {}})
        self.assertEqual(cls.layout, {None: os.path.join(path, "implicit2.json")})

    def test_default_filter(self):
        """Check the default filter"""
        # test basic bytes
        extract = b"Extract content"
        self.assertEqual(
            self.test_instance.default_filter(extract),
            "[codeblock]Extract content[/codeblock]",
        )
        # test bytes with utf-8 errors
        extract = b"Extract \xC2\xC2co\xC2ntent"
        self.assertEqual(
            self.test_instance.default_filter(extract),
            "[codeblock]Extract content[/codeblock]",
        )
        # test a str
        extract = "Extract content"
        self.assertEqual(
            self.test_instance.default_filter(extract),
            "[codeblock]Extract content[/codeblock]",
        )

    def test_run_filter(self):
        """Check run_filter()"""
        # check None is return on unknown extracts
        self.assertIsNone(
            self.test_instance.run_filter("filter", "unknown"),
            msg="run_filter() should return None on unknown extract",
        )

        # Check filtering
        rev = self.test_instance.run_filter("decoder", "Title 1.1")
        self.assertIsInstance(rev, review.Review)
        self.assertIsInstance(rev.review, type(""))
        self.assertEqual(rev.review, "decoder - Content 1.1\n")
        self.assertEqual(len(self.test_instance.errors), 0)
        self.assertFalse(self.test_instance.has_errors)

        # Check unknown filters use the default filter
        rev = self.test_instance.run_filter("unknown", "Title 1.1")
        self.assertIsInstance(rev, review.Review)
        self.assertIsInstance(rev.review, type(""))
        self.assertEqual(
            rev.review,
            self.test_instance.default_filter(b"Content 1.1\n"),
        )
        self.assertEqual(len(self.test_instance.errors), 0)
        self.assertFalse(self.test_instance.has_errors)

        # Check empty filters use the default filter
        rev = self.test_instance.run_filter("", "Title 1.1")
        self.assertIsInstance(rev, review.Review)
        self.assertIsInstance(rev.review, type(""))
        self.assertEqual(
            rev.review,
            self.test_instance.default_filter(b"Content 1.1\n"),
        )
        self.assertEqual(len(self.test_instance.errors), 0)
        self.assertFalse(self.test_instance.has_errors)

        # Check not decoded extract are decoded
        rev = self.test_instance.run_filter("raw", "Title 1.1")
        self.assertIsInstance(rev, review.Review)
        self.assertIsInstance(rev.review, type(""))
        self.assertEqual(rev.review, "raw - Content 1.1\n")
        self.assertEqual(len(self.test_instance.errors), 0)
        self.assertFalse(self.test_instance.has_errors)

        # Check the behavior when error are raised on filters
        rev = self.test_instance.run_filter("error", "Title 1.1")
        self.assertIsInstance(rev, review.Review)
        self.assertIsInstance(rev.review, type(""))
        self.assertEqual(
            rev.review,
            self.test_instance.default_filter(b"Content 1.1\n"),
        )
        self.assertEqual(len(self.test_instance.errors), 1)
        self.assertTrue(self.test_instance.has_errors)
