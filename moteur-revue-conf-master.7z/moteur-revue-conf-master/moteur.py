#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""This programs only dispatch calls to the cli handler of the engine"""

# Standard libraries
import sys

# ensure python 3 is used to start the engine
if sys.version_info < (3, 0):
    print(
        "Le moteur n’est plus compatible avec Python 2. Merci de le "
        "lancer avec Python 3 :\n\n"
        "python3 %s\n" % " ".join(sys.argv),
    )
    sys.exit(1)


# Project imports
from engine import cli  # noqa: E402

if cli.main():
    sys.exit(0)
else:
    sys.exit(1)
