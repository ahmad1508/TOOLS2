#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""This programs only dispatch calls to the test program"""

# Project imports
from tests.main import main

if __name__ == "__main__":
    main()
