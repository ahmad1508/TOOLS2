#!/bin/ksh

#------------------------------------------------------------------------------
# Script d'audit système AIX
#------------------------------------------------------------------------------
# v1.0   - 15/10/08 - Création
# v1.1   - 23/12/09 - Modifications - VLM
# v2.0   - 17/11/10 - Adaptation au nouveau format des scripts - JMI
# v2.0.1 - 25/11/12 - Modifications mineures (lsof et bootlist) - JMI
# v2.1   - 10/11/16 - Modifs mineures
#------------------------------------------------------------------------------


echo ""
echo "Attention, l'execution du script peut parfois etre lente (attente de RPC, important nombre de fichiers)."
echo "En cas d'execution anormalement longue, arreter le script et regarder quelle est la derniere commande executee, grace à la derniere info produite dans le fichier de resultats"
echo ""

fichierRes="Wavestone_Audit_AIX.res" 
fichierResCorrectifs="Wavestone_Audit_AIX_CORRECTIFS.res" 

function ecrireTitreSection {
	echo "===== $1 =====" >> $fichierRes
}

function ecrireDescription {
	echo "--=== $1 ===--" >> $fichierRes
}

function ecrire {
	echo "-- $1 --" >> $fichierRes
}

# verifier que l on est root
uid=`id -u`
if [[ "$uid" != "0" ]];
then
	echo "Ce script necessite les droits d'administateur"
	echo "Voulez vous continuer ? (o/N)"
	read rep
	if [[ "$rep" != "o" ]];
	then
		exit 0;
	fi;
fi

# renice du processus pour ne pas affecter les autres services
echo "Souhaitez vous diminuer la priorite du processus afin de"
echo "ne pas impacter les autres services ? (o/N)"
read rep
if test "$rep" = "o"
then
	renice 19 -p $$
fi

echo ""
echo "--------------------------------------------------------"
echo "Début du script"
echo "--------------------------------------------------------"
echo ""

rm -fr $fichierRes
rm -fr $fichierResCorrectifs


#--- Identification du serveur -------------------------------------------------
ecrireTitreSection "Identification du serveur"
echo " - Identification du serveur"

ecrireDescription "Hostname"
hostname >> $fichierRes 2>&1

ecrireDescription "Version noyau et version OS"
uname -r >> $fichierRes 2>&1

ecrireDescription "information sur l'OS"
oslevel -r >> $fichierRes 2>&1

ecrireDescription "Liste des cartes reseau"
lspci >> $fichierRes 2>&1

ecrireDescription "Configuration reseau"
ifconfig -a >> $fichierRes 2>&1

ecrireDescription "Serveurs DNS"
cat /etc/resolv.conf >> $fichierRes 2>&1

ecrireDescription "Information boot"
bootinfo -r >> $fichierRes 2>&1

ecrireDescription "Information Systeme 1"
lsattr -E -l sys0 >> $fichierRes 2>&1

ecrireDescription "Information Systeme 2"
lsps -s >> $fichierRes 2>&1

ecrireDescription "Peripheriques"
lsdev -C >> $fichierRes 2>&1

ecrireDescription "Disques physiques"
lspv >> $fichierRes 2>&1

ecrireDescription "Partitionnement"
df -k >> $fichierRes 2>&1

ecrireDescription "Points de Montage"
mount >> $fichierRes 2>&1

ecrireDescription "BootLoader"
bootlist -o -m normal >> $fichierRes 2>&1

ecrireDescription "Processus en cours"
ps -Aedf >> $fichierRes 2>&1


#--- Version / Patches ---------------------------------------------------------
ecrireTitreSection "Versions / Patches"
echo " - Versions / Patches"

ecrireDescription "Correctifs"
ecrire "instfix - voir le fichier complentaire Wavestone_Audit_AIX_CORRECTIFS.res"
instfix -i >> $fichierResCorrectifs 2>&1
ecrire "plus d'autres infos sur les correctifs"
ecrire "RMP"
rpm -qa >> $fichierRes 2>&1
ecrire "EMGR"
emgr -l >> $fichierRes 2>&1

ecrireDescription "Mises à jour possibles ?"
oslevel -rq >> $fichierRes 2>&1

ecrireDescription "Liste paquets installés"
lslpp -L all >> $fichierRes 2>&1



#--- Compte ROOT ---------------------------------------------------------------
ecrireTitreSection "Analyse de la configuration du compte root"
echo " - Analyse de la configuration du compte root"

ecrireDescription "Contenu du fichier /etc/security/user"
cat /etc/security/user  >> $fichierRes 2>&1

ecrireDescription "Path de root"
# Vérifier que le "." n'est pas présent
echo $PATH >> $fichierRes 2>&1

ecrireDescription "Emplacement home dir de root"
grep "root:" /etc/passwd | head -n1 | cut -d":" -f6 >> $fichierRes 2>&1

ecrireDescription "Contenu home dir de root"
ls -al `grep root /etc/passwd | head -n1 | cut -d":" -f6` >> $fichierRes 2>&1

ecrireDescription "Verification absence de rhost"
ls -al `grep root /etc/passwd | head -n1 | cut -d":" -f6` | grep rhosts >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/sudoers"
more /etc/sudoers >> $fichierRes 2>&1
more /usr/local/etc/sudoers  >> $fichierRes 2>&1



#--- Comptes utilisateurs et système -------------------------------------------
ecrireTitreSection "Comptes utilisateurs et système"
echo " - Comptes utilisateurs et système"

ecrireDescription "Cohérence des fichiers passwd et shadow"
pwck >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier passwd - /etc/passwd"
cat /etc/passwd >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier shadow - /etc/security/passwd"
cat /etc/security/passwd >> $fichierRes 2>&1

ecrireDescription "Nombre de compte sans mot de passe sur /etc/passwd"
cat /etc/passwd | cut -d":" -f2 | grep "\*" | wc -l >> $fichierRes 2>&1

ecrireDescription "Nombre de compte sans mot de passe sur /etc/security/passwd"
cat /etc/security/passwd | grep "password = *" | wc -l >> $fichierRes 2>&1

ecrireDescription "Existence d'un shell non fonctionnel pour les comptes systèmes"
cat /etc/passwd | grep "/bin/false" >> $fichierRes 2>&1

ecrireDescription "Absence d'utilisateurs ayant le meme uid"
cat /etc/passwd | cut -d":" -f3 | sort -n | uniq -d >> $fichierRes 2>&1

ecrireDescription "Uid des utilisateurs dans une plage distincte (> 1000)"
cat /etc/passwd | cut -d":" -f1,3 >> $fichierRes 2>&1

ecrireDescription "Absence de répertoires de connexion communs entre plusieurs utilisateurs"
cat /etc/passwd | cut -d":" -f6 | sort | uniq -d >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/security/.profile"
cat /etc/security/.profile >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/group"
cat /etc/group >> $fichierRes 2>&1

ecrireDescription "Nombre de groupes minimisés"
wc -l /etc/group >> $fichierRes 2>&1

ecrireDescription "Entrées commençant pas + dans /etc/group"
cat /etc/group | grep "^+" >> $fichierRes 2>&1

ecrireDescription "Erreurs dans le fichier /etc/group"
grpck -n ALL >> $fichierRes 2>&1

ecrireDescription "Message de démarrage MOTD"
cat /etc/motd >> $fichierRes 2>&1

ecrireDescription "Message d'avertissement herald dans /etc/security/login.cfg"
cat /etc/security/login.cfg | grep "herald" >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /usr/lib/security/mkuser.default"
cat /usr/lib/security/mkuser.default >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/security/.profile"
cat /etc/security/.profile >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/security/user"
cat /etc/security/user >> $fichierRes 2>&1

ecrireDescription "Desactivation du compte après n connexions infructueuses" # Reco = 5
grep loginretries /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep loginretries /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Expiration des compte" # Reco = 4 (soit 1 mois)
grep maxexpired /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep maxexpired /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/profile"
cat  /etc/profile >> $fichierRes 2>&1



#--- Politique de mots de passe ------------------------------------------------
ecrireTitreSection "Politique de mots de passe"
echo " - Politique de mots de passe"

ecrireDescription "Contenu du fichier /etc/pam.conf - PAM"
cat /etc/pam.conf >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /usr/lib/security/methods.cfg - LAM"
# Ce fichier contient tout le paramétrage du module LAM (ancienne version AIX 5.2 de PAM).
# Si ce module est utilisé les fonctions suivantes ne marcherons plus, il faudra regarder
# le paramétrage manuellement.
cat /usr/lib/security/methods.cfg >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/security/login.cfg"
# vérifier le paramètre auth_type (STD_AUTH ou PAM_AUTH en fonction de l'élément prioritaire)
cat /etc/security/login.cfg >> $fichierRes 2>&1

ecrireDescription "Paramètre AUTH_TYPE"
cat /etc/security/login.cfg | grep "auth_type" >> $fichierRes 2>&1

# Il est intéréssant de repérer les lignes suivantes pour contrôler la politique
# de mots de passe appliquée sur PAM:
#      password required pam_cracklib.so retry=3 minlen=6 difok=3
#      password required pam_unix.so md5 use_authtok
ecrireDescription "Liste des fichiers /usr/lib/security/pam*"  
ls -la /usr/lib/security/pam* >> $fichierRes 2>&1

ecrireDescription "Contrôle du nombre de caractères différents" # Reco = 2 (difork)
grep "password required" /etc/pam.conf >> $fichierRes 2>&1

ecrireDescription "Algorithme de hashage des mots de passe"
more /usr/lib/security/pam* | grep "password required pam_unix.so" >> $fichierRes 2>&1

ecrireDescription "Contrôle de la longueur minimale" # Reco = 8
grep minlen /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep minlen /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Contrôle de l'historique des mots de passe " # Reco = 5
grep histsize /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep histsize /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Recuperation de l'unité de calcul des param de frequence de changement"
# On vérifie dans le fichier /etc/security/user si minage et maxage sont en 'days' ou en 'weeks'
grep -e'^* maxage' /etc/security/user | grep "weeks" >> $fichierRes 2>&1
grep -e'^* maxage' /etc/security/user | grep "days" >> $fichierRes 2>&1

ecrireDescription "Contrôle de la fréquence de changement" # Reco = 14 (minage) et 56 (maxage) jours
grep minage /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep minage /etc/security/user | grep -v "^*" >> $fichierRes 2>&1
grep maxage /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep maxage /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Message de prévention avant obligation de changement" # Reco = 7 (une semaine)
grep pwdwarntime /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep pwdwarntime /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Contrôle de la complexité (fichiers système, non PAM)"
grep minalpha  /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep minalpha  /etc/security/user | grep -v "^*" >> $fichierRes 2>&1
grep minother   /usr/lib/security/mkuser.default | grep -v "^*" >> $fichierRes 2>&1
grep minother   /etc/security/user | grep -v "^*" >> $fichierRes 2>&1

ecrireDescription "Contrôle de l'application de la politique à tous" # Reco = aucun retour
grep "NOCHECK" /etc/security/passwd >> $fichierRes 2>&1
grep "NOCHECK" /etc/default/passwd >> $fichierRes 2>&1



#--- Journaux ------------------------------------------------------------------
ecrireTitreSection "Journaux"
echo " - Journaux"

ecrireDescription "Etat de Syslog"
ps -ef | grep syslog | grep -v "grep" >> $fichierRes 2>&1

ecrireDescription "Types d'événements journalisés"
more /etc/*syslog.conf >> $fichierRes 2>&1

ecrireDescription "Contenu du dossier /var/log"
# Attention, il faudrait peut être améliorer le script en lisant le contenu des fichiers
# syslog.conf et en allant chercher dans les rep correspondants
ls -RAl /var/log >> $fichierRes 2>&1



#--- Ordonanceurs cron et at ---------------------------------------------------
ecrireTitreSection "Ordonanceurs cron et at"
echo " - Ordonanceurs cron et at"

ecrireDescription "Panorama des fichiers /var/adm/cron*"
# Vérifier ici les droits d'accès des utilisateurs - Interdit !
ls -RAl /var/adm/cron* >> $fichierRes 2>&1

ecrireDescription "Contenu des fichiers cron"
more /var/adm/cron/cron* >> $fichierRes 2>&1

ecrireDescription "Panorama des fichiers /var/adm/at*"
# Vérifier ici les droits d'accès des utilisateurs - Interdit !
ls -RAl /var/adm/at* >> $fichierRes 2>&1

ecrireDescription "Contenu des fichiers at"
more /var/adm/cron/at* >> $fichierRes 2>&1

ecrireDescription "Utilisation de cron interdite aux utilisateurs"
more /var/adm/cron/cron.allow >> $fichierRes 2>&1
more /var/adm/cron/cron.deny >> $fichierRes 2>&1

ecrireDescription "Contenu du spool de cron et de at"
more /var/spool/cron/*/* >> $fichierRes 2>&1



#--- Réseau --------------------------------------------------------------------
ecrireTitreSection "Réseau"
echo " - Réseau"

ecrireDescription "Services - Netstat"
netstat -na -f inet >> $fichierRes 2>&1

ecrireDescription "Services - Lsof"
lsof -i >> $fichierRes 2>&1

ecrireDescription "Services en écoute - Netstat"
netstat -na -f inet | grep LISTEN >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/rc.tcpip (demons lancés au démarrage)"
cat /etc/rc.tcpip >> $fichierRes 2>&1

ecrireDescription "Configuration de RPC"
rpcinfo -p >> $fichierRes 2>&1

ecrire "Verification du demarrage du démon inetd"
grep inetd /etc/rc.tcpip  >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/inetd.conf"
more /etc/inetd.conf >> $fichierRes 2>&1

ecrireDescription "Configuration complete de NO (Configuration courante de la couche réseau au niveau du noyau)"
no -a  >> $fichierRes 2>&1

ecrireDescription "Extracts de la configuration de no"
no -a | grep bcastping >> $fichierRes 2>&1
no -a | grep clean_partial_conns >> $fichierRes 2>&1
no -a | grep ipforwarding >> $fichierRes 2>&1
no -a | grep ipignoreredirects   >> $fichierRes 2>&1
no -a | grep ipsendredirects >> $fichierRes 2>&1
no -a | grep ipsrcrouterecv >> $fichierRes 2>&1
no -a | grep ipsrcrouteforward >> $fichierRes 2>&1
no -a | grep ip6srcrouteforward >> $fichierRes 2>&1
no -a | grep icmpaddressmask >> $fichierRes 2>&1
no -a | grep nonlocsrcroute >> $fichierRes 2>&1
no -a | grep tcp_pmtu_discover >> $fichierRes 2>&1
no -a | grep udp_pmtu_discover   >> $fichierRes 2>&1
no -a | grep tcp_icmpsecure >> $fichierRes 2>&1

ecrireDescription "Vérification de l'activation de NFS"
lssrc -g nfs >> $fichierRes 2>&1

ecrireDescription "Configuration des exports NFS (/etc/exports)"
# Controler les options ro (OK), localhost (NOK), secure (OK), root_squash (OK), * (NOK)
more /etc/exports >> $fichierRes 2>&1

ecrireDescription "Vérification de l'activation de SSH"
ps -eaf | grep ssh | grep -v "grep" >> $fichierRes 2>&1

ecrireDescription "Configuration de SSH"
# Vérifier les paramètres suivants :
#    PermitRootLogin = no
#    PermitEmptyPasswords = no
#    RhostsRSAAuthentication = no
#    HostbasedAuthentication = no
#    RhostsAuthentication = no
#    IgnoreRhosts = yes
#    X11Forward = yes
#    Protocol = 2
more /etc/sshd_config /usr/local/etc/sshd_config /etc/ssh/sshd_config >> $fichierRes 2>&1



#--- Fichiers systèmes ---------------------------------------------------------
ecrireTitreSection "Fichiers systèmes"
echo " - Fichiers systèmes"

ecrireDescription "Droits sur les fichiers et repertoires de la racine"
ls -Al / >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/netgroup"
more /etc/netgroup >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/host.equiv"
more /etc/hosts.equiv   >> $fichierRes 2>&1

ecrireDescription "Contenu du fichier /etc/host.lpd"
more /etc/hosts.lpd   >> $fichierRes 2>&1

ecrireDescription "Panorama des fichiers /etc/hosts*"
ls -RAl /etc/hosts* >> $fichierRes 2>&1

ecrireDescription "Contenu des fichiers /etc/hosts*"
more /etc/hosts* >> $fichierRes 2>&1

ecrireDescription "Niveaux de umask"
grep umask /etc/profile >> $fichierRes 2>&1

ecrireDescription "Abscence de fichier .rhosts et .netrc"
for i in `cut -d":" -f6 /etc/passwd` ; do ls -al $i | grep rhosts; done >> $fichierRes 2>&1
for i in `cut -d":" -f6 /etc/passwd` ; do ls -al $i | grep netrc; done  >> $fichierRes 2>&1

ecrireDescription "Contrôle de l'activation de sendmail"
lssrc -g mail >> $fichierRes 2>&1

ecrireDescription "Sendmail aliases"
more /etc/aliases /etc/mail/aliases >> $fichierRes 2>&1



#--- Propriétés et permissions sur les fichiers et répertoires -----------------
ecrireTitreSection "Propriétés et permissions sur les fichiers et répertoires"
echo ""
echo "Extraction des configurations terminée"
echo "La suite parcours l'ensemble de l'arboréscence, cela peut peut prendre du temps"
echo "Il est néanmoins possible de killer le script si celui-ci dure trop longtemps (présence de montages NFS par exemple)"
echo ""
echo " - Propriétés et permissions sur les fichiers et répertoires"

echo "   - Répertoires  et fichiers système"
ecrireDescription "Répertoires système" # Reco = propriété de root et droits corrects (750)
ls -ld /bin >> $fichierRes 2>&1
ls -ld /dev >> $fichierRes 2>&1
ls -ld /etc  >> $fichierRes 2>&1
ls -ld /sbin >> $fichierRes 2>&1
ls -ld /usr/etc >> $fichierRes 2>&1
ls -ld /usr/bin >> $fichierRes 2>&1
ls -ld /usr/sbin >> $fichierRes 2>&1

ecrireDescription "Répertoires du PATH de root" # Reco = propriété de root et droits corrects (750)
ls -ld `echo $PATH |tr ':' ' '` >> $fichierRes 2>&1

ecrireDescription "Fichiers de configurations spécifiques"
# Reco = propriété des utilisateurs adéquats et droits corrects limités à ceux-ci (640)
ls -al /etc/utmp >> $fichierRes 2>&1
ls -al /etc/motd >> $fichierRes 2>&1
ls -al /etc/mtab >> $fichierRes 2>&1
ls -al /etc/exports >> $fichierRes 2>&1
ls -al /etc/syslog.pid >> $fichierRes 2>&1
ls -al /var/adm/wtmp >> $fichierRes 2>&1 
ls -al /etc/securetty >> $fichierRes 2>&1

ecrireDescription "Abscence des droits d'écriture pour root" # Reco = 440
ls -al /etc/passwd >> $fichierRes 2>&1
ls -al /etc/services  >> $fichierRes 2>&1
ls -al /etc/inittab  >> $fichierRes 2>&1
ls -al /etc/group >> $fichierRes 2>&1
ls -al /etc/profile >> $fichierRes 2>&1
ls -al /etc/mail/aliases >> $fichierRes 2>&1
ls -al /vmunix >> $fichierRes 2>&1

ecrireDescription "Abscence des droits d'écriture pour les utilisateurs" # Reco = 400 et a minima xx0
ls -al /etc/inetd.conf >> $fichierRes 2>&1
ls -al /etc/security/passwd >> $fichierRes 2>&1
ls -al /etc/hosts.equiv >> $fichierRes 2>&1
ls -al /etc/hosts.lpd >> $fichierRes 2>&1
ls -al /etc/login.access >> $fichierRes 2>&1
ls -al /etc/login.conf >> $fichierRes 2>&1
ls -al /etc/login.defs >> $fichierRes 2>&1
ls -al /etc/netgroup >> $fichierRes 2>&1
ls -al /etc/security >> $fichierRes 2>&1
ls -al /var/log/* >> $fichierRes 2>&1
ls -al /var/adm/messages >> $fichierRes 2>&1
ls -al /var/adm/utmpx >> $fichierRes 2>&1
ls -al /var/adm/wtmpx >> $fichierRes 2>&1
ls -al /var/cron/log >> $fichierRes 2>&1
ls -al /var/adm/cron/* >> $fichierRes 2>&1

ecrireDescription "Seuls les propriétaires ont accès à leurs fichiers"  # Reco = 700
ls -ld `cut -d: -f6 /etc/passwd | sort -u` >> $fichierRes 2>&1

echo "   - Fichiers des utilisateurs supprimés"
ecrireDescription "Verification que les fichiers utilisateurs sont bien supprimés lors de la suppression du compte"
find / \( -nouser -o -nogroup \) -exec ls -ld {} \; >> $fichierRes 2>&1

echo "   - Répertoires et fichiers en écriture pour tous"
ecrireDescription "Contrôle des répertoires autorisés en écriture pour tous sans le sticky-bit" # Reco = aucun
find / -type d -perm -2 ! -perm -1000 -print >> $fichierRes 2>&1

ecrireDescription "Contrôle des fichiers autorisés en écriture pour tous sans le sticky-bit"
find / -type f -perm -2 -exec ls -ld {} \; >> $fichierRes 2>&1

echo "   - Fichiers de root avec le SUID bit activé"
ecrireDescription "Contrôle des fichiers de root avec le SUID bit activé en execution"
find / -type d -perm -4000 -exec ls -ld {} \; >> $fichierRes 2>&1

echo "   - Fichiers de root avec le SGID bit activé"
ecrireDescription "Contrôle des fichiers de root avec le SGID bit activé en execution"
find / -type d -perm -2000 -exec ls -ld {} \; >> $fichierRes 2>&1



#--- Parcours de l'arborescence ------------------------------------------------
#ecrireTitreSection "Parcours de l'arborescence"
#echo "Parcours de l'arborescence"

#ecrireDescription "Droits sur les fichiers et repertoires"
#ls -RAl / >> $fichierRes 2>&1


#--- Fin du script d'extraction ------------------------------------------------
ecrireDescription "EoF"


echo ""
echo "--------------------------------------------------------"
echo "L'audit du système est terminé."
echo "Les fichiers générés sont dans le répertoire actuel:"
echo $fichierRes
echo $fichierResCorrectifs
echo "--------------------------------------------------------"
