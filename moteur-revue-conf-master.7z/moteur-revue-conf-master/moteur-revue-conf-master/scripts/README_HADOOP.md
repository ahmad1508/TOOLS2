# HADOOP

## PREREQUIS

Le script `script_hadoop.sh` doit être lancé avec les droits root sur les
serveurs sur lesquels tournent les composants audités.

## CHOIX DES COMPOSANTS AUDITES

Dans les premières lignes du code, les variables suivantes permettent de
choisir les configurations que l'on souhaite extraire :

- core_hadoop : configuration Hadoop Core dont HDFS, MapReduce et YARN;
- hbase : HBase;
- knox : Apache Knox;
- ranger : Apache Ranger;
- hive : Apache Hive;
- kafka : Kafka;
- zookeeper : Zookeeper. Il suffit de mettre à "1" la variable pour que la
  configuration soit extraite, ou à "0" pour qu'elle ne le soit pas.

## PLAN B : LE SCRIPT NE TROUVE PAS LES FICHIERS DE CONFIGURATION

Dans le cas où le script n'arrive pas à trouver les fichiers de configuration,
il sera demandé à l'utilisateur du script s'il souhaite générer la liste des
fichiers présents sur le serveur. Cette liste pourra être utilisée par
l'auditeur pour identifier la localisation des fichiers de configuration.

## FICHIERS DE CONFIGURATION DONNEES DIRECTEMENT

Dans le cas où les fichiers de configuration soient donner directement à
l'auditeur, ce dernier pourra décommenter la partie "A décommenter pour lui
fournir les fichiers de configuration en paramètres :" et renseigner les
fichiers de configuration en paramètres du script. Veuillez trouver ci-dessous
la correspondance entre les variables et les fichiers de configuration :

- core_site : core-site.xml
- hadoop_policy : hadoop-policy.xml
- hdfs_site : hdfs-site.xml
- mapred_site : mapred-site.xml
- yarn_site : yar-site.xml
- hbase_site : hbase-site.xml
- gateway_site : gateway-site.xml
- gateway_log4j : log4j.properties
- ranger_admin_site : ranger-admin-site.xml
- hive_site : hive-site.xml
- kafka_properties : kafka.properties (ou bien server.properties ou autre)
- kafka_log4j : log4j.properties
- zoo_cfg : zoo.cfg
- zoo_log4j : log4j.properties

Il est interessant de faire exécuter le script sur les serveurs même si les
fichiers de configuration sont données directement car d'autres actions sont
réalisées par le script pour récolter des informations n'étant pas présentes
dans les fichiers de configuration.

## TIPS :

Il peut être interessant de faire tourner le script sur plusieurs serveurs
Hadoop (par exemple un DataNode, un NameNode, un EdgeNode) pour s'assurer
notamment que les droits sur les keytabs sont bien restreints sur tous les
serveurs.
