#!/bin/ksh

#------------------------------------------------------------------------------
# Script d'audit Base de donnée Oracle
#------------------------------------------------------------------------------
# v1.0 - Création (JMI)
#------------------------------------------------------------------------------

fichierRes="Wavestone_Audit_OracleDB_OS.res"

function ecrireTitreSection {
	echo "===== $1 =====" >> $fichierRes
}

function ecrireDescription {
	echo "--=== $1 ===--" >> $fichierRes
}

function ecrire {
	echo "-- $1 --" >> $fichierRes
}

echo ""
echo "--------------------------------------------------------"
echo "Début du script"
echo "--------------------------------------------------------"
echo ""

rm -fr $fichierRes


#--- Identification du serveur -------------------------------------------------
ecrireTitreSection "Identification du serveur"
echo " - Identification du serveur"

ecrireDescription "Hostname"
hostname >> $fichierRes 2>&1

ecrireDescription "Version noyau et version OS"
uname -r >> $fichierRes 2>&1
uname -a >> $fichierRes 2>&1

ecrireDescription "Configuration réseau"
ifconfig -a >> $fichierRes 2>&1

ecrireDescription "Compte Utilisateur utilisé pour lancer le script"
whoami >> $fichierRes 2>&1

ecrireDescription "Variables d'environnement Oracle"
env|grep ORACLE >> $fichierRes 2>&1



#--- Configuration Oracle -------------------------------------------------------
ecrireTitreSection "Configuration Oracle"
echo " - Configuration Oracle"

ecrireDescription "Version et patchs déployés"
opatch lsinventory -detail >> $fichierRes 2>&1

ecrireDescription "Liste des processus en écoute réseau (TCP)"
netstat -ntlpg >> $fichierRes 2>&1

ecrireDescription "Processus"
# Pour voir les utilisateurs qui lancent le service
ps -ef >> $fichierRes 2>&1

ecrireDescription "Configuration des utilisateurs"
cat /etc/passwd >> $fichierRes 2>&1

ecrireDescription "Liste des bases actives"
ps -aux | grep pmon >> $fichierRes 2>&1

ecrireDescription "Informations sur les Listeners démarrés"
lsnrctl status >> $fichierRes 2>&1

ecrireDescription "Version des Listeners"
lsnrctl version >> $fichierRes 2>&1

ecrireDescription "Services des Listeners"
lsnrctl services >> $fichierRes 2>&1

ecrireDescription "Droits et contenu des fichiers listener.ora"
find / -name listener*.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null

ecrireDescription "Contenu et droits sur les fichiers oracle"
ls -Rla $ORACLE_HOME >> $fichierRes 2>&1

ecrireDescription "Droits et contenu des fichiers init.ora"
find / -name init.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null

ecrireDescription "Droits et contenu des fichiers sqlnet.ora"
find / -name sqlnet.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null

ecrireDescription "Droits et contenu des fichiers tnsnames.ora"
find / -name tnsnames.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null

ecrireDescription "Droits et contenu des fichiers listener.ora"
find / -name listener.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null

ecrireDescription "Droits et contenu des fichiers spfile<SID>.ora"
find / -name spfile*.ora -exec echo '==============' \; -exec ls -ld {} \; -exec cat {} \; >> $fichierRes 2>>/dev/null
echo >> $fichierRes 2>&1


#--- Fin du script d'extraction ------------------------------------------------
ecrireDescription "EoF"

echo ""
echo "--------------------------------------------------------"
echo "L'audit de l'application est terminé."
echo "Les fichiers générés sont dans le répertoire actuel:"
echo $fichierRes
echo "--------------------------------------------------------"
