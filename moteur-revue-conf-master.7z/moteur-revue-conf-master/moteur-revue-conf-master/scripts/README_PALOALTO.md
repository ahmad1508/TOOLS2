# Palo Alto

## Notes générales

Le moteur Palo Alto se base sur le format d’export de configuration embarqué
sur le pare-feu. Il n’y a aucun script à faire tourner.

## Comment extraire la configuration

Pour plus de détails, se référer à la [documentation officielle][doc].

### Via l’interface graphique

1. Aller sur _Device > Setup > Operation > Export named configuration snapshot_
2. Enregistrer la configuration actuelle et la transmettre aux auditeurs

### Via la CLI

Exécuter les commandes suivantes :

```
> configure
# save config to CurrentConfig.xml
# exit
>
```

[doc]:
  https://knowledgebase.paloaltonetworks.com/KCSArticleDetail?id=kA10g000000ClaOCAS
