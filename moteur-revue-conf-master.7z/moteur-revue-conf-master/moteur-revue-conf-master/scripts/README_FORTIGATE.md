# FortiGate

## Notes générales

Le moteur FortiGate se base sur le format d’export de configuration embarqué
sur le pare-feu. Il n’y a aucun script à faire tourner.

## Comment extraire la configuration

Pour plus de détails, se référer à la [documentation officielle][doc].

### Via l’interface graphique

Pour les versions les plus récentes (FortiOS 5.6+) :

1. Aller sur _Admin > Configuration > Backup_
2. Enregistrer la configuration actuelle et la transmettre aux auditeurs

[doc]: https://kb.fortinet.com/kb/documentLink.do?externalID=10063
