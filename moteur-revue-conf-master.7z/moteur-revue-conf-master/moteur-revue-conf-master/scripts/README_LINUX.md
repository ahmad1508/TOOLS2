# Linux

### Notes générales

vérifier que le fichier est bien exécutable. Dans le cas contraire, exécuter

```bash
chmod +x script_linux.sh
```

Le script doit être exécuté avec les droits root.

## Exécution

- Déposer le fichier sur le serveur distant
- Exécuter le script : `(sudo) ./script_linux.sh`
- Répondre aux différentes questions
- Récupérer le fichier `Wavestone_Audit_Linux.tar.gz`
- Extraire l'archive pour l'analyse avec le moteur

## Exécution sans interaction utilisateur

Il est également possible de lancer le script de manière non-interactive. Les
questions qui sont posées aux utilisateurs peuvent être activées au travers
d’options.

Pour une liste complète des options, il suffit d’exécuter :

```shell
./script_linux.sh -h
```
