#!/bin/bash

fichierRes="Wavestone_Audit_Hadoop.res"
fichierConf="Wavestone_Audit_Hadoop_Conf.res"
fichierFileSYS="Wavestone_Audit_Hadoop_FileSYS.res"

#############################################################
# Mettez à 0 les solutions que vous ne souhaitez pas auditer#
#############################################################
core_hadoop=1
hbase=1
knox=1
ranger=1
hive=1
kafka=1
zookeeper=1

function ecrireTitreSection {
	echo "===== $1 =====" >> $fichierRes
}

function ecrireDescription {
	echo "--=== $1 ===--" >> $fichierRes
}

function ecrire {
	echo "-- $1 --" >> $fichierRes
}

function topologie {
for filename in $1; do
	echo "" >> $2 2>&1
	echo "###################################################################" >> $2 2>&1
	echo "#$filename#" >> $2 2>&1
	echo "###################################################################" >> $2 2>&1
	echo "" >> $2 2>&1
	cat $filename 2>&1 | sed '/<!--.*-->/d' 2>&1 | sed '/<!--/,/-->/d' 2>&1 >> $2 2>&1
	echo "" >> $2 2>&1
	echo "" >> $2 2>&1
done
}

# verifier que l on est root
uid=`id | sed -n 's/.*uid=\([0-9][0-9]*\)(.*/\1/p'`
if test "$uid" -ne 0
then
	echo "Ce script necessite les droits d'administateur"
	echo "Voulez-vous continuer ? (o/N)"
	read rep
	if test "$rep" != "o"
	then
		exit 0
	fi
fi

# renice du processus pour ne pas affecter les autres services
echo "Souhaitez-vous diminuer la priorite du processus afin de"
echo "ne pas impacter les autres services ? (o/N)"
read rep
if test "$rep" = "o"
then
	renice 19 -p $$
fi

echo "Début du script"

# debut main

rm -fr $fichierRes
rm -fr $fichierConf
rm -fr $fichierFileSYS

# recherche fichiers de conf

if [ "$core_hadoop" -eq "1" ] || [ "$hbase" -eq "1" ] || [ "$hive" -eq "1" ] || [ "$ranger" -eq "1" ] || [ "$knox" -eq "1" ]
then
	chemin=`ps -aux 2>&1 | grep -oP '(?<=hadoop.home.dir=)[^\\ ]+' 2>&1 | head -n 1 2>&1`
	if [[ -d $chemin ]]
	then
		chemin=`ps -aux 2>&1 | grep -oP '(?<=hadoop.home.dir=)[^\\ ]+' 2>&1 | head -n 1 2>&1 | xargs dirname`
	fi
	if [[ ! -d $chemin ]]
	then
		chemin=$HADOOP_HOME
	fi
	if [[ ! -d $chemin ]]
	then
		echo "Le chemin vers le répertoire home de Hadoop n'a pas pu être identifié. Souhaitez-vous générer la liste des fichiers présents sur ce serveur afin que l'auditeur puisse l'utiliser pour identifier où sont placés les fichiers de configuration Hadoop ? [y/n]"
		echo ""
		read answer
		if [[ $answer = "y" ]]
		then
			fileSYS=y
			ls -RAl / >> $fichierFileSYS 2>&1
			echo "Fichier $fichierFileSYS généré."
			echo ""
		fi
	fi

	core_site=$chemin'/hadoop/conf/core-site.xml'
	hadoop_policy=$chemin'/hadoop/conf/hadoop-policy.xml'
	hdfs_site=$chemin'/hadoop/conf/hdfs-site.xml'
	mapred_site=$chemin'/hadoop/conf/mapred-site.xml'
	yarn_site=$chemin'/hadoop/conf/yarn-site.xml'
	hbase_site=$chemin'/hadoop/conf/hbase-site.xml'
	gateway_site=$chemin'/knox/conf/gateway-site.xml'
	gateway_log4j=$chemin'/knox/conf/gateway-log4j.properties'
	ranger_admin_site=$chemin'/ranger-admin/conf/ranger-admin-site.xml'
	hive_site=$chemin'/hive/conf/hive-site.xml'
fi

if [ "$kafka" -eq "1" ]
then
	kafka_properties=`ps -aux 2>&1 | grep kafka 2>&1 | grep -v grep 2>&1 | grep -oE '[^ ]+$' 2>&1`
	if [[ -f $kafka_properties ]]
	then
		kafka_log4j=`dirname $kafka_properties 2>&1`'/log4j.properties'
		kafka_home=`dirname $kafka_properties 2>&1 | xargs dirname 2>&1`
	fi
	if [[ ! -f $kafka_properties ]]
	then
		if [[ -d $KAFKA_HOME ]]
		then
			kafka_home=$KAFKA_HOME
			kafka_properties=$kafka_home'/config/server.properties'
			kafka_log4j=$kafka_home'/config/log4j.properties'
			if [ ! -f $kafka_properties ]
			then
				kafka_properties=$kafka_home'/conf/server.properties'
				kafka_log4j=$kafka_home'/conf/log4j.properties'
			fi
			if [ ! -f $kafka_properties ]
			then
				kafka_properties=$kafka_home'/config/kafka.properties'
				kafka_log4j=$kafka_home'/config/log4j.properties'
			fi
			if [ ! -f $kafka_properties ]
			then
				kafka_properties=$kafka_home'/conf/kafka.properties'
				kafka_log4j=$kafka_home'/conf/log4j.properties'
			fi
			if [ ! -f $kafka_properties ] && [[ $fileSYS = "y" ]]
			then
				echo "Le chemin vers les fichiers de configuration Kafka n'a pas pu être identifié. L'auditeur utilisera la liste des fichiers sur le serveur pour identifier où sont placés les fichiers de configuration ? [y/n]"
			else
				if [ ! -f $kafka_properties ]
				then
					echo "Le chemin vers les fichiers de configuration Kafka n'a pas pu être identifié. Souhaitez-vous générer la liste des fichiers présents sur ce serveur afin que l'auditeur puisse l'utiliser pour identifier où sont placés les fichiers de configuration ? [y/n]"
					echo ""
					read answer
					if [[ $answer = "y" ]]
					then
						fileSYS=y
						ls -RAl / >> $fichierFileSYS 2>&1
						echo "Fichier $fichierFileSYS généré."
						echo ""
					fi
				fi
			fi
		else
			if [[ $fileSYS = "y" ]]
			then
				echo "Le chemin vers les fichiers de configuration Kafka n'a pas pu être identifié. L'auditeur utilisera la liste des fichiers sur le serveur pour identifier où sont placés les fichiers de configuration."
				echo ""
			else
				echo "Le chemin vers les fichiers de configuration Kafka n'a pas pu être identifié. Souhaitez-vous générer la liste des fichiers présents sur ce serveur afin que l'auditeur puisse l'utiliser pour identifier où sont placés les fichiers de configuration ? [y/n]"
				echo ""
				read answer
				if [[ $answer = "y" ]]
				then
					fileSYS=y
					ls -RAl / >> $fichierFileSYS 2>&1
					echo "Fichier $fichierFileSYS généré."
					echo ""
				fi
			fi
		fi
	fi
fi

if [ "$zookeeper" -eq "1" ]
then
	zoo_cfg=`ps -aux 2>&1 | grep zoo.cfg 2>&1 | grep -v grep 2>&1 | grep -oE '[^ ]+$' 2>&1`
	if [[ -f $zoo_cfg ]]
	then
		zoo_log4j=`dirname $zoo_cfg 2>&1`'/log4j.properties'
		zoo_home=`dirname $zoo_cfg 2>&1 | xargs dirname 2>&1`
	fi
	if [[ ! -f $zoo_cfg ]]
	then
		if [[ -d $ZOOKEEPER_HOME ]]
		then
			zoo_cfg=$ZOOKEEPER_HOME'/conf/zoo.cfg'
			zoo_log4j=$ZOOKEEPER_HOME'/conf/log4j.properties'
			if [ ! -f $zoo_cfg ]
			then
				zoo_cfg=$ZOOKEEPER_HOME'/config/zoo.cfg'
				zoo_log4j=$ZOOKEEPER_HOME'/config/log4j.properties'
			fi
			if [ ! -f $zoo_cfg ] && [[ $fileSYS = "y" ]]
			then
				echo "Le chemin vers les fichiers de configuration Zookeeper n'a pas pu être identifié. L'auditeur utilisera la liste des fichiers sur le serveur pour identifier où sont placés les fichiers de configuration."
				echo ""
			else
				if [ ! -f $zoo_cfg ]
				then
					echo "Le chemin vers le fichier de configuration Zookeeper n'a pas pu être identifié. Souhaitez-vous générer la liste des fichiers présents sur ce serveur afin que l'auditeur puisse l'utiliser pour identifier où sont placés les fichiers de configuration ? [y/n]"
					echo ""
					read answer
					if [[ $answer = "y" ]]
					then
						fileSYS=y
						ls -RAl / >> $fichierFileSYS 2>&1
						echo "Fichier $fichierFileSYS généré."
						echo ""
					fi
				fi
			fi
		else
			if [[ $fileSYS = "y" ]]
			then
				echo "Le chemin vers les fichiers de configuration Zookeeper n'a pas pu être identifié. L'auditeur utilisera la liste des fichiers sur le serveur pour identifier où sont placés les fichiers de configuration ? [y/n]"
				echo ""
			else
				echo "Le chemin vers le fichier de configuration Zookeeper n'a pas pu être identifié. Souhaitez-vous générer la liste des fichiers présents sur ce serveur afin que l'auditeur puisse l'utiliser pour identifier où sont placés les fichiers de configuration ? [y/n]"
				echo ""
				read answer
				if [[ $answer = "y" ]]
				then
					fileSYS=y
					ls -RAl / >> $fichierFileSYS 2>&1
					echo "Fichier $fichierFileSYS généré."
					echo ""
				fi
			fi
		fi
	fi
fi

##############################################################################
#A décommenter pour lui fournir les fichiers de configuration en paramètres :#
##############################################################################
#core_site=`echo $1`
#hadoop_policy=`echo $2`
#hdfs_site=`echo $3`
#mapred_site=`echo $4`
#yarn_site=`echo $5`
#hbase_site=`echo $6`
#gateway_site=`echo $7`
#gateway_log4j=`echo $8`
#ranger_admin_site=`echo $9`
#hive_site=`echo $10`
#kafka_properties=`echo $11`
#kafka_log4j=`echo $12`
#zoo_cfg=`echo $13`
#zoo_log4j=`echo $14`


# Remplir le fichier ficherConf avec toutes les confs
if [ "$core_hadoop" -eq "1" ] && [ -f $core_site ]
then
	echo "===== Core Hadoop =====" >> $fichierConf
	cat $core_site >> $fichierConf 2>&1
fi
if [ "$core_hadoop" -eq "1" ] && [ -f $hadoop_policy ]
then
	echo "===== Hadoop Policy =====" >> $fichierConf
	cat $hadoop_policy >> $fichierConf 2>&1
fi
if [ "$core_hadoop" -eq "1" ] && [ -f $hdfs_site ]
then
	echo "===== HDFS =====" >> $fichierConf
	cat $hdfs_site >> $fichierConf 2>&1
fi
if [ "$core_hadoop" -eq "1" ] && [ -f $mapred_site ]
then
	echo "===== MapReduce =====" >> $fichierConf
	cat $mapred_site >> $fichierConf 2>&1
fi
if [ "$core_hadoop" -eq "1" ] && [ -f $yarn_site ]
then
	echo "===== YARN =====" >> $fichierConf
	cat $yarn_site >> $fichierConf 2>&1
fi

if [ "$hbase" -eq "1" ] && [ -f $hbase_site ]
then
	echo "===== HBase =====" >> $fichierConf
	cat $hbase_site >> $fichierConf 2>&1
	echo "\n" >> $fichierConf
fi

if [ "$knox" -eq "1" ] && [ -f $gateway_site ]
then
	echo "===== Knox =====" >> $fichierConf
	cat $gateway_site >> $fichierConf 2>&1
fi
if [ "$knox" -eq "1" ] && [ -f $gateway_log4j ]
then
	cat $gateway_log4j >> $fichierConf 2>&1
fi
if [ "$knox" -eq "1" ] && [ -d $chemin ]
then
	for filename in $chemin'/knox/conf/topologies/*.xml'; do
			echo $filename >> $fichierConf 2>&1
			echo "" >> $fichierConf 2>&1
			cat $filename >> $fichierConf 2>&1
			echo "" >> $fichierConf 2>&1
			echo "" >> $fichierConf 2>&1
	done
fi

if [ "$ranger" -eq "1" ] && [ -f $ranger_admin_site ]
then
	echo "===== Ranger =====" >> $fichierConf
	cat $ranger_admin_site >> $fichierConf 2>&1
fi

if [ "$hive" -eq "1" ] && [ -f $hive_site ]
then
	echo "===== Hive =====" >> $fichierConf
	cat $hive_site >> $fichierConf 2>&1
fi

if [ "$kafka" -eq "1" ] && [ ! -z $kafka_properties ]
then
	echo "===== Kafka =====" >> $fichierConf
	cat $kafka_properties >> $fichierConf 2>&1
fi
ps -aux 2>&1 | grep kafka 2>&1 | grep -v grep 2>&1 >> $fichierConf 2>&1

if [ "$kafka" -eq "1" ] && [ ! -z $kafka_log4j ]
then
	echo "===== Kafka Log4j =====" >> $fichierConf
	cat $kafka_log4j >> $fichierConf 2>&1
fi

if [ "$zookeeper" -eq "1" ] && [ ! -z $zoo_cfg ]
then
	echo "===== Zookeeper =====" >> $fichierConf
	cat $zoo_cfg >> $fichierConf 2>&1
fi
ps -aux 2>&1 | grep zoo.cfg 2>&1 | grep -v grep 2>&1 >> $fichierConf 2>&1

if [ "$zookeeper" -eq "1" ] && [ ! -z $zoo_log4j ]
then
	echo "===== Zookeeper Log4j =====" >> $fichierConf
	cat $zoo_log4j >> $fichierConf 2>&1
fi

echo "===== Groupes =====" >> $fichierConf
cat /etc/group >> $fichierConf 2>&1

echo "===== Paquets installés =====" >> $fichierConf
yum list installed  2>&1 >> $fichierConf 2>&1
dpkg-query -W  2>&1 >> $fichierConf 2>&1
rpm -qa 2>&1 >> $fichierConf 2>&1

echo "===== Repertoires Home =====" >> $fichierConf
if [ -d $chemin ]
then
	ls -alsR $chemin >> $fichierConf 2>/dev/null
fi
if [ -d $kafka_home ]
then
	ls -alsR $kafka_home >> $fichierConf 2>/dev/null
fi
if [ -d $zoo_home ]
then
	ls -alsR $zoo_home >> $fichierConf 2>/dev/null
fi

# recherche info

ecrireTitreSection "Informations générales"
echo "Informations générales"
ecrireDescription "Mises à jour possibles ?"
ecrire "Yum"
yum check-update >> $fichierRes 2>&1
ecrire "Apt"
apt-get update >> $fichierRes 2>&1
echo n |apt-get upgrade >> $fichierRes 2>&1
ecrire "Zypper"
zypper list-updates -a >> $fichierRes 2>&1

ecrireDescription "Liste des paquets installés"
ecrire "Yum"
yum list installed 2>&1 | grep hadoop 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep hbase 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep knox 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep ranger 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep kafka 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep zookeeper 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep flume 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep sqoop 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep hive 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep impala 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep zepellin 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep bigtop 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep datafu 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep falcon 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep oozie 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep pig 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep slider 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep spark 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep hdp 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep cloudera 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep storm 2>&1 >> $fichierRes 2>&1
yum list installed 2>&1 | grep tez 2>&1 >> $fichierRes 2>&1
ecrire "Apt"
dpkg-query -W 2>&1 | grep hadoop 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep hbase 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep knox 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep ranger 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep kafka 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep zookeeper 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep flume 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep sqoop 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep hive 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep impala 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep zepellin 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep bigtop 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep datafu 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep falcon 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep oozie 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep pig 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep slider 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep spark 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep hdp 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep cloudera 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep storm 2>&1 >> $fichierRes 2>&1
dpkg-query -W 2>&1 | grep tez 2>&1 >> $fichierRes 2>&1
ecrire "Zypper"
rpm -qa 2>&1 | grep hadoop 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep hbase 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep knox 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep ranger 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep kafka 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep zookeeper 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep flume 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep sqoop 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep hive 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep impala 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep zepellin 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep bigtop 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep datafu 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep falcon 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep oozie 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep pig 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep slider 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep spark 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep hdp 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep cloudera 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep storm 2>&1 >> $fichierRes 2>&1
rpm -qa 2>&1 | grep tez 2>&1 >> $fichierRes 2>&1

ecrireDescription "Permissions sur les fichiers de configuration"
if [ ! -z $core_site ]
then
	ls -alsR $core_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $hadoop_policy ]
then
	ls -alsR $hadoop_policy >> $fichierRes 2>/dev/null
fi
if [ ! -z $hdfs_site ]
then
	ls -alsR $hdfs_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $yarn_site ]
then
	ls -alsR $yarn_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $hbase_site ]
then
	ls -alsR $hbase_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $gateway_site ]
then
	ls -alsR $gateway_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $gateway_log4j ]
then
	ls -alsR $gateway_log4j >> $fichierRes 2>/dev/null
fi
if [ ! -z $ranger_admin_site ]
then
	ls -alsR $ranger_admin_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $hive_site ]
then
	ls -alsR $hive_site >> $fichierRes 2>/dev/null
fi
if [ ! -z $kafka_properties ]
then
	ls -alsR $kafka_properties >> $fichierRes 2>/dev/null
fi
if [ ! -z $kafka_log4j ]
then
	ls -alsR $kafka_log4j >> $fichierRes 2>/dev/null
fi
if [ ! -z $zoo_cfg ]
then
	ls -alsR $zoo_cfg >> $fichierRes 2>/dev/null
fi
if [ ! -z $zoo_log4j ]
then
	ls -alsR $zoo_log4j >> $fichierRes 2>/dev/null
fi

if [ "$core_hadoop" -eq "1" ]
then
	ecrireTitreSection "Configuration générale"
	echo "Configuration générale"

	ecrireDescription "Authentification"
	if [ -f $core_site ]
	then
		cat $core_site 2>&1 | grep "hadoop.security.authentication" -B 1 -A 2 >> $fichierRes 2>&1
		echo "<property>" >> $fichierRes 2>&1
		cat $core_site 2>&1 | sed -n "/hadoop.security.auth_to_local/,/property/p" >> $fichierRes 2>&1
	fi
	ecrireDescription "Contrôle d'accès"
	if [ -f $core_site ]
	then
		cat $core_site 2>&1 | grep "hadoop.security.authorization" -B 1 -A 2 >> $fichierRes 2>&1
		if [ -f $hadoop_policy ]
		then
			cat $hadoop_policy 2>&1 | grep ".protocol.acl" -B 1 -A 2 >> $fichierRes 2>&1
		fi
	fi
	ecrireDescription "Impersonation"
	if [ -f $core_site ]
	then
		cat $core_site 2>&1 | grep "hadoop.proxyuser.superuser.groups" -B 1 -A 2 >> $fichierRes 2>&1
		cat $core_site 2>&1 | grep "hadoop.proxyuser.superuser.hosts" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireTitreSection "Hadoop Distributed File System (HDFS)"
	echo "Hadoop Distributed File System (HDFS)"
	ecrireDescription "Keytabs"
	find / -name "*.keytab" -print 2>&1 | xargs ls -l >> $fichierRes 2>/dev/null

	ecrireDescription "Jetons d'accès"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.block.access.token.enable" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Administration HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.cluster.administrators" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "dfs.datanode.address" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "dfs.datanode.http.address" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "dfs.datanode.https.address" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Permissions HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.datanode.data.dir.perm" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "dfs.permissions.enabled" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "dfs.permissions.superusergroup" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Accès Web HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.webhdfs.enabled" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement HTTP HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.http.policy" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement RPC HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "hadoop.rpc.protection" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement DTP HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "dfs.encrypt.data.transfer" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Interface Web HDFS"
	if [ -f $hdfs_site ]
	then
		cat $hdfs_site 2>&1 | grep "hadoop.ssl.enabled" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hdfs_site 2>&1 | grep "hadoop.ssl.hostname.verifier" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireTitreSection "MapReduce"
	echo "MapReduce"
	ecrireDescription "Authentification MapReduce"
	if [ -f $mapred_site ]
	then
		cat $mapred_site 2>&1 | grep "kerberos" -B 2 -A 1 >> $fichierRes 2>&1
		cat $mapred_site 2>&1 | grep "mapreduce.jobhistory.keytab" -B 1 -A 2 >> $fichierRes 2>&1
		cat $mapred_site 2>&1 | grep "mapreduce.jobhistory.principal" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Contrôle d'accès MapReduce"
	if [ -f $mapred_site ]
	then
		cat $mapred_site 2>&1 | grep "mapreduce.cluster.acls.enabled" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement MapReduce"
	if [ -f $mapred_site ]
	then
		cat $mapred_site 2>&1 | grep "mapreduce.shuffle.ssl.enabled" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireTitreSection "YARN"
	echo "YARN"
	ecrireDescription "Authentification YARN"
	if [ -f $yarn_site ]
	then
		cat $yarn_site 2>&1 | grep "yarn.timeline-service.http-authentication.type" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Contrôle d'accès YARN"
	if [ -f $yarn_site ]
	then
		cat $yarn_site 2>&1 | grep "yarn.nodemanager.container-executor.class" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement YARN"
	if [ -f $yarn_site ]
	then
		cat $yarn_site 2>&1 | grep "yarn.http.policy" -B 1 -A 2 >> $fichierRes 2>&1
	fi
fi

if [ "$hbase" -eq "1" ]
then
	ecrireTitreSection "HBase"
	echo "HBase"
	ecrireDescription "Authentification HBase"
	if [ -f $hbase_site ]
	then
		cat $hbase_site 2>&1 | grep "hbase.security.authentication" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hbase_site 2>&1 | grep "hbase.rpc.engine" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hbase_site 2>&1 | grep "hbase.zookeeper.quorum" -B 1 -A 2 >> $fichierRes 2>&1
		cat $hbase_site 2>&1 | grep "hbase.cluster.distributed" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Contrôle d'accès HBase"
	if [ -f $hbase_site ]
	then
		cat $hbase_site 2>&1 | grep "hbase.security.authorization" -B 1 -A 2 >> $fichierRes 2>&1
	fi
fi
if [ "$knox" -eq "1" ]
then
	ecrireTitreSection "Knox"
	echo "Knox"
	ecrireDescription "Configuration globale Knox"
	if [ -f $gateway_site ]
	then
		cat $gateway_site 2>&1 | grep "gateway.hadoop.kerberos.secured" -B 1 -A 2 >> $fichierRes 2>&1
		cat $gateway_site 2>&1 | grep "gateway.path" -B 1 -A 2 >> $fichierRes 2>&1
		cat $gateway_site 2>&1 | grep "gateway.port" -B 1 -A 2 >> $fichierRes 2>&1
		cat $gateway_site 2>&1 | grep "java.security.krb5.conf" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Topologies Knox"
	topologie $chemin'/knox/conf/topologies/*.xml' $fichierRes
	
	ecrireDescription "Journalisation Knox"
	if [ -f $gateway_log4j ]
	then
		cat $gateway_log4j 2>&1 | grep -v \# 2>&1 >> $fichierRes 2>&1
		echo "" >> $fichierRes 2>&1
	fi
fi

if [ "$ranger" -eq "1" ]
then
	ecrireTitreSection "Ranger"
	echo "Ranger"
	ecrireDescription "Authentification Ranger"
	if [ -f $ranger_admin_site ]
	then
		cat $ranger_admin_site 2>&1 | grep "ranger.authentication.method" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.admin.kerberos.keytab" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.admin.kerberos.principal" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.admin.kerberos.token.valid.seconds" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement Ranger"
	if [ -f $ranger_admin_site ]
	then
		cat $ranger_admin_site 2>&1 | grep "ranger.service.http.enabled" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.service.http.port" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.service.https.attrib.ssl.enabled" -B 1 -A 2 >> $fichierRes 2>&1
		cat $ranger_admin_site 2>&1 | grep "ranger.service.https.port" -B 1 -A 2 >> $fichierRes 2>&1
	fi
fi

if [ "$hive" -eq "1" ]
then
	ecrireTitreSection "Hive"
	echo "Hive"
	ecrireDescription "Authentification Hive"
	if [ -f $hive_site ]
	then
		cat $hive_site 2>&1 | grep "hive.server2.authentication" -B 1 -A 2 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement Hive"
	if [ -f $hive_site ]
	then
		cat $hive_site 2>&1 | grep "hive.server2.thrift.sasl.qop" -B 1 -A 2 >> $fichierRes 2>&1
	fi
fi

if [ "$kafka" -eq "1" ]
then
	ecrireTitreSection "Kafka"
	echo "Kafka"
	ecrireDescription "Authentification et chiffrement des consumers et producers"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "ssl.client.auth=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "listeners=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Authentification et chiffrement entre brokers"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "security.inter.broker.protocol=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Authentification et chiffrement avec Zookeeper"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "zookeeper.connect=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "zookeeper.set.acl=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Chiffrement des flux Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "ssl.keystore.location=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "ssl.keystore.password=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "ssl.key.password=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Authentification des clients Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "ssl.truststore.location=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "ssl.truststore.password=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Protocoles et suites de chiffrement supportés Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "ssl.enabled.protocols=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "ssl.cipher.suites=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Contrôle des ACL par Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "authorizer.class.name=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "allow.everyone.if.no.acl.found=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "super.users=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "principal.builder.class=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Gestion des ACL Kafka"
	$kafka_home/bin/kafka-acls.sh --authorizer-properties zookeeper.connect=localhost:2181 --list 2>&1 >> $fichierRes 2>&1
	ecrireDescription "Journalisation Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "log.dir=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "log.dirs=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "log.retention.hours=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "log.segment.bytes=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "log.retention.check.interval.ms=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Permissions journalisation Kafka"
	if [ ! -z $zoo_cfg ]
	then
		cat $kafka_properties 2>&1 | grep -oP '(?<=log.dirs=).*' 2>&1 | xargs ls -alRs 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Journalisation Kafka log4j"
	if [ ! -z $kafka_log4j ]
	then
		cat $kafka_log4j 2>&1 | grep -v \# 2>&1 >> $fichierRes 2>&1
		echo "" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Gestion des topics Kafka"
	if [ ! -z $kafka_properties ]
	then
		cat $kafka_properties 2>&1 | grep "auto.create.topics.enable=" 2>&1 >> $fichierRes 2>&1
		cat $kafka_properties 2>&1 | grep "delete.topic.enable=" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Consoles de Java JMX"
		ps -aux 2>&1 | grep kafka 2>&1 | grep -v grep 2>&1 >> $fichierRes 2>&1
fi

if [ "$zookeeper" -eq "1" ]
then
	ecrireTitreSection "Zookeeper"
	echo "Zookeeper"
	ecrireDescription "Services accessibles"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "clientPort" 2>&1 >> $fichierRes 2>&1
		cat $zoo_cfg 2>&1 | grep "secureClientPort" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Gestion des certificats"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "ssl.keyStore.location" 2>&1 >> $fichierRes 2>&1
		cat $zoo_cfg 2>&1 | grep "ssl.keyStore.password" 2>&1 >> $fichierRes 2>&1
		cat $zoo_cfg 2>&1 | grep "ssl.trustStore.location" 2>&1 >> $fichierRes 2>&1
		cat $zoo_cfg 2>&1 | grep "ssl.trustStore.password" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Authentification et ACL des clients"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "authProvider" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Authentification entre serveurs"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "quorum" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Contournement des ACL"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "skipACL" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Journalisation Zookeeper"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "dataLogDir" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Permissions journalisation Zookeeper"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep -oP '(?<=dataLogDir=).*' 2>&1 | xargs ls -alRs 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Journalisation log4j Zookeeper"
	ps -aux 2>&1 | grep zoo.cfg 2>&1 | grep -v grep 2>&1 >> $fichierRes 2>&1
	ecrireDescription "Configuration log4j Zookeeper"
	if [ ! -z $zoo_log4j ]
	then
		cat $zoo_log4j 2>&1 | grep -v \# 2>&1 >> $fichierRes 2>&1
		echo "" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Sauvegarde Zookeeper"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "dataDir" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Permissions sauvegardes Zookeeper"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep -oP '(?<=dataDir=).*' 2>&1 | xargs ls -alRs 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Nombre de connexion simultanées"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "maxClientCnxns" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Algorithme d’élection"
	if [ ! -z $zoo_cfg ]
	then
		cat $zoo_cfg 2>&1 | grep "electionAlg" 2>&1 >> $fichierRes 2>&1
	fi
	ecrireDescription "Consoles de Java JMX"
	ps -aux 2>&1 | grep zoo.cfg 2>&1 | grep -v grep 2>&1 >> $fichierRes 2>&1
fi

ecrireDescription "EoF"

echo "-----------------------------------------------------"
echo "L'audit du système est terminé. Les fichiers générés "
echo "sont dans le répertoire actuel."
echo "-----------------------------------------------------"

