# Forcepoint

## Notes générales

Le moteur Forcepoint se base sur deux exports de configuration différents.
Comme le moteur a besoin d’un fichier unique, un script à destination des
auditeurs est fourni pour transformer ces deux fichiers en un fichier unique
pour le moteur.

## Note importante

Le moteur a été créé sur la base d’extraction d’un unique client. Il est
possible que les extractions ou le moteur ne fonctionne pas correctement pour
d’autres client.

Si vous constatez cela, n’hésitez pas à contacter l’équipe du moteur.

## Extractions

### Désactivation du chiffrement des configurations

Par défaut, les configurations sont chiffrées. Il est nécessaire de désactiver
le chiffrement avant l’extraction. Pour cela, il est nécessaire d’aller dans la
console d’administration SMC et de se connecter.

Suivre ensuite la procédure de l’éditeur :
https://support.forcepoint.com/KBArticle?id=How-to-run-sginfo-script

### Extraction de la configuration système

Cette étape va permettre de récupérer la configuration système des pare-feux,
au format but. Pour cela, il suffit d’exécuter la commande :

```shell
sgInfo
```

Il est possible de lancer la commande via plusieurs biais :

- Via l’interface de management,
- Via une connexion SSH sur la console de management,
- Via une connexion SSH sur le pare-feu concerné.

Ces options sont documentées par l’éditeur à l’URL suivante :
https://support.forcepoint.com/KBArticle?id=How-to-run-sginfo-script

Une archive tar.gz est générée pour chaque équipement. Ce fichier est à
récupérer.

### Extraction des politiques de filtrage au format XML

En se connectant en SSH sur la console d’administration, il suffit de lancer la
commande `sgExport` pour extraire l’ensemble du paramétrage au format XML:

```shell
sgExport type=all file=export_all.xml recursion -system
```

Compresser le fichier afin d’en optimiser la taille:

```shell
zip export_all.xml
```

Ce fichier est à récupérer.

## Génération du fichier pour le moteur

Une fois les deux fichiers récupérés, il faut générer le fichier texte
exploitable par le moteur, en utilisant le script `script_forcepoint.sh` :

```shell
script_forcepoint.sh <path/to/export_all.xml_DATE.zip> <path/to/gInfo-FIREWALL_NAME-DATE.tar.gz>  > audit.txt
```

_Note_: le script génére le fichier sur sa sortie standard. Il est donc
nécessaire de la rediriger vers un fichier
