#Requires -Version 2.0
<#Requires -RunAsAdministrator <##>

# Options
Param(
	#   [switch] $encrypt = $true,
	[switch] $extractWirelessKeys = $false,
	[switch] $help = $false,
	[switch] $ignoreRightsOnCriticalDirectories = $false,
	[switch] $includeWinSxs = $false,
	[switch] $includeLCU = $false,
	[int] $scanLevelRightsOnCriticalDirectories = 5,
	[string] $test

)

$scriptStartTime = Get-Date

#Register-EngineEvent PowerShell.Exiting Action {
#   Stop-Transcript
#}

#Start-Transcript -Path "$($global:outputPath)\console.txt"

Write-Host ""
Write-Host " __  __    __" -ForegroundColor Magenta
Write-Host " \ \ \ \  / /" -ForegroundColor Magenta
Write-Host "  \ \ \ \/ /   Windows Configuration Review" -ForegroundColor Magenta
Write-Host "   \ \ \  /    > Configuration extraction script" -ForegroundColor Magenta
Write-Host "    \/  \/   " -ForegroundColor Magenta
Write-Host ""

If ($help) {
	Write-Host " Arguments:" -ForegroundColor Yellow
	#   Write-Host "   -encrypt" -ForegroundColor Cyan
	#   Write-Host "     Encrypt the archive with a randomly generated password."
	#   Write-Host ""
	Write-Host "   -extractWirelessKeys" -ForegroundColor Cyan
	Write-Host "     Get wireless keys."
	Write-Host ""
	Write-Host "   -help" -ForegroundColor Cyan
	Write-Host "     Displays this help."
	Write-Host ""
	Write-Host "   -ignoreRightsOnCriticalDirectories" -ForegroundColor Cyan
	Write-Host "     Ignore right analysis on critical directories (because it can be time "
	Write-Host "     consuming)."
	Write-Host ""
	Write-Host "   -scanLevelRightsOnCriticalDirectories" -ForegroundColor Cyan
	Write-Host "     1 - fast scan (approx 1min30)" -ForegroundColor Green
	Write-Host "     5 - medium scan(approx 10min)" -ForegroundColor Yellow
	Write-Host "    10 - complete scan (approx 14min)" -ForegroundColor Red
	Write-Host "     (by default the script use an depth of 5)"
	Write-Host ""
	

	Exit
}

Write-Host " Command line:" -ForegroundColor Yellow
Write-Host "   $($MyInvocation.Line)"
Write-Host ""
Write-Host " Options:" -ForegroundColor Yellow
#Write-Host "   -encrypt = $encrypt"
Write-Host "   -extractWirelessKeys = $extractWirelessKeys"
Write-Host "   -ignoreRightsOnCriticalDirectories = $ignoreRightsOnCriticalDirectories"
Write-Host ""
Write-Host " Start time:" (Get-Date -Date $scriptStartTime -Format "yyyy-MM-dd HH:mm:ss K")
Write-Host ""

###############################
#    Script initialization    #
###############################

# Define the global variables
$global:outputPath = ".\output_$(hostname)_$(Get-Date -Format yyyyMMdd_HHmmss)"
$global:outputArchive = $global:outputPath # without .zip extension
$global:outputFirefoxPath = "$($global:outputPath)\firefox"
$global:logFileName = "$($global:outputPath)\audit.txt"
$global:ErrorlogFileName = "$($global:outputPath)\error_log.txt"
$global:auditpolFileName = "$($global:outputPath)\auditpol.csv"
$global:appLockerPolicy = "$($global:outputPath)\appLockerPolicy.xml"
$global:secpolExportFileName = "$($env:tmp)\audit_secpol.txt"
$global:tempFileName = "$($env:tmp)\audit_temp.txt"
$global:gpresultFileName = "$($global:outputPath)\gpresult.html"
$global:gpresultXmlFileName = "$($global:outputPath)\gpresult.xml"
$global:SAMhiveFileName = "$($global:outputPath)\SAM"
$global:SYSTEMhiveFileName = "$($global:outputPath)\SYSTEM"
$global:SOFTWAREhiveFileName = "$($global:outputPath)\SOFTWARE"

<#
    Output directory name : output_yyyyMMdd_HHmmss
                 Year: 0000-9999 ___/  / /   \ \ \__ Seconds: 00-59
                Month:   01-12   _____/ /     \ \___ Minutes: 00-59
                  Day:   01-31   ______/       \____ Hour:    00-23
#>

# Function: Update the log file
Function Update-LogFile {
	Param(
		[Parameter(Position = 0, ValueFromPipeline = $True)]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$FileName,

		[Parameter(Position = 1, ValueFromPipeline = $True)]
		[String[]]
		$Content
	)
	Process {
		Add-Content -path $FileName -value $Content -encoding utf8
	}
}
# Create error log file in the current directory
New-Item $ErrorlogFileName -Type File -Force 2>&1> $null


# Set to 1 the categories that you want to test
$Global:CategoriesToTest = @{
	_0_TestAllCategories    = 1; # If set to 1, all categories will be tested, regardless of the following parameters
	_1_ComputerInformation  = 0;
	_2_PhysicalSecurity     = 0;
	_3_Authentification     = 0;
	_4_SystemAccessControl  = 0;
	_5_NetworkAccessControl = 0;
	_6_Encryption           = 0;
	_7_Logging              = 0;
	_8_PatchManagement      = 0;
	_9_LocalPolicies        = 0;
	_10_Antivirus           = 0;
	_11_Administration      = 0;
	_12_WebBrowsers         = 0;
	_13_SystemSecurity      = 0;
	_14_Getions             = 0;
}


Try {
	# Verify if the current user has administrator privileges - because they are required for the script
	If (-Not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
		Write-Warning "[!] You do not have Administrator rights to run this script.`n    Please run this script as an Administrator."
		Throw "[!] You do not have Administrator rights to run this script.`n    Please run this script as an Administrator."
		
	}

	# Verify if the system is able to run the script
	If (-Not ([environment]::OSVersion.Version.Major -ge 6)) {
		Throw "[!] This script is made for Windows Operating Systems with version greater than Windows XP, which does not seem to be the case for this machine."
	}
	#verify if the script is launch in 64-bit environnements
	if (-Not([System.Environment]::Is64BitProcess)) {
		Throw "[!] The script is not in a 64-bit shell environnement. Please run this script in a 64-bit powershell command terminal"
	}
}
Catch {
	Write-Host $_.Exception.Message -ForegroundColor Red
	Update-LogFile $ErrorlogFileName $_.Exception.Message

	Exit
}
# Create log file in the current directory
New-Item $logFileName -Type File -Force 2>&1> $null

# Export secpol (security policies) to the current directory
secedit /export /cfg $global:secpolExportFileName 2>&1> $null




# Function: Get specific information from the secpol export
Function Get-GPO {
	Param(
		[Parameter(Position = 0, ValueFromPipeline = $True)]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$FileName,

		[Parameter(Position = 1, ValueFromPipeline = $True)]
		[String[]]
		$Parameter
	)
	Process {
		Try {
			$match = Get-ChildItem $FileName | Select-String $Parameter | ForEach-Object { $_.Matches } | ForEach-Object { $_.Value }
			If ($match) {
				$info = $match.Split("=")[1] -replace '\s', ''
				If ($info -match '\*S-1-') {
					$SIDs = $info.Split(",")
					$res = ""
					Foreach ($SID in $SIDs) {
						$tmp = New-Object System.Security.Principal.SecurityIdentifier($SID.Replace("*", ""))
						$res = $res + $tmp.Translate( [System.Security.Principal.NTAccount]).Value + ","
					}
					return $res.Substring(0, $res.Length - 1)
				}
				Else {
					return $info
				}
			}
			Else {
				return "."
			}
		}
		Catch {
			Update-LogFile $ErrorlogFileName $_.Exception.Message
			Write-Warning -Message "Error occured (see error log file)"
			return "."
		}
	}
}

# Function: Get specific subcategory from auditpol
Function Get-Auditpol {
	Param(
		[Parameter(Position = 0, ValueFromPipeline = $True)]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Subcategory
	)
	Process {
		$tmp = auditpol /get /subcategory:$Subcategory /r
		$tmp.Split(",")[11]
	}
}

# Function: Get registry values
Function Get-Registry {
	Param(
		[Parameter(Position = 0, ValueFromPipeline = $True)]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$KeyPath,

		[Parameter(Position = 1, ValueFromPipeline = $True)]
		[String[]]
		$ValueName
	)
	Process {
		Try {
			$match = (Get-ItemProperty -LiteralPath $KeyPath -Name $ValueName -EA SilentlyContinue).$ValueName
			If ($match -or $match -eq 0) { return $match } Else { return "." }
		}
		Catch {
			Write-Host "Error occured (see error log file)" -ForegroundColor Red
			Update-LogFile $ErrorlogFileName "Error retrieving registry $($KeyPath)$($ValueName)"

		}
	}
}

# Function: finds name of local administrator account
Function Get-SWLocalAdmin {
	[CmdletBinding()]
	param (
		[Parameter(Mandatory = $true)]
		$ComputerName
	)
	Process {
		Foreach ($Computer in $ComputerName) {
			Try {
				Add-Type -AssemblyName System.DirectoryServices.AccountManagement
				$PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $Computer)
				$UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
				$Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
				$Searcher.QueryFilter = $UserPrincipal
				$Searcher.FindAll() | Where-Object { $_.Sid -Like "*-500" }
			}
			Catch {
				;
				Update-LogFile $ErrorlogFileName $_.Exception.Message
				Write-Warning -Message "Error occured (see error log file)"
			}
		}
	}
}

# Function: Retrieve scheduled tasks on local computer
Function Get-ScheduledTasks {
	Begin {
		$schedule = New-Object -ComObject "Schedule.Service"
	}
	Process {
		Function Get-Tasks {
			$out = @()
			$tasks = Get-ScheduledTask
			foreach ($task in $tasks) {
				$out += New-Object psobject -Property @{
					"Name"        = $task.TaskName
					"Path"        = $task.TaskPath
					"LastRunTime" = ($task | Get-ScheduledTaskInfo).LastRunTime
					"NextRunTime" = ($task | Get-ScheduledTaskInfo).NextRunTime
					"Actions"     = $task.Actions.Execute
					"Argument"    = $task.Actions.Arguments
					"Author"      = $task.Author
					"Description" = $task.Description
					"RunAs"       = $task.Principal.UserId
					"Status"      = $task.state
				}				
			}
			
			return $out
		}
		$schedule.connect($env:COMPUTERNAME)
		$tasks = Get-Tasks
		
	}
	End {
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($schedule) | Out-Null
		Remove-Variable schedule

		return $tasks
	}
}

# Function: Gets shares ACLs
Function Get-ShareACL {
	param(
		[String]$Name = "%",
		[String]$Computer = $Env:ComputerName
	)

	$file = New-Item $global:tempFileName -Type File -Force

	Get-WMIObject Win32_Share -Computer $Computer -Filter "Name LIKE '$Name'" | ForEach-Object {
		$Access = @()

		If ($_.Type -eq 0) {
			$SD = (Get-WMIObject Win32_LogicalShareSecuritySetting -Computer $Computer -Filter "Name='$($_.Name)'").GetSecurityDescriptor().Descriptor
			$SD.DACL | ForEach-Object {
				$Trustee = $_.Trustee.Name
				If ($null -ne $_.Trustee.Domain) {
					$Trustee = "$($_.Trustee.Domain)\$Trustee"
				}
				$Access += New-Object Security.AccessControl.FileSystemAccessRule(
					$Trustee, $_.AccessMask, $_.AceType)
			}
		}

		$shareDescription = $_ | Select-Object Name, Path, Description, Caption,
		@{n = 'Type'; e = {
				switch ($_.Type) {
					0 { "Disk Drive" }
					1 { "Print Queue" }
					2 { "Device" }
					2147483648 { "Disk Drive Admin" }
					2147483649 { "Print Queue Admin" }
					2147483650 { "Device Admin" }
					2147483651 { "IPC Admin" }
				}
			}
  },
		MaximumAllowed, AllowMaximum, Status, InstallDate,
		@{n = 'Access'; e = { $Access } }

		Update-LogFile $logFileName ($shareDescription)
		Update-LogFile $logFileName ("")

		If ($_.Path) {
			# NTFS ACL
			Update-LogFile $logFileName ("NTFS ACL")
			Update-LogFile $logFileName ("--------")

			icacls $_.Path > $file

			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Update-LogFile $logFileName ("")

			# Share ACL
			Update-LogFile $logFileName ("Share ACL")
			Update-LogFile $logFileName ("---------")

			Try {
				Get-SmbShareAccess $_.Name | Format-List > $file

				ForEach ($system in Get-Content $file) {
					Update-LogFile $logFileName ($system)
				}
			}
			Catch {
				Update-LogFile $ErrorlogFileName $_.Exception.Message
				Update-LogFile $logFileName "Default share: no ACL"
				Write-Warning -Message "Default share: no ACL"
			}
		}

		Update-LogFile $logFileName ("")
	}

	Remove-item $global:tempFileName 2>&1> $null
}

# TBD
Function Get-RegistryRecursive {
	Param(
		[Parameter(Mandatory = $True)]
		[ValidatePattern('^REGISTRY\:\:HKEY_[\w_]+(?:\\[^\\]+)*$')]
		[String] $rootKey
	)
	Process {
		$result = @()

		If (Test-Path -Path $rootKey) {
			$root = Get-Item -Path $rootKey

			# List keys
			$keys = Get-ChildItem -Path $rootKey
			ForEach ($key in $keys) {
				$result += Get-RegistryRecursive "REGISTRY::$($key.Name)"
			}

			# List values
			$values = $root.Property
			ForEach ($name in $values) {
				$value = ($root | Get-ItemProperty -Name $name).$name
				#$result+= @{A = "$($root.Name)\$name"; B = $value}
				$result += New-Object PSObject -Property @{Name = "$($root.Name)\$name"; Value = $value }
			}
		}

		return $result
	}
}

Function Resolve-CommandPath {
	Param(
		[Parameter(Mandatory = $True)]
		[AllowEmptyString()]
		[String] $executable
	)
	Process {
		# Expand environment variables (example: %windir% --> C:\Windows)
		$path = [System.Environment]::ExpandEnvironmentVariables($executable)

		# Check if file do not exists, if so it may be a command (regedit, secedit, ...)
		If (-Not (Test-Path -Path $path)) {
			# Get command informations
			$command = Get-Command -All $path -ErrorAction SilentlyContinue

			If ($?) {
				$path = $command.Definition
			}
			Else {
				$path = $False
			}
		}

		#Return Resolve-Path $path
		Return $path
	}
}

# Function: Get NT Account by SID
Function Get-NTAccountBySID {
	Param(
		[Parameter(Mandatory = $True)]
		[ValidatePattern('^S(?:\-\d+){3,}$')]
		[String] $strSID
	)
	Process {
		$objSID = New-Object System.Security.Principal.SecurityIdentifier ($strSID)
		$objAccount = $objSID.Translate([System.Security.Principal.NTAccount])
		return $objAccount
	}
}

# Function: Get product/machine type (workstation, server or domain controller)
Function Get-ProductType { return (Get-WmiObject win32_OperatingSystem).ProductType }

Add-Type -TypeDefinition @"
	public enum ProductType {
		WorkStation      = 1,
		DomainController = 2,
		Server           = 3
	}
"@

Function Assert-Is-WorkStation { return (Get-ProductType) -eq [ProductType]::WorkStation }
Function Assert-Is-DomainController { return (Get-ProductType) -eq [ProductType]::DomainController }
Function Assert-Is-Server { return (Get-ProductType) -eq [ProductType]::Server }

# Function: Return if machine is in domain or not
Function Assert-Is-PartOfDomain { return (Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain }

<#
	Get functions for web browsers
#>

###############################
#  1 - Computer information   #
###############################

Function Get-ComputerInfo {
	# Computer information
	Update-LogFile $logFileName "--=== Computer information ===--"

	Try {
		$colItems = Get-WMIObject Win32_ComputerSystem -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Domain: " + $objItem.Domain)
				Update-LogFile $logFileName ("Manufacturer: " + $objItem.Manufacturer)
				Update-LogFile $logFileName ("Model: " + $objItem.Model)
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("PrimaryOwnerName: " + $objItem.PrimaryOwnerName)
				Update-LogFile $logFileName ("TotalPhysicalMemory: " + [System.Math]::Round($objItem.TotalPhysicalMemory / 1048576) + " Mo")
				Update-LogFile $logFileName ("OS Version: " + (Get-WMIObject Win32_OperatingSystem).Caption)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Computer information: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve computer information"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
		
	}
}

Function Get-Whoami {
	# Whoami information
	Update-LogFile $logFileName "--=== Whoami information ===--"
	Try {
		$tmp = whoami.exe /ALL /FO LIST
		If ($?) {
			Update-LogFile $logFileName ($tmp)
			Write-Host "[-] Whoami information: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve whoami information\n \
			command : whoami.exe /ALL /FO LIST"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Disks {
	# Disks
	Update-LogFile $logFileName "--=== Disks ===--"

	Try {
		$colItems = Get-WMIObject Win32_LogicalDisk -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("DeviceID: " + $objItem.DeviceID)
				Update-LogFile $logFileName ("DriveType: " + $objItem.DriveType)
				Update-LogFile $logFileName ("FreeSpace: " + [System.Math]::Round($objItem.FreeSpace / 1000000000) + "Go")
				Update-LogFile $logFileName ("Size: " + [System.Math]::Round($objItem.Size / 1000000000) + "Go")
				Update-LogFile $logFileName ("VolumeName: " + $objItem.VolumeName)
				Update-LogFile $logFileName ("VolumeSerialNumber: " + $objItem.VolumeSerialNumber)
				Update-LogFile $logFileName ("FileSystem: " + $objItem.FileSystem)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Disks: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve disks information"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-WindowsVersion {
	# Permet de récupérer les informations sur l'installation de l'OS, des numéros de version, ... (lorsque le filtre est enlevé, des informations sont affichées mais pas complétées par les postes Wavestone)
	#
	# Windows version
	Update-LogFile $logFileName "--=== Windows version ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		Get-WmiObject Win32_OperatingSystem >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Windows version: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Windows version"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-DefaultAccountConfiguration {
	# Default account configuration
	Update-LogFile $logFileName "--=== Default account configuration ===--"

	Get-Content $global:secpolExportFileName | Out-File -FilePath $logFileName -Encoding ascii -Append

	Write-Host "[-] Default account configuration: -" -ForegroundColor Cyan
}

Function Get-NtpConfiguration {
	# NTP
	Update-LogFile $logFileName "--=== NTP Configuration ===--"

	Try {
		w32tm /query /status | Out-File -FilePath $logFileName -Encoding utf8 -Append

		If ($?) {
			Write-Host "[-] NTP configuration extract status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve NTP configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-ServiceList {
	Update-LogFile $logFileName "--=== Services List ===--"
	Try {
		$tmp = wmic service get /format:list
		#$tmp -replace '\n','' 2>&1 > $null
		Update-LogFile $logFileName $tmp
		If ($?) {
			Write-Host "[-] Services list extraction status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve services list"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}

}

Function Get-ServiceRunning {
	Update-LogFile $logFileName "--=== Services running ===--"
	Try {
		Get-WmiObject Win32_Process -Computer 'localhost' | Out-File -FilePath $logFileName -Encoding ascii -Append
		If ($?) {
			Write-Host "[-] Services running extraction status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve services running"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-SafeMode {
	Update-LogFile $logFileName "--=== SafeMode configuration ===--"
	Try {
		If ($?) {
			Write-Host "[-] SafeMode configuration: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve SafeMode configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-PowerShell {
	Update-LogFile $logFileName "--=== Powershell v5 audit configuration ===--"
	Try {
		$tmp = Get-RegistryRecursive "REGISTRY::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\PowerShell"
		Update-LogFile $logFileName $tmp

		if (-Not $tmp) {
			Update-LogFile $logFileName "Powershell v5 audit configuration is not configured"
			Write-Host "[-] Powershell v5 audit configuration: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Powershell v5 audit configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-ScriptInformation {
	Write-Host "[0] - Script information"
	Update-LogFile $logFileName "===== [0] - Script information ====="

	# Script Version
	Update-LogFile $logFileName "--=== Script Version ===--"
	Update-LogFile $logFileName "2.0.1"

	# Server Language
	Update-LogFile $logFileName "--=== Server Language ===--"
	$info = GET-WinSystemLocale
	Update-LogFile $logFileName $info.name
}
Function Get-Category-ComputerInformation {
	Write-Host "[1] - Computer information"
	Update-LogFile $logFileName "===== [1] - Computer information ====="

	Get-ComputerInfo
	Get-Whoami
	Get-Disks
	Get-WindowsVersion
	Get-DefaultAccountConfiguration
	Get-NtpConfiguration
	Get-ServiceRunning
	Get-ServiceList
	Get-PowerShell
	Get-SafeMode
	
}


###############################
#    2 - Physical security    #
###############################

Function Get-Bios {
	# Bios information
	Update-LogFile $logFileName "--=== Bios information ===--"
	Try {
		$colItems = Get-WmiObject win32_bios -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Manufacturer: " + $objItem.Manufacturer)
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("SerialNumber: " + $objItem.SerialNumber)
				Update-LogFile $logFileName ("Version: " + $objItem.Version)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Bios information: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve bios information"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-PhysicalSecurity {
	Write-Host "[2] - Physical security"
	Update-LogFile $logFileName "===== [2] - Physical security ====="

	Get-Bios
}




###############################
#      3 - Authentication     #
###############################

Function Get-ListOfLocalUsers {
	# Default local accounts status
	Update-LogFile $logFileName "--=== Default local accounts status ===--"
	Try {
		Update-LogFile $logFileName ("Default Administrator account must be renamed (NewAdministratorName): $(Get-GPO $secpolExportFileName 'NewAdministratorName.*')")
		Update-LogFile $logFileName ("Default Administrator account must be disabled (EnableAdminAccount): $(Get-GPO $secpolExportFileName 'EnableAdminAccount.*')")
		Update-LogFile $logFileName ("Default Guest account must be renamed (NewGuestName): $(Get-GPO $secpolExportFileName 'NewGuestName.*')")
		Update-LogFile $logFileName ("Default Guest account must be disabled (EnableGuestAccount): $(Get-GPO $secpolExportFileName 'EnableGuestAccount.*')")
		Update-LogFile $logFileName ""

		If ($?) {
			Write-Host "[-] Default local accounts status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of other authentication parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}

	# List of local users
	Update-LogFile $logFileName "--=== List of local users ===--"

	Try {
		$colItems = Get-WMIObject Win32_UserAccount -NameSpace "root\CIMV2" -Filter "LocalAccount='$True'" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Caption: " + $objItem.Caption)
				Update-LogFile $logFileName ("Domain: " + $objItem.Domain)
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("FullName: " + $objItem.FullName)
				Update-LogFile $logFileName ("Description: " + $objItem.Description)
				Update-LogFile $logFileName ("Disabled: " + $objItem.Disabled)
				Update-LogFile $logFileName ("PasswordChangeable: " + $objItem.PasswordChangeable)
				Update-LogFile $logFileName ("PasswordExpires: " + $objItem.PasswordExpires)
				Update-LogFile $logFileName ("PasswordRequired: " + $objItem.PasswordRequired)
				Update-LogFile $logFileName ("LocalAccount: " + $objItem.LocalAccount)
				Update-LogFile $logFileName ("Lockout: " + $objItem.Lockout)
				Update-LogFile $logFileName ("SID: " + $objItem.SID)
				Update-LogFile $logFileName ("Status: " + $objItem.Status)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] List of local users: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve local users"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-ListOfLocalGroups {
	# List of local groups
	Update-LogFile $logFileName "--=== List of local groups ===--"

	Try {
		$colItems = Get-WMIObject Win32_Group -NameSpace "root\CIMV2" -Filter "LocalAccount='$True'" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Caption: " + $objItem.Caption)
				Update-LogFile $logFileName ("Domain: " + $objItem.Domain)
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("FullName: " + $objItem.FullName)
				Update-LogFile $logFileName ("Description: " + $objItem.Description)
				Update-LogFile $logFileName ("LocalAccount: " + $objItem.LocalAccount)
				Update-LogFile $logFileName ("SID: " + $objItem.SID)
				Update-LogFile $logFileName ("Status: " + $objItem.Status)
				$temp = net localgroup $objItem.Name
				Update-LogFile $logFileName $temp
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] List of local groups: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve local groups"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-LastChangeDateForLocalAdministratorPassword {
	# Last change date for local administrator password
	Update-LogFile $logFileName "--=== Last change date for local administrator password ===--"

	Try {
		$colItems = net user Administrator

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ($objItem)
			}

			Write-Host "[-] Last change date for local administrator password: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve ast change date for local administrator password"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-DomainLogonsCache {
	# Domain logons cache
	Update-LogFile $logFileName "--=== Domain logons cache ===--"
	Try {
		If ((Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain) {
			$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" "CachedLogonsCount"
			Update-LogFile $logFileName ("Number of previous logons to cache, in case domain controller is not available (CachedLogonsCount): $($tmp)")
		}
		Else {
			Update-LogFile $logFileName "Computer is in WORKGROUP mode, this check is not needed."
		}
		Write-Host "[-] Domain logons cache: OK" -ForegroundColor Green
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-LapsAndLastChangeDateForLocalAdministratorPassword {
	# LAPS and Last change date for local administrator password
	Update-LogFile $logFileName "--=== Local users passwords ===--"

	Try {
		$LAPSdll = Get-ChildItem 'c:\program files\LAPS\CSE\Admpwd.dll' -ea SilentlyContinue
		If ($?) {
			Update-LogFile $logFileName ("DLL Admpwd.dll has been found, meaning LAPS is installed.")


		}
		Else {
			Update-LogFile $logFileName ("DLL Admpwd.dll has not been found, meaning LAPS is not installed.")
		}
		Write-Host "[-] LAPS: OK" -ForegroundColor Green
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}

	Try {
		$colItems = Get-WMIObject Win32_ComputerSystem -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				$userName = $objItem.Name
			}
			$localAdmin = Get-SWLocalAdmin($userName)

			Update-LogFile $logFileName ("Last change date for local administrator password: " + $localAdmin.LastPasswordSet)

			Write-Host "[-] Last change date for local administrator password: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve last change date for local administrator password"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-LocalPasswordPolicy {
	# Local Password policy
	Update-LogFile $logFileName "--=== Local Password policy ===--"

	Try {
		Update-LogFile $logFileName ("A password history must be enabled (PasswordHistorySize): $(Get-GPO $secpolExportFileName 'PasswordHistorySize.*')")
		Update-LogFile $logFileName ("A maximum password age must be configured (MaximumPasswordAge): $(Get-GPO $secpolExportFileName 'MaximumPasswordAge.*')")
		Update-LogFile $logFileName ("A minimum password age must be configured (MinimumPasswordAge): $(Get-GPO $secpolExportFileName 'MinimumPasswordAge.*')")
		Update-LogFile $logFileName ("Password complexity must be enabled (PasswordComplexity): $(Get-GPO $secpolExportFileName 'PasswordComplexity.*')")
		Update-LogFile $logFileName ("A minimum password length must be configured (MinimumPasswordLength): $(Get-GPO $secpolExportFileName 'MinimumPasswordLength.*')")

		If ($?) {
			Write-Host "[-] Password policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of password policy parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-AccountLockoutLocalPolicy {
	# Account lockout local policy
	Update-LogFile $logFileName "--=== Account lockout local policy ===--"

	Try {
		Update-LogFile $logFileName ("A lockout duration must be configured (LockoutDuration): $(Get-GPO $secpolExportFileName 'LockoutDuration.*')")
		Update-LogFile $logFileName ("A reset lockout count must be configured (ResetLockoutCount): $(Get-GPO $secpolExportFileName 'ResetLockoutCount.*')")
		Update-LogFile $logFileName ("A lockout bad count must be configured (LockoutBadCount): $(Get-GPO $secpolExportFileName 'LockoutBadCount.*')")

		If ($?) {
			Write-Host "[-] Account lockout policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of account lockout policy parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Screensaver {
	# Screensaver
	Update-LogFile $logFileName ("--=== Screensaver ===--")

	Try {
		$tmp = Get-Registry "HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop" "ScreenSaveActive"
		Update-LogFile $logFileName ("Screensaver must be enabled (ScreenSaveActive): $($tmp)")
		$tmp = Get-Registry "HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop" "ScreenSaverIsSecure"
		Update-LogFile $logFileName ("A password must be required to unlock a computer (ScreenSaverIsSecure): $($tmp)")
		$tmp = Get-Registry "HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop" "ScreenSaveTimeOut"
		Update-LogFile $logFileName ("Screen saver time out (ScreenSaveTimeOut): $($tmp)")
		$tmp = Get-Registry "HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop" "SCRNSAVE.EXE"
		Update-LogFile $logFileName ("Load a specific theme (SCRNSAVE.EXE): $($tmp)")

		If ($?) {
			Write-Host "[-] Screensaver: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve screensaver parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-KerberosPolicy {
	# Kerberos policy
	Update-LogFile $logFileName "--=== Kerberos policy ===--"
	Try {
		$tmp = (Get-WmiObject win32_OperatingSystem).ProductType
		switch ($tmp) {
			1 { Update-LogFile $logFileName "You are on a workstation OS."; }
			2 { Update-LogFile $logFileName "You are on a domain controller."; }
			3 { Update-LogFile $logFileName "You are on a server that is not a domain controller."; }
		}
		if ($tmp -eq 2) {
			Update-LogFile ("Enforce user logon restrictions must be enabled (TicketValidateClient): $(Get-GPO $secpolExportFileName 'TicketValidateClient .*')")
			Update-LogFile ("Maximum lifetime for service ticket must be configured (600 minutes): $(Get-GPO $secpolExportFileName 'MaxServiceAge .*')")
			Update-LogFile ("Maximum lifetime for user ticket must be configured (10 hours): $(Get-GPO $secpolExportFileName 'MaxTicketAge .*')")
			Update-LogFile ("Maximum lifetime for user ticket renewal must be configured (7 days): $(Get-GPO $secpolExportFileName 'MaxRenewAge .*')")
			Update-LogFile ("Maximum tolerance for computer clock synchronization must be configured (5 minutes): $(Get-GPO $secpolExportFileName 'MaxClockSkew .*')")
		}
		Else {
			Update-LogFile $logFileName ("Cannot retrieve Kerberos policy because your are not on a controller.")
		}

		If ($?) {
			Write-Host "[-] Kerberos policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Kerberos policy"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-Authentification {
	Write-Host "[3] - Authentication"
	Update-LogFile $logFileName "===== [3] Authentication ====="

	Get-ListOfLocalUsers
	Get-ListOfLocalGroups
	Get-LastChangeDateForLocalAdministratorPassword
	Get-DomainLogonsCache
	Get-LapsAndLastChangeDateForLocalAdministratorPassword
	Get-LocalPasswordPolicy
	Get-AccountLockoutLocalPolicy
	Get-Screensaver
	Get-KerberosPolicy
}

###############################
#  4 - System Access Control  #
###############################

Function Export-UserAccountControl {
	# User Account Control
	Update-LogFile $logFileName "--=== User Account Control ===--"

	Try {
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "FilterAdministratorToken"
		Update-LogFile $logFileName ("The setting ""Admin Approval Mode for the Built-in Administrator account"" must be configured (FilterAdministratorToken): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableUIADesktopToggle"
		Update-LogFile $logFileName ("The setting ""Allow UIAccess applications to prompt for elevation without using the secure desktop"" must be configured (EnableUIADesktopToggle): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "ConsentPromptBehaviorAdmin"
		Update-LogFile $logFileName ("The setting ""Behavior of the elevation prompt for administrators in Admin Approval Mode"" must be configured (ConsentPromptBehaviorAdmin): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "ConsentPromptBehaviorUser"
		Update-LogFile $logFileName ("The setting ""Behavior of the elevation prompt for standard users"" must be configured (ConsentPromptBehaviorUser): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableInstallerDetection"
		Update-LogFile $logFileName ("The setting ""Detect application installations and prompt for elevation"" must be configured (EnableInstallerDetection): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "ValidateAdminCodeSignatures"
		Update-LogFile $logFileName ("The setting ""Only elevate executables that are signed and validated"" must be configured (ValidateAdminCodeSignatures): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableSecureUIAPaths"
		Update-LogFile $logFileName ("The setting ""Only elevate UIAccess applications that are installed in secure locations"" must be configured (EnableSecureUIAPaths): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableLUA"
		Update-LogFile $logFileName ("The setting ""Run all administrators in Admin Approval Mode"" must be configured (EnableLUA): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "PromptOnSecureDesktop"
		Update-LogFile $logFileName ("The setting ""Switch to the secure desktop when prompting for elevation"" must be configured (PromptOnSecureDesktop): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableVirtualization"
		Update-LogFile $logFileName ("The setting ""Virtualize file and registry write failures to per-user locations"" must be configured (EnableVirtualization): $($tmp)")


		If ($?) {
			Write-Host "[-] User Account Control: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve User Account Control parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Export-Autorun {
	# Autorun
	Update-LogFile $logFileName "--=== Autorun ===--"

	Try {
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" "NoDriveTypeAutorun"
		Update-LogFile $logFileName ("Autoplay must be disabled for all drives (NoDriveTypeAutorun): $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" "NoAutorun"
		Update-LogFile $logFileName ("Autorun must be disabled for all drives (NoAutorun): $($tmp)")

		If ($?) {
			Write-Host "[-] Other system access controls parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of other system access controls parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Export-FileSystem {
	# File system
	Update-LogFile $logFileName "--=== File system ===--"

	Try {
		$tmp = Get-Registry "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" "HideFileExt"
		Update-LogFile $logFileName ("Parameter ""Hide file name extension"" must be configured (HideFileExt): $($tmp)")

		If ($?) {
			Write-Host "[-] File system: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve file system parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

function Get-ServiceDriverList {
	<#
    .SYNOPSIS
    Helper - Enumerates services (based on the registry)
    Author: @staringCat
    .DESCRIPTION
    This uses the registry to enumerate the services by looking for the subkeys of "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services". This allows any user to get information about all the services. So, even if non-privileged users can't access the details of a service through the Service Control Manager, they can do so simply by accessing the registry.
    .PARAMETER FilterLevel
    This parameter can be used to filter out the result returned by the function based on the
    following criteria:
        FilterLevel = 0 - No filtering
        FilterLevel = 1 - List Win32 services
        FilterLevel = 2 - List Win32 Drivers
    .EXAMPLE
    PS C:\> Get-ServiceDriverList -FilterLevel 1
    Name         : VMTools
    DisplayName  : VMware Tools
    User         : LocalSystem
    ImagePath    : "C:\Program Files\VMware\VMware Tools\vmtoolsd.exe"
    StartMode    : Automatic
    Type         : Win32OwnProcess
    RegistryKey  : HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\VMTools
    RegistryPath : Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\VMTools
    .NOTES
    A service "Type" can be one of the following:
        KernelDriver = 1
        FileSystemDriver = 2
        Adapter = 4
        RecognizerDriver = 8
        Win32OwnProcess = 16
        Win32ShareProcess = 32
        InteractiveProcess = 256
    #>

	[CmdletBinding()] Param(
		[Parameter(Mandatory = $true)]
		[ValidateSet(0, 1, 2)]
		[Int]
		$FilterLevel
	)
	$CachedServiceList = @()

	$ServicesRegPath = "HKLM\SYSTEM\CurrentControlSet\Services"
	$RegAllServices = Get-ChildItem -Path "Registry::$($ServicesRegPath)" -ErrorAction SilentlyContinue
	$RegAllServices | ForEach-Object { $CachedServiceList += (Get-ServiceFromRegistry -Name $_.PSChildName) }


	foreach ($ServiceItem in $CachedServiceList) {

		if ($ServiceItem.ImagePath -and (-not [String]::IsNullOrEmpty($ServiceItem.ImagePath.trim()))) {
			switch ($FilterLevel) {
				# FilterLevel = 0 - Add all to the list and go to the next one
				0 { $ServiceItem }
				# FilterLevel = 1 - Add the service to the list
				1 { if ($ServiceItem.Type -eq 16 -or $ServiceItem.Type -eq 32 -or $ServiceItem.Type -eq 256) { $ServiceItem } }
				# FilterLevel = 2 - Add the driver to the list
				2 { if ($ServiceItem.Type -eq 1 -or $ServiceItem.Type -eq 2 -or $ServiceItem.Type -eq 8) { $ServiceItem } }
			}
		}
       
	}
}
function Get-ServiceFromRegistry {
	<#
    .SYNOPSIS
    Extract the configuration of a service from the registry.
    Author: @staringCat
    .DESCRIPTION
    Services' configuration is stored in teh registry under "HKLM\SYSTEM\CurrentControlSet\Services". For each service, a subkey is created and contains all the information we need. So we can just query this key to get a service's configuration.
    .PARAMETER Name
    Name of a service.
    .EXAMPLE
    PS C:\> Get-ServiceFromRegistry -Name Spooler
    Name         : Spooler
    DisplayName  : @C:\WINDOWS\system32\spoolsv.exe,-1
    User         : LocalSystem
    ImagePath    : C:\WINDOWS\System32\spoolsv.exe
    StartMode    : Automatic
    Type         : Win32OwnProcess, InteractiveProcess
    RegistryKey  : HKLM\SYSTEM\CurrentControlSet\Services
    RegistryPath : HKLM\SYSTEM\CurrentControlSet\Services\Spooler
    #>

	[CmdletBinding()] Param(
		[Parameter(Mandatory = $true)]
		[ValidateNotNullOrEmpty()]
		[String]$Name
	)

	$RegKeyServices = "HKLM\SYSTEM\CurrentControlSet\Services"
	$RegKey = Join-Path -Path $RegKeyServices -ChildPath $Name
	$RegItem = Get-ItemProperty -Path "Registry::$($RegKey)" -ErrorAction SilentlyContinue
	if ($null -eq $RegItem) { return }

	$Result = New-Object -TypeName PSObject
	$Result | Add-Member -NotePropertyName "Name" -NotePropertyValue $RegItem.PSChildName
	$Result | Add-Member -NotePropertyName "ImagePath" -NotePropertyValue $RegItem.ImagePath
	$Result | Add-Member -NotePropertyName "Type" -NotePropertyValue $RegItem.Type
	$Result
}

function Get-AclModificationRights {
	<#
    .SYNOPSIS
    Helper - Enumerates modification rights the current user has on an object.
    Author: @itm4n
    License: BSD 3-Clause
    
    .DESCRIPTION
    This cmdlet retrieves the ACL of an object and returns the ACEs that grant modification permissions to the current user. It should be noted that, in case of deny ACEs, restricted rights are removed from the permission list of the ACEs.
    
    .PARAMETER Path
    The full path of a securable object.
    
    .PARAMETER Type
    The target object type (e.g. "File").
    
    .EXAMPLE
    PS C:\> Get-AclModificationRights -Path C:\Temp\foo123.txt -Type File
    IdentityReference: BUILTIN\Users
	FileSystemRights: GenericExecute, GenericRead
	InheritanceFlags: ContainerInherit, ObjectInherit
	PropagationFlags: InheritOnly
    .EXAMPLE
    PS C:\> Get-AclModificationRights -Path C:\Temp\deny-delete.txt -Type File
	IdentityReference: BUILTIN\Users
	FileSystemRights: GenericExecute, GenericRead
	InheritanceFlags: ContainerInherit, ObjectInherit
	PropagationFlags: InheritOnly
    .EXAMPLE
    PS C:\> Get-AclModificationRights -Path C:\Temp\deny-write.txt -Type File
    IdentityReference: BUILTIN\Users
	FileSystemRights: GenericExecute, GenericRead
	InheritanceFlags: ContainerInherit, ObjectInherit
	PropagationFlags: InheritOnly
    #>

	[CmdletBinding()] Param(
		[String]
		$Path,

		[ValidateSet("File", "Directory", "RegistryKey")]
		[String]
		$Type
	)

	BEGIN {
		$TypeFile = "File"
		$TypeDirectory = "Directory"
		$TypeRegistryKey = "RegistryKey"

		$FileAccessMask = @{
			[UInt32]'0x80000000' = 'GenericRead'
			[UInt32]'0x40000000' = 'GenericWrite'
			[UInt32]'0x20000000' = 'GenericExecute'
			[UInt32]'0x10000000' = 'GenericAll'
			[UInt32]'0x02000000' = 'MaximumAllowed'
			[UInt32]'0x01000000' = 'AccessSystemSecurity'
			[UInt32]'0x00100000' = 'Synchronize'
			[UInt32]'0x00080000' = 'WriteOwner'
			[UInt32]'0x00040000' = 'WriteDAC'
			[UInt32]'0x00020000' = 'ReadControl'
			[UInt32]'0x00010000' = 'Delete'
			[UInt32]'0x00000100' = 'WriteAttributes'
			[UInt32]'0x00000080' = 'ReadAttributes'
			[UInt32]'0x00000040' = 'DeleteChild'
			[UInt32]'0x00000020' = 'Execute'
			[UInt32]'0x00000010' = 'WriteExtendedAttributes'
			[UInt32]'0x00000008' = 'ReadExtendedAttributes'
			[UInt32]'0x00000004' = 'AppendData'
			[UInt32]'0x00000002' = 'WriteData'
			[UInt32]'0x00000001' = 'ReadData'
		}

		$DirectoryAccessMask = @{
			[UInt32]'0x80000000' = 'GenericRead'
			[UInt32]'0x40000000' = 'GenericWrite'
			[UInt32]'0x20000000' = 'GenericExecute'
			[UInt32]'0x10000000' = 'GenericAll'
			[UInt32]'0x02000000' = 'MaximumAllowed'
			[UInt32]'0x01000000' = 'AccessSystemSecurity'
			[UInt32]'0x00100000' = 'Synchronize'
			[UInt32]'0x00080000' = 'WriteOwner'
			[UInt32]'0x00040000' = 'WriteDAC'
			[UInt32]'0x00020000' = 'ReadControl'
			[UInt32]'0x00010000' = 'Delete'
			[UInt32]'0x00000100' = 'WriteAttributes'
			[UInt32]'0x00000080' = 'ReadAttributes'
			[UInt32]'0x00000040' = 'DeleteChild'
			[UInt32]'0x00000020' = 'Traverse'
			[UInt32]'0x00000010' = 'WriteExtendedAttributes'
			[UInt32]'0x00000008' = 'ReadExtendedAttributes'
			[UInt32]'0x00000004' = 'AddSubdirectory'
			[UInt32]'0x00000002' = 'AddFile'
			[UInt32]'0x00000001' = 'ListDirectory'
		}

		$RegistryKeyAccessMask = @{
			# Generic access rights
			[UInt32]'0x10000000' = 'GenericAll'
			[UInt32]'0x20000000' = 'GenericExecute'
			[UInt32]'0x40000000' = 'GenericWrite'
			[UInt32]'0x80000000' = 'GenericRead'
			# Registry key access rights
			[UInt32]'0x00000001' = 'QueryValue'
			[UInt32]'0x00000002' = 'SetValue'
			[UInt32]'0x00000004' = 'CreateSubKey'
			[UInt32]'0x00000008' = 'EnumerateSubKeys'
			[UInt32]'0x00000010' = 'Notify'
			[UInt32]'0x00000020' = 'CreateLink'
			# Valid standard access rights for registry keys
			[UInt32]'0x00010000' = 'Delete'
			[UInt32]'0x00020000' = 'ReadControl'
			[UInt32]'0x00040000' = 'WriteDAC'
			[UInt32]'0x00080000' = 'WriteOwner'
		}

		$AccessMask = @{
			$TypeFile        = $FileAccessMask
			$TypeDirectory   = $DirectoryAccessMask
			$TypeRegistryKey = $RegistryKeyAccessMask
		}

		$AccessRights = @{
			$TypeFile        = "FileSystemRights"
			$TypeDirectory   = "FileSystemRights"
			$TypeRegistryKey = "RegistryRights"
		}
  
	}

	PROCESS {

		try {
            
			# First things first, try to get the ACL of the object given its path.
			$Acl = Get-Acl -Path $Path -ErrorAction SilentlyContinue -ErrorVariable GetAclError
			if ($GetAclError) { return }
    
			# If no ACL is returned, it means that the object has a "null" DACL, in which case everyone is
			# granted full access to the object. We can therefore simply return a "virtual" ACE that grants
			# Everyone the "FullControl" right and exit.
			if ($null -eq $Acl) {
				$Result = New-Object -TypeName PSObject
				$Result | Add-Member -MemberType "NoteProperty" -Name "IdentityReference-0" -Value "S-1-1-0"
				$Result | Add-Member -MemberType "NoteProperty" -Name "Permissions-0" -Value "GenericAll"
				$Result | Add-Member -MemberType "NoteProperty" -Name $("InheritanceFlags-0") -Value False
				$Result | Add-Member -MemberType "NoteProperty" -Name $("PropagationFlags-0") -Value False
				$Result
				return
			}

			$AllowAces = [Object[]]($Acl | Select-Object -ExpandProperty Access | Where-Object { $_.AccessControlType -match "Allow" })
			# Here we simply get the access mask, access list name and list of access rights that are
			# specific to the object type we are dealing with.
			$TypeAccessMask = $AccessMask[$Type]
			$TypeAccessRights = $AccessRights[$Type]

			# Need to make sure it not null because of PSv2
			if ($AllowAces) {
				$Result = New-Object -TypeName PSObject
				$count = 0
				foreach ($AllowAce in $AllowAces) {

					
					# Here, we simply extract the permissions for each Identity reference
					$Permissions = New-Object System.Collections.ArrayList
					$TypeAccessMask.Keys | Where-Object { $AllowAce.$TypeAccessRights.value__ -band $_ } | ForEach-Object { $null = $Permissions.Add($TypeAccessMask[$_]) }
					if ($AllowAce.IsInherited -eq $False -or $type -notlike "Directory") {
						$Result | Add-Member -MemberType "NoteProperty" -Name $("IdentityReference-" + $count) -Value $AllowAce.IdentityReference
						$Result | Add-Member -MemberType "NoteProperty" -Name $("Permissions-" + $count) -Value ($Permissions -join ", ")
						if ($type -notlike "Directory") { $Result | Add-Member -MemberType "NoteProperty" -Name $("IsInherited-" + $count) -Value $AllowAce.IsInherited }
						$Result | Add-Member -MemberType "NoteProperty" -Name $("InheritanceFlags-" + $count) -Value $AllowAce.InheritanceFlags
						$Result | Add-Member -MemberType "NoteProperty" -Name $("PropagationFlags-" + $count) -Value $AllowAce.PropagationFlags
						$count += 1
					}
                    
				}
				if ($count -gt 0) {
					$Result | Add-Member -MemberType "NoteProperty" -Name "Count" -Value $count
				}
                
				$Result
			}
		}
		catch {
			Write-Debug "Could not handle path: $($Path)"
		}
	}
}
function Invoke-ServicesImagePermissionsCheck {
	<#
    .SYNOPSIS
    Enumerates all the services that have a modifiable binary (or argument)
    Author: @StaringCat
    License: BSD 3-Clause
    .DESCRIPTION
    FIrst, it enumerates the services thanks to the custom "Get-ServiceDriverList" function. For each result, it checks the permissions of the ImagePath setting thanks to the "Get-ModifiablePath" function. Each result is returned in a custom PS object.
    .EXAMPLE
    PS C:\> Invoke-ServicesImagePermissionsCheck
    Name              : VulneService
    ImagePath         : C:\APPS\service.exe
    User              : LocalSystem
    ModifiablePath    : C:\APPS\service.exe
    IdentityReference-0  : NT SERVICE\TrustedInstaller
    Permissions-0        : WriteOwner, Delete, WriteAttributes, Synchronize, ReadControl, ListDirectory, AddSubdirectory, WriteExtendedAttributes, WriteDAC, ReadAttributes, AddFile, ReadExtendedAttributes, 
                           DeleteChild, Traverse
    IsInherited-0        : True
    InheritanceFlags-0   : None
    PropagationFlags-0   : None
    #>

	[CmdletBinding()] Param()

	$Services = Get-ServiceDriverList -FilterLevel 1
	Write-Verbose "Enumerating $($Services.Count) services..."
   
	foreach ($Service in $Services) {
		if ($Service.ImagePath -match "(\""([^\""]+)\"")|((^[^\s]+)\s)|(^[^\s]+$)") {
			$CleanImagePath = $matches[0] -replace """", ""
			$Permissions = Get-AclModificationRights -Path $CleanImagePath -Type File 

			if ( $Permissions) {
				For ($permissionCount = 0; $permissionCount -lt $Permissions.count; $permissionCount++) {
					Update-LogFile $logFileName ("
ServiceName:" + $Service.Name + "
Path: " + $Service.ImagePath + "
IdentityReference: " + $Permissions.$("IdentityReference-" + $permissionCount) + "
FileSystemRights: "+ $Permissions.$("Permissions-" + $permissionCount) + "
IsInherited: " + $Permissions.$("IsInherited-" + $permissionCount) + "
InheritanceFlags: " + $Permissions.$("InheritanceFlags-" + $permissionCount) + "
PropagationFlags: " + $Permissions.$("PropagationFlags-" + $permissionCount) + "")
				}
				Update-LogFile $logFileName "------------------------"
			}
           
            
		}
	}
}

function Invoke-DriverImagePermissionsCheck {
	<#
    .SYNOPSIS
    Enumerates all the services that have a modifiable binary (or argument)
    Author: @StaringCat
    License: BSD 3-Clause
    .DESCRIPTION
    FIrst, it enumerates the services thanks to the custom "Get-ServiceDriverList" function. For each result, it checks the permissions of the ImagePath setting thanks to the "Get-ModifiablePath" function. Each result is returned in a custom PS object.
    .EXAMPLE
    PS C:\> Invoke-ServicesImagePermissionsCheck
    DriverName              : VulneService
    Path         : C:\APPS\service.exe
    IdentityReference : NT AUTHORITY\Authenticated Users
    
    #>

	[CmdletBinding()] Param()

	$Drivers = Get-ServiceDriverList -FilterLevel 2
	Write-Verbose "Enumerating $($Services.Count) services..."
   
	foreach ($Driver in $Drivers) {
		$Driver.ImagePath = $Driver.ImagePath -ireplace "(\\SystemRoot\\system32|^system32)", ($env:windir + "\System32") -replace "\\\?\?\\", ""
		$Permissions = Get-AclModificationRights -Path $Driver.ImagePath -Type File 

		if ( $Permissions) {
			For ($permissionCount = 0; $permissionCount -lt $Permissions.count; $permissionCount++) {
				#don't touch the formalism :)
				Update-LogFile $logFileName("
DriverName:" + $Driver.Name + "
Path: " + $Driver.ImagePath + "
IdentityReference: " + $Permissions.$("IdentityReference-" + $permissionCount) + "
FileSystemRights: "+ $Permissions.$("Permissions-" + $permissionCount) + "
IsInherited: " + $Permissions.$("IsInherited-" + $permissionCount) + "
InheritanceFlags: " + $Permissions.$("InheritanceFlags-" + $permissionCount) + "
PropagationFlags: " + $Permissions.$("PropagationFlags-" + $permissionCount) + "")
			}
			Update-LogFile $logFileName "------------------------"
		}	
        
	}
}

function Invoke-DirectoryPermissionsCheck {
	<#
    .SYNOPSIS
    Enumerates all the critical directory
    Author: @StaringCat
    License: BSD 3-Clause
    .DESCRIPTION
    Enumerate all directory of ProgramFiles and Windows with a 0 depth.
    .EXAMPLE
    PS C:\> Invoke-ServicesImagePermissionsCheck
    Name              : VulneService
    IdentityReference-0  : NT SERVICE\TrustedInstaller
    Permissions-0        : WriteOwner, Delete, WriteAttributes, Synchronize, ReadControl, ListDirectory, AddSubdirectory, WriteExtendedAttributes, WriteDAC, ReadAttributes, AddFile, ReadExtendedAttributes, 
                            DeleteChild, Traverse
    IsInherited-0        : True
    InheritanceFlags-0   : None
    PropagationFlags-0   : None
    #>
	[array]$ExclusionList = $null

	# by default the level used is Low (0 depth)
	if ($scanLevelRightsOnCriticalDirectories -lt 1) {
		Write-Error "Depth Level is below 0"
		Write-Warning "define depth level to 0"
		$scanLevelRightsOnCriticalDirectories = 1
	}
	
	Write-Warning "By default, WinSxs and LCU repertories are excluded because they are too big (10000 repertories)"
	Write-Host "[*]"$scanLevelRightsOnCriticalDirectories" depth of scan is used" -ForegroundColor Yellow
	$Directories = @("C:/", $env:windir, $Env:ProgramFiles)
	$Directories += @((Get-ChildItem -Path $env:windir, $Env:ProgramFiles -Directory -ErrorAction SilentlyContinue).FullName)
	# exclude windows component store and LCU cause is too big 
	if ($includeWinSxs -eq $false) {
		$ExclusionList += @('WinSxs') 
		
	}
	if ($includeLCU -eq $false) {
		$ExclusionList += @('servicing') 
	}
	$Directories += @((Get-ChildItem -Path $env:windir, $Env:ProgramFiles -Directory -Exclude $ExclusionList |
			Get-ChildItem -Directory -Recurse -Depth $($scanLevelRightsOnCriticalDirectories - 1) -ErrorAction SilentlyContinue).FullName)
	Write-Host "extracting ACL for $($Directories.Count) directories" -ForegroundColor Green
	#reduce time
	$pathStack = @()
	Foreach ($Directory in $Directories) { 

		$Permissions = Get-AclModificationRights -Path ($Directory) -Type Directory 
		if ($Permissions.count) {
			if ( $pathStack.Count -gt 0) {
				$pathStack += @("Path: " + ($Directory))
				Update-LogFile	$logFileName($pathStack)
				$pathStack = @()
			}
			else {
				Update-LogFile $logFileName ("Path: " + ($Directory))
			}
			For ($permissionCount = 0; $permissionCount -lt $Permissions.count; $permissionCount++) {
				#don't touch the formalism :)
				if ($Permissions.$("IdentityReference-" + $permissionCount)) {
					Update-LogFile $logFileName("
IdentityReference: " + $Permissions.$("IdentityReference-" + $permissionCount) + "
FileSystemRights: "+ $Permissions.$("Permissions-" + $permissionCount) + "
InheritanceFlags: " + $Permissions.$("InheritanceFlags-" + $permissionCount) + "
PropagationFlags: " + $Permissions.$("PropagationFlags-" + $permissionCount) + "
")
				}
			}
	
		}
		else {
			$pathStack += @("Path: " + ($Directory) + "
")
		}
	}
}


Function Export-ScheduledTasks {
	# Scheduled tasks
	$scheduledTasksOutput = "$($global:outputPath)\scheduled-tasks.dat"
	Update-LogFile $scheduledTasksOutput "--=== Scheduled tasks ===--"
	Try {
		schtasks /query /fo list /v | Out-File -FilePath $scheduledTasksOutput -Encoding ascii -Append

		If ($?) {
			Write-Host "[-] Save Scheduled tasks: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot get scheduled tasks"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}

	Update-LogFile $logFileName "--=== Scheduled tasks ===--"
	Try {
		
		$scheduled_tasks = Get-ScheduledTasks
		If ($?) {
			ForEach ($scheduled_task in $scheduled_tasks) {
				Update-LogFile $logFileName ("Name: " + $scheduled_task.Name)
				Update-LogFile $logFileName ("Path: " + $scheduled_task.Path)
				Update-LogFile $logFileName ("LastRunTime: " + $scheduled_task.LastRunTime)
				Update-LogFile $logFileName ("NextRunTime: " + $scheduled_task.NextRunTime)
				Update-LogFile $logFileName ("Actions: " + $scheduled_task.Actions)
				Update-LogFile $logFileName ("Argument: " + $scheduled_task.Argument)
				Update-LogFile $logFileName ("Author: " + $scheduled_task.Author)
				Update-LogFile $logFileName ("Description: " + $scheduled_task.Description)
				Update-LogFile $logFileName ("RunAs: " + $scheduled_task.RunAs)
				Update-LogFile $logFileName ("Status: " + $scheduled_task.Status)
				Update-LogFile $logFileName ""

			}

			Write-Host "[-] Scheduled tasks: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve scheduled tasks"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}


Function Export-StartupItems {
	# Startup items
	Update-LogFile $logFileName "--=== Startup items ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		$colItems = Get-WMIObject Win32_StartupCommand -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Command: " + $objItem.Command)
				Update-LogFile $logFileName ("User: " + $objItem.User)
				Update-LogFile $logFileName ("Caption: " + $objItem.Caption)
				Update-LogFile $logFileName ""

				$binary_path = Resolve-CommandPath($objItem.Command.Split("-")[0].Split("/")[0].Replace('"', ''))

				Try {
					icacls $binary_path 2>&1 > $file

					ForEach ($system in Get-Content $file) {
						Update-LogFile $logFileName ($system)
					}

					Update-LogFile $logFileName ""
				}
				Catch {
					Write-Host "Error occured (see error log file)" -ForegroundColor Red
					Update-LogFile $ErrorlogFileName $_.Exception.Message
				}
			}

			Write-Host "[-] Startup items: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve startup items"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Export-StoragePeripherals {
	# Storage Peripherals
	Update-LogFile $logFileName "--=== Storage peripherals ===--"

	Try {
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\RemovableStorageDevices" "Deny_All"
		Update-LogFile $logFileName ("Deny access to all removable storage classes (Deny_All): $($tmp)")

		If ($?) {
			Write-Host "[-] Storage peripherals: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve storage peripherals configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Export-AppLockerConfiguration {
	# AppLocker
	Update-LogFile $logFileName "--=== AppLocker configuration ===--"

	Try {
		$serv = (Get-Service "AppIDSvc").Status

		If ($?) {
			Update-LogFile $logFileName ("AppIDSvc service status: " + $serv)
			Get-AppLockerPolicy -Xml -Effective | Set-Content $appLockerPolicy
		}
		Else {
			Throw "[!] Cannot retrieve AppIDSvc status"
		}

		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows" "Safer"
		Update-LogFile $logFileName ("The setting ""Virtualize file and registry write failures to per-user locations"" must be configured (Safer): $($tmp)")
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\SrpV2\Appx" "EnforcementMode"
		Update-LogFile $logFileName ("AppLocker must be configured for packaged apps (Appx): $($tmp)")
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\SrpV2\Dll" "EnforcementMode"
		Update-LogFile $logFileName ("AppLocker must be configured for DLL (Dll): $($tmp)")
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\SrpV2\Exe" "EnforcementMode"
		Update-LogFile $logFileName ("AppLocker must be configured for executables (Exe): $($tmp)")
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\SrpV2\Msi" "EnforcementMode"
		Update-LogFile $logFileName ("AppLocker must be configured for Windows Installers (Msi): $($tmp)")
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows\SrpV2\Script" "EnforcementMode"
		Update-LogFile $logFileName ("AppLocker must be configured for Scripts (Script): $($tmp)")


		If ($?) {
			Write-Host "[-] AppLocker configuration: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve AppLocker configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Export-AppLockerRules {
	# AppLocker
	Update-LogFile $logFileName "--=== AppLocker rules ===--"

	Try {
		$serv = Get-AppLockerPolicy -Effective

		If ($?) {
			Update-LogFile $logFileName ($serv)
			Write-Host "[-] AppLocker rules: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve AppLocker rules"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-SystemAccessControl {
	Write-Host "[4] - System Access Control"
	Update-LogFile $logFileName "===== [4] System Access Control ====="

	Export-UserAccountControl
	Export-Autorun
	Export-FileSystem
	Update-LogFile $logFileName "--=== Rights on services ===--"
	Invoke-ServicesImagePermissionsCheck
	Write-Host "[-] DACL Service: OK" -ForegroundColor Green
	Update-LogFile $logFileName "--=== Rights on system drivers ===--"
	Invoke-DriverImagePermissionsCheck
	Write-Host "[-] DACL Driver: OK" -ForegroundColor Green
	if ($ignoreRightsOnCriticalDirectories) {
		Write-Host "[-] Ignore rights" -ForegroundColor Yellow
		Update-LogFile $logFileName "===== [-] Ignore rights ====="
	}
	else {
		Update-LogFile $logFileName "--=== Rights on critical directories ===--"
		Invoke-DirectoryPermissionsCheck
		Write-Host "[-] DACL Critical Directory: OK" -ForegroundColor Green
	}

	Export-ScheduledTasks
	Export-StartupItems
	Export-StoragePeripherals
	Export-AppLockerConfiguration
	Export-AppLockerRules
}




###############################
#  5 - Network Access Control #
###############################

Function Get-NetworkInterfaces {
	# Network interfaces
	Update-LogFile $logFileName "--=== Network interfaces ===--"

	Try {
		$colItems = Get-WMIObject Win32_NetworkAdapter -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("NetEnabled: " + $objItem.NetEnabled)
				Update-LogFile $logFileName ("ServiceName: " + $objItem.ServiceName)
				Update-LogFile $logFileName ("Index: " + $objItem.Index)
				Update-LogFile $logFileName ("MACAddress: " + $objItem.MACAddress)
				Update-LogFile $logFileName ("AdapterType: " + $objItem.AdapterType)
				Update-LogFile $logFileName ("DeviceID: " + $objItem.DeviceID)
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("NetworkAddresses: " + $objItem.NetworkAddresses)
				Update-LogFile $logFileName ("Speed: " + $objItem.Speed)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Network interfaces: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve network interfaces"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-WirelessConfiguration {
	# Wireless configuration (Wi-Fi wifi)
	Update-LogFile $logFileName "--=== Wireless configuration ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		netsh wlan show all >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Wireless configuration: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve wireless configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-WirelessKeys {
	# Wireless keys
	Update-LogFile $logFileName "--=== Wireless keys ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		netsh wlan show profiles | Select-String "^[^:\n]+\: *([^\n]+)$"  | ForEach-Object { $name = $_.Matches.Groups[1].Value.Trim(); $_ } | ForEach-Object { (netsh wlan show profile name="$name" key=clear) }  | Select-String "Key Content\W+\:(.+)$" | ForEach-Object { $pass = $_.Matches.Groups[1].Value.Trim(); $_ } | ForEach-Object { [PSCustomObject]@{ PROFILE_NAME = $name; PASSWORD = $pass } } | Format-Table -AutoSize >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Wireless keys: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve wireless keys"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-IpConfiguration {
	# IP configuration
	Update-LogFile $logFileName "--=== IP configuration ===--"

	Try {
		$colItems = Get-WMIObject Win32_NetworkAdapterConfiguration -NameSpace "root\CIMV2" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("IPEnabled: " + $objItem.IPEnabled)
				Update-LogFile $logFileName ("ServiceName: " + $objItem.ServiceName)
				Update-LogFile $logFileName ("Description: " + $objItem.Description)
				Update-LogFile $logFileName ("MACAddress: " + $objItem.MACAddress)
				Update-LogFile $logFileName ("DHCPEnabled: " + $objItem.DHCPEnabled)
				Update-LogFile $logFileName ("DHCPServer: " + $objItem.DHCPServer)
				Update-LogFile $logFileName ("DHCPLeaseExpires: " + $objItem.DHCPLeaseExpires)
				Update-LogFile $logFileName ("DHCPLeaseObtained: " + $objItem.DHCPLeaseObtained)
				Update-LogFile $logFileName ("IPAddress: " + $objItem.IPAddress)
				Update-LogFile $logFileName ("IPSubnet: " + $objItem.IPSubnet)
				Update-LogFile $logFileName ("Gateway: " + $objItem.DefaultIPGateway)
				Update-LogFile $logFileName ("DNSDomain: " + $objItem.DNSDomain)
				Update-LogFile $logFileName ("WINSPrimaryServer: " + $objItem.WINSPrimaryServer)
				Update-LogFile $logFileName ("DNSDomainSuffixSearchOrder: " + $objItem.DNSDomainSuffixSearchOrder)
				Update-LogFile $logFileName ("IPFilterSecurityEnabled: " + $objItem.IPFilterSecurityEnabled)
				Update-LogFile $logFileName ("IPPortSecurityEnabled: " + $objItem.IPPortSecurityEnabled)
				If ($objItem.TcpipNetbiosOptions -eq 0) {
					$TcpipNetbiosOptions = "EnableNetbiosViaDhcp"
				}
				ElseIf ($objItem.TcpipNetbiosOptions -eq 1) {
					$TcpipNetbiosOptions = "EnableNetbios"
				}
				ElseIf ($objItem.TcpipNetbiosOptions -eq 2) {
					$TcpipNetbiosOptions = "DisableNetbios"
				}
				Update-LogFile $logFileName ("TcpipNetbiosOptions: " + $TcpipNetbiosOptions)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] IP configuration: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve IP configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-ListeningServices {
	# Listening services
	Update-LogFile $logFileName "--=== Listening services ===--"

	Try {
		$colItems = Get-NetTCPConnection -State Listen | Select-Object -Property *,@{'Name' = 'ProcessName';'Expression'={(Get-Process -Id $_.OwningProcess).Name}}

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("ProcessName: " + $objItem.ProcessName)
				Update-LogFile $logFileName ("LocalAddress: " + $objItem.LocalAddress)
				Update-LogFile $logFileName ("LocalPort: " + $objItem.LocalPort)		
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Listening services: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve listening services"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-FirewallProfilesParameters {
	# Firewall profiles parameters
	Update-LogFile $logFileName "--=== Firewall profiles parameters ===--"

	Try {
		Update-LogFile $logFileName ("Parameter ""Unidentified networks"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\010103000F0000F0010000000F0000F0C967A3643C3AD745950DA7859209176EF5B87C875FA20DF21951640E807D7C24" "Category"
		Update-LogFile $logFileName ("- Category: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\010103000F0000F0010000000F0000F0C967A3643C3AD745950DA7859209176EF5B87C875FA20DF21951640E807D7C24" "CategoryReadOnly"
		Update-LogFile $logFileName ("- CategoryReadOnly: $($tmp)")

		If ($?) {
			Write-Host "[-] Firewall profiles parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve firewall profiles parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-ActualConnectionsProfiles {
	# Actual connections profiles
	Update-LogFile $logFileName "--=== Actual connections profiles ===--"

	Try {
		$colItems = Get-WmiObject -Namespace "root\StandardCimv2" -Class MSFT_NetConnectionProfile
		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("Name: " + $objItem.Name)
				Update-LogFile $logFileName ("InterfaceAlias: " + $objItem.InterfaceAlias)
				Update-LogFile $logFileName ("InterfaceIndex: " + $objItem.InterfaceIndex)
				Update-LogFile $logFileName ("NetworkCategory: " + $objItem.NetworkCategory)
				Update-LogFile $logFileName ("IPv4Connectivity: " + $objItem.IPv4Connectivity)
				Update-LogFile $logFileName ("IPv6Connectivity: " + $objItem.IPv6Connectivity)
				Update-LogFile $logFileName ""
			}
			Write-Host "[-] Actual connections profiles: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve actual connections profiles"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-FirewallProfiles {
	# Firewall profiles
	Update-LogFile $logFileName "--=== Firewall profiles ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		netsh advfirewall show allprofile >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Firewall profiles: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve firewall profiles"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-FirewallRules {
	# Firewall rules
	Update-LogFile $logFileName "--=== Firewall rules ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		(New-object -comObject HNetCfg.FwPolicy2).Rules >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Firewall rules: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve firewall rules"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-IPSecParameters {
	# IPSec parameters
	Update-LogFile $logFileName "--=== IPSec parameters ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		netsh advfirewall show global >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] IPSec parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve IPSec parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-IPSecRules {
	# IPSec rules
	Update-LogFile $logFileName "--=== IPSec rules ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		netsh advfirewall consec show rule name=all >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] IPSec rules: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve IPSec rules"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-NetworkShares {
	# Network shares
	Update-LogFile $logFileName "--=== Network shares ===--"

	Try {
		Get-ShareACL

		If ($?) {
			Write-Host "[-] Network shares: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve network shares"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-NetworkConfigurationParameters {
	# Network configuration parameters
	Update-LogFile $logFileName "--=== Network configuration parameters ===--"

	Try {
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "DisableIPSourceRouting"
		Update-LogFile $logFileName ("IP source routing must be disabled (DisableIPSourceRouting): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "EnableDeadGWDetect"
		Update-LogFile $logFileName ("Dead gateway detection must be disabled (EnableDeadGWDetect): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "EnableICMPRedirect"
		Update-LogFile $logFileName ("ICMP redirect must be disabled (EnableICMPRedirect): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "EnablePMTUDiscovery"
		Update-LogFile $logFileName ("PMTU must be disabled (EnablePMTUDiscovery): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "KeepAliveTime"
		Update-LogFile $logFileName ("Keep alive time must be set (KeepAliveTime): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "PerformRouterDiscovery"
		Update-LogFile $logFileName ("Router discovery must be disabled (PerformRouterDiscovery): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "SynAttackProtect"
		Update-LogFile $logFileName ("The functionality protecting from SynFlood attacks must be enabled (SynAttackProtect): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "TcpMaxHalfOpen"
		Update-LogFile $logFileName ("The number of connections authorized in the SYN-RCVD state before protection must be configured (TcpMaxHalfOpen): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters" "TcpMaxHalfOpenRetried"
		Update-LogFile $logFileName ("The number of connections authorized in the SYN-RCVD state for which at least one SYN retransmission has oCD-ROM ccured must be configured (TcpMaxHalfOpenRetried): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\IPSEC" "NoDefaultExempt"
		Update-LogFile $logFileName ("NoDefaultExempt for IPSec Filtering must be disabled (NoDefaultExempt): $($tmp)")

		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\Windows NT" "DNSClient"
		Update-LogFile $logFileName ("DNSClient for LLMNR usage must be disabled (DNSClient): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters" "AutoShareServer"
		Update-LogFile $logFileName ("Administrative shares must be disabled (AutoShareServer): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters" "AutoShareWks"
		Update-LogFile $logFileName ("Local drives shares must be ignored (AutoShareWks): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\MrxSmb\Parameters" "RefuseReset"
		Update-LogFile $logFileName ("ResetBrowser trames must be ignored (RefuseReset): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\Lanmanserver\Parameters" "Hidden"
		Update-LogFile $logFileName ("Server service must be prevented from sending exploration announces (Hidden): $($tmp)")

		$tmp = Get-Registry "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" "AutoAdminLogon"
		Update-LogFile $logFileName ("Local administrator autologon must be disabled (AutoAdminLogon): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" "ScreenSaverGracePeriod"
		Update-LogFile $logFileName ("Grace period for screensaver must be disabled (ScreenSaverGracePeriod): $($tmp)")

		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\TCPIP6\Parameters" "DisabledComponents"
		Update-LogFile $logFileName ("IPv6 protocol must be disabled (DisabledComponents): $($tmp)")

		If ($?) {
			Write-Host "[-] Registry: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of registry parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-SmbConfiguration {
	# SMB configuration
	$strSectionName = "SMB Configuration"
	Update-LogFile $logFileName "--=== $($strSectionName) ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		#Get-SmbServerConfiguration >> $file
		# Get-SmbServerConfiguration | Select-Object -Property "EnableSMB*" | Format-List

		$tmp = Invoke-WMIMethod -Namespace "root\Microsoft\Windows\SMB" -Class MSFT_SmbServerConfiguration -Name GetConfiguration
		$tmp.Output >> $file
		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] $($strSectionName): OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve $($strSectionName)"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
	Remove-Variable strSectionName
}

Function Get-Category-NetworkAccessControl {
	Write-Host "[5] - Network Access Control"
	Update-LogFile $logFileName "===== [5] Network Access Control ====="

	Get-NetworkInterfaces
	Get-WirelessConfiguration

	If ($extractWirelessKeys) {
		Get-WirelessKeys
	}

	Get-IpConfiguration
	Get-ListeningServices
	Get-FirewallProfilesParameters
	Get-ActualConnectionsProfiles
	Get-FirewallProfiles
	Get-FirewallRules
	Get-IPSecParameters
	Get-IPSecRules
	Get-NetworkShares
	Get-NetworkConfigurationParameters
	Get-SmbConfiguration
}




###############################
#       6 - Encryption        #
###############################

Function Get-CertstoreParameters {
	# Certstore parameters
	Update-LogFile $logFileName "--=== Certstore parameters ===--"

	Try {
		$tmp = Get-Registry "HKLM:\Software\Policies\Microsoft\SystemCertificates\AuthRoot" "DisableRootAutoUpdate"
		Update-LogFile $logFileName ("Parameter ""Turn off automatic updating of trusted root authority certificates"" must be configured (DisableRootAutoUpdate): $($tmp)")

		If ($?) {
			Write-Host "[-] Certstore parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve certstore parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-BitlockerStatus {
	# BitLocker status
	Update-LogFile $logFileName "--=== BitLocker status ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		manage-bde -status >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] BitLocker status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve BitLocker status"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-Category-Encryption {
	Write-Host "[6] - Encryption"
	Update-LogFile $logFileName "===== [6] - Encryption ====="

	Get-CertstoreParameters
	Get-BitlockerStatus
}




###############################
#         7 - Logging         #
###############################

Function Get-AppliedAuditPolicy {
	# Applied audit policy
	Update-LogFile $logFileName "--=== Applied audit policy ===--"

	Try {
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Control\Lsa" "SCENoApplyLegacyAuditPolicy"
		Update-LogFile $logFileName ("Audit policy using subcategories must be enabled (SCENoApplyLegacyAuditPolicy): $($tmp)")

		Update-LogFile $logFileName ("""Audit directory service access"" must be configured: $(Get-GPO $secpolExportFileName 'AuditDSAccess.*')")
		Update-LogFile $logFileName ("""Audit object access"" must be configured: $(Get-GPO $secpolExportFileName 'AuditObjectAccess.*')")
		Update-LogFile $logFileName ("""Audit privilege use"" must be configured: $(Get-GPO $secpolExportFileName 'AuditPrivilegeUse.*')")
		Update-LogFile $logFileName ("""Audit account management"" must be configured: $(Get-GPO $secpolExportFileName 'AuditAccountManage.*')")
		Update-LogFile $logFileName ("""Audit process tracking"" must be configured: $(Get-GPO $secpolExportFileName 'AuditProcessTracking.*')")
		Update-LogFile $logFileName ("""Audit logon events"" must be configured: $(Get-GPO $secpolExportFileName 'AuditLogonEvents.*')")
		Update-LogFile $logFileName ("""Audit account logon events"" must be configured: $(Get-GPO $secpolExportFileName 'AuditAccountLogon.*')")
		Update-LogFile $logFileName ("""Audit of system events"" must be configured: $(Get-GPO $secpolExportFileName 'AuditSystemEvents.*')")
		Update-LogFile $logFileName ("""Audit policy change"" must be configured: $(Get-GPO $secpolExportFileName 'AuditPolicyChange.*')")

		If ($?) {
			Write-Host "[-] Standard audit policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve standard audit policy"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-AuditPolicy {
	# Audit policy
	Update-LogFile $logFileName "--=== Audit policy ===--"

	Try {
		auditpol /backup /file:"$global:auditpolFileName"

		If (-Not $?) {
			Throw "[!] Audit policy: error during audit policy backup."
		}

		Get-Content $global:auditpolFileName | Out-File -FilePath $logFileName -Encoding utf8 -Append

		If ($?) {
			Write-Host "[-] Audit policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Audit policy: error during copy into audit file."
		}
	}
	Catch {
		Update-LogFile $ErrorlogFileName $_.Exception.Message
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
	}
	Finally {
		#del $global:auditpolFileName
	}
}

Function Get-EventLogsParameters {
	# Event logs parameters
	Update-LogFile $logFileName "--=== Event logs parameters ===--"

	Try {

		# DES INFORMATIONS SUR "COMMENT LIRE LES DROITS D'ACCES AUX LOGS" SONT DISPOS ICI :
		#https://docs.microsoft.com/en-us/windows/win32/eventlog/eventlog-key

		#Application
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Application" "File"
		Update-LogFile $logFileName ("Path file of the Application Event log file must be configured (File): $($tmp)")
		$tmp = [System.Math]::Round((Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Application" "MaxSize") / 1000)
		Update-LogFile $logFileName ("The Application Event log size must be configured (MaxSize): $($tmp)Ko")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Application" "AutoBackupLogFiles"
		Update-LogFile $logFileName ("The Application Event log auto backup must be configured (AutoBackupLogFiles): $($tmp)")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Application" "Retention"
		Update-LogFile $logFileName ("The Application Event log retention must be configured (Retention): $($tmp)")
		$tmp = wevtutil gl Application  | Select-String isolation
		Update-LogFile $logFileName $tmp
		$tmp = wevtutil gl Application  | Select-String channelAccess
		Update-LogFile $logFileName ("$tmp `n")

		#Security
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Security" "File"
		Update-LogFile $logFileName ("Path file of the Security Event log file must be configured (File): $($tmp)")
		$tmp = [System.Math]::Round((Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Security" "MaxSize") / 1000)
		Update-LogFile $logFileName ("The Security Event log size must be configured (MaxSize): $($tmp)Ko")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Security" "AutoBackupLogFiles"
		Update-LogFile $logFileName ("The Security Event log auto backup must be configured (AutoBackupLogFiles): $($tmp)")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\Security" "Retention"
		Update-LogFile $logFileName ("The Security Event log retention must be configured (Retention): $($tmp)")
		$tmp = wevtutil gl Security  | Select-String isolation
		Update-LogFile $logFileName $tmp
		$tmp = wevtutil gl Security  | Select-String channelAccess
		Update-LogFile $logFileName ("$tmp `n")

		#System
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\System" "File"
		Update-LogFile $logFileName ("Path file of the System Event log file must be configured (File): $($tmp)")
		$tmp = [System.Math]::Round((Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\System" "MaxSize") / 1000)
		Update-LogFile $logFileName ("The System Event log size must be configured (MaxSize): $($tmp)Ko")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\System" "AutoBackupLogFiles"
		Update-LogFile $logFileName ("The System Event log auto backup must be configured (AutoBackupLogFiles): $($tmp)")
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Services\EventLog\System" "Retention"
		Update-LogFile $logFileName ("The System Event log retention must be configured (Retention): $($tmp)")
		$tmp = wevtutil gl System  | Select-String isolation
		Update-LogFile $logFileName $tmp
		$tmp = wevtutil gl System  | Select-String channelAccess
		Update-LogFile $logFileName ("$tmp")

		If ($?) {
			Write-Host "[-] Event logs parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve one of event logs parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-Logging {
	Write-Host "[7] - Logging"
	Update-LogFile $logFileName "===== [7] - Logging ====="

	Get-AppliedAuditPolicy
	Get-AuditPolicy
	Get-EventLogsParameters
}




###############################
#     8 - Patch Management    #
###############################


Function Get-InstalledHotfixes {
	# Installed hotfixes
	Update-LogFile $logFileName "--=== Installed hotfixes ===--"

	Try {
		Get-HotFix | Select-Object -Property HotFixID, InstalledOn, InstalledBy, Description | ConvertTo-Csv -NoTypeInformation | Out-File -FilePath $logFileName -Encoding ascii -Append

		If ($?) {
			Write-Host "[-] Windows updates status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Windows updates"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	
}

Function Get-WindowsUpdatesParameters {
	# Windows updates parameters
	Update-LogFile $logFileName "--=== Windows updates parameters ===--"

	Try {
		Update-LogFile $logFileName ("Parameter ""Do not display ""Install Updates and Shut Down"" in Shut Down Windows dialog"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "NoAUShutdownOption"
		Update-LogFile $logFileName ("- NoAUShutdownOption: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Do not adjust default option to ""Install Updates and Shut Down"" in Shut Down Windows dialog"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "NoAUAsDefaultShutdownOption"
		Update-LogFile $logFileName ("- NoAUAsDefaultShutdownOption: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Enabling Windows Update Power Management to automatically wake up the computer to install scheduled updates"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "AUPowerManagement"
		Update-LogFile $logFileName ("- AUPowerManagement: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Configure Automatic Updates"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "NoAutoUpdate"
		Update-LogFile $logFileName ("- NoAutoUpdate: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "AUOptions"
		Update-LogFile $logFileName ("- AUOptions: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "ScheduledInstallDay"
		Update-LogFile $logFileName ("- ScheduledInstallDay: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "ScheduledInstallTime"
		Update-LogFile $logFileName ("- ScheduledInstallTime: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Specify intranet Microsoft update service location"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "UseWUServer"
		Update-LogFile $logFileName ("- UseWUServer: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "WUServer"
		Update-LogFile $logFileName ("- WUServer: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "WUStatusServer"
		Update-LogFile $logFileName ("- WUStatusServer: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Automatic Updates detection frequency"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "DetectionFrequency"
		Update-LogFile $logFileName ("- DetectionFrequency: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "DetectionFrequencyEnabled"
		Update-LogFile $logFileName ("- DetectionFrequencyEnabled: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Allow non-administrators to receive update notifications"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" "ElevateNonAdmins"
		Update-LogFile $logFileName ("- ElevateNonAdmins: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Turn on Software Notifications"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "EnableFeaturedSoftware"
		Update-LogFile $logFileName ("- EnableFeaturedSoftware: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Allow Automatic Updates immediate installation"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "AutoInstallMinorUpdates"
		Update-LogFile $logFileName ("- AutoInstallMinorUpdates: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Turn on recommended updates via Automatic Updates"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "IncludeRecommendedUpdates"
		Update-LogFile $logFileName ("- IncludeRecommendedUpdates: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""No auto-restart with logged on users for scheduled automatic updates installations"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "NoAutoRebootWithLoggedOnUsers"
		Update-LogFile $logFileName ("- NoAutoRebootWithLoggedOnUsers: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Re-prompt for restart with scheduled installations"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RebootRelaunchTimeoutEnabled"
		Update-LogFile $logFileName ("- RebootRelaunchTimeoutEnabled: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RebootRelaunchTimeout"
		Update-LogFile $logFileName ("- RebootRelaunchTimeout: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Delay Restart for scheduled installations"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RebootWarningTimeoutEnabled"
		Update-LogFile $logFileName ("- RebootWarningTimeoutEnabled: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RebootWarningTimeout"
		Update-LogFile $logFileName ("- RebootWarningTimeout: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Reschedule Automatic Updates scheduled installations"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RescheduleWaitTimeEnabled"
		Update-LogFile $logFileName ("- RescheduleWaitTimeEnabled: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" "RescheduleWaitTime"
		Update-LogFile $logFileName ("- RescheduleWaitTime: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Enable client-side targeting"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" "TargetGroupEnabled"
		Update-LogFile $logFileName ("- TargetGroupEnabled: $($tmp)")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" "TargetGroup"
		Update-LogFile $logFileName ("- TargetGroup: $($tmp)")

		Update-LogFile $logFileName ("Parameter ""Allow signed updates from an intranet Microsoft update service location"" must be configured:")
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" "AcceptTrustedPublisherCerts"
		Update-LogFile $logFileName ("- AcceptTrustedPublisherCerts: $($tmp)")

		If ($?) {
			Write-Host "[-] Windows updates parameters: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Windows updates parameters"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-InstalledSoftware {
	# Installed softwares
	Update-LogFile $logFileName "--=== Installed softwares ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		If (Test-Path "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\") {
			Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-List >> $file
		}
		ElseIf (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\") {
			Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-List >> $file
		}

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Windows updates status: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Windows updates"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-EnvironmentVariables {
	# Environment variables
	Update-LogFile $logFileName "--=== Environment variables ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		Get-ChildItem Env: | Format-Table -HideTableHeader >> $file
		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] Environment variables: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve environment variables"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-JavaVersion {
	# Java version
	Update-LogFile $logFileName "--=== Java version ===--"

	Try {
		$tmp = java -version 2>&1
		Update-LogFile $logFileName ($tmp)

		# TODO: extract java control panel configuration files (https://docs.oracle.com/javase/7/docs/technotes/guides/jweb/jcp/properties.html)
		# <User Application Data Folder>\LocalLow\Sun\Java\Deployment\deployment.properties
		# <Windows Directory>\Sun\Java\Deployment\deployment.config
		# ${deployment.java.home}\lib\deployment.config

		If ($?) {
			Write-Host "[-] Java version: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Java not found."
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-FlashVersion {
	# Flash version
	Update-LogFile $logFileName "--=== Flash version ===--"

	Try {
		# Directories to scan
		$flashDirectories = @(
			"$($Env:SystemRoot)\System32\Macromed\Flash",
			"$($Env:SystemRoot)\SysWOW64\Macromed\Flash"
		)

		# Results
		$flashResults = @()

		# Get VersionInfo for each files in targeted directories
		ForEach ($flashDirectory in $flashDirectories) {
			If (Test-Path $flashDirectory) {
				$flashFiles = Get-ChildItem $flashDirectory
				ForEach ($flashFile in $flashFiles) {
					$flashResults += Get-Item "$flashDirectory\$flashFile"# | Select-Object -Property FullName, VersionInfo
				}
			}
		}

		# Format and write the result
		$flashResults | ConvertTo-Csv -NoTypeInformation | Out-File -FilePath $logFileName -Encoding ascii -Append

		# TODO: extract flash player settings manager

		If ($?) {
			Write-Host "[-] Flash version: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] An error occurred during flash export."
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-PatchManagement {
	Write-Host "[8] - Patch Management"
	Update-LogFile $logFileName "===== [8] - Patch Management ====="

	Get-InstalledHotfixes
	Get-WindowsUpdatesParameters
	Get-InstalledSoftware
	Get-EnvironmentVariables
	Get-JavaVersion
	Get-FlashVersion
}




###############################
#      9 - Local policies     #
###############################

Function Get-UserRightsAssignment {
	# User rights assignment
	Update-LogFile $logFileName "--=== User rights assignment ===--"

	Try {
		Update-LogFile $logFileName ("Parameter ""Access this computer from the network"" must be configured (SeNetworkLogonRight): $(Get-GPO $secpolExportFileName 'SeNetworkLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Access Credential Manager as a trusted caller"" must be configured (SeTrustedCredManAccessPrivilege): $(Get-GPO $secpolExportFileName 'SeTrustedCredManAccessPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Act as part of the operating system"" must be configured (SeTcbPrivilege): $(Get-GPO $secpolExportFileName 'SeTcbPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Add workstations to domain"" must be configured (SeMachineAccountPrivilege): $(Get-GPO $secpolExportFileName 'SeMachineAccountPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Adjust memory quotas for a process"" must be configured (SeIncreaseQuotaPrivilege): $(Get-GPO $secpolExportFileName 'SeIncreaseQuotaPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Shut down the system"" must be configured (SeShutdownPrivilege): $(Get-GPO $secpolExportFileName 'SeShutdownPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Increase scheduling priority"" must be configured (SeIncreaseBasePriorityPrivilege): $(Get-GPO $secpolExportFileName 'SeIncreaseBasePriorityPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Increase a process working set"" must be configured (SeIncreaseWorkingSetPrivilege): $(Get-GPO $secpolExportFileName 'SeIncreaseWorkingSetPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Allow log on through remote desktop service"" must be configured (SeRemoteInteractiveLogonRight): $(Get-GPO $secpolExportFileName 'SeRemoteInteractiveLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Change the time zone"" must be configured (SeTimeZonePrivilege): $(Get-GPO $secpolExportFileName 'SeTimeZonePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Load and unload device drivers"" must be configured (SeLoadDriverPrivilege): $(Get-GPO $secpolExportFileName 'SeLoadDriverPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Bypass traverse checking"" must be configured (SeChangeNotifyPrivilege): $(Get-GPO $secpolExportFileName 'SeChangeNotifyPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Create symbolic links"" must be configured (SeCreateSymbolicLinkPrivilege): $(Get-GPO $secpolExportFileName 'SeCreateSymbolicLinkPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Create global objects"" must be configured (SeCreateGlobalPrivilege): $(Get-GPO $secpolExportFileName 'SeCreateGlobalPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Create permanent shared objects"" must be configured (SeCreatePermanentPrivilege): $(Get-GPO $secpolExportFileName 'SeCreatePermanentPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Create a pagefile"" must be configured (SeCreatePagefilePrivilege): $(Get-GPO $secpolExportFileName 'SeCreatePagefilePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Create a token object"" must be configured (SeCreateTokenPrivilege): $(Get-GPO $secpolExportFileName 'SeCreateTokenPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Debug programs"" must be configured (SeDebugPrivilege): $(Get-GPO $secpolExportFileName 'SeDebugPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Perform volume maintenance tasks"" must be configured (SeManageVolumePrivilege): $(Get-GPO $secpolExportFileName 'SeManageVolumePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Impersonate a client after authentication"" must be configured (SeImpersonatePrivilege): $(Get-GPO $secpolExportFileName 'SeImpersonatePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Force shutdown from a remote system"" must be configured (SeRemoteShutdownPrivilege): $(Get-GPO $secpolExportFileName 'SeRemoteShutdownPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Generate security audits"" must be configured (SeAuditPrivilege): $(Get-GPO $secpolExportFileName 'SeAuditPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Manage auditing and security log"" must be configured (SeSecurityPrivilege): $(Get-GPO $secpolExportFileName 'SeSecurityPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Deny logon through network"" must be configured (SeDenyNetworkLogonRight): $(Get-GPO $secpolExportFileName 'SeDenyNetworkLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Deny logon locally"" must be configured (SeDenyInteractiveLogonRight): $(Get-GPO $secpolExportFileName 'SeDenyInteractiveLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Deny logon as a service"" must be configured (SeDenyServiceLogonRight): $(Get-GPO $secpolExportFileName 'SeDenyServiceLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Deny logon as a batch job"" must be configured (SeDenyBatchLogonRight): $(Get-GPO $secpolExportFileName 'SeDenyBatchLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Deny log on through Remote Desktop Services"" must be configured (SeDenyRemoteInteractiveLogonRight): $(Get-GPO $secpolExportFileName 'SeDenyRemoteInteractiveLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Change the system time"" must be configured (SeSystemtimePrivilege): $(Get-GPO $secpolExportFileName 'SeSystemtimePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Modify firmware environment values"" must be configured (SeSystemEnvironmentPrivilege): $(Get-GPO $secpolExportFileName 'SeSystemEnvironmentPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Modify an object label"" must be configured (SeRelabelPrivilege): $(Get-GPO $secpolExportFileName 'SeRelabelPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Logon as a service"" must be configured (SeServiceLogonRight): $(Get-GPO $secpolExportFileName 'SeServiceLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Logon as a batch job"" must be configured (SeBatchLogonRight): $(Get-GPO $secpolExportFileName 'SeBatchLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Profile system performance"" must be configured (SeSystemProfilePrivilege): $(Get-GPO $secpolExportFileName 'SeSystemProfilePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Enable computer and user accounts trusted for delegation"" must be configured (SeEnableDelegationPrivilege): $(Get-GPO $secpolExportFileName 'SeEnableDelegationPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Allow log on locally"" must be configured (SeInteractiveLogonRight): $(Get-GPO $secpolExportFileName 'SeInteractiveLogonRight.*')")
		Update-LogFile $logFileName ("Parameter ""Take ownership of files or other objects"" must be configured (SeTakeOwnershipPrivilege): $(Get-GPO $secpolExportFileName 'SeTakeOwnershipPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Profile single process"" must be configured (SeProfileSingleProcessPrivilege): $(Get-GPO $secpolExportFileName 'SeProfileSingleProcessPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Replace a process level token"" must be configured (SeAssignPrimaryTokenPrivilege): $(Get-GPO $secpolExportFileName 'SeAssignPrimaryTokenPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Restore files and directories"" must be configured (SeRestorePrivilege): $(Get-GPO $secpolExportFileName 'SeRestorePrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Remove computer from docking station"" must be configured (SeUndockPrivilege): $(Get-GPO $secpolExportFileName 'SeUndockPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Back up files and directories"" must be configured (SeBackupPrivilege): $(Get-GPO $secpolExportFileName 'SeBackupPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Synchronize directory service data"" must be configured (SeSyncAgentPrivilege): $(Get-GPO $secpolExportFileName 'SeSyncAgentPrivilege.*')")
		Update-LogFile $logFileName ("Parameter ""Lock pages in memory"" must be configured (SeLockMemoryPrivilege): $(Get-GPO $secpolExportFileName 'SeLockMemoryPrivilege.*')")

		If ($?) {
			Write-Host "[-] User rights assignment: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve user rights assignment"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-SecurityPolicy {
	# Security policy
	Update-LogFile $logFileName "--=== Security policy ===--"

	Try {
		# Security policy
		secedit /export /cfg $global:tempFileName 2>&1 | ForEach-Object { "; $_" } | Out-File -FilePath $logFileName -Encoding ascii -Append

		If ($?) {
			Get-Content $global:tempFileName | Out-File -FilePath $logFileName -Encoding ascii -Append
			Write-Host "[-] Security policy: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve security policy"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-SecurityOptions {
	# Security options
	Update-LogFile $logFileName "--=== Security options ===--"

	Try {
		#Network Access
		Update-LogFile $logFileName ("Parameter ""Network access: Remotely accessible sub paths and registry paths"" must be configured: $(Get-GPO $secpolExportFileName 'AllowedPaths\\Machine.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Let Everyone permissions apply to anonymous users"" must be configured: $(Get-GPO $secpolExportFileName 'EveryoneIncludesAnonymous.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Named Pipes that can be accessed anonymously"" must be configured: $(Get-GPO $secpolExportFileName 'NullSessionPipes.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Remotely accessible registry path"" must be configured: $(Get-GPO $secpolExportFileName 'AllowedExactPaths\\Machine.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Shares that can be accessed anonymously"" must be configured: $(Get-GPO $secpolExportFileName 'NullSessionShares.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Sharing and security model for local accounts"" must be configured: $(Get-GPO $secpolExportFileName 'ForceGuest.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Do not allow anonymous enumeration of SAM accounts and shares"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictAnonymousSAM.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Do not allow anonymous enumeration of SAM accounts"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictAnonymous.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Allow anonymous SID/Name translation"" must be configured: $(Get-GPO $secpolExportFileName 'LSAAnonymousNameLookup.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Restrict anonymous access to Named Pipes and Shares"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictNullSessAccess.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Do not allow storage of credentials or .NET Passports for network authentication"" must be configured: $(Get-GPO $secpolExportFileName 'DisableDomainCreds.*')")
		Update-LogFile $logFileName ("Parameter ""Network access: Restrict clients allowed to make remote calls to SAM"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictRemoteSam.*')")

		#Shutdown
		Update-LogFile $logFileName ("Parameter ""Shutdown: Clear virtual memory pagefile on shutdown"" must be configured: $(Get-GPO $secpolExportFileName 'ClearPageFileAtShutdown.*')")
		Update-LogFile $logFileName ("Parameter ""Shutdown: Allow system to be shut down without having to log on"" must be configured: $(Get-GPO $secpolExportFileName 'ShutdownWithoutLogon.*')")

		#Audit
		Update-LogFile $logFileName ("Parameter ""Audit: Shut down system immediately if unable to log Security audits"" must be configured: $(Get-GPO $secpolExportFileName 'CrashOnAuditFail.*')")
		Update-LogFile $logFileName ("Parameter ""Audit: Audit the access of global system objects"" must be configured: $(Get-GPO $secpolExportFileName 'AuditBaseObjects.*')")
		Update-LogFile $logFileName ("Parameter ""Audit: Audit the use of backup and restore privilege"" must be configured: $(Get-GPO $secpolExportFileName 'FullPrivilegeAuditing.*')")
		Update-LogFile $logFileName ("Parameter ""Audit: Force audit policy subcategory settings ,Windows Vista or later, to override audit policy category settings"" must be configured: $(Get-GPO $secpolExportFileName 'SCENoApplyLegacyAuditPolicy.*')")

		#System cryptography
		Update-LogFile $logFileName ("Parameter ""System cryptography: Use FIPS compliant algorithms for encryption, hashing, and signing"" must be configured: $(Get-GPO $secpolExportFileName 'FIPSAlgorithmPolicy\\Enabled.*')")

		#Microsoft network client
		Update-LogFile $logFileName ("Parameter ""Microsoft network client: Digitally sign communications ,if server agrees"" must be configured: $(Get-GPO $secpolExportFileName 'LanManWorkstation\\Parameters\\EnableSecuritySignature.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network client: Digitally sign communications ,always"" must be configured: $(Get-GPO $secpolExportFileName 'LanManWorkstation\\Parameters\\RequireSecuritySignature.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network client: Send unencrypted password to third-party SMB servers"" must be configured: $(Get-GPO $secpolExportFileName 'EnablePlainTextPassword.*')")

		#Accounts
		Update-LogFile $logFileName ("Parameter ""Accounts: Limit local account use of blank passwords to console logon only"" must be configured: $(Get-GPO $secpolExportFileName 'LimitBlankPasswordUse.*')")
		Update-LogFile $logFileName ("Parameter ""Accounts: Administrator account status"" must be configured: $(Get-GPO $secpolExportFileName 'EnableAdminAccount.*')")
		Update-LogFile $logFileName ("Parameter ""Accounts: Guest account status"" must be configured: $(Get-GPO $secpolExportFileName 'EnableGuestAccount.*')")
		Update-LogFile $logFileName ("Parameter ""Accounts: Block Microsoft Accounts"" must be configured: $(Get-GPO $secpolExportFileName 'NoConnectedUser.*')")

		#Interactive logon
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Display user information when the session is locked"" must be configured: $(Get-GPO $secpolExportFileName 'DontDisplayLockedUserId.*')")

		#Recovery console
		Update-LogFile $logFileName ("Parameter ""Recovery console: Allow automatic administrative logon"" must be configured: $(Get-GPO $secpolExportFileName 'RecoveryConsole\\SecurityLevel.*')")
		Update-LogFile $logFileName ("Parameter ""Recovery console: Allow floppy copy and access to all drives and all folders"" must be configured: $(Get-GPO $secpolExportFileName 'RecoveryConsole\\SetCommand.*')")

		#Other
		Update-LogFile $logFileName ("Parameter ""User Account Control: Admin Approval Mode for the built-in Administrator account"" must be configured: $(Get-GPO $secpolExportFileName 'FilterAdministratorToken.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Switch to the secure desktop when prompting for elevation"" must be configured: $(Get-GPO $secpolExportFileName 'PromptOnSecureDesktop.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Allow UIAccess applications to prompt for elevation without using the secure desktop"" must be configured: $(Get-GPO $secpolExportFileName 'EnableUIADesktopToggle.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode"" must be configured: $(Get-GPO $secpolExportFileName 'ConsentPromptBehaviorAdmin.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Behavior of the elevation prompt for standard users"" must be configured: $(Get-GPO $secpolExportFileName 'ConsentPromptBehaviorUser.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Detect application installations and prompt for elevation"" must be configured: $(Get-GPO $secpolExportFileName 'EnableInstallerDetection.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Only elevate UIAccess applications that are installed in secure locationsn"" must be configured: $(Get-GPO $secpolExportFileName 'EnableSecureUIAPaths.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Only elevate executables that are signed and validated"" must be configured: $(Get-GPO $secpolExportFileName 'ValidateAdminCodeSignatures.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Run all administrators in Admin Approval Mode"" must be configured: $(Get-GPO $secpolExportFileName 'EnableLUA.*')")
		Update-LogFile $logFileName ("Parameter ""User Account Control: Virtualize file and registry write failures to per-user locations"" must be configured: $(Get-GPO $secpolExportFileName 'EnableVirtualization.*')")

		#Domain controller
		Update-LogFile $logFileName ("Parameter ""Domain controller: LDAP server signing requirements"" must be configured: $(Get-GPO $secpolExportFileName 'LDAPServerIntegrity.*')")
		Update-LogFile $logFileName ("Parameter ""Domain controller: Allow server operators to schedule tasks"" must be configured: $(Get-GPO $secpolExportFileName 'SubmitControl.*')")
		Update-LogFile $logFileName ("Parameter ""Domain controller: Refuse machine account password changes"" must be configured: $(Get-GPO $secpolExportFileName 'RefusePasswordChange.*')")

		#System cryptography
		Update-LogFile $logFileName ("Parameter ""System cryptography: Force strong key protection for user keys stored on the computer"" must be configured: $(Get-GPO $secpolExportFileName 'Cryptography\\ForceKeyProtection.*')")

		#DCOM
		Update-LogFile $logFileName ("Parameter ""DCOM: Machine access restrictions in security descriptor definition language ,SDLL, syntax"" must be configured: $(Get-GPO $secpolExportFileName 'MachineAccessRestriction.*')")
		Update-LogFile $logFileName ("Parameter ""DCOM: Machine launch restrictions in security descriptor definition language ,SDLL, syntax"" must be configured: $(Get-GPO $secpolExportFileName 'MachineLaunchRestriction.*')")

		#Domain member
		Update-LogFile $logFileName ("Parameter ""Domain member: Encrypt secure channel data ,when possible"" must be configured: $(Get-GPO $secpolExportFileName 'SealSecureChannel.*')")
		Update-LogFile $logFileName ("Parameter ""Domain member: Encrypt or sign secure channel data ,always"" must be configured: $(Get-GPO $secpolExportFileName 'RequireSignOrSeal.*')")
		Update-LogFile $logFileName ("Parameter ""Domain member: Disable machine account password changes"" must be configured: $(Get-GPO $secpolExportFileName 'DisablePasswordChange.*')")
		Update-LogFile $logFileName ("Parameter ""Domain member: Require strong ,Windows 2000 or later, session key"" must be configured: $(Get-GPO $secpolExportFileName 'RequireStrongKey.*')")
		Update-LogFile $logFileName ("Parameter ""Domain member: Digitally sign secure channel data"" must be configured: $(Get-GPO $secpolExportFileName 'SignSecureChannel.*')")
		Update-LogFile $logFileName ("Parameter ""Domain member: Maximum machine account password age"" must be configured: $(Get-GPO $secpolExportFileName 'Parameters\\MaximumPasswordAge.*')")

		#System objects
		Update-LogFile $logFileName ("Parameter ""System objects: Require case insensitivity for non-Windows subsystems"" must be configured: $(Get-GPO $secpolExportFileName 'ObCaseInsensitive.*')")
		Update-LogFile $logFileName ("Parameter ""System objects: Strengthen default permissions of internal system objects ,e.g. Symbolic Links"" must be configured: $(Get-GPO $secpolExportFileName 'Session Manager\\ProtectionMode.*')")

		#Interactive logon
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Require smart card"" must be configured: $(Get-GPO $secpolExportFileName 'ScForceOption.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Smart card removal behavior"" must be configured: $(Get-GPO $secpolExportFileName 'ScRemoveOption.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Message text for users attempting to log on"" must be configured: $(Get-GPO $secpolExportFileName 'LegalNoticeText.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Do not display last user name"" must be configured: $(Get-GPO $secpolExportFileName 'DontDisplayLastUserName.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: o not require CTRL+ALT+DEL"" must be configured: $(Get-GPO $secpolExportFileName 'DisableCAD.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Require Domain Controller authentication to unlock workstation"" must be configured: $(Get-GPO $secpolExportFileName 'ForceUnlockLogon.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Prompt user to change password before expiration"" must be configured: $(Get-GPO $secpolExportFileName 'PasswordExpiryWarning.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Message title for users attempting to log on"" must be configured: $(Get-GPO $secpolExportFileName 'LegalNoticeCaption.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Number of previous logons to cache, in case domain controller is not available"" must be configured: $(Get-GPO $secpolExportFileName 'CachedLogonsCount.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Machine inactivity limit"" must be configured: $(Get-GPO $secpolExportFileName 'System\\InactivityTimeoutSecs.*')")
		Update-LogFile $logFileName ("Parameter ""Interactive logon: Machine account lockout threshold"" must be configured: $(Get-GPO $secpolExportFileName 'System\\MaxDevicePasswordFailedAttempts.*')")

		#System settings
		Update-LogFile $logFileName ("Parameter ""System settings: Optional subsystems"" must be configured: $(Get-GPO $secpolExportFileName 'optional.*')")
		Update-LogFile $logFileName ("Parameter ""System settings: Use certificate rules on Windows Executables for Software restriction policies"" must be configured: $(Get-GPO $secpolExportFileName 'AuthenticodeEnabled.*')")

		#Devices
		Update-LogFile $logFileName ("Parameter ""Devices:Restrict CD-ROM access to locally logged-on user only"" must be configured: $(Get-GPO $secpolExportFileName 'AllocateCDRoms.*')")
		Update-LogFile $logFileName ("Parameter ""Devices: Allow undock without having to log on"" must be configured: $(Get-GPO $secpolExportFileName 'UndockWithoutLogon.*')")
		Update-LogFile $logFileName ("Parameter ""Devices: Prevent users from installing printer drivers"" must be configured: $(Get-GPO $secpolExportFileName 'AddPrinterDrivers.*')")
		Update-LogFile $logFileName ("Parameter ""Devices: Restrict floppy access to locally logged-on user only"" must be configured: $(Get-GPO $secpolExportFileName 'AllocateFloppies.*')")
		Update-LogFile $logFileName ("Parameter ""Devices: Allowed to format and eject removable media"" must be configured: $(Get-GPO $secpolExportFileName 'AllocateDASD.*')")

		#Network security
		Update-LogFile $logFileName ("Parameter ""Network security: LDAP client signing requirements"" must be configured: $(Get-GPO $secpolExportFileName 'LDAPClientIntegrity.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Force logoff when logon hours expire"" must be configured: $(Get-GPO $secpolExportFileName 'ForceLogoffWhenHourExpire.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Do not store LAN Manager hash value on next password change"" must be configured: $(Get-GPO $secpolExportFileName 'Control\\Lsa\\NoLMHash.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: LAN Manager authentication level"" must be configured: $(Get-GPO $secpolExportFileName 'LmCompatibilityLevel.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Minimum session security for NTLM SSP based clients"" must be configured: $(Get-GPO $secpolExportFileName 'NTLMMinClientSec.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Minimum session security for NTLM SSP based servers"" must be configured: $(Get-GPO $secpolExportFileName 'NTLMMinServerSec.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Allow LocalSystem NULL session fallback"" must be configured: $(Get-GPO $secpolExportFileName 'allownullsessionfallback.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Allow PKU2U authentication requests to this computer to use online identities"" must be configured: $(Get-GPO $secpolExportFileName 'AllowOnlineID.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Allow Local System to use computer identity for NTLM"" must be configured: $(Get-GPO $secpolExportFileName 'UseMachineId.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Configure encryption types allowed for Kerberos"" must be configured: $(Get-GPO $secpolExportFileName 'SupportedEncryptionTypes.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM:Add server exceptions in this domain"" must be configured: $(Get-GPO $secpolExportFileName 'DCAllowedNTLMServers.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM:Add remote server exceptions for NTLM authentication"" must be configured: $(Get-GPO $secpolExportFileName 'ClientAllowedNTLMServers.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM: Audit NTLM authentication in this domain"" must be configured: $(Get-GPO $secpolExportFileName 'AuditNTLMInDomain.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM: Audit Incoming NTLM Traffic"" must be configured: $(Get-GPO $secpolExportFileName 'AuditReceivingNTLMTraffic.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM: NTLM authentication in this domain"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictNTLMInDomain.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM: Incoming NTLM Traffic"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictReceivingNTLMTraffic.*')")
		Update-LogFile $logFileName ("Parameter ""Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers"" must be configured: $(Get-GPO $secpolExportFileName 'RestrictSendingNTLMTraffic.*')")

		#Microsoft network server
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Digitally sign communications ,if server agrees"" must be configured: $(Get-GPO $secpolExportFileName 'LanmanWorkstation\\Parameters\\EnableSecuritySignature.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Digitally sign communications ,always"" must be configured: $(Get-GPO $secpolExportFileName 'LanmanWorkstation\\Parameters\\RequireSecuritySignature.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Disconnect clients when logon hours expire"" must be configured: $(Get-GPO $secpolExportFileName 'EnableForcedLogOff.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Amount of idle time required before suspending session"" must be configured: $(Get-GPO $secpolExportFileName 'AutoDisconnect.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Server SPN target name validation level"" must be configured: $(Get-GPO $secpolExportFileName 'SmbServerNameHardeningLevel.*')")
		Update-LogFile $logFileName ("Parameter ""Microsoft network server: Attempt S4U2Self to obtain claim information"" must be configured: $(Get-GPO $secpolExportFileName 'Parameters\\EnableS4U2SelfForClaims.*')")

		If ($?) {
			Write-Host "[-] Security options: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve security options"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-LocalPolicies {
	Write-Host "[9] - Local policies"
	Update-LogFile $logFileName "===== [9] - Local policies ====="

	Get-SecurityPolicy
	Get-UserRightsAssignment
	Get-SecurityOptions
}




###############################
#        10 - Antivirus       #
###############################

Function Get-Category-Antivirus {
	Write-Host "[10] - Antivirus"
	Update-LogFile $logFileName "===== [10] - Antivirus ====="

	# Antivirus
	Update-LogFile $logFileName ("--=== Antivirus ===--")

	Try {
		$colItems = Get-WMIObject -class "AntiVirusProduct" -namespace "root\SecurityCenter2" -computername "." -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("displayName: " + $objItem.displayName)
				Update-LogFile $logFileName ("instanceGuid: " + $objItem.instanceGuid)
				Update-LogFile $logFileName ("pathToSignedProductExe: " + $objItem.pathToSignedProductExe)
				Update-LogFile $logFileName ("productState: " + $objItem.productState)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] AntiVirusProduct: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve antivirus information"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}




###############################
#     11 - Administration     #
###############################

Function Get-WinRM {
	# WinRM
	Update-LogFile $logFileName "--=== WinRM ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		winrm get winrm/config >> $file 2>> $logFileName

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName $system
			}
			Update-LogFile $logFileName "\r\n"

			Write-Host "[-] WinRM: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve WinRM configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-RemoteDesktopServices {
	# Remote Desktop Services
	Update-LogFile $logFileName "--=== Remote Desktop Services ===--"

	Try {
		$colItems = Get-WmiObject -class "Win32_TSGeneralSetting" -Namespace "root\cimv2\terminalservices" -Filter "TerminalName='RDP-tcp'" -ErrorAction SilentlyContinue

		If ($?) {
			Foreach ($objItem in $colItems) {
				Update-LogFile $logFileName ("TerminalName: " + $objItem.TerminalName)
				Update-LogFile $logFileName ("TerminalProtocol: " + $objItem.TerminalProtocol)
				Update-LogFile $logFileName ("UserAuthenticationRequired: " + $objItem.UserAuthenticationRequired)
				Update-LogFile $logFileName ("MinEncryptionLevel: " + $objItem.MinEncryptionLevel)
				Update-LogFile $logFileName ("SecurityLayer: " + $objItem.SecurityLayer)
				Update-LogFile $logFileName ""
			}

			Write-Host "[-] Remote Desktop Services: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve remote desktop services information"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-Administration {
	Write-Host "[11] - Administration"
	Update-LogFile $logFileName "===== [11] - Administration ====="

	Get-WinRM
	Get-RemoteDesktopServices
}




###############################
#        12 - Browsers        #
###############################

Function Get-Chrome {
	# Chrome settings (it is also possible to export policy from chrome://policy to .json)
	$sectionName = "Google Chrome settings"
	Update-LogFile $logFileName "--=== $($sectionName) ===--"

	Try {
		$result = @()
		$result += Get-RegistryRecursive "REGISTRY::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Google\Chrome"

		$users = Get-ChildItem -Path "REGISTRY::HKEY_USERS" -Name
		ForEach ($user in $users) {
			If (!$user.endswith("_Classes")) {
				$result += Get-RegistryRecursive "REGISTRY::HKEY_USERS\$user\SOFTWARE\Policies\Google\Chrome"
			}
		}

		$result | Select-Object -Property "Name", "Value" | ConvertTo-Csv -NoTypeInformation | Out-File -FilePath $logFileName -Encoding ascii -Append

		If ($?) {
			Write-Host "[-] $($sectionName): OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve $($sectionName)"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Firefox {
	# Firefox settings
	Update-LogFile $logFileName "--=== Firefox settings ===--"

	Try {
		# Application configuration files
		$ffAppPaths = @{}
		$ffAppPaths["app-x64"] = "C:\Program Files\Mozilla Firefox"
		$ffAppPaths["app-x86"] = "C:\Program Files (x86)\Mozilla Firefox"

		ForEach ($ffAppPath in $ffAppPaths.GetEnumerator()) {
			$ffAppConfPath = "$($ffAppPath.Value)\defaults\pref"
			If ( Test-Path $ffAppConfPath ) {
				$ffOutputPath = "$($global:outputFirefoxPath)\$($ffAppPath.Key)"
				New-Item -ItemType "directory" -Path $ffOutputPath | Out-Null
				Copy-Item -Path "$($ffAppConfPath)\*.js" -Destination $ffOutputPath
			}
		}

		# Profile configuration files
		$ffUsersPath = "C:\Users"
		If ( Test-Path $ffUsersPath ) {
			# Users enumeration
			$ffUsers = Get-ChildItem -Directory -Name -Path $ffUsersPath
			ForEach ($ffUser in $ffUsers) {
				$ffProfilesPath = "$($ffUsersPath)\$($ffUser)\AppData\Roaming\Mozilla\Firefox\Profiles"
				If ( Test-Path $ffProfilesPath ) {
					# Profiles enumeration for each user
					$ffProfiles = Get-ChildItem -Directory -Name -Path $ffProfilesPath
					ForEach ($ffProfile in $ffProfiles) {
						$ffOutputPath = "$($global:outputFirefoxPath)\$($ffUser)\$($ffProfile)"
						New-Item -ItemType "directory" -Path $ffOutputPath | Out-Null
						If ( Test-Path "$($ffProfilesPath)\$($ffProfile)\prefs.js" ) {
							Copy-Item -Path "$($ffProfilesPath)\$($ffProfile)\prefs.js" -Destination $ffOutputPath
						}
						If ( Test-Path "$($ffProfilesPath)\$($ffProfile)\user.js" ) {
							Copy-Item -Path "$($ffProfilesPath)\$($ffProfile)\user.js" -Destination $ffOutputPath
						}
					}
				}
			}
		}

		Update-LogFile $logFileName "Check directory: $($global:outputFirefoxPath)"

		If ($?) {
			Write-Host "[-] Firefox settings: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Firefox settings"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-InternetExplorer {
	# Internet Explorer settings
	Update-LogFile $logFileName "--=== Internet Explorer settings ===--"

	Try {
		#
		$regValue = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext" "DisableAddonLoadTimePerformanceNotifications"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext\DisableAddonLoadTimePerformanceNotifications: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext" " IgnoreFrameApprovalCheck"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext\ IgnoreFrameApprovalCheck: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions" "NoCrashDetection"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions\NoCrashDetection: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions" "NoExtensionManagement"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions\NoExtensionManagement: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security\ActiveX" "BlockNonAdminActiveXInstall"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security\ActiveX\BlockNonAdminActiveXInstall: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AxInstaller" "OnlyUseAXISForActiveXInstall"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\AxInstaller\OnlyUseAXISForActiveXInstall: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\ActiveXFiltering" "IsEnabled"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\ActiveXFiltering\IsEnabled: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions" "NoJITSetup"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions\NoJITSetup: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer" "AllowService PoweredQSA"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\AllowService PoweredQSA: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Suggested Sites" "Enabled"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Suggested Sites\Enabled: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SearchScopes" "ShowSearchSuggestionsGlobal"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SearchScopes\ShowSearchSuggestionsGlobal: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions" "NoSearchBox"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions\NoSearchBox: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Recovery" "NoReopenLastSession"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Recovery\NoReopenLastSession: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions" "NoSplash"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Infodelivery\Restrictions\NoSplash: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Explorer\AutoComplete" "AutoSuggest"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Explorer\AutoComplete\AutoSuggest: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "Proxy"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\Proxy: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "ProxySettingsPerUser"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ProxySettingsPerUser: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Recovery" "AutoRecover"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Recovery\AutoRecover: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "Autoconfig"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\Autoconfig: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "Connection Settings"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\Connection Settings: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "Connwiz Admin Lock"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\Connwiz Admin Lock: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SQM" "DisableCustomerImprovementProgram"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SQM\DisableCustomerImprovementProgram: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security" "DisableFixSecuritySettings"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security\DisableFixSecuritySettings: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security" "DisableSecuritySettingsCheck"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Security\DisableSecuritySettingsCheck: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\SecondaryStartPages" "about:blank"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\SecondaryStartPages\about:blank: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "Security_HKLM_only"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Security_HKLM_only: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "Security_options_edit"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Security_options_edit: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "Security_zones_map_edit"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Security_zones_map_edit: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions" "DisablePopupFilterLevel"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions\DisablePopupFilterLevel: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter" "PreventOverride"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter\PreventOverride: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter" "PreventOverrideAppRepUnknown"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter\PreventOverrideAppRepUnknown: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter" "Enabled"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter\Enabled: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter" "EnabledV9"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\PhishingFilter\EnabledV9: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Geolocation" "PolicyDisableGeolocation"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Geolocation\PolicyDisableGeolocation: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions" "NoPopupManagement"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Restrictions\NoPopupManagement: $($regValue)")
		# Accélérateurs
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Activities" "NoActivities"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Activities\NoActivities: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Activities\Restrictions" "UsePolicyActivitiesOnly"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Activities\Restrictions\UsePolicyActivitiesOnly: $($regValue)")
		# Barre d'outils
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\IEDevTools" "Disabled"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\IEDevTools\Disabled: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Toolbars\Restrictions" "DisableToolbarUpgrader"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Toolbars\Restrictions\DisableToolbarUpgrader: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Toolbar" "Locked"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Toolbar\Locked: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\CommandBar" "ShowLeftAddressToolbar"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\CommandBar\ShowLeftAddressToolbar: $($regValue)")
		# Compatibilité des applications > Accès au Presse-papiers
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt\iexplore.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt" "*"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\Feature_Enable_Script_Paste_URLAction_If_Prompt\*: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl" "ListBox_Support_Feature_Enable_Script_Paste_URLAction_If_Prompt"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\ListBox_Support_Feature_Enable_Script_Paste_URLAction_If_Prompt: $($regValue)")
		# Confidentialité
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE" "DisableInPrivateBlocking"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE\DisableInPrivateBlocking: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE" "DisableTrackingProtection"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE\DisableTrackingProtection: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Privacy" "EnableInPrivateBrowsing"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Privacy\EnableInPrivateBrowsing: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE" "DisableLogging"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE\DisableLogging: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE" "DisableToolbars"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE\DisableToolbars: $($regValue)")
		# Panneau de configuration Internet
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "AdvancedTab"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\AdvancedTab: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "ConnectionsTab"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\ConnectionsTab: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "PrivacyTab"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\PrivacyTab: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "SecurityTab"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\SecurityTab: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "PreventIgnoreCertErrors"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\PreventIgnoreCertErrors: $($regValue)")
		# Panneau de configuration Internet > Onglet Avancé
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "DisableEPMCompat"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\DisableEPMCompat: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "Isolation"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\Isolation: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "Isolation64Bit"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\Isolation64Bit: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Download" "RunInvalidSignatures"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Download\RunInvalidSignatures: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "SecureProtocols"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\SecureProtocols: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel" "DisableRIED"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Control Panel\DisableRIED: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "DisableCachingOfSSLPages"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\DisableCachingOfSSLPages: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "NoUpdateCheck"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\NoUpdateCheck: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "CertificateRevocation"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\CertificateRevocation: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Cache" "Persistent"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Cache\Persistent: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "DoNotTrack"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\DoNotTrack: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "EnableHttp1_1"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\EnableHttp1_1: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "NoJITSetup"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\NoJITSetup: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN\Settings" "LOCALMACHINE_CD_UNLOCK"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN\Settings\LOCALMACHINE_CD_UNLOCK: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\FlipAhead" "Enabled"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\FlipAhead\Enabled: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Download" "CheckExeSignatures"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Download\CheckExeSignatures: $($regValue)")
		# Panneau de configuration Internet > Onglet Sécurité
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings" "WarnOnBadCertRecving"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\WarnOnBadCertRecving: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap" "AutoDetect"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\AutoDetect: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap" "IntranetName"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\IntranetName: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap" "ProxyByPass"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\ProxyByPass: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap" "UNCAsIntranet"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\UNCAsIntranet: $($regValue)")
		# Panneau de configuration Internet > Onglet Sécurité > Zone Internet verrouillée
		# et
		# Panneau de configuration Internet > Onglet Sécurité > Zone Internet
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2100"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2100: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2100"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2100: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1409"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1409: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2100"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2100: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2500"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2500: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2500"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2500: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1C00"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1C00: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1C00"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1C00: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "120b"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\120b: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "120b"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\120b: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1405"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1405: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1405"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1405: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1201"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1201: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1201"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1201: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2201"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2201: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2201"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2201: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2200"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2200: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2200"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2200: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2004"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2004: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2004"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2004: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2001"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2001: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2001"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2001: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1200"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1200: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1200"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1200: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "160A"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\160A: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "160A"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\160A: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1402"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1402: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1402"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1402: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1004"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1004: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1004"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1004: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "1001"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\1001: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "1001"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\1001: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" "2301"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3\2301: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3" "2301"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Lockdown_Zones\3\2301: $($regValue)")
		# Paramètres Internet > Saisie semi-automatique
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\WindowsSearch" "EnabledScopes"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\WindowsSearch\EnabledScopes: $($regValue)")
		# Fonctionnalités de sécurité
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "DisablePasswordReveal"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\DisablePasswordReveal: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" "DEPOff"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\DEPOff: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DATAURI" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DATAURI\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > AJAX
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_XDOMAINREQUEST" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_XDOMAINREQUEST\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Barre de notification
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_SECURITYBAND\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Fonctionnalité de sécurité de détection MIME
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_SNIFFING\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Gestion des modules complémentaires
		$regValue = Get-Registry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext" "RestrictToList"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Ext\RestrictToList: $($regValue)")
		# Fonctionnalités de sécurité > Gestion MIME cohérente
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MIME_HANDLING\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Protection contre l'élévation de zone
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ZONE_ELEVATION\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Protection de mise en cache d'objets
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_OBJECT_CACHING\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Restreindre l'installation ActiveX
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_ACTIVEXINSTALL\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Restreindre le téléchargement de fichiers
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_RESTRICT_FILEDOWNLOAD\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Restriction de sécurité de comportement binaire
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BEHAVIORS\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Restriction de sécurité du protocole MK
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DISABLE_MK_PROTOCOL\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Restriction de sécurité de scripts de fenêtres
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_WINDOW_RESTRICTIONS\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité > Sécurité du verrouillage de la zone Ordinateur local
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN\iexplore.exe: $($regValue)")
		# Fonctionnalités de sécurité >Verrouillage des protocoles réseau
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN" "(Reserved)"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN\(Reserved): $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN" "explorer.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN\explorer.exe: $($regValue)")
		$regValue = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN" "iexplore.exe"
		Update-LogFile $logFileName ("HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_PROTOCOL_LOCKDOWN\iexplore.exe: $($regValue)")
		# En complément
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "AlwaysPromptWhenDownload"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\AlwaysPromptWhenDownload: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoBrowserBars"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoBrowserBars: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoBrowserOptions"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoBrowserOptions: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoBrowserSaveAs"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoBrowserSaveAs: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoFileNew"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoFileNew: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoFileOpen"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoFileOpen: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoFindFiles"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoFindFiles: $($regValue)")
		$regValue = Get-Registry "HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions" "NoSelectDownloadDir"
		Update-LogFile $logFileName ("HKLM:\Software\Policies\Microsoft\Internet Explorer\Restrictions\NoSelectDownloadDir: $($regValue)")
		# En complément (proxy)
		$regValue = Get-Registry "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" "AutoConfigUrl"
		Update-LogFile $logFileName ("HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\AutoConfigUrl: $($regValue)")

		If ($?) {
			Write-Host "[-] Internet Explorer settings: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve Internet Explorer settings"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-WebBrowsers {
	Write-Host "[12] - Browsers"
	Update-LogFile $logFileName "===== [12] - Browsers ====="

	Get-Chrome
	Get-Firefox
	Get-InternetExplorer
}




###############################
#     13 - System security    #
###############################

Function Get-DEP {
	# DEP
	Update-LogFile $logFileName "--=== DEP ===--"

	Try {
		$file = New-Item $global:tempFileName -Type File -Force
		bcdedit >> $file

		If ($?) {
			ForEach ($system in Get-Content $file) {
				Update-LogFile $logFileName ($system)
			}

			Write-Host "[-] DEP: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve DEP configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-SEHOP {
	# SEHOP
	Update-LogFile $logFileName "--=== SEHOP ===--"

	Try {
		
		Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel\" -ErrorAction SilentlyContinue | Out-File -FilePath $logFileName -Encoding ascii -Append

		If ($?) {
			Write-Host "[-] SEHOP: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve SEHOP configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
	Finally {
		Remove-item $global:tempFileName 2>&1> $null
	}
}

Function Get-SmartScreen {
	# SmartScreen
	Update-LogFile $logFileName "--=== SmartScreen ===--"

	Try {
		$tmp = Get-Registry "HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer" "SmartScreenEnabled"
		Update-LogFile $logFileName ("SmartScreen status: $($tmp)")

		#Nico -> if $?
		If ($tmp) {
			Write-Host "[-] SmartScreen: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve SmartScreen configuration"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}
Function Get-CredentialGuard {
	# Credential Guard
	Update-LogFile $logFileName ("--=== Credential Guard ===--")

	Try {
		$tmp = Get-Registry "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" "LsaCfgFlags"

		Update-LogFile $logFileName ("Enable Credential Guard : $($tmp)")
		$tmp = Get-Registry "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\CredentialGuard" "Enabled"
		Update-LogFile $logFileName ("Credential Guard is enabled : $($tmp)")
		
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Control\DeviceGuard" "EnableVirtualizationBasedSecurity"
		Update-LogFile $logFileName ("Turn On Virtualization Based Security (EnableVirtualizationBasedSecurity): $($tmp)")
	
		$tmp = Get-Registry "HKLM:\System\CurrentControlSet\Control\DeviceGuard" "RequirePlatformSecurityFeatures"
		Update-LogFile $logFileName ("Platform security features required (RequirePlatformSecurityFeatures): $($tmp)")
		
		Write-Host "[-] Credential Guard: OK" -ForegroundColor Green
		
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}
Function Get-Category-SystemSecurity {
	Write-Host "[13] - System security"
	Update-LogFile $logFileName "===== [13] - System security ====="

	Get-DEP
	Get-SEHOP
	Get-SmartScreen
	Get-CredentialGuard
}




###############################
#       14 - Gestions      #
###############################

Function Get-GPresult {
	# GPresult
	Try {
		If (Test-Path $global:gpresultFileName) {
			Remove-Item $global:gpresultFileName
			Remove-Item $global:gpresultXmlFileName
		}
		gpresult /SCOPE COMPUTER /H $global:gpresultFileName 2>&1> $null
		gpresult /SCOPE COMPUTER /X $global:gpresultXmlFileName 2>&1> $null

		If ($?) {
			Write-Host "[-] GPresult: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve GPresult"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-RegistryHives {
	# Export SAM, SYSTEM and SOFTWARE registry hives
	Try {
		If (Test-Path $global:SAMhiveFileName) {
			Remove-Item $global:SAMhiveFileName
		}
		If (Test-Path $global:SYSTEMhiveFileName) {
			Remove-Item $global:SYSTEMhiveFileName
		}
		If (Test-Path $global:SOFTWAREhiveFileName) {
			Remove-Item $global:SOFTWAREhiveFileName
		}

		reg save HKLM\SAM $global:SAMhiveFileName 2>&1> $null
		reg save HKLM\SYSTEM $global:SYSTEMhiveFileName 2>&1> $null
		reg save HKLM\SOFTWARE $global:SOFTWAREhiveFileName 2>&1> $null

		If ($?) {
			Write-Host "[-] Export SAM, SYSTEM and SOFTWARE registry hives: OK" -ForegroundColor Green
		}
		Else {
			Throw "[!] Cannot retrieve SAM, SYSTEM adn SOFTWARE registry hives"
		}
	}
	Catch {
		Write-Host "Error occured (see error log file)" -ForegroundColor Red
		Update-LogFile $ErrorlogFileName $_.Exception.Message
	}
}

Function Get-Category-Getions {
	Write-Host "[14] - Gestions"
	Update-LogFile $logFileName "===== [14] Gestions ====="

	Get-GPresult
	Get-RegistryHives
}




###############################
#        Run the script       #
###############################

If ($test) {
	$($Global:CategoriesToTest.Keys) | ForEach-Object { $Global:CategoriesToTest[$_] = 0 }
	Invoke-Expression -Command $test
}

If ($Global:CategoriesToTest._0_TestAllCategories -eq 1) {
	Get-Category-ScriptInformation
	Get-Category-ComputerInformation
	Get-Category-PhysicalSecurity
	Get-Category-Authentification
	Get-Category-SystemAccessControl
	Get-Category-NetworkAccessControl
	Get-Category-Encryption
	Get-Category-Logging
	Get-Category-PatchManagement
	Get-Category-LocalPolicies
	Get-Category-Antivirus
	Get-Category-Administration
	Get-Category-WebBrowsers
	Get-Category-SystemSecurity
	Get-Category-Getions
}
Else {
	If ($Global:CategoriesToTest._1_ComputerInformation -eq 1) { Get-Category-ComputerInformation }
	If ($Global:CategoriesToTest._2_PhysicalSecurity -eq 1) { Get-Category-PhysicalSecurity }
	If ($Global:CategoriesToTest._3_Authentification -eq 1) { Get-Category-Authentification }
	If ($Global:CategoriesToTest._4_SystemAccessControl -eq 1) { Get-Category-SystemAccessControl }
	If ($Global:CategoriesToTest._5_NetworkAccessControl -eq 1) { Get-Category-NetworkAccessControl }
	If ($Global:CategoriesToTest._6_Encryption -eq 1) { Get-Category-Encryption }
	If ($Global:CategoriesToTest._7_Logging -eq 1) { Get-Category-Logging }
	If ($Global:CategoriesToTest._8_PatchManagement -eq 1) { Get-Category-PatchManagement }
	If ($Global:CategoriesToTest._9_LocalPolicies -eq 1) { Get-Category-LocalPolicies }
	If ($Global:CategoriesToTest._10_Antivirus -eq 1) { Get-Category-Antivirus }
	If ($Global:CategoriesToTest._11_Administration -eq 1) { Get-Category-Administration }
	If ($Global:CategoriesToTest._12_WebBrowsers -eq 1) { Get-Category-WebBrowsers }
	If ($Global:CategoriesToTest._13_SystemSecurity -eq 1) { Get-Category-SystemSecurity }
	If ($Global:CategoriesToTest._14_Getions -eq 1) { Get-Category-Getions }
}




###############################
#        End of script        #
###############################

# Remove temporary files
If (Test-Path $global:secpolExportFileName) {
	Remove-Item $global:secpolExportFileName
}
If (Test-Path $global:tempFileName) {
	Remove-Item $global:tempFileName
}
Update-LogFile $logFileName ("--=== EoF ===--")

Write-Host ""

# Create an output archive of the result
Try {

	Compress-Archive -Path $global:outputPath -DestinationPath $global:outputArchive

	If ($?) {
		Write-Host "[*] Archive export output: $($global:outputArchive)" -ForegroundColor Cyan
		Write-Host "[!] Please verify archive content, then remove output directory." -ForegroundColor Red
	}
	Else {
		Throw "[!] Cannot archive export result"
	}
}
Catch {
	Write-Host "Error occured (see error log file)" -ForegroundColor Red
	Update-LogFile $ErrorlogFileName $_.Exception.Message
}

# Display script execution results
$scriptEndTime = Get-Date

Write-Host ""
Write-Host " End time:" (Get-Date -Date $scriptEndTime -Format "yyyy-MM-dd HH:mm:ss")
Write-Host " Execution time:" (New-TimeSpan -Start $scriptStartTime -End $scriptEndTime)
Write-Host ""

#Stop-Transcript
