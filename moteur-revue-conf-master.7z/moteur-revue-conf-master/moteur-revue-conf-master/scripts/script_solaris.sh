#!/bin/ksh

echo ""
echo "Attention, l'execution du script peut parfois etre lente (attente de RPC, important nombre de fichiers)."
echo "En cas d'execution anormalement longue, arreter le script et regarder quelle est la derniere commande executee, grace à la derniere info produite dans le fichier de resultats"
echo ""

fichierResBrutsParcoursArbo="Wavestone_Audit_Parcours.res" 
fichierResBrutsBruts="Wavestone_Audit_controle.res"

function ecrireTitreSection {
	echo "===== $1 =====" >> $fichierResBruts
}

function ecrireDescription {
	echo "--=== $1 ===--" >> $fichierResBruts
}

function ecrire {
	echo "-- $1 --" >> $fichierResBruts
}

# verifier que l on est root
uid=`id -u`
if [[ "$uid" != "0" ]];
then
	echo "Ce script necessite les droits d'administrateur"
	echo "Voulez vous continuer ? (o/N)"
	read rep
	if [[ "$rep" != "o" ]];
	then
		exit 0;
	fi;
fi

# renice du processus pour ne pas affecter les autres services
echo "Souhaitez vous diminuer la priorite du processus afin de"
echo "ne pas impacter les autres services ? (o/N)"
read rep
if test "$rep" = "o"
then
	renice 19 -p $$
fi

echo ""
echo "--------------------------------------------------------"
echo "Début du script"
echo "--------------------------------------------------------"
echo ""

rm -fr $fichierResBruts
rm -fr $fichierResBrutsCorrectifs


#--- Identification du serveur -------------------------------------------------
ecrireTitreSection "Identification du serveur"
echo " - Identification du serveur"

ecrireDescription "Hostname"
hostname >> $fichierResBruts 2>&1

nomMachine=$(`whereis hostname | cut -f2 -d" "`)

ecrireDescription "Version noyau et version OS"
uname -X >> $fichierResBruts 2>&1

ecrireDescription "Liste des cartes réseau"
prtconf >> $fichierResBruts 2>&1

ecrireDescription "Configuration réseau"
ifconfig -a >> $fichierResBruts 2>&1

ecrireDescription "Serveurs DNS"
cat /etc/resolv.conf >> $fichierResBruts 2>&1

ecrireDescription "Informations Mémoire - RAM"
prtconf | grep -i memory >> $fichierResBruts 2>&1

ecrireDescription "Informations Mémoire - SWAP"
swap -l >> $fichierResBruts 2>&1

ecrireDescription "Informations Cpu"
psrinfo -vp >> $fichierResBruts 2>&1

ecrireDescription "Partitionnement"
df -k >> $fichierResBruts 2>&1

ecrireDescription "Points de Montage"
mount >> $fichierResBruts 2>&1

ecrireDescription "BootLoader"
# Vérifier que le security mode est bien à full
eeprom >> $fichierResBruts 2>&1

ecrireDescription "Premier peripherique de boot"
# Vérifier que le primary boot device est bien le disque
eeprom boot-device >> $fichierResBruts 2>&1

ecrireDescription "Mot de passe au boot"
eeprom security-mode >> $fichierResBruts 2>&1

ecrireDescription "Echec des connexions au boot"
eeprom security-\#badlogins >> $fichierResBruts 2>&1

ecrireDescription "Processus en cours"
ps -Aedf >> $fichierResBruts 2>&1


#--- Version / Patches ---------------------------------------------------------
ecrireTitreSection "Versions / Patches"
echo " - Versions / Patches"

ecrireDescription "Correctifs"
ecrire "Voir le fichier complentaire Solucom_Audit_SOLARIS_CORRECTIFS.res"
showrev -p >> $fichierResBrutsCorrectifs 2>&1

ecrireDescription "Liste paquets installés"
pkginfo >> $fichierResBruts 2>&1



#--- Compte ROOT ---------------------------------------------------------------
ecrireTitreSection "Analyse de la configuration du compte root"
echo " - Analyse de la configuration du compte root"

ecrireDescription "Path de root"
# Vérifier que le "." n'est pas présent
echo $PATH >> $fichierResBruts 2>&1

ecrireDescription "Emplacement home dir de root"
grep "root:" /etc/passwd | head -n1 | cut -d":" -f6 >> $fichierResBruts 2>&1

ecrireDescription "Contenu home dir de root"
ls -al `grep "root:" /etc/passwd | head -n1 | cut -d":" -f6` >> $fichierResBruts 2>&1

ecrireDescription "Verification absence de rhost"
ls -al `grep root /etc/passwd | head -n1 | cut -d":" -f6` | grep rhosts >> $fichierResBruts 2>&1

ecrireDescription "Vérification du log des accès root" # Reco SYSLOG=YES
grep "SYSLOG=" /etc/default/login >> $fichierResBruts 2>&1

ecrireDescription "Désactivation de l'accès root distant"
grep "CONSOLE=" /etc/default/login >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /var/adm/sulog"
cat /var/adm/sulog >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/sudoers"
more /etc/sudoers >> $fichierResBruts 2>&1
more /usr/local/etc/sudoers  >> $fichierResBruts 2>&1



#--- Comptes utilisateurs et système -------------------------------------------
ecrireTitreSection "Comptes utilisateurs et système"
echo " - Comptes utilisateurs et système"

ecrireDescription "Contenu du fichier passwd - /etc/passwd"
cat /etc/passwd >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier shadow - /etc/shadow"
cat /etc/shadow >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/group"
cat /etc/group >> $fichierResBruts 2>&1

ecrireDescription "Cohérence des fichiers passwd et shadow"
pwck >> $fichierResBruts 2>&1

ecrireDescription "Absence de compte sans mot de passe"
logins -p >> $fichierResBruts 2>&1

ecrireDescription "Forcage du mot de passe pour tous les comptes"
# Vérifier que la ligne PASSREQ=YES est présente et non commentée dans /etc/default/login
grep "PASSREQ" /etc/default/login  >> $fichierResBruts 2>&1

ecrireDescription "Existence d'un shell non fonctionnel pour les comptes systèmes"
logins -sx >> $fichierResBruts 2>&1 # Reco = 3eme ligne à /bin/false

ecrireDescription "Absence d'utilisateurs ayant le meme uid"
cat /etc/passwd | cut -d":" -f3 | sort -n | uniq -d >> $fichierResBruts 2>&1

ecrireDescription "Uid des utilisateurs dans une plage distincte (> 1000)"
cat /etc/passwd | cut -d":" -f1,3 >> $fichierResBruts 2>&1

ecrireDescription "Absence de répertoires de connexion communs entre plusieurs utilisateurs"
cat /etc/passwd | cut -d":" -f6 | sort | uniq -d >> $fichierResBruts 2>&1

ecrireDescription "Nombre de groupes minimisés"
wc -l /etc/group >> $fichierResBruts 2>&1

ecrireDescription "Entrées commençant pas + dans /etc/group"
cat /etc/group | grep "^+" >> $fichierResBruts 2>&1

ecrireDescription "Erreurs dans le fichier /etc/group"
grpck >> $fichierResBruts 2>&1

ecrireDescription "Message d'avertissement MOTD - Connexion réussie"
cat /etc/motd >> $fichierResBruts 2>&1

ecrireDescription "Message d'avertissement ISSUE - Connexion échouée"
cat /etc/issue >> $fichierResBruts 2>&1

ecrireDescription "Message d'avertissement SERVICES - Avant connexion" # RECO = Des bannieres non commentées et correctes
grep BANNER /etc/default/* >> $fichierResBruts 2>&1

ecrireDescription "Desactivation du compte après n connexions infructueuses" # Reco = 5
grep RETRIES /etc/default/login >> $fichierResBruts 2>&1
grep RETRIES /etc/security/policy.conf >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/default/login"
cat /etc/default/login >> $fichierResBruts 2>&1


#--- Environnement graphique ---------------------------------------------------
ecrireTitreSection "Environnement graphique"
echo " - Environnement graphique"

ecrireDescription "Désactivation de xhost"
# Doit être désactivé sauf si besoin application - Reco = 744 (rwxr--r--)
ls -al /usr/openwin/bin/xhost >> $fichierResBruts 2>&1
ls -al /usr/X/bin/xhost >> $fichierResBruts 2>&1

ecrireDescription "Désactivation de l'accès XDCMP en cas d'utilisation de CDE"
# Si CDE est utilisé, le fichier /etc/dt/config/Xaccess doit exister et contenir
# une ligne avec "!*". Les droits doivent être à 444
ls -al /etc/dt/config/Xaccess >> $fichierResBruts 2>&1
more /etc/dt/config/Xaccess >> $fichierResBruts 2>&1

ecrireDescription "Timeout du screensaver en environnement CDE"
grep "dtsession\*saverTimeout" /usr/dt/config/*/sys.resources >> $fichierResBruts 2>&1

ecrireDescription "Timeout de la session en environnement CDE"
grep "dtsession\*lockTimeout" /usr/dt/config/*/sys.resources >> $fichierResBruts 2>&1



#--- Politique de mots de passe ------------------------------------------------
ecrireTitreSection "Politique de mots de passe"
echo " - Politique de mots de passe"

ecrireDescription "Contenu du fichier /etc/default/passwd"
cat /etc/default/passwd >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/security/policy.conf"
cat /etc/security/policy.conf >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/pam.conf - PAM"
cat /etc/pam.conf >> $fichierResBruts 2>&1

# Il est intéréssant de repérer les lignes suivantes pour contrôler la politique
# de mots de passe appliquée sur PAM:
#      password required pam_cracklib.so retry=3 minlen=6 difok=3
#      password required pam_unix.so md5 use_authtok
ecrireDescription "Liste des fichiers /usr/lib/security/pam*"  
ls -la /usr/lib/security/pam* >> $fichierResBruts 2>&1

ecrireDescription "Contrôle du nombre de caractères différents" # Reco = 2 (difork)
grep "password required" /etc/pam.conf >> $fichierResBruts 2>&1

ecrireDescription "Algorithme de chiffrement des mots de passe"
grep CRYPT_DEFAULT /etc/security/policy.conf >> $fichierResBruts 2>&1

ecrireDescription "Contrôle de la longueur minimale" # Reco = 8
grep PASSLENGHT /etc/default/passwd >> $fichierResBruts 2>&1

ecrireDescription "Contrôle de l'historique des mots de passe " # Reco = 5
grep HISTORY /etc/default/passwd  >> $fichierResBruts 2>&1

ecrireDescription "Contrôle de la fréquence de changement" # Reco = 2 (MINWEEKS) et 8 (MAXWEEKS) semaines
grep MINWEEKS /etc/default/passwd >> $fichierResBruts 2>&1
grep MAXWEEKS /etc/default/passwd >> $fichierResBruts 2>&1

ecrireDescription "Contrôle de l'application de la politique à tous" # Reco = aucun retour
grep "NOCHECK" /etc/security/passwd >> $fichierResBruts 2>&1
grep "NOCHECK" /etc/default/passwd >> $fichierResBruts 2>&1


#--- Journaux ------------------------------------------------------------------
ecrireTitreSection "Journaux"
echo " - Journaux"

ecrireDescription "Etat de Syslog"
ps -ef | grep syslog | grep -v "grep" >> $fichierResBruts 2>&1

ecrireDescription "Types d'événements journalisés"
cat /etc/syslog.conf >> $fichierResBruts 2>&1

ecrireDescription "Contenu du dossier /var/log"
# Attention, il faudrait peut être améliorer le script en lisant le contenu des fichiers
# syslog.conf et en allant chercher dans les rep correspondants
ls -RAl /var/log >> $fichierResBruts 2>&1



#--- Ordonanceurs cron et at ---------------------------------------------------
ecrireTitreSection "Ordonanceurs cron et at"
echo " - Ordonanceurs cron et at"

ecrireDescription "Panorama des fichiers /var/spool/cron*"
# Vérifier ici les droits d'accès des utilisateurs aux cron d'admin - Interdit !
ls -RAl /var/spool/cron/* >> $fichierResBruts 2>&1

ecrireDescription "Contenu des fichiers cron"
more /var/spool/cron/crontabs/* >> $fichierResBruts 2>&1

ecrireDescription "Panorama des fichiers /var/spool/at*"
# Vérifier ici les droits d'accès des utilisateurs aux cron d'admin  - Interdit !
ls -RAl /var/spool/at* >> $fichierResBruts 2>&1

ecrireDescription "Contenu des fichiers at"
more /var/spool/cron/atjobs/* >> $fichierResBruts 2>&1

ecrireDescription "Utilisation de cron interdite aux utilisateurs"
more /etc/cron.d/cron.allow >> $fichierResBruts 2>&1
more /etc/cron.d/cron.deny >> $fichierResBruts 2>&1

ecrireDescription "Utilisation de at interdite aux utilisateurs"
more /etc/cron.d/at.allow >> $fichierResBruts 2>&1
more /etc/cron.d/at.deny >> $fichierResBruts 2>&1



#--- Réseau --------------------------------------------------------------------
ecrireTitreSection "Réseau"
echo " - Réseau"

ecrireDescription "Services"
netstat -na -f inet >> $fichierResBruts 2>&1

ecrireDescription "Services en écoute"
netstat -na -f inet | grep LISTEN >> $fichierResBruts 2>&1

ecrireDescription "Configuration de RPC"
rpcinfo -p >> $fichierResBruts 2>&1

ecrireDescription "Services RPC disponibles"
inetadm | grep online >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/inetd.conf"
more /etc/inetd.conf >> $fichierResBruts 2>&1

ecrireDescription "Contrôle de la journalisation d'inetd"
inetadm -p | grep tcp_trace >> $fichierResBruts 2>&1 # Reco = TRUE

ecrireDescription "Contrôle de la génération aléatoire des numéros de séquence TCP"
cat /etc/default/inetinit | grep TCP_STRONG_ISS >> $fichierResBruts 2>&1  # Reco = 2

ecrireDescription "Paramètres TCP/IP du noyau"
ecrire "Attaques ARP"
ndd /dev/arp arp_cleanup_interval >> $fichierResBruts 2>&1
ndd /dev/ip ip_ire_arp_interval >> $fichierResBruts 2>&1
ecrire "Attaques par re-routage"
ndd /dev/ip ip_forward_src_routed >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip6_forward_src_routed >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/tcp tcp_rev_src_routes >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_forward_directed_broadcasts >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_ignore_redirect >> $fichierResBruts 2>&1 # Reco = 1
ndd /dev/ip ip6_ignore_redirect >> $fichierResBruts 2>&1 # Reco = 1
ecrire "Fonction routeur"
ndd /dev/ip ip_forwarding >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip6_forwarding >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_strict_dst_multihoming >> $fichierResBruts 2>&1 # Reco = 1
ndd /dev/ip ip6_strict_dst_multihoming >> $fichierResBruts 2>&1 # Reco = 1
ndd /dev/ip ip_send_redirects >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip6_send_redirects >> $fichierResBruts 2>&1 # Reco = 0
ecrire "File d'attente TCP"
ndd /dev/tcp tcp_conn_req_max_q0 >> $fichierResBruts 2>&1
ndd /dev/tcp tcp_conn_req_max_q >> $fichierResBruts 2>&1
ecrire "Flood ICMP"
ndd /dev/ip ip_respond_to_timestamp >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_respond_to_timestamp_broadcast >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_respond_to_address_mask_broadcast >> $fichierResBruts 2>&1 # Reco = 0
ndd /dev/ip ip_respond_to_echo_broadcast >> $fichierResBruts 2>&1 # Reco = 0

ecrireDescription "Vérification de l'activation de NFS"
ps -eaf | grep nfs | grep -v "grep" >> $fichierResBruts 2>&1

ecrireDescription "Configuration des exports NFS (/etc/dfs/dfstab)"
cat /etc/dfs/dfstab >> $fichierResBruts 2>&1

ecrireDescription "Vérification de l'activation de SSH"
ps -eaf | grep ssh | grep -v "grep" >> $fichierResBruts 2>&1

ecrireDescription "Configuration de SSH"
# Vérifier les paramètres suivants :
#    PermitRootLogin = no
#    PermitEmptyPasswords = no
#    RhostsRSAAuthentication = no
#    HostbasedAuthentication = no
#    RhostsAuthentication = no
#    IgnoreRhosts = yes
#    X11Forward = yes
#    Protocol = 2
more /etc/sshd_config /usr/local/etc/sshd_config /etc/ssh/sshd_config >> $fichierResBruts 2>&1



#--- Fichiers systèmes ---------------------------------------------------------
ecrireTitreSection "Fichiers systèmes"
echo " - Fichiers systèmes"

ecrireDescription "Droits sur les fichiers et repertoires de la racine"
ls -Al / >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/netgroup"
more /etc/netgroup >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/host.equiv"
more /etc/hosts.equiv   >> $fichierResBruts 2>&1

ecrireDescription "Contenu du fichier /etc/host.lpd"
more /etc/hosts.lpd   >> $fichierResBruts 2>&1

ecrireDescription "Panorama des fichiers /etc/hosts*"
ls -RAl /etc/hosts* >> $fichierResBruts 2>&1

ecrireDescription "Contenu des fichiers /etc/hosts*"
more /etc/hosts* >> $fichierResBruts 2>&1

ecrireDescription "Niveaux de umask"
grep umask /etc/profile >> $fichierResBruts 2>&1

#--- A VERIFIER ------------------------------------------
ecrireDescription "Abscence de fichier .rhosts et .netrc"
for i in `cut -d":" -f6 /etc/passwd` ; do ls -al $i | grep rhosts; done >> $fichierResBruts 2>&1
for i in `cut -d":" -f6 /etc/passwd` ; do ls -al $i | grep netrc; done  >> $fichierResBruts 2>&1
#--- A VERIFIER ------------------------------------------

ecrireDescription "Vérification des mécanismes de protection de la pile"
cat /etc/system | grep noexec_user_stack >> $fichierResBruts 2>&1 # Reco = 1
cat /etc/system | grep noexec_user_stack_log >> $fichierResBruts 2>&1 # Reco = 1

ecrireDescription "Contrôle de l'activation de Sendmail"
ps -eaf | grep mail | grep -v "grep" >> $fichierResBruts 2>&1

ecrireDescription "Sendmail aliases"
more /etc/aliases /etc/mail/aliases >> $fichierResBruts 2>&1 # Reco = pas de chaine decode



#--- Propriétés et permissions sur les fichiers et répertoires -----------------
ecrireTitreSection "Propriétés et permissions sur les fichiers et répertoires"
echo ""
echo "Extraction des configurations terminée"
echo "La suite parcours l'ensemble de l'arboréscence, cela peut peut prendre du temps"
echo "Il est néanmoins possible de killer le script si celui-ci dure trop longtemps (présence de montages NFS par exemple)"
echo ""
echo " - Propriétés et permissions sur les fichiers et répertoires"

echo "   - Répertoires  et fichiers système"
ecrireDescription "Répertoires système" # Reco = propriété de root et droits corrects (750)
ls -ld /bin >> $fichierResBruts 2>&1
ls -ld /dev >> $fichierResBruts 2>&1
ls -ld /etc  >> $fichierResBruts 2>&1
ls -ld /sbin >> $fichierResBruts 2>&1
ls -ld /usr/etc >> $fichierResBruts 2>&1
ls -ld /usr/bin >> $fichierResBruts 2>&1
ls -ld /usr/sbin >> $fichierResBruts 2>&1

ecrireDescription "Répertoires du PATH de root" # Reco = propriété de root et droits corrects (750)
ls -ld `echo $PATH |tr ':' ' '` >> $fichierResBruts 2>&1

ecrireDescription "Fichiers de configurations spécifiques"
# Reco = propriété des utilisateurs adéquats et droits corrects limités à ceux-ci (640)
ls -al /etc/utmp >> $fichierResBruts 2>&1
ls -al /etc/motd >> $fichierResBruts 2>&1
ls -al /etc/mtab >> $fichierResBruts 2>&1
ls -al /etc/dfs/dfstab >> $fichierResBruts 2>&1
ls -al /etc/syslog.pid >> $fichierResBruts 2>&1
ls -al /var/adm/wtmp >> $fichierResBruts 2>&1 
ls -al /etc/securetty >> $fichierResBruts 2>&1

ecrireDescription "Abscence des droits d'écriture pour root" # Reco = 440
ls -al /etc/passwd >> $fichierResBruts 2>&1
ls -al /etc/services  >> $fichierResBruts 2>&1
ls -al /etc/inittab  >> $fichierResBruts 2>&1
ls -al /etc/group >> $fichierResBruts 2>&1
ls -al /etc/profile >> $fichierResBruts 2>&1
ls -al /etc/mail/aliases >> $fichierResBruts 2>&1
ls -al /vmunix >> $fichierResBruts 2>&1

ecrireDescription "Abscence des droits d'écriture pour les utilisateurs" # Reco = 400 et a minima xx0
ls -al /etc/inetd.conf >> $fichierResBruts 2>&1
ls -al /etc/shadow >> $fichierResBruts 2>&1
ls -al /etc/hosts.equiv >> $fichierResBruts 2>&1
ls -al /etc/hosts.lpd >> $fichierResBruts 2>&1
ls -al /etc/login.access >> $fichierResBruts 2>&1
ls -al /etc/login.conf >> $fichierResBruts 2>&1
ls -al /etc/login.defs >> $fichierResBruts 2>&1
ls -al /etc/netgroup >> $fichierResBruts 2>&1
ls -al /etc/security >> $fichierResBruts 2>&1
ls -al /var/log/* >> $fichierResBruts 2>&1
ls -al /var/adm/messages >> $fichierResBruts 2>&1
ls -al /var/adm/utmpx >> $fichierResBruts 2>&1
ls -al /var/adm/wtmpx >> $fichierResBruts 2>&1
ls -al /var/cron/log >> $fichierResBruts 2>&1
ls -al /var/adm/cron/* >> $fichierResBruts 2>&1

ecrireDescription "Seuls les propriétaires ont accès à leurs fichiers" # Reco = 700
ls -ld `cut -d: -f6 /etc/passwd | sort -u` >> $fichierResBruts 2>&1

echo "   - Fichiers des utilisateurs supprimés"
ecrireDescription "Verification que les fichiers utilisateurs sont bien supprimés lors de la suppression du compte"
find / \( -nouser -o -nogroup \) -exec ls -ld {} \; >> $fichierResBruts 2>&1

echo "   - Répertoires et fichiers en écriture pour tous"
ecrireDescription "Contrôle des répertoires autorisés en écriture pour tous sans le sticky-bit" # Reco = aucun
find / -type d -perm -2 ! -perm -1000 -print >> $fichierResBruts 2>&1

ecrireDescription "Contrôle des fichiers autorisés en écriture pour tous sans le sticky-bit"
find / -type f -perm -2 -exec ls -ld {} \; >> $fichierResBruts 2>&1

echo "   - Fichiers de root avec le SUID bit activé"
ecrireDescription "Contrôle des fichiers de root avec le SUID bit activé en execution"
find / -perm -4000 -exec ls -ld {} \; >> $fichierResBruts 2>&1

echo "   - Fichiers de root avec le SGID bit activé"
ecrireDescription "Contrôle des fichiers de root avec le SGID bit activé en execution"
find / -perm -2000 -exec ls -ld {} \; >> $fichierResBruts 2>&1



#--- Parcours de l'arborescence ------------------------------------------------
ecrireTitreSection "Parcours de l'arborescence"
echo "Parcours de l'arborescence"

ecrireDescription "Droits sur les fichiers et repertoires"
ls -RAl / > $fichierResBrutsParcoursArbo 2>&1


#--- Fin du script d'extraction ------------------------------------------------
ecrireDescription "EoF"



tar czf "A_FOURNIR_A_WAVESTONE_$nomMachine.tgz" $fichierResBrutsBruts $fichierResBrutsParcoursArbo
rm -fr $fichierResBrutsBruts
rm -fr $fichierResBrutsParcoursArbo

echo "-----------------------------------------------------"
echo "L'audit du système est terminé. Le fichier généré "
echo "est l'archive \"A_FOURNIR_A_WAVESTONE_$nomMachine.tgz\""
echo "-----------------------------------------------------"

