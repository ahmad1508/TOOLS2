# Revue ESXi

Un script, des instructions d’extraction et un rapport anonymisé se trouvent
sur la WIC audit et doit être privilégiée tant que le moteur n’est pas mis à
jour :

https://digiplace.sharepoint.com/sites/WIC-CDT-AUDITANDPENETRATIONTESTING/Documents%20partages/Forms/Affichage%20avec%20arbo.aspx?id=%2Fsites%2FWIC%2DCDT%2DAUDITANDPENETRATIONTESTING%2FDocuments%20partages%2F02%20%2D%20KM%20and%20Accelerators%2FXX%20%2D%20Autres%2FVMWare%2F2%20%2D%20Guide&viewid=fd6e7ab8%2D1621%2D43ed%2Da3a5%2D5ea81add4b4e&OR=Teams%2DHL&CT=1678442430456&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMzAyMDUwMTQyMSIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D
