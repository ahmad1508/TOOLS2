#!/bin/bash

if [[ $# -lt 2 ]]; then
        echo "Usage: $0 <path/to/export_all.xml_DATE.zip> <path/to/gInfo-FIREWALL_NAME-DATE.tar.gz>"
        exit 1
fi

# write each section to stdout
echo "===== SysInfo ====="
tar -xzOf "$2" --wildcards "*/sginfo/sginfo.txt"

echo "===== Forcepoint Console Extract ====="
unzip -p "$1" "exported_data.xml"
