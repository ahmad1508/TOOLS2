#!/bin/bash

###############################################################################
###############################################################################
#
# Linux
#
###############################################################################
###############################################################################
# v1.0 creation 15/10/08
# v1.1 VLM 22/12/09
# v2.0 Refonte du script : extraction sans analyse - ECA 07/04/10
# v2.1 ECA 05/11/2010
# v2.2 COG 27/02/2014
# v2.3 ECA 12/05/2015
# v3.0 ECA 19/08/2016
# v3.1 MaMG 2/03/2017 : bugfix (find SUID, etc...)
# v3.2 MaMG 10/03/2017 : minor improvement (route)
# v3.3 TBT 21/06/2018 : Correction des bugs sous RHEL 7 et CentOS 7
# v3.4 GSE 10/01/2019 : Refonte des extractions dans le cadre du KM
# v4.0 GSE 15/01/2020 : Réécriture complète
###############################################################################
###############################################################################

##############################################################################
## CONFIGURATION
##############################################################################

resultsDir="Wavestone_Audit_Linux"


##############################################################################
## SCRIPT VARIABLES
##############################################################################
declare working_dir script_dir tar_file
declare script_err_pid extract_err_pid extract_out_pid logging_pid
declare logres=-1


##############################################################################
# clean the local environnement from functions & aliases
unalias -a
old_IFS="$IFS"
IFS=$'\n'
for name in $(declare -F); do
    # declare -F return all functions formatted as 'declare -f myfunction'
    unset -f "${name:11}"
done
IFS="$old_IFS"

# Defines some constants for output coloring
if [ -t 1 ]; then
    RED=$'\x1b[1;31m'
    YELLOW=$'\x1b[1;33m'
    GREEN=$'\x1b[1;32m'
    BOLD=$'\x1b[1m'
    UNDER=$'\x1b[4m'
    NOCOL=$'\x1b[0m'
else
    RED=""
    YELLOW=""
    GREEN=""
    BOLD=""
    UNDER=""
    NOCOL=""
fi

# defines variables for the script path & directory
script_path="$(realpath "$0")"
script_dir="${script_path%/*}"

##############################################################################
## FUNCTIONS
##############################################################################
# function to setup the redirections environnement
function setupRedirections() {
    # handle all redirections as following:
    #
    # stream | file/program
    # -------|-------------
    #      1 | stdout
    #      2 | debug.txt (for xtrace)
    #      7 | audit.txt
    #      9 | log.txt
    #     10 | debug.txt
    #     12 | stdout
    #     13 | stderr
    #
    # files are written with the following data
    #
    #            data | output files
    # ----------------|--------------------
    #   script errors | debug.txt
    # extract outputs | debug.txt audit.txt
    # logging outputs | log.txt   stdout
    #
    exec 12>&1 13>&2
    exec  7>audit.txt
    exec  9>log.txt
    exec 10>debug.txt 2>&10
}
# function to write to multiple fd
function writeTo() {
    # it takes as input a list of fd to duplicate stdin into
    set +x
    local buf="$(cat;echo x)"  # add to trailing x to prevent \n deletion
    buf="${buf%?}"             # remove the trailing x
    local fd
    for fd in "$@"; do
        echo -n "$buf" | cat >> "/dev/fd/$fd"
    done
    set -x
}

# functions to properly format the report
function newSection() {
    endSection
    # audit.txt & error.txt
    echo "===== $1 =====" | writeTo 7
    # log.txt
    echo -n "|-- $1" | writeTo 9 12
}

function newSubsection() {
    endSection
    # audit.txt & error.txt
    echo "--=== $1 ===--" | writeTo 7
    # log.txt
    echo -n "|   |-- $1" | writeTo 9 12
}

function newSubsubsection() {
    endSection
    # audit.txt & error.txt
    echo "-- $1 --" | writeTo 7
    # log.txt
    echo -n "|   |   |-- $1" | writeTo 9 12
}

function newSubsubsubsection() {
    endSection
    # audit.txt & error.txt
    echo "## $1 ##" | writeTo 7
    # log.txt
    echo -n "|   |   |   |-- $1" | writeTo 9 12
}

function endSection() {
    if test "$logres" -eq 1; then
        echo ": ${GREEN}OK${NOCOL}" | writeTo 9 12
    elif test "$logres" -eq 0; then
        echo ": ${RED}ERROR${NOCOL}" | writeTo 9 12
    elif test "$logres" -eq -2; then
        echo ": ${YELLOW}SKIP${NOCOL}" | writeTo 9 12
    else
        echo | writeTo 9 12
    fi
    logres=-1
}

function do_extract() {
    local buf ret

    # check whether the first command is known or skip
    if ! type "$1" &> /dev/null; then
        # indicate we have skipped command if no command was already run
        if [ "$logres" -lt 0 ]; then
          logres=-2
        fi
        return
    fi

    # run the command and log it
    set +x
    "$@" 2>&1 | writeTo 7 10

    # update the logging result status based on the command status
    ret="$((!${PIPESTATUS[0]}))"
    set -x

    # variables OP can be used to define result combination
    # it can be either:
    #   - or: either the cmd result or previous status must be OK
    #   - and: both the cmd result and previous status must be OK
    #   - ign: the cmd result is ignored
    # default is: or
    if [[ "x${OP:-or}" == "xign" ]]; then
        # do nothing
        true
    elif [[ "x${OP:-or}" == "xskip" && "$ret" -eq 0 ]]; then
        # indicate we have skipped command if no command was already run
        if [ "$logres" -lt 0 ]; then
          logres=-2
        fi
    elif [ "$logres" -lt 0 ]; then
        # for first run command in the section
        logres="$ret"
    elif [[ "x${OP:-or}" == "xor" ]]; then
        logres="$((logres || ret))"
    elif [[ "x${OP:-or}" == "xand" ]]; then
        logres="$((logres && ret))"
    fi
}

# a function to replace the mktemp command in case it doesn't exist
function mktemp() {
    local base_dir="$1"
    local dir="$resultsDir.$$.$RANDOM"
    while [ -d "$1/$dir" ]; do
        dir="$resultsDir.$$.$RANDOM"
    done
    mkdir -p "$1/$dir"
    echo -n "$1/$dir"
}

# a function to replace the realpath command in case it doesn't exist
function realpath() {
    local path="$1"
    if [ -f "$1" ]; then
        if [[ "$1" == */* ]]; then
            echo "$(cd "${1%/*}" && echo "$PWD/${1##*/}")"
        else
            echo "$PWD/${1}"
        fi
    else
        echo "$(cd "$1" && echo "$PWD")"
    fi
}

# function to check whether a program exists
function exists() {
    type "$@" &> /dev/null
    return $?
}

# function to ask for a confirmation
function confirm() {
    local space="[y/n]" default="" yn=
    [ $# -eq 2 ] && case "$2" in
        [Yy]* ) space="[Y/n]"; default="y";;
        [Nn]* ) space="[y/N]"; default="n";;
    esac

    while true; do
        # 2>&13 is required for prompt not being sent to the debug.txt
        read -n 1 -p "$1 $space " yn 2>&13
        [ "$yn" ] && echo >&13
        [ "$yn" == "" ] && [ "$default" ] && yn=$default
        case $yn in
            [Yy]* ) echo; return 0;;
            [Nn]* ) echo; return 1;;
        esac
    done
}

# function to ask interactively the user if in interactive mode otherwise
# return the response from cmdline
function ask() {
    local cmdline="$1" pre="$2" prompt="$3" default="$4"
    if [ "$opt_interactive" -eq 1 ]; then
        # interactive mode ==> print the pre-string and prompt the user
        [ -n "$pre" ] && echo "$pre"
        if confirm "$prompt" "$default"; then
            return 0
        else
            return 1
        fi
    else
        # non interactive mode ==> return the cmdline option
        [[ "$cmdline" == "y" ]] && return 0 || return 1
    fi
}

# function to do a more-like printing, in case more is not installed
function get_files() {
    local ret=1
    local content
    local args=""
    # we use different separators depending on the encoding
    # default is * for raw file
    # separator with # is used for base64 encoded files
    local b="*"
    # check for base64 arg
    if [[ "$1" == "-b" ]]; then args="$1"; b="#"; shift; fi
    for f in "$@"; do
        # pass the file if it does not exist
        if ! [ -e "$f" ]; then continue; fi
        if [ -f "$f" ]; then
            cat <<EOF
/$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b\\
$(realpath "$f")
\\$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b$b/
EOF
            # we need to ensure file end with a newline
            #  => we store the file in a variable and append an "x"
            #     to prevent stripping
            if [[ "$args" == "-b" ]]; then
                # base64-encode the file
                content="$(cat "$f" | tob64 ; echo -n "x")"
            else
                content="$(cat "$f"; echo -n "x")"
            fi
            if [[ "${content:${#content}-2:1}" == $'\n' ]]; then
                echo -n "${content:0:${#content}-1}"
            else
                echo "${content:0:${#content}-1}"
            fi
            ret=0
        elif [ -d "$f" -a -n "$(ls -A $f)" ]; then
            # we dont try to get hidden files. It is not required
            # for now
            get_files $args "$f"/*
            ret=0
        fi
    done
    #if [ "$ret" -eq 1 ]; then
    #    echo "Fichiers non trouvés: $*"
    #fi
    return "$ret"
}

# base64 encoder with fallback to awk and full-bash in case of system
# missing fast C programs
# Based on: https://gist.github.com/markusfisch/2648733
if exists base64; then
    function tob64() { base64; }
else
    # the 2 fallbacks relies on od
    # reimplement it if it does not exist
    if ! exists od; then
        # the od function is greatly inspired of F.Hauri's code
        # https://stackoverflow.com/questions/13889659/
        #   read-a-file-by-bytes-in-bash?answertab=votes#answer-13890319
        # It heavily relies on printf %q to find the hex value
        # printf %q may escape a character in 4 different ways:
        #   - non-shell printable char are not escaped (e.g. "g" => "g")
        #   - shell printable char are escaped with \ (e.g. "[" => "\[")
        #   - control char are escaped with $ and \ (e.g. newline => "$'\n'")
        #   - other char are escaped in octal form with $
        #               (e.g. \x02 => "$'\002'")
        #
        # Bash cannot store null byte as it use null-terminated strings
        # internally. Reading a null byte would result in a empty string.

        # some constants to transform char to value
        #   ascii is used for printable chars
        #   cntrl is used for control chars
        printf -v ascii \\%o {32..126}
        printf -v ascii "$ascii"
        printf -v cntrl %-20sE abtnvfr

        function od() {
            local char val offset=0 width=16
            while LANG=C IFS= read -r -d '' -n 1 char; do
                # print current offset at the beginning
                (( offset % width )) || printf '%07o' $offset
                # decode the current char value
                printf -v char "%q" "$char"
                case ${#char} in
                    # printable char  "g" or "\["
                    1|2 ) char=${ascii%$char*}; val=($((${#char}+32)));;
                    # octal form "$'\002'"
                    7 ) char=${char#*\'\\}; val=($((8#${char%\'})));;
                    # control char "$'\n'"
                    5 ) char=${char#*\'\\}; char=${cntrl%${char%\'}*}
                        val=($((${#char}+7)));;
                    # should no append
                    * ) echo >&2 "od: ERROR: could no decode $char";;
                esac
                printf ' %02x' "$val"
                # end line after width chars
                (( ++offset % width )) || echo
            done
            echo
        }
    fi

    # Falls back to awk first then pur bash
    if exists awk; then
        function tob64() {
            awk '
BEGIN {
  b64="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  while( "od -v -t x1" | getline ) {
    for(c=9; c<=length($0); c++) {
      d=index("0123456789abcdef",substr($0,c,1));
      if(d--) {
        for(b=1; b<=4; b++ ) {
          o=o*2+int(d/8); d=(d*2)%16;
          if(++obc==6) {
            printf substr(b64,o+1,1);
            if(++rc>75) { printf("\n"); rc=0; }
            obc=0; o=0;
          }
        }
      }
    }
  }
  if(obc) {
    obcb = obc;
    while(obc++<6) { o=o*2; }
    printf "%c",substr(b64,o+1,1);
    if(obcb==2){ print "=="; }
    else{ print "="; }
  } else { printf("\n"); }
}'
        }
    else
        function tob64() {
            local SET='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            od -v -t x1 | {
                local val=0 width=0 shift=16 i j len
                local -a line_array

                # read each line
                while read -r -a line_array; do
                    # leave the first column (= index)
                    for ((i=1, len=${#line_array[@]}; i < len; ++i)); do
                        # concat 3 bytes
                        val=$(( 16#${line_array[$i]} << shift | val ))
                        (( (shift -= 8) < 0 )) || continue

                        # dump the 3 bytes as 4 B64 characters
                        for ((j=18; j > -1; j -= 6)); do
                            echo -n ${SET:$(( val >> j & 63 )):1}
                            (( ++width > 75 )) && { echo; width=0; }
                        done

                        # reset environment
                        shift=16
                        val=0
                    done
                done

                # dump final bytes
                if (( shift == 8 )); then
                    i=11
                elif (( shift == 0 )); then
                    i=5
                else
                    i=0
                fi

                if (( i )); then
                    for (( j=18; j > i; j -= 6 )); do
                        echo -n ${SET:$(( val >> j & 63 )):1}
                        (( ++width > 75 )) && { echo; width=0; }
                    done

                    # append 1 or 2 = at the end
                    for (( j=i/5; j--; )); do
                        echo -n '='
                    done
                fi
                # final newline
                echo
            }
        }
    fi
fi

# create a fallback method to getent if it does not work
if ! exists getent; then
    function getent() {
        # this function only works with some entries
        # but the script currently use passwd, shadow, group, gshadow
        # which all work
        cat "/etc/$1"
    }
fi


##############################################################################
## Preliminary setup and checks
##############################################################################

# Sanitize the PATH to prevent some security issues: remove all relative
# directories in the path to prevent command injections as root
declare path="$PATH:" part="" new_path=""
while [[ "x$path" != "x" ]]; do
    part="${path%%:*}"
    path="${path#*:}"
    if [[ "x${part:0:1}" == "x/" ]]; then
        new_path="$new_path:$part"
    fi
done
new_path="${new_path:1}"
export PATH="$new_path"

# check required programs
if ! exists cat mkdir find ls uname sysctl ps stat service chmod; then
    echo "Certains programmes utilisés par le script ne sont pas disponibles :"
    for p in cat mkdir find ls uname sysctl ps stat service chmod; do
        if ! exists "$p"; then echo "  - $p"; fi
    done
    exit 1
fi


##############################################################################
## Parse the command line options
##############################################################################
function usage() {
    cat <<EOF
Usage: ${0##*/} [-fhilnrs] [-o CHEMIN] [-t CHEMIN]

Extrait les informations nécessaires à la revue de configuration Linux.
Lorsque le script est lancé sans argument, il s’exécutera en mode interactif
et demandera à l’utilisateur le comportement à adopter.

Options:
    $BOLD-f$NOCOL          force l’écriture de l’archive de sortie, même si elle existe
                  déjà
    $BOLD-i$NOCOL          réduire la priorité d’accès au disque du script (ionice)
                  ${UNDER}note:$NOCOL si l’option -n est également spécifiée, le comportement
                  par défaut de Linux est d’également réduire la priorité d’accès
                  au disque
    $BOLD-l$NOCOL          Désactiver la récupération des droits de l’ensemble des fichiers
                  du disque
                  ${UNDER}note:$NOCOL cette option empêchera certaines analyses d’être
                  effectuées
    $BOLD-n$NOCOL          réduire la priorité du processus pour ne pas impacter les
                  autres services (nice)
    $BOLD-o CHEMIN$NOCOL   spécifie le dossier dans lequel l’archive sera générée
                  par défaut, elle est générée dans le dossier courant
    $BOLD-r$NOCOL          autoriser le script à s’exécuter sans les droits root
                  ${UNDER}note:$NOCOL le script nécessite les drois administrateurs pour
                  pouvoir extraire l’ensemble des éléments nécessaires à la revue
    $BOLD-s$NOCOL          lancer le script en mode non-interactif
                  ${UNDER}note:$NOCOL le mode interactif est automatiquement
                  désactivé lorsqu’une option est passée au script
    $BOLD-t CHEMIN$NOCOL   spécifie un dossier temporaire inscriptible
                  Par défaut, /tmp est utilisé

    $BOLD-h$NOCOL          montre ce message et quitte
EOF
}

# When no option are given run interactively to setup the same options
declare opt_force=n opt_io=n opt_list=y opt_nice=n opt_root=n opt_interactive=1
declare out_dir="$PWD" tmp_dir="/tmp"
while getopts "fhilnrso:t:" OPTION; do
    case $OPTION in
    f)
        opt_force=y
        opt_interactive=0;;
    h)
        usage
        exit 0;;
    i)
        opt_io=y
        opt_interactive=0;;
    l)
        opt_list=n
        opt_interactive=0;;
    n)
        opt_nice=y
        opt_interactive=0;;
    r)
        opt_root=y
        opt_interactive=0;;
    s)
        opt_interactive=0;;
    o)
        out_dir="$(realpath "$OPTARG")";;
    t)
        tmp_dir="$(realpath "$OPTARG")";;
    *)
        echo "Incorrect options provided: $OPTION" >&2
        exit 1;;
    esac
done

##############################################################################
## Content of the script
##############################################################################

# Check we are running with root privileges
if [ "$EUID" -ne 0 ]; then
    if ! ask "$opt_root" \
        "Ce script necessite les droits d'administateur" \
        "Voulez-vous continuer ?" n 13>&2; then
            exit 1
    fi
fi

# create log files within a temporary directory in the script directory
working_dir="$(mktemp "${tmp_dir}")"
# protect the working directory from unauthorized access
chmod 700 "$working_dir"
cd "$working_dir"

# setup the environment
setupRedirections
# ensure the language for command is english
export LC_ALL=en_US.UTF-8
# activate xtrace for later debugging purpose, if needed
set -o xtrace

# do some interactive configuration

# renice the process not to impact running processes
if exists renice; then
    if ask "$opt_nice" \
        "" \
        $'Souhaitez-vous diminuer la priorité du processus afin de ne pas\n'\
'impacter les autres services ?' n; then
        renice 19 -p $$
    fi
fi
if exists ionice; then
    if ask "$opt_io" \
        "" \
        $'Souhaitez-vous diminuer la priorité d’accès au disque afin de ne \n'\
'pas impacter les services consommateurs de disque ?' n; then
        ionice -c 2 -n 7 -p $$
    fi
fi

# prevent the potential listing of the filesystem
if ! ask "$opt_list" \
    $'Le parcours de l\'arborescence permet d\'évaluer les propriétés\n'\
$'et permissions sur les fichiers et répertoires. Cela peut\n'\
$'prendre un long moment, mais il est nécessaire pour permettre une\n'\
$'revue exhaustive.' \
    "Souhaitez-vous tout de même un parcours automatique par le script ?" y
then
    opt_list=n
fi

# start of the main body
echo "Début du script"
###############################################################################
newSection "Informations script"
newSubsection "Version"
OP=ign do_extract echo "4.0.0"
newSubsection "Run as"
OP=ign do_extract echo "$EUID"

###############################################################################
newSection "Informations générales"

#------------------------------------------------------------------------------
newSubsection "Identification du serveur"
newSubsubsection "Hostname"
do_extract hostname
newSubsubsection "Version noyau et version OS"
newSubsubsubsection "uname"
do_extract uname -n
OP=and do_extract uname -r
OP=and do_extract uname -v
OP=and do_extract uname -m
OP=and do_extract uname -o
newSubsubsubsection "lsb_release"
do_extract lsb_release -a

#------------------------------------------------------------------------------
newSubsection "Rôle du serveur"
do_extract echo "Expliquer le rôle du serveur, sur la base d'entretiens ou"\
    "des services à l'écoute"



###############################################################################
newSection "Gestion des utilisateurs et des groupes"

#------------------------------------------------------------------------------
newSubsection "Compte utilisateur root"
newSubsubsection "Vérifier l'absence de « . » dans le PATH de root"
do_extract echo "$PATH"
newSubsubsection "Droit du répertoire personnel de root"
do_extract ls -ldL ~root
newSubsubsection "Contenu home dir de root"
do_extract ls -alL ~root
newSubsubsection "Variables d'environnement de root"
do_extract env

#------------------------------------------------------------------------------
newSubsection "Liste des comptes et des groupes"
newSubsubsection "Liste des comptes"
do_extract getent passwd
newSubsubsection "Mot de passe des comptes"
do_extract getent shadow
newSubsubsection "Liste des groupes"
do_extract getent group
newSubsubsection "Mot de passe des groupes"
do_extract getent gshadow


###############################################################################
newSection "Gestion de l'authentification"

#------------------------------------------------------------------------------
newSubsection "Sources d'authentification"
do_extract get_files /etc/nsswitch.conf /etc/sssd/*
do_extract get_files /etc/pam.conf /etc/pam.d/*

#------------------------------------------------------------------------------
newSubsection "Politique des mots de passe locaux"
newSubsubsection "Fichiers"
do_extract get_files /etc/pam.conf /etc/pam.d/* # pam_cracklib,unix,pwquality
# password renewal & warning
OP=and do_extract get_files /etc/login.defs
newSubsubsection "Shadow"
OP=and do_extract getent shadow

#------------------------------------------------------------------------------
newSubsection "Verrouillage des comptes locaux"
do_extract get_files /etc/pam.conf /etc/pam.d/* # pam_tally

#------------------------------------------------------------------------------
newSubsection "Algorithme de hachage des mots de passes locaux"
do_extract get_files /etc/libuser.conf /etc/login.defs \
    /etc/pam.conf /etc/pam.d/*

#------------------------------------------------------------------------------
newSubsection "Robustesse des mots de passes en place"
do_extract getent shadow

#------------------------------------------------------------------------------
newSubsection "Cohérence des fichiers /etc/passwd et /etc/shadow"
OP=ign do_extract pwck -r

#------------------------------------------------------------------------------
newSubsection "Cohérence des fichiers /etc/group et /etc/gshadow"
OP=ign do_extract grpck -r


###############################################################################
newSection "Sécurité du système de fichiers"

#------------------------------------------------------------------------------
newSubsection "Partitionnement"
do_extract df -k

#------------------------------------------------------------------------------
newSubsection "Partitionnement et mount"
do_extract mount

#------------------------------------------------------------------------------
newSubsection "Niveaux de umask"
do_extract umask

#------------------------------------------------------------------------------
newSubsection "Droits des répertoires systèmes"
do_extract ls -ldL /bin /dev /etc /sbin
OP=or do_extract ls -ldL /usr/etc /usr/bin /usr/sbin

#------------------------------------------------------------------------------
newSubsection "Droits des répertoires utilisateurs"
newSubsubsection "Liste des comptes"
do_extract getent passwd
newSubsubsection "Mot de passe des comptes"
do_extract getent shadow
newSubsubsection "Liste des groupes"
do_extract getent group
newSubsubsection "Mot de passe des groupes"
do_extract getent gshadow
while IFS=: read user _ _ _ _ home _; do
    newSubsubsection "$user"
    OP=ign do_extract ls -ldL "$home"
done < <(getent passwd)

#------------------------------------------------------------------------------

newSubsection "Droits des répertoires des programmes"
while read path; do
    OP=or do_extract ls -ldL "$path"
done < <(echo "$PATH" | tr ':' '\n')

#------------------------------------------------------------------------------
newSubsection "Reliquats d'anciens utilisateurs"
do_extract find / \( -path /proc -o -path /sys \) -prune -o \( -nouser -o -nogroup \) -exec ls -ldL {} \;

#------------------------------------------------------------------------------
newSubsection "Fichiers et répertoires avec des droits spéciaux"
newSubsubsection "Fichiers modifiables par tout le monde"
do_extract find / \( -path /proc -o -path /sys \) -prune -o -type f -perm -2 -exec ls -ldL {} \;
newSubsubsection "Fichiers avec le bit SUID"
do_extract find / \( -path /proc -o -path /sys \) -prune -o -type f -perm -4000 -exec ls -ldL {} \;
newSubsubsection "Fichiers avec le bit SGID"
do_extract find / \( -path /proc -o -path /sys \) -prune -o -type f -perm -2000 -exec ls -ldL {} \;
newSubsubsection "Répertoires modifiables par tout le monde sans sticky-bit"
do_extract find / \( -path /proc -o -path /sys \) -prune -o -type d -perm -2 ! -perm -1000 -exec ls -ldL {} \;
newSubsubsection "Fichiers et répertoires avec des ACL spécifiques"
do_extract getfacl --recursive --skip-base /


###############################################################################
newSection "Sécurité du système"

#------------------------------------------------------------------------------
newSubsection "BootLoader"
newSubsubsection "LILO"
OP=skip do_extract cat /etc/lilo.conf
newSubsubsection "Grub Legacy"
OP=skip do_extract cat /boot/grub/menu.lst
newSubsubsection "Grub 2"
OP=skip do_extract get_files /boot/grub{,2}/grub.cfg

#------------------------------------------------------------------------------
newSubsection "Configuration noyau lié au système"
do_extract sysctl -a

#------------------------------------------------------------------------------
newSubsection "Contrôle de l'utilisation de sudo"
do_extract get_files /etc/sudoers /etc/sudoers.d/*

#------------------------------------------------------------------------------
newSubsection "Antivirus"
do_extract ps -efjwwl

#------------------------------------------------------------------------------
newSubsection "Configuration des namespace Linux"
newSubsubsection "Kernel compilation options"
do_extract get_files /boot/config-`uname -r`
do_extract get_files -b /proc/config.gz
newSubsubsection "Namespace sysctl"
do_extract sysctl -a

#------------------------------------------------------------------------------
newSubsection "Configuration des LSM - AppArmor"
newSubsubsection "Status"
do_extract apparmor_status --verbose
newSubsubsection "Profiles"
# get the apparmor.d files but ignore cache files
OP=skip do_extract get_files `find /etc/apparmor.d -type f \
    -a -not -path "/etc/apparmor.d/cache*"`

#------------------------------------------------------------------------------
newSubsection "Configuration des LSM - SELinux"
newSubsubsection "Status"
do_extract sestatus
newSubsubsection "Rules"
do_extract semanage fcontext -l
newSubsubsection "File contexts"
do_extract seinfo -t
newSubsubsection "Users"
do_extract seinfo -u
newSubsubsection "Roles"
do_extract seinfo -r

#------------------------------------------------------------------------------
newSubsection "Désactivation USB"
newSubsubsection "Désactivation USB via udev"
OP=skip do_extract get_files /etc/udev/rules.d /usr/lib/udev/rules.d /lib/udev/rules.d

newSubsubsection "Désactivation USB via USBGuard"
OP=skip do_extract get_files /etc/usbguard/


###############################################################################
newSection "Sécurité du réseau"

#------------------------------------------------------------------------------
newSubsection "Services en écoute réseau"
newSubsubsection "Liste des services - systèmes récents"
do_extract ss -lnp
newSubsubsection "Liste des interfaces - systèmes récents"
do_extract ip address show
newSubsubsection "Liste des services - systèmes anciens"
do_extract netstat -lnp
newSubsubsection "Liste des interfaces - systèmes anciens"
do_extract ifconfig -a

newSubsubsection "Liste des services - via procfs"
newSubsubsubsection "/proc/net"
OP=ign do_extract get_files /proc/net
newSubsubsubsection "/proc/*/cmdline"
OP=ign do_extract get_files -b /proc/[0-9]*/cmdline
newSubsubsubsection "/proc/*/fd/*"
OP=ign do_extract stat -c %N /proc/[0-9]*/fd/[0-9]*
newSubsubsubsection "/sys/class/net/*/ifindex"
OP=ign do_extract get_files /sys/class/net/*/ifindex

#------------------------------------------------------------------------------
newSubsection "Pare-feu"
newSubsubsection "iptables"
do_extract iptables-save
newSubsubsection "ip6tables"
do_extract ip6tables-save
newSubsubsection "ebtables"
do_extract ebtables-save
newSubsubsection "arptables"
do_extract arptables-save
newSubsubsection "nftables"
do_extract nft list ruleset

#------------------------------------------------------------------------------
newSubsection "Configuration noyau lié au réseau"
do_extract sysctl -a

#------------------------------------------------------------------------------
newSubsection "Service anti-bruteforce"
newSubsubsection "fail2ban"
OP=skip do_extract get_files /etc/fail2ban/
newSubsubsection "PAM Shield"
OP=skip do_extract get_files /etc/security/shield.conf /etc/pam.conf /etc/pam.d/

#------------------------------------------------------------------------------
newSubsection "Samba"
newSubsubsection "Configuration"
OP=skip do_extract get_files /usr/local/samba/lib/smb.conf /usr/samba/lib/smb.conf \
    /etc/samba/smb.conf
newSubsubsection "SAM"
do_extract pdbedit -Lwv

#------------------------------------------------------------------------------
newSubsection "NFS"
newSubsubsection "Serveur"
do_extract get_files /etc/exports
newSubsubsection "Client"
OP=skip do_extract showmount

#------------------------------------------------------------------------------
newSubsection "RPC"
do_extract rpcinfo -p


###############################################################################
newSection "Administration à distance"

#------------------------------------------------------------------------------
newSubsection "Services (x)inetd"
newSubsubsection "Liste des services"
do_extract get_files /etc/inetd.conf /etc/xinetd.conf /etc/xinetd.d/*
newSubsubsection "Règle d'accès TCP Wrapper"
# netgroup is collected because may be used in later files
# hosts.{allow,deny} enable TCP wrapping based on the remote host
# hosts.equiv and .rhosts defines remote machines and/or users which are
#   allowed to connect to the local machine (and user for .rhosts) w/out passwd
# hosts.lpd lists remote machines which are allowed to print on local printers
do_extract get_files /etc/netgroup /etc/hosts.{equiv,allow,deny,lpd}
while IFS=: read user _ _ _ _ home _; do
    OP=or do_extract get_files "$home/.rhosts"
done < <(getent passwd)

#------------------------------------------------------------------------------
newSubsection "SSH"
do_extract get_files /etc/ssh/sshd_config /usr/local/etc/sshd_config


###############################################################################
newSection "Sécurité des applications et des services"

#------------------------------------------------------------------------------
newSubsection "Mises à jour possibles ?"
newSubsubsection "Yum"
do_extract yum check-update
newSubsubsection "Apt"
do_extract apt-get update
do_extract apt-get -u upgrade --assume-no
newSubsubsection "Zypper"
do_extract zypper list-updates -a

#------------------------------------------------------------------------------
newSubsection "Liste des paquets installés"
newSubsubsection "Yum"
do_extract yum list installed
newSubsubsection "Apt"
do_extract dpkg -l
newSubsubsection "Zypper"
do_extract rpm -qa
newSubsubsection "Java"
do_extract java -version

#------------------------------------------------------------------------------
newSubsection "Utilisation de cron"
newSubsubsection "Droits d'accès du crontab"
do_extract ls -lL /etc/crontab

newSubsubsection "Restriction des utilisateurs de cron"
OP=skip do_extract get_files /etc/cron.{deny,allow}

newSubsubsection "Vérification des programmes appelés par cron"
do_extract get_files /etc/crontab

newSubsubsection "Vérification des crontab utilisateur"
while IFS=: read user _ _ _ _ _ _; do
    OP=ign do_extract echo "$user crontab:"
    OP=ign do_extract crontab -l -u "$user"
done < <(getent passwd)

newSubsubsection "Vérification des droits sur /etc/cron.hourly"
do_extract ls -alL /etc/cron.hourly/
newSubsubsection "Vérification des droits sur /etc/cron.daily"
do_extract ls -alL /etc/cron.daily/
newSubsubsection "Vérification des droits sur /etc/cron.weekly"
do_extract ls -alL /etc/cron.weekly/
newSubsubsection "Vérification des droits sur /etc/cron.monthly"
do_extract ls -alL /etc/cron.monthly/

newSubsubsection "Autres fichiers de configuration de Cron (/etc/cron.d/)"
do_extract get_files /etc/cron.d/*

#------------------------------------------------------------------------------
newSubsection "Utilisation de At"
newSubsubsection "Restriction des utilisateurs de At"
OP=skip do_extract get_files /etc/at.{allow,deny}
newSubsubsection "Liste des commandes en attente"
do_extract atq


###############################################################################
newSection "Journalisation"

#------------------------------------------------------------------------------
newSubsection "Contenu du dossier /var/log"
do_extract ls -RAlL /var/log

#------------------------------------------------------------------------------
newSubsection "Syslog"
newSubsubsection "rsyslog"
OP=skip do_extract get_files /etc/*syslog.conf /etc/*syslog.d/*
newSubsubsection "syslog-ng"
OP=skip do_extract get_files /etc/syslog-ng/syslog-ng.conf

#------------------------------------------------------------------------------
newSubsection "Auditd"
OP=skip do_extract get_files /etc/audit/auditd.conf /etc/audit/rules.d/*.rules
# rule number 1: audit the auditd log

#------------------------------------------------------------------------------
newSubsection "Renouvellement des logs"
OP=skip do_extract get_files /etc/logrotate.conf /etc/logrotate.d/*

#------------------------------------------------------------------------------
newSubsection "NTP"
newSubsubsection "État du service NTP"
# must ignore all commands because service fail if the service isn't running
OP=ign do_extract service ntp status
OP=ign do_extract service chrony status
OP=ign do_extract service chronyd status
OP=ign do_extract service ntpd status
OP=ign do_extract service openntpd status
OP=ign do_extract service systemd-timesyncd status

newSubsubsection "Configuration du NTP"
do_extract get_files /etc/ntp.conf /etc/ntpd.conf /etc/chrony.conf \
    /etc/openntpd/ntpd.conf /etc/systemd/timesyncd.conf


###############################################################################
endSection

getent passwd  >> "passwd.txt"  2>&1
getent shadow  >> "shadow.txt"  2>&1
getent group   >> "group.txt"   2>&1
getent gshadow >> "gshadow.txt" 2>&1

echo "Récupération du dossier /etc, secrets exclus"
# Get all configuration files except big files (more than 5M) & secrets
# (identify by the missing read permission for other)
if exists tar; then
    # do an archive directly
    tar cJf etc.tar.xz --no-recursion --files-from <(find /etc -type d -o \( -size -5M -a -perm -004 \))
else
    # just copy as such
    find /etc -type f -a -size -5M -a -perm -004 -exec cp --parents '{}' . \;
fi

echo "Extraction des configurations terminée."
echo "La suite parcours l'ensemble de l'arborescence. Cela peut prendre du temps."

if [[ "$opt_list" == "y" ]]; then
    echo "Parcours de l'arborescence démarré"
    find / -ls >> file_list.txt 2>&1
else
    echo "Parcours de /etc démarré et renseigné dans le fichier"
    find / -maxdepth 1 -ls >> file_list.txt 2>&1
    find /etc -ls >> file_list.txt 2>&1
fi

echo
if exists tar; then
    echo "Une archive tar va être créée pour rassembler les fichiers générés"
    tar_file="$out_dir/$resultsDir.tar.gz"
    declare results create_tar

    if [ -e "$tar_file" ]; then
        echo "Le fichier '$tar_file' existe déjà"
        if ask "$opt_force" "" \
            "Voulez-vous le réécrire ?" n; then
            echo "Le fichier '$tar_file' va être réécrit"
            create_tar=1
        else
            create_tar=0
        fi
    else
        create_tar=1
    fi
    if [ $create_tar -eq 1 ]; then
        # create the tar file and remove the working dir (only if tar was
        # successfully created)
        cd "$working_dir" && \
            tar czf "$tar_file" * && \
            cd "$script_dir" && \
            rm -rf "$working_dir"

        # check that the file could be created
        if [ -f "$tar_file" -a ! -d "$working_dir" ]; then
            results="$tar_file"
        else
            echo "Erreur lors de la création de l’archive"
            results="$working_dir"
        fi
    else
        results="$working_dir"
    fi
else
    echo "La commande 'tar' n’est pas installée sur le système : aucune archive ne sera créée"
    results="$working_dir"
fi

echo    "-----------------------------------------------------"
echo    "L'audit du système est terminé."
echo    "Les résultats de l’audit sont dans :"
echo -e "   \x1b[1m$results\x1b[0m"
echo    "-----------------------------------------------------"

