# HP-UX

## Usage

- Copiez le script `script_hp_ux.sh` sur le serveur HP-UX
- Rendez le exécutable
- Exécutez le script : `./script_hp_ux.sh`
- Récupérez le fichier `/tmp/wavestone-HOSTNAME.tar`
