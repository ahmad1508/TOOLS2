#!/bin/bash

mkdir /tmp/wavestone
cd /tmp/

# general configuration
hostname > /tmp/wavestone/hostname
model > /tmp/wavestone/model
uname -a > /tmp/wavestone/uname-a
uname -r > /tmp/wavestone/uname-r
ioscan > /tmp/wavestone/ioscan

# software & patching level
swlist > /tmp/wavestone/swlist
swm list > /tmp/wavestone/swm-list
swlist -l product > /tmp/wavestone/swlist-product
swlist -l patch > /tmp/wavestone/swlist-patch

# ip configuration
lanscan -v > /tmp/wavestone/lanscan
cp /etc/resolv.conf /tmp/wavestone/resolv.conf
cp /etc/networks /tmp/wavestone/network
cp /etc/opt/ipf/ipf.conf /tmp/wavestone/ipf.conf
cp /etc/hosts* /tmp/wavestone/
netstat -r > /tmp/wavestone/netstat-r
netstat -in > /tmp/wavestone/netstat-in

# environnement
echo $PATH > /tmp/wavestone/root-path
set > /tmp/wavestone/set
cp /root/.*sh_history > /tmp/wavestone/root-sh-history
grep '' /home/*/.*sh_history > /tmp/wavestone/home-sh-history

# accounts
cp /etc/passwd /tmp/wavestone/passwd
cp /etc/group /tmp/wavestone/group
cp /etc/shadow /tmp/wavestone/shadow
cp /tcb/files/auth/r/root /tmp/wavestone/auth-r-root
cp /etc/pam* /tmp/wavestone/
cp /usr/local/etc/sudoers /tmp/wavestone/sudoers-1
cp /etc/sudoers /tmp/wavestone/sudoers-2
cp /etc/default/security /tmp/wavestone/default-security
cp /etc/security.dsc /tmp/wavestone/security.dsc
cp /etc/opt/ssh/sshd_config /tmp/wavestone/sshd_config

# logging
cp /etc/syslog.conf /tmp/wavestone/syslog.conf

# archive and clean
tar -cvf wavestone-`hostname`.tar wavestone/
rm -r wavestone/
