prompt Launching collector script, please wait...

set serveroutput off
set head off
set feed off
set termout off
set echo off
set long 1000000
set newpage 0
set space 0
set pagesize 0
set linesize 10000
set feedback off
set colsep @@

spool Wavestone_Oracle.res
prompt '===== Informations générales ====='
prompt '--=== Heure d'exécution du script ===--'
select to_char(sysdate,'Dy Mon dd hh24:mi:ss yyyy') system_date from sys.dual;

prompt '--=== Domain ===--'
show parameter domain;

prompt '--=== Numéro de version ===--'
show release;

prompt '--=== infos_bdd ===--'
SELECT * FROM V$INSTANCE;

prompt '--=== show_parameters ===--'
select name, value from sys.v$parameter;

prompt '--=== Privilèges de la session courante ===--'
select * from session_privs

prompt '--=== Rôles de la session courante ===--'
select * from session_roles;

prompt '--=== Mémoire pour Java ===--'
select pool, name, bytes from v$sgastat where POOL='java pool';

prompt '--=== dba_directories ===--'
select owner, directory_name, directory_path from dba_directories;

prompt '===== Utilisateurs et authentification ====='
prompt '--=== Liste des comptes ===--'
SELECT USERNAME, ACCOUNT_STATUS, lock_date, PASSWORD, PROFILE, AUTHENTICATION_TYPE FROM DBA_USERS ORDER BY ACCOUNT_STATUS DESC;

prompt '--=== accounts_passwords_2 ===--'
SELECT name, type#, password, spare4 FROM sys.user$ ORDER BY SPARE4;

prompt '--=== all_accounts ===--'
select username, user_id, created from all_users;

prompt '--=== password_strategy ===--'
SELECT PROFILE, RESOURCE_NAME, LIMIT FROM DBA_PROFILES WHERE RESOURCE_NAME='FAILED_LOGIN_ATTEMPTS' OR RESOURCE_NAME='PASSWORD_LIFE_TIME' OR RESOURCE_NAME='PASSWORD_REUSE_MAX' OR RESOURCE_NAME='PASSWORD_REUSE_TIME' OR RESOURCE_NAME='PASSWORD_LOCK_TIME' OR RESOURCE_NAME='PASSWORD_GRACE_TIME';

prompt '--=== Sensitivité à la casse des mots de passe ===--'
show parameter sec_case_sensitive_logon;

prompt '--=== Fonction de vérification de la solidité des mots de passe ===--'
select profile, resource_name, limit from dba_profiles where resource_name='PASSWORD_VERIFY_FUNCTION';

prompt '--=== Paramètres pour l'authentification via l'OS ===--'
show parameter os_authent

prompt '--=== Utilisateurs concernés par l'authentification via l'OS ===--'
select name from sys.user$ where upper(name) like '' || upper((select value from sys.v$parameter where name='os_authent_prefix')) ||'%';

prompt '--=== Utilisateurs avec un mot de passe EXTERNAL ===--'
SELECT USERNAME FROM DBA_USERS WHERE PASSWORD='EXTERNAL';

prompt '--=== Authentification externe ===--'
SELECT username, external_name, account_status from dba_users where authentication_type='GLOBAL';

prompt '--=== Directive REMOTE_LOGIN_PASSWORDFILE ===--'
show parameter remote_login_passwordfile;

prompt '--=== Utilisateurs présents dans le fichier de mots de passe (Oracle 11) ===--'
select username, sysdba, sysoper, sysasm from v$pwfile_users;

prompt '--=== Utilisateurs présents dans le fichier de mots de passe (Oracle 10) ===--'
select username, sysdba, sysoper from v$pwfile_users;

prompt '--=== Tables en vrac pouvant contenir des empreintes ===--'
prompt == Table SYS.EXU7LNK;
select owner,user$,passwd from SYS.EXU7LNK;
prompt == Table SYS.EXU7LNKU;
select * from SYS.EXU7LNKU;
prompt == Table SYS.EXU7ROL;
select * from SYS.EXU7ROL;
prompt == Table SYS.EXU7USR;
select * from SYS.EXU7USR;
prompt == Table SYS.EXU7USRU;
select * from SYS.EXU7USRU;
prompt == Table SYS.EXU8LNK;
select * from SYS.EXU8LNK;
prompt == Table SYS.EXU8LNKU;
select * from SYS.EXU8LNKU;
prompt == Table SYS.EXU8PHS;
select * from SYS.EXU8PHS;
prompt == Table SYS.EXU8PHS;
select * from SYS.EXU8PHS;
prompt == Table SYS.EXU8ROL;
select * from SYS.EXU8ROL;
prompt == Table SYS.EXU8USR;
select * from SYS.EXU8USR;
prompt == Table SYS.EXU8USRU;
select * from SYS.EXU8USRU;
prompt == Table SYS.EXU9LNK;
select * from SYS.EXU9LNK;
prompt == Table SYS.EXU9LNKU;
select * from SYS.EXU9LNKU;
prompt == Table SYS._ROLE_VIEW;
select * from SYS.KU$_ROLE_VIEW;
prompt == Table SYS._USER_VIEW;
select * from SYS.KU$_USER_VIEW;
prompt == Table SYS.USER_HISTORY;
select * from SYS.USER_HISTORY$;

prompt '===== Privilèges et accès aux données ====='
prompt '--=== Liste des profils ===--'
select distinct profile from dba_profiles;

prompt '--=== Ressources allouées aux profils ===--'
SELECT PROFILE, RESOURCE_NAME, LIMIT FROM DBA_PROFILES WHERE RESOURCE_NAME='CPU_PER_SESSION' OR RESOURCE_NAME='PRIVATE_SGA' OR RESOURCE_NAME='LOGICAL_READS_PER_SESSION' OR RESOURCE_NAME='SESSIONS_PER_USER' OR RESOURCE_NAME='CONNECT_TIME' OR RESOURCE_NAME='IDLE_TIME';

prompt '--=== Utilisateurs rattachés aux profils ===--'
select username, profile from dba_users;

prompt '--=== Utilisateurs DBA ===--'
select * from dba_role_privs where granted_role='DBA';

prompt '--=== DEFAULT_TABLESPACE ===--'
SELECT USERNAME, DEFAULT_TABLESPACE FROM DBA_USERS;

prompt '--=== USER_HISTORY_PERMISIONS ===--'
SELECT GRANTEE, PRIVILEGE FROM DBA_TAB_PRIVS WHERE TABLE_NAME='USER_HISTORY$';

prompt '--=== USER_HISTORY ===--'
SELECT * FROM SYS.USER_HISTORY$;

prompt '--=== SYSTEM_PRIVILEGES ===--'
SELECT * FROM DBA_SYS_PRIVS ORDER BY GRANTEE, PRIVILEGE;

prompt '--=== DBA_ROLES_PASSWORD_PROTECT ===--'
SELECT * FROM DBA_ROLES ORDER BY password_required, role;

prompt '--=== Utilisateurs autorisés à accéder à la table SYSLINKS ===--'
SELECT GRANTEE, PRIVILEGE FROM DBA_TAB_PRIVS WHERE TABLE_NAME='LINK$';

prompt '--=== BDD externes accessibles ===--'
select db_link, username, host from all_db_links;

prompt '--=== Identifiants stockés dans sys.link$ ===--'
select name, password, passwordx from sys.link$;

prompt '--=== SYS_USERS ===--'
SELECT GRANTEE, PRIVILEGE FROM DBA_TAB_PRIVS WHERE TABLE_NAME='USER$';

prompt '--=== SYS_SOURCE ===--'
SELECT GRANTEE, PRIVILEGE FROM DBA_TAB_PRIVS WHERE TABLE_NAME='SOURCE$';

prompt '--=== SHARED_ACCOUNTS ===--'
SELECT COUNT(distinct(terminal)) COUNT, USERNAME FROM DBA_AUDIT_SESSION HAVING COUNT(distinct(terminal))>1 GROUP BY USERNAME;

prompt '===== Checklist ====='
prompt '--=== PERF_STATS_SQLTEXT_SQLSUM ===--'
SELECT GRANTEE, PRIVILEGE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME='STATS$SQLTEXT' OR TABLE_NAME='STATS$SQLSUM';

prompt '--=== DBA_TAB_PRIVS_TABLES ===--'
SELECT GRANTEE, PRIVILEGE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME LIKE('X$%') OR TABLE_NAME LIKE('V$') OR TABLE_NAME LIKE('DBA_$');

prompt '--=== interesting_tables ===--'
SELECT GRANTEE, PRIVILEGE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME='ALL_SOURCE' OR TABLE_NAME='DBA_ROLES' OR TABLE_NAME='DBA_SYS_PRIVS' OR TABLE_NAME='DBA_ROLE_PRIVS' OR TABLE_NAME='DBA_TAB_PRIVS' OR TABLE_NAME='DBA_USERS' OR TABLE_NAME='ROLE_ROLE_PRIVS' OR TABLE_NAME='USER_TAB_PRIVS' OR TABLE_NAME='USER_ROLE_PRIVS'

prompt '--=== CATALOG ===--'
SELECT GRANTEE, PRIVILEGE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME LIKE('%_CATALOG_%');

prompt '--=== TABLE_SYNONYMS ===--'
SELECT SYNONYM_NAME, TABLE_NAME FROM ALL_SYNONYMS WHERE TABLE_NAME LIKE('V$%');

prompt '--=== ANY_PRIVILEGES ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE LIKE('%ANY%');

prompt '--=== GRANTING_ALL_PRIVILEGES ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='GRANT ANY PRIVILEGE' OR PRIVILEGE='GRANT ANY OBJECT PRIVILEGE';

prompt '--=== EXEMPT_ACCESS_POLICY ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='EXEMPT ACCESS POLICY';

prompt '--=== WITH_ADMIN ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE ADMIN_OPTION='YES';

prompt '--=== WITH_GRANT ===--'
SELECT * FROM DBA_TAB_PRIVS WHERE GRANTABLE='YES';

prompt '--=== CREATE ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE LIKE('CREATE %');

prompt '--=== CREATE_LIBRARY ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='CREATE LIBRARY';

prompt '--=== ALTER_SYSTEM ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='ALTER SYSTEM';

prompt '--=== CREATE_PROCEDURE ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='CREATE PROCEDURE';

prompt '--=== BECOME_USER ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE LIKE('BECOME USER');

prompt '--=== SELECT_ANY_TABLE ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE LIKE('SELECT ANY%');

prompt '--=== AUDIT_SYSTEM ===--'
SELECT * FROM DBA_SYS_PRIVS WHERE PRIVILEGE='AUDIT SYSTEM';

prompt '--=== GRANTED_ROLE ===--'
SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTED_ROLE='PUBLIC' OR GRANTED_ROLE='RESOURCE' OR GRANTED_ROLE='DBA';

prompt '--=== DBMS_DBA_TAB_PRIVS ===--'
SELECT GRANTEE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME='DBMS_LOB' OR TABLE_NAME='DBMS_SYS_SQL' OR TABLE_NAME='DBMS_JOB' OR TABLE_NAME='DBMS_BACKUP_RESTORE' OR TABLE_NAME='DBMS_RANDOM';

prompt '--=== PUBLIC_VIEWS_ALL ===--'
SELECT TABLE_NAME FROM DBA_TAB_PRIVS WHERE TABLE_NAME LIKE('ALL_%') AND GRANTEE='PUBLIC';

prompt '--=== Tables UTL et privilèges associés ===--'
SELECT GRANTEE, TABLE_NAME FROM DBA_TAB_PRIVS WHERE table_name like 'UTL%' ORDER BY GRANTEE;

prompt '--=== Paramètre UTL_FILE_DIR ===--'
show parameter utl_file_dir

prompt '--=== Dossiers UTL ===--'
select value from v$parameter where name = 'utl_file_dir';

prompt '===== Procédures, fonctions et triggers ====='
prompt '--=== Liste des procédures ===--'
SELECT object_name, owner FROM dba_objects WHERE object_type='PROCEDURE';

prompt '--=== Source des procédures ===--'
-- select line, text from dba_source where type='PROCEDURE';

prompt '--=== Liste des fonctions ===--'
SELECT object_name, owner FROM dba_objects WHERE object_type='FUNCTION';

prompt '--=== Source des fonctions ===--'
-- select line, text from dba_source where type='FUNCTION';

prompt '--=== Liste des triggers ===--'
SELECT object_name, owner FROM dba_objects WHERE object_type='TRIGGER';

prompt '--=== Source des triggers ===--'
-- select line, text from dba_source where type='TRIGGER';

prompt '===== Audit des actions ====='
prompt '--=== Paramètre audit ===--'
show parameter audit

prompt '--=== Paramètre DICTIONARY_ACCESSIBILITY ===--'
show parameter DICTIONARY_ACCESSIBILITY

prompt '--=== Table audit ===--'
select SESSIONID, ENTRYID, STATEMENT, TIMESTAMP#, USERID , USERHOST, TERMINAL, ACTION#, RETURNCODE, OBJ$CREATOR, OBJ$NAME, AUTH$PRIVILEGES, AUTH$GRANTEE, NEW$OWNER, NEW$NAME, SES$ACTIONS, SES$TID, LOGOFF$LREAD, LOGOFF$PREAD, LOGOFF$LWRITE, LOGOFF$DEAD, LOGOFF$TIME, COMMENT$TEXT, CLIENTID, SPARE1 , SPARE2 , OBJ$LABEL, SES$LABEL, PRIV$USED, SESSIONCPU, NTIMESTAMP#, PROXY$SID, USER$GUID, INSTANCE#, PROCESS#, XID, AUDITID, SCN, DBID, SQLBIND, SQLTEXT, OBJ$EDITION	 from sys.aud$;

prompt '--=== Audit des connexions/deconnexions ===--'
SELECT USERNAME, LOGOFF_TIME, LOGOFF_LREAD, LOGOFF_PREAD, LOGOFF_LWRITE, LOGOFF_DLOCK FROM DBA_AUDIT_SESSION;

prompt '--=== Table fine grained audit ===--'
select * from sys.fga_log$ where rownum < 20;

prompt '--=== Options d'audit OBJET par défaut ===--'
SELECT * FROM ALL_DEF_AUDIT_OPTS;

prompt '--=== Options d'audit courantes ===--'
select * from DBA_STMT_AUDIT_OPTS;

prompt '--=== Options d'audit SYSTÈME courantes ===--'
select * from DBA_PRIV_AUDIT_OPTS;

prompt '--=== Options d'audit sur les objets ===--'
SELECT * FROM DBA_OBJ_AUDIT_OPTS;

prompt '--=== Codes des types d'option d'audit ===--'
select * from STMT_AUDIT_OPTION_MAP;

prompt '--=== Code des actions d'audit ===--'
select * from AUDIT_ACTIONS;

prompt '--=== EoF ===--'
spool off
set termout on
prompt Finished.
exit
