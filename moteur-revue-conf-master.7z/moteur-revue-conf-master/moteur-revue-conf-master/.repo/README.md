This directory contains scripts and files useful to manage the git repository.
