#!/bin/bash

# ensure we work within the repository root
cd "$(dirname "$0")/.."

# extract files
./translations.sh extract &> /dev/null

# translate all files
./translations.sh translate all all &> /dev/null
# check if some files changed
if ! git diff --quiet -- locales/; then
  echo "The following translations changed"
  git status -s locales/
  exit 1
fi

# compile all files
./translations.sh compile &> /dev/null
# check if some files changed
if ! git diff --quiet -- locales/; then
  echo "The following translations were compiled"
  git status -s locales/
  exit 1
fi
