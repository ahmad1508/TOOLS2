# Documentation du moteur de revue de configuration

## Synthèse du document

Ce document a pour ambition de présenter le projet « Moteur de revue de
configuration ».

L’objectif global du projet est de proposer aux auditeurs de toutes
technologies une plateforme d’aide à l’audit. Cette plateforme doit être
cohérent avec le livrable client et suivre le même plan. De plus, les
extractions de configuration doivent être placées aux bons endroits afin de
gagner en efficacité. Enfin, cette plateforme doit contenir des commentaires
d’aide à l’analyse propre à chaque technologie.

Cette plateforme se base sur un moteur développé en python. Il permet
d’analyser les extractions des configurations pour lesquelles une technologie
est définie.

![Context initial](assets/contexte_initial.png)

Ce document est donc destiné aux personnes suivantes :

- Auditeur souhaitant utiliser l’outil de revue de configuration :
  [voir ici](use_the_engine.md) ;
- Auditeur souhaitant ajouter une nouvelle technologie au moteur python :
  [voir ici](add_technology.md) ;
- Toutes personnes souhaitant améliorer et poursuivre le projet :
  [voir ici](how_engine_works.md) ;
- Toutes personnes souhaitant proposer des améliorations :
  [voir ici](../../../issues) ;
