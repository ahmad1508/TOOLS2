var editor_schema = {
  title: "Sections",
  type: "array",
  format: "tabs",
  items: {
    title: "Section",
    type: "object",
    headerTemplate: "{{i1}}.{{self.title}}",
    properties: {
      title: { type: "string" },
      desc: {
        type: "string",
        format: "bbcode",
        required: true,
        options: { wysiwyg: true },
      },
      content: {
        title: "Subsections",
        type: "array",
        format: "tabs-top",
        items: {
          title: "Subsection",
          type: "object",
          headerTemplate: "{{i1}}.{{self.title}}",
          properties: {
            title: { type: "string" },
            desc: {
              type: "string",
              format: "bbcode",
              required: true,
              options: { wysiwyg: true },
            },
            analyze: {
              type: "string",
              format: "bbcode",
              required: true,
              options: { wysiwyg: true },
            },
            rec: {
              type: "string",
              format: "bbcode",
              required: true,
              options: { wysiwyg: true },
            },
            extract: {
              title: "Extracts",
              type: "array",
              items: {
                title: "Extract",
                type: "object",
                properties: {
                  title: { type: "string", required: true },
                  target: { type: "string", required: false },
                  cmd: { type: "string", required: false },
                  filter: { type: "string", required: false },
                },
              },
            },
          },
        },
      },
    },
  },
};

// This is the starting value for the editor
// We will use this to seed the initial editor
// and to provide a "Restore to Default" button.
var starting_value = [
  {
    title: "Titre de la partie",
    content: [
      {
        title: "Titre de la sous-partie",
        desc: "Description permettant d'expliquer la pertinence de ce contrôle",
        extract: [
          {
            title: "titre-de-l'extract-dans-le-fichier-d'extraction",
            cmd: "Commande utilisée pour obtenir ce bloc d'extraction",
            filter: "Filtre pour l’extract",
          },
        ],
        analyze: "Explications sur l'extraction",
        rec: "Recommandations associées",
      },
    ],
  },
];
