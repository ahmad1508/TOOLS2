JSONEditor.defaults.themes._materialize =
  JSONEditor.defaults.themes.materialize;
JSONEditor.defaults.themes.materialize =
  JSONEditor.defaults.themes._materialize.extend({
    // @see https://github.com/Dogfalo/materialize/issues/2542#issuecomment-233458602
    getTabHolder: function (propertyName) {
      var pName = typeof propertyName === "undefined" ? "" : propertyName;
      var el = document.createElement("div");
      el.classList.add("row", "card-panel");

      el.innerHTML =
        '<div class="col s2">' +
        '   <ul id="' +
        pName +
        '" class="tabs vertical">' +
        "   </ul>" +
        "</div>" +
        '<div class="col s10">' +
        "</div>";
      return el;
    },

    getTopTabHolder: function (propertyName) {
      var pName = typeof propertyName === "undefined" ? "" : propertyName;
      var el = document.createElement("div");
      el.classList.add("row", "card-panel");

      el.innerHTML =
        '<div class="col s12">' +
        '   <ul id="' +
        pName +
        '" class="tabs">' +
        "   </ul>" +
        "</div>" +
        '<div class="col s12">' +
        "</div>";
      return el;
    },

    addTab: function (tabHolder, tab) {
      tabHolder.children[0].children[0].appendChild(tab);
    },
    addTopTab: function (tabHolder, tab) {
      tabHolder.children[0].children[0].appendChild(tab);
    },

    getTabContentHolder: function (tabHolder) {
      return tabHolder.children[1];
    },
    getTopTabContentHolder: function (tabHolder) {
      return tabHolder.children[1];
    },

    // @see https://github.com/Dogfalo/materialize/issues/2542#issuecomment-233458602
    getTab: function (text, tabId) {
      var li = document.createElement("li");
      var a = document.createElement("a");
      a.setAttribute("href", "#" + tabId);
      a.appendChild(text);
      li.appendChild(a);
      li.classList.add("tab");
      return li;
    },

    getTopTab: function (text, tabId) {
      var li = document.createElement("li");
      var a = document.createElement("a");
      a.setAttribute("href", "#" + tabId);
      a.appendChild(text);
      li.appendChild(a);
      li.classList.add("tab");
      return li;
    },
    getTabContent: function () {
      var el = document.createElement("div");
      //el.classList.add('col', 's10');
      return el;
    },
    getTopTabContent: function () {
      var el = document.createElement("div");
      //el.classList.add('col', 's12');
      return el;
    },
    markTabActive: function (row) {
      row.tab.classList.add("active");
      row.container.classList.add("active");
      row.container.style.display = "block";
    },
    markTabInactive: function (row) {
      row.tab.classList.remove("active");
      row.container.classList.remove("active");
      row.container.style.display = "none";
    },
  });
