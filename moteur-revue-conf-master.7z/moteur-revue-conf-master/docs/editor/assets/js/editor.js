function init_editor(val) {
  // Initialize the editor
  return new JSONEditor(document.getElementById("editor_holder"), {
    // The schema for the editor
    schema: editor_schema,

    // Seed the form with a starting value
    startval: val,

    // Disable additional properties
    no_additional_properties: true,

    // Require all properties by default
    required_by_default: true,

    // Theming
    theme: "materialize",
    iconlib: "materialicons",
  });
}

var editor = init_editor(starting_value);

// Hook up the submit button to log to the console
document.getElementById("generate").addEventListener("click", function () {
  // Get the value from the editor
  var val = JSON.stringify(editor.getValue(), null, 2);
  download(current_filename, val);
});

// Hook up the Restore to Default button
document.getElementById("reset").addEventListener("click", function () {
  if (confirm("Are you sure you want to reset your work?")) {
    editor.destroy();
    editor = init_editor(starting_value);
  }
});

// Hook up the file selection to load it
document.getElementById("readfile").addEventListener("change", function (e) {
  var file = e.target.files[0];
  if (!file) {
    return;
  }
  var reader = new FileReader();
  reader.onload = function (e) {
    current_filename = file.name;
    starting_value = JSON.parse(e.target.result);
    editor.destroy();
    editor = init_editor(starting_value);
  };
  reader.readAsText(file);
});

var current_filename = "tech.json";
function download(filename, text) {
  var element = document.createElement("a");
  var val = encodeURIComponent(text);
  element.setAttribute("href", "data:application/json;charset=utf-8," + val);
  element.setAttribute("download", filename);

  element.style.display = "none";
  document.body.appendChild(element);

  element.click();

  document.body.removeChild(element);
}

$(document).ready(function () {
  $(".modal").modal();
});
