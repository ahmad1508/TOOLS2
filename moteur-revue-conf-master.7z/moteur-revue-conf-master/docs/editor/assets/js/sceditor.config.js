/*****************************\
 * Configure SCEditor plugin *
\*****************************/

// plugins
JSONEditor.plugins.sceditor.plugins = "undo";
JSONEditor.plugins.sceditor.icons = "material";

// set inner style to use the same as the engine output
JSONEditor.plugins.sceditor.style = "assets/vendors/css/bootstrap.min.css";
JSONEditor.plugins.sceditor.toolbar =
  "bold,italic,removeformat|" +
  "bulletlist,indent,outdent|" +
  "code,codeblock|" +
  "table|" +
  "link,unlink|" +
  "cut,copy,paste|" +
  "maximize,source";

var each = sceditor.utils.each;
var dom = sceditor.dom;

// add the code block command
sceditor.command.set("codeblock", {
  exec: function (caller) {
    var document = this.getBody().ownerDocument;
    var selected = document.getSelection();
    this.wysiwygEditorInsertHtml(
      '<pre class="pre-scrollable">' + (selected || "codeblock") + "</pre>"
    );
  },
  txtExec: ["[codeblock]", "[/codeblock]"],
  tooltip: "Insert a codeblock",
});
// update the way code are handled
sceditor.command.set("code", {
  exec: function (caller) {
    var document = this.getBody().ownerDocument;
    var selected = document.getSelection();
    this.wysiwygEditorInsertHtml(
      '<span class="code">' + (selected || "code") + "</span>"
    );
  },
});
// update the way lists are handled
sceditor.command.set("bulletlist", {
  txtExec: function (caller, selected) {
    var content = "";

    each(selected.split(/\r?\n/), function (k, v) {
      content += (content ? "\n" : "") + "[*]" + v;
    });

    this.insertText("[list]\n" + content + "\n[/list]");
  },
});
//udpet the way tables are handled
sceditor.command.set("table", {
  exec: function (caller) {
    var editor = this,
      content = document.createElement("div");

    content.appendChild(
      dom.parseHTML(
        '<div><label for="rows">Rows:</label>' +
          '<input type="text" id="rows" value="2" /></div>' +
          '<div><label for="cols">Cols:</label>' +
          '<input type="text" id="cols" value="2" /></div>' +
          "<div><label>" +
          '<input type="checkbox" id="head" class="filled-in" checked />' +
          "<span>Add headers</span></label>" +
          '<div><input type="button" class="button" value="Insert"/></div>'
      )
    );
    $(content);

    content.querySelector(".button").addEventListener("click", function (e) {
      var rows = Number(content.querySelector("#rows").value),
        cols = Number(content.querySelector("#cols").value),
        headers = content.querySelector("#head").checked,
        html = '<table class="table table-striped">';

      if (rows > 0 && cols > 0) {
        if (headers) {
          html += "<tr>" + Array(cols + 1).join("<th>Header</th>") + "</tr>";
        }
        html += Array(rows + 1).join(
          "<tr>" + Array(cols + 1).join("<td>Cell</td>") + "</tr>"
        );

        html += "</table>";

        editor.wysiwygEditorInsertHtml(html);
        editor.closeDropDown(true);
        e.preventDefault();
      }
    });

    editor.createDropDown(caller, "inserttable", content);
  },
});

// add an icon for code block
sceditor.icons.material.icons["codeblock"] =
  "<path d='M19 3H5C3.9 3 3 3.9 " +
  "3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 " +
  "3M11 8H9V10C9 11.1 8.1 12 7 12C8.1 12 9 12.9 9 14V16H11V18H9C7.9 18 7 " +
  "17.1 7 16V15C7 13.9 6.1 13 5 13V11C6.1 11 7 10.1 7 9V8C7 6.9 7.9 6 9 " +
  "6H11V8M19 13C17.9 13 17 13.9 17 15V16C17 17.1 16.1 18 15 " +
  "18H13V16H15V14C15 12.9 15.9 12 17 12C15.9 12 15 11.1 15 " +
  "10V8H13V6H15C16.1 6 17 6.9 17 8V9C17 10.1 17.9 11 19 11V13Z' />    " +
  "<path d='M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 " +
  "20.1 21 19V5C21 3.9 20.1 3 19 3M11 8H9V10C9 11.1 8.1 12 7 12C8.1 12 9 " +
  "12.9 9 14V16H11V18H9C7.9 18 7 17.1 7 16V15C7 13.9 6.1 13 5 13V11C6.1 " +
  "11 7 10.1 7 9V8C7 6.9 7.9 6 9 6H11V8M19 13C17.9 13 17 13.9 17 15V16C17 " +
  "17.1 16.1 18 15 18H13V16H15V14C15 12.9 15.9 12 17 12C15.9 12 15 11.1 " +
  "15 10V8H13V6H15C16.1 6 17 6.9 17 8V9C17 10.1 17.9 11 19 11V13Z' />";

// Configure BBcode tags
// For details on the syntax, see
//      https://www.sceditor.com/documentation/custom-bbcodes/
//
//  Implemented tags
//     * [b][/b]:                 emphasize the text
//     * [i][/i]:                 italicize the text
//     * [code][/code]:           print text as code
//     * [list][*][/list]:        create a bullet list
//     * [url][/url]:             create a link
//     * [url=XXX][/url]:         create a link with replacement text
//     * [table][/table]:         create a table
//     * [tr][/tr]:               create a table row
//     * [th][/th]:               create a table header cell
//     * [td][/td]:               create a table cell
//     * [bg=XX][/bg]:            define the background of the current
//                                cell (need [th] or [td] parent)
//     * [codeblock][/codeblock]: print text as code
sceditor.formats.bbcode.set("b", {
  tags: {
    b: null,
    strong: null,
  },
  format: "[b]{0}[/b]",
  html: "<strong>{0}</strong>",
});

sceditor.formats.bbcode.set("i", {
  tags: {
    i: null,
    em: null,
  },
  format: "[i]{0}[/i]",
  html: "<em>{0}</em>",
});

sceditor.formats.bbcode.set("code", {
  // The developer of sceditor decided to hard-code the behavior of
  // code tags…
  // We cannot use it anymore!
  // instead use span.code
  // bootstrap CSS was modified accordingly
  tags: {
    span: { class: ["code"] },
  },
  isInline: true,
  format: "[code]{0}[/code]",
  html: '<span class="code">{0}</span>',
});

sceditor.formats.bbcode.set("list", {
  tags: {
    ul: null,
  },
  breakStart: true,
  isInline: false,
  skipLastLineBreak: true,
  format: "[list]{0}[/list]",
  html: "<ul>{0}</ul>",
});

sceditor.formats.bbcode.set("*", {
  tags: {
    li: null,
  },
  isInline: false,
  closedBy: ["/list", "*"],
  excludeClosing: true,
  format: "[*]{0}",
  html: "<li>{0}</li>",
});

sceditor.formats.bbcode.set("url", {
  tags: {
    a: {
      href: null,
    },
  },
  quoteType: sceditor.BBCodeParser.QuoteType.never,
  format: function (element, content) {
    var url = sceditor.dom.attr(element, "href");

    // If the link and the content are the same,
    // we use the [url]link[/url] tag
    // else, we use the [url=link]content[/url]
    if (url === content) {
      return "[url]" + url + "[/url]";
    } else {
      return "[url=" + url + "]" + content + "[/url]";
    }
  },
  html: function (token, attrs, content) {
    url = sceditor.escapeEntities(attrs.defaultattr, true) || content;

    return (
      '<a href="' + sceditor.escapeUriScheme(url) + '">' + content + "</a>"
    );
  },
});

sceditor.formats.bbcode.set("table", {
  tags: {
    table: null,
  },
  isInline: false,
  //isHtmlInline: true,

  breakBefore: false,
  breakStart: false,
  breakEnd: false,
  breakAfter: false,
  skipLastLineBreak: true,

  allowedChildren: ["tr"],
  format: "[table]{0}[/table]",
  //html: "<table class='table table-striped'>{0}</table>"
  html: function (token, attrs, content) {
    // the developer of sceditor has decided to automatically add
    // newlines when converting to BBCode and completely ignore
    // allowedChildren for non-tags: it just add anything which is
    // not allowed, as text…
    // Thus, conversion between HTML & BBCode adds plenty of newlines
    // which must be deleted
    content = content.replace(/<\/tr>.*?<tr>/gm, "</tr><tr>");
    return "<table class='table table-striped'>" + content + "</table>";
  },
});

sceditor.formats.bbcode.set("tr", {
  tags: {
    tr: null,
  },
  isInline: false,

  breakBefore: false,
  breakStart: false,
  breakEnd: false,
  breakAfter: false,
  skipLastLineBreak: true,
  allowedChildren: ["th", "td"],
  format: "[tr]{0}[/tr]",
  //html: '<tr>{0}</tr>'
  html: function (token, attrs, content) {
    // the developer of sceditor has decided to automatically add
    // newlines when converting to BBCode and completely ignore
    // allowedChildren for non-tags: it just add anything which is
    // not allowed, as text…
    // Thus, conversion between HTML & BBCode adds plenty of newlines
    // which must be deleted
    content = content.replace(/(<\/t[hd]>).*?(<t[hd][ >])/gm, "$1$2");
    return "<tr>" + content + "</tr>";
  },
});

sceditor.formats.bbcode.set("th", {
  tags: {
    th: null,
  },
  allowsEmpty: true,
  isInline: false,

  breakBefore: false,
  breakStart: false,
  breakEnd: false,
  breakAfter: false,
  skipLastLineBreak: true,
  quoteType: sceditor.BBCodeParser.QuoteType.never,
  format: function (element, content) {
    var colspan = sceditor.dom.attr(element, "colspan");

    if (typeof colspan === "number" && colspan > 1) {
      return "[th=" + colspan + "]" + content + "[/th]";
    } else {
      return "[th]" + content + "[/th]";
    }
  },
  html: function (token, attrs, content) {
    var colspan = parseInt(attrs.defaultattr || 1);

    if (colspan > 1)
      return '<th colspan="' + colspan + '">' + content + "</th>";
    else return "<th>" + content + "</th>";
  },
});

sceditor.formats.bbcode.set("td", {
  tags: {
    td: null,
  },
  allowsEmpty: true,
  isInline: false,

  breakBefore: false,
  breakStart: false,
  breakEnd: false,
  breakAfter: false,
  skipLastLineBreak: true,
  quoteType: sceditor.BBCodeParser.QuoteType.never,
  format: function (element, content) {
    var colspan = sceditor.dom.attr(element, "colspan");
    // ensure colspan is transformed to number
    if (colspan !== null) colspan = parseInt(colspan);

    if (typeof colspan === "number" && colspan > 1) {
      return "[td=" + colspan + "]" + content + "[/td]";
    } else {
      return "[td]" + content + "[/td]";
    }
  },
  html: function (token, attrs, content) {
    var colspan = parseInt(attrs.defaultattr || 1);

    if (colspan > 1)
      return '<td colspan="' + colspan + '">' + content + "</td>";
    else return "<td>" + content + "</td>";
  },
});

sceditor.formats.bbcode.set("bg", {});

sceditor.formats.bbcode.set("codeblock", {
  tags: {
    pre: { class: ["pre-scrollable"] },
  },
  isInline: false,
  allowedChildren: ["#", "#newline"],
  format: "[codeblock]{0}[/codeblock]",
  html: '<pre class="pre-scrollable">{0}</pre>',
});

// Remove all handlers we dont want
to_remove = [
  "u",
  "s",
  "sub",
  "sup",
  "font",
  "size",
  "color",
  "ul",
  "ol",
  "li",
  "emoticon",
  "hr",
  "img",
  "email",
  "quote",
  "left",
  "center",
  "right",
  "justify",
  "youtube",
  "rtl",
  "ltr",
];
to_remove.forEach(function (v) {
  sceditor.formats.bbcode.remove(v);
});

// Configure a new custom format for BBCode to handle [[ and ]]
// It relies on the already existing format to do the heavy lifting

// Save the previous format
sceditor.formats["_bbcode"] = sceditor.formats["bbcode"];

// Create the new custom format which wraps the old one
sceditor.formats["bbcode"] = function () {
  var bbcode;

  this.init = function () {
    // create a ref to the old formatter
    bbcode = new sceditor.formats["_bbcode"]();
    if ("init" in bbcode) bbcode.init.call(this);
  };

  this.onReady = function () {
    // nothing special to do
    if ("onReady" in bbcode) bbcode.onReady.call(this);
  };

  /*
   * All functions to convert between BBCode & HTML
   *
   * To handle [[ and ]] without them being parsed by the
   * original bbcode parser, we replace them with non-bbcode structure
   *
   * When [[ or ]] are next to a tag, it may causes issues. The following
   * cases may happen:
   *      [[[tag]content[/tag]
   *        [tag]content[/tag][[
   *      ]][tag]content[/tag]
   *        [tag]content[/tag]]]
   *
   * If we repalce the first occurence of [[ or ]], it would works in all
   * 3 first cases.
   * However, the last case would be replaced with
   *        [tag]content[/tagREPLACEMENT]
   *
   * To prent that, substitution is performed in the reverse order for ]]
   * NOTE: BRACKET_OPEN and BRACKET_CLOSE are palindromes for that purpose
   */
  const BRACKET_OPEN = "#=#=OPENING_GNINEPO=#=#";
  const BRACKET_CLOSE = "#=#=CLOSING_GNISOLC=#=#";
  const BRACKET_OPEN_R = new RegExp(BRACKET_OPEN, "g");
  const BRACKET_CLOSE_R = new RegExp(BRACKET_CLOSE, "g");

  function reverse(str) {
    return str.split("").reverse().join("");
  }

  // functions to unify conversions for whole text or just fragments
  function toSource(converter, html, context, parent) {
    // Convert single square brackets to the escape structure
    html = html.replace(/\[/g, BRACKET_OPEN);
    html = html.replace(/\]/g, BRACKET_CLOSE);

    // Call the real formatter
    var ret = converter(html, context, parent);

    // re-interprete the escape structures
    ret = ret.replace(BRACKET_OPEN_R, "[[");
    ret = ret.replace(BRACKET_CLOSE_R, "]]");
    return ret;
  }
  function toHtml(converter, source) {
    // Convert single square brackets to the escape structure
    source = source.replace(/\[\[/g, BRACKET_OPEN);
    source = reverse(reverse(source).replace(/\]\]/g, BRACKET_CLOSE));

    // Call the real formatter
    var ret = converter(source);

    // re-interprete the escape structures
    ret = ret.replace(BRACKET_OPEN_R, "[");
    ret = ret.replace(BRACKET_CLOSE_R, "]");
    return ret;
  }

  // All four external interfaces
  this.toSource = function (html, context) {
    return toSource(bbcode.toSource, html, context);
  };

  this.toHtml = function (source) {
    return toHtml(bbcode.toHtml, source);
  };

  this.fragmentToSource = function (html, context, parent) {
    return toSource(bbcode.fragmentToSource, html, context, parent);
  };

  this.fragmentToHtml = function (source) {
    return toHtml(bbcode.fragmentToHtml, source);
  };
};
