# Fonctionnement du moteur

Le fonctionnement du moteur, développé en python, peut se découper en trois
phases distinctes :

- La conversion de l’extraction en dictionnaires ;
- Le filtrage des données brutes de l’extraction avec le guide d’audit ;
- La génération du rapport.

Le schéma ci-dessous représente ces trois phases :

![Fonctionnement du moteur](assets/fonctionnement_moteur.png)

Le moteur python a donc :

- Deux entrées : le guide sous format JSON et l’extraction de la
  configuration ;
- Une sortie : le rapport de revue de configuration.

## Conversion de l’extraction en dictionnaires

Cette étape correspond à l’analyse du fichier d’extraction de la configuration.

Des titres de différents niveaux sont présents dans ce fichier :

- Titre de niveau 1 : `==== Titre macro ====`
- Titre de niveau 2 : `--=== Titre partie ===--`
- Titre de niveau 3 : `-- Titre sous partie --`

Ces séparations sont nécessaires si l’auditeur souhaite lire le fichier obtenu
suite à l’extraction. Ces titres en simplifient la lecture.

Le moteur python va donc analyser ce fichier et créer des entrées dans un objet
python `engine.core.extracts.Extracts` (héritant de `dict`). Chaque entrée
contiendra l’ensemble des données de la section, y compris celles présentes
dans des sous-sections.

Par exemple, le fichier d’extraction suivant :

```
===== Titre niveau 1 =====
--=== Titre niveau 2 ===--
-- Titre niveau 3 --
Contenu A

--=== Second titre niveau 2 ===--
Contenu B
```

sera transformé dans le dictionnaire :

```python
{
    "Titre niveau 1": """
--=== Titre niveau 2 ===--
-- Titre niveau 3 --
Contenu A
""",

    "Titre niveau 2": """
-- Titre niveau 3 --
Contenu A
""",

    "Titre niveau 3": """
Contenu A
""",

    "Second titre niveau 2": """
Contenu B
"""
}
```

Ce découpage permet ensuite aux filtres de prendre en entrée une section
entière et de faire le découpage des sous-sections directement dans le filtre.
Il est ainsi possible de récupérer le résultat de plusieurs commandes et de les
corréler au sein d’un même filtre.

Par ailleurs, le dictionnaire généré contient une entrée spéciale, `ALL`, qui
contient l’ensemble du fichier d’extraction, sans découpage. Cette entrée doit
notamment être utilisée pour les technologies pour lesquelles le moteur
s’appuie sur des fonctions d’extraction de l’équipement. Les fichiers
d’extraction ne contiendront alors pas de titre.

À ce stade, le moteur dispose donc de l’ensemble des blocs d’extraction sous
forme de dictionnaires identifiables par leur titre.

## Filtrage des données brutes de l’extraction avec le guide d’audit

Cette étape du moteur consiste à :

1. Lire le fichier guide JSON initial ;
2. Identifier chaque bloc d’extraction nécessaire à chaque partie du guide
   d’audit (fichier JSON) ;
3. Compléter le guide d’audit avec les blocs identifiés à l’aide du
   dictionnaire python généré par l’analyse du fichier d’extraction.

En effet, un champ `extract` est présent au sein du guide JSON et permet de
notifier quelle section de l’extraction est nécessaire en spécifiant le
`titre`.

Les champs `cmd` et `filter` sont également présents :

- Le champ `cmd` renseigne la (ou les) commande(s) utilisée(s) pour obtenir le
  bloc d’extraction.
- Le champ filtre permet de faire appel au catalogue de filtre de la
  technologie afin de mettre en forme l’extraction.

Le filtre spécifié est appelé en lui passant en argument la section de
l’extraction donnée par `title`. L’extraction est passé sous forme de suite
d’octets (le type `bytes` en python3). Il est donc nécessaire de le décoder
dans le bon encodage de texte. Cela permet notamment d’extraire des données
binaires et des fichiers avec des encodages non UTF-8.

Le résultat des filtres est stocké dans le guide d’audit. Il est important que
les résultats des filtres soient agnostiques au format de sortie. Un langage
intermédiaire, basé sur BBCode a donc été développé.

## Génération du rapport

Cette partie du moteur consiste à utiliser le guide JSON complété par les blocs
d’extraction filtrés lors de l’étape précédente. Cette structure JSON complète
associée à des générateurs permettent d’obtenir de manière simple, une
interface comprenant l’ensemble des données de la revue de configuration.

Il existe plusieurs modèles différents. Ils vont transformer le langage interne
de formatage (le BBCode), en le bon format.
