# Comment ajouter une nouvelle technologie ?

## Démarche générale

Afin d’ajouter le support d’une nouvelle technologie, il suffit de créer :

- Le [script d’extraction][script] de la configuration ;
- Le [guide d’audit][guide] ;
- Les [filtres d’analyse][filtres] de la configuration.

## Script d’extraction

Il est nécessaire de développer un script d’extraction qui récupérera
l’ensemble des données à auditer au sein d’un unique fichier.

Pour séparer les différentes extractions, il est nécessaire de les organiser au
sein d’une structure à trois niveaux.

Chaque niveau doit être introduit par l’en-tête approprié :

- Titre de niveau 1 : `==== Titre macro ====`
- Titre de niveau 2 : `--=== Titre partie ===--`
- Titre de niveau 3 : `-- Titre sous partie --`

Un dernier niveau peut être utilisé, pour séparer des entrées au niveau du
filtre, mais pas du moteur. Il doit utiliser le format : `## Titre ##`.

Pour permettre des tests sur le moteur, il est **fortement** recommandé de
mettre dans le dossier `tests/generation/extractions/` le résultat du script
d’extraction. La structure attendue de ce dossier est la suivante :

```
tests/generation/extractions/
 `--- nom de la technologie
       `---- extraction 1
       `---- extraction 2
```

## Ajout de la technologie au moteur

Les différents types de technologies pris en charge sont regroupés dans le
dossier `engine/techs`. Pour chaque technologie supportée par le moteur, on
retrouve les deux éléments suivants :

- Un fichier Python contenant les filtres utilisés par le guide (généralement
  nommé selon la technologie) ;
- Un fichier JSON contenant le guide d’audit (généralement nommé selon la
  technologie) ;

Pour éviter des fichiers de filtres extrêmement long, il est conseillé de ne
pas utiliser le fichier de filtre tel-quel, mais d’utiliser un _package_
python. Il suffit alors de créer un dossier du nom de la technologie et
s’assurer que la classe implémentant la technologie est chargée par le fichier
`engine/techs/techno/__init__.py`.

### Fichier guide techno.json :

Ce fichier est une retranscription au format JSON du guide de revue de
configuration correspondant à la technologie. Il définit :

- la structure du rapport généré en sections et sous-section ;
- des indications pour aider les auditeurs à effectuer l’analyse de la
  configuration ;
- des recommandations à suivre sur les analyses ;
- les extractions à inclure et filtrer dans le rapport.

Une interface Web est disponible dans `docs/editor/editor.html` afin de
simplifier l’opération de création de ce fichier. Il s’agit d’un fichier
statique qui peut être ouvert directement dans un navigateur.

Pour créer le fichier manuellement, il est possible de s’appuyer sur le modèle
[techno.json](docs/templates/techno.json). Il est composé ainsi :

```JSON
[
    {
        "title": "Titre de la partie",
        "desc": "Description permettant d’introduire cette partie",
        "content": [
            {
                "title": "Titre de la sous-partie",
                "desc": "Description permettant d'expliquer la pertinence de ce contrôle",
                "extract": [
                    {
                        "title": "titre-de-l'extract-dans-le-fichier-d'extraction",
                        "cmd": "Commande utilisée pour obtenir ce bloc d'extraction",
                        "filter": "Nom du filtre tel que listé dans le dictionnaire dict_filters du fichier .py regroupant les filtres"
                    }
                ]
                "analyze": "Explications sur la façon d’analyser les extracts",
                "rec": "Recommandations associées",
            }
        ]
    }
]
```

Le JSON définit donc un tableau de dictionnaire. Chaque élément de ce tableau
racine est une section de niveau 1. La section est nommée par un `title`, et
peut être complétée par une `desc`-cription qui a pour but de l’introduire. La
section contient un dernier attribut particulier : `content`. Il s’agit d’un
tableau qui liste toutes les sous-sections.

Les sous-sections sont elles-mêmes nommées par un `title`, elles peuvent être
décrites par une `desc` et elles contiennent enfin une `analyze` et une
`rec`-ommandation. La partie `analyze` est censée être utilisée pour décrire la
manière dont les extractions doivent être analysées, ainsi que les points de
contrôle. La partie `rec` contient les recommandations relatives aux différents
points de contrôle. Elle peut donner :

- Les bonnes pratiques de sécurité ;
- Les valeurs recommandées de certains paramètres de configuration ;
- Des phrases types qui peuvent être copiées dans le rapport final par un
  auditeur. Les sous-sections contiennent enfin un attribut particulier,
  `extract`, qui est un tableau qui liste l’ensemble des extractions.

Chaque extraction est décrite par un dictionnaire contenant les trois attributs
suivants :

- `title` qui est le nom de l’extract à insérer/traiter ;
- `cmd` qui documente la commande qui a été utilisée pour faire l’extraction ;
- `filter` qui est le nom du filtre à utiliser pour extraire et formater
  l’extraction (voir [la section sur les filtres][filtres] pour plus de
  détails).

De plus, les éléments suivants peuvent contenir des éléments de formatage :

- `desc` (sur les deux niveaux de titre)
- `analyze`
- `rec`

Pour que le formatage soit agnostique du format de sortie, un langage
intermédiaire dédié a été développé. Une [section dédiée][bbcode] décrit le
langage. Par ailleurs, l’éditeur Web du dossier `docs/editor` supporte des
zones de texte améliorées, qui génère le formatage dans ce langage.

Afin de faciliter l’utilisation du rapport dans une revue de configuration, il
est fortement souhaitable que l’organisation du JSON corresponde au maximum à
celle des rapports finaux de revue de configuration.

### Fichier filtres techno.py :

Ce fichier regroupe les filtres Python utilisés pour réaliser des opérations
sur les blocs d’extraction (par exemple, transformer un bloc de texte brut en
tableau).

Ce fichier doit implémenter une classe qui hérite de
`engine.core.technology.Technology`. La classe doit posséder, en attribut de
classe, un `dict` nommé `desc` qui définit :

- Le nom de la technologie (clé `name`) ;
- Le chemin du fichier guide techno.json, relativement au répertoire
  `engine/techs/` (clé `layout`).

Toutes les méthodes de cette classe peuvent être utilisées comme filtre. Il est
conseillé de découper la classe en deux parties :

- Fonctions dites « snippets » : ces fonctions « de base » sont utilisées par
  les fonctions filtres. Ces fonctions sont généralement indépendantes du
  filtre et permettent de centraliser certaines fonctionnalités.

- Fonctions « filtres » : ces fonctions sont les filtres implémentant les
  opérations effectuées sur les blocs d’extraction. Ces opérations étant
  souvent dépendantes du format des fichiers de configuration, les filtres
  correspondants doivent être adaptés d’une technologie à une autre.

Par ailleurs, de nombreuses fonctions sont indépendantes des technologies. Ces
fonctions sont implémentées dans le fichier `engine/techs/common.py`. Les
fonctions qui y sont implémentées peuvent être réutilisées telle-quelle. Il
s’agit par exemple de fonctions pour analyser simplement les fichiers INI, ou
encore pour transformer un tableau python en tableau affichable dans le
[langage intermédiaire][bbcode].

Lors de la génération du rapport, pour chaque extraction définie dans le
fichier JSON, la fonction de filtre de l’extraction est appelée avec le contenu
de l’extraction en paramètre. Par exemple, prenons la définition de
l’extraction suivante :

```JSON
{
    "titre": "Liste des comptes et des groupes",
    "cmd": "getent passwd\ngetent shadow\ngetent group\ngetent gshadow",
    "filtre": "etc_passwd_users"
}
```

La méthode `etc_passwd_users` de la classe sera appelée avec le contenu de la
section « Liste des comptes et des groupes ». Elle doit donc être définie par
l’un des trois niveaux de titre dans la sortie du script d’extraction.

Il est important de noter que le contenu de la section passé en argument du
filtre est sous forme de suite d’octets (le type `bytes` en python3). Il est
donc nécessaire de le décoder dans le bon encodage de texte. Cela permet
notamment d’extraire des données binaires et des fichiers avec des encodages
non UTF-8. Pour cela, des décorateurs python ont été créés pour faciliter le
décodage, pour les filtres en ayant besoin. Ils sont définis dans le fichier
`engine/techs/common.py`. Pour décoder automatiquement l’extract, il suffit de
définir le filtre comme cela :

```python
@decode("utf-8")
def default(self, extract):
    return extract
```

Lorsque la technologie a besoin de faire référence à une autre section que
celle analysée (pour faire de l’enrichissement ou de la corrélation, par
exemple), il est possible d’y accéder au travers de l’attribut `self.extracts`
qui contient une instance de `engine.core.extracts.Extracts`. Il suffit par
exemple récupérer la section de cette manière :

```
def myfilter(self, extract):
    # Do something
    other_extract = self.extracts["Section name"]
```

Chaque filtre doit retourner du texte dans le [langage intermédiaire][bbcode].
Il sera interprété ensuite lors de la génération du rapport pour effectuer le
formatage. Au sein des filtres (et de tout code python, en général), il est
nécessaire d’utiliser la classe `Markup` pour spécifier qu’un texte contient du
code dans le langage intermédiaire. Si un texte n’est pas marqué comme sûr,
grâce à cette classe, il sera automatiquement échappé et il s’affichera
tel-quel.

Dans le cas où l’utilisation des sections n’est pas possible, par exemple parce
que la configuration est extraite par les fonctions de l’équipement, il reste
possible de faire appel au titre spécial `ALL`. La section nommée `ALL`
contient en réalité l’ensemble du fichier d’entrée.

Le fichier [techno.py](docs/templates/techno.py) devrait être utilisé comme
modèle pour implémenter de nouveaux filtres.

Pour être en mesure de reprendre et améliorer le moteur et les filtres,
quelques règles de développement doivent être suivies :

- Il est important de **commenter le code**. Une bonne proportion est 1/3 de
  commentaires pour 2/3 de code
- Les fonctions doivent être **documentées**. Python possède un mécanisme de
  _docstring_ qui doit être mis à profit.
- Le style de codage python doit être compatible avec la [PEP8][pep8] et la
  [PEP257][pep257]. Parmi les règles les plus importantes :
  - Les noms de variables et de fonctions doivent être **explicits** ;
  - L’indentation doit utiliser 4 espaces ;
  - Les lignes des fichiers python ne doivent pas dépasser 79 caractères ;
  - Les _docstring_ ne doivent pas dépasser 72 caractères ;
  - Les _docstring_ doivent décrire la fonction, ses paramètres et sa sortie.

## Vérifier le fonctionnement

Une fois la technologie ajoutée, il est important de vérifier son
fonctionnement. Pour cela, il est conseillé d’ajouter les sorties des scripts
d’extraction dans le dossier `tests/generation/extractions`, comme précisé
[ici][script].

Un script de tests unitaires est fourni et permet de valider que le rapport est
généré sans erreur.

:warning:**Attention, il ne vérifie pas que le rapport généré soit correct**,
seulement qu’aucune erreur ne survienne lors de la génération du rapport. Le
contenu du rapport généré doit être vérifié manuellement.

Pour lancer le script de test, il suffit d’exécuter :

```shell
pip install -r requirements-dev.txt
tox
```

Il est nécessaire que **le script de test unitaire réussisse** avant de faire
une _merge request_ sur GitLab. Si le script échoue, la _merge request_ ne
pourra être acceptée par les mainteneurs du moteur.

## Langage intermédiaire

Le langage intermédiaire qui peut être utilisé dans le fichier de guide et dans
les retours des fonctions de filtre est un langage basé sur BBCode. Il en
implémente une sous-partie et l’étend avec des balises supplémentaires.

### Balises supportées

Les balises suivantes sont supportées dans le langage intermédiaire :

|          Balise           | Description                                                                                                     | Exemple                                                                                                                                                | Rendu                                                                            |
| :-----------------------: | :-------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------- |
|         \[b]\[/b]         | Met un texte en valeur                                                                                          | `texte [b]en valeur[/b]`                                                                                                                               | texte **en valeur**                                                              |
|         \[i]\[/i]         | Met un texte en italique                                                                                        | `texte [i]en italique[/i]`                                                                                                                             | texte _en italique_                                                              |
|      \[code]\[/code]      | Affiche du texte comme du code en ligne                                                                         | `morceau de [code]code[/code]`                                                                                                                         | morceau de `code`                                                                |
| \[codeblock]\[/codeblock] | Affiche du texte comme un bloc de code                                                                          | `[codeblock]mon bloc de code[/codeblock]`                                                                                                              | <pre>mon bloc de code</pre>                                                      |
|   \[list]\[\*]\[/list]    | Crée un list à point                                                                                            | `[list][*] Liste à [*] points[/list]`                                                                                                                  | <ul><li>Liste à</li><li>points</li></ul>                                         |
|       \[url]\[/url]       | Crée un lien hypertexte qui affichera le lien                                                                   | `[url]https://poolailler1.domain.loc/gitlab/[/url]`                                                                                                    | [https://poolailler1.domain.loc/gitlab/](https://poolailler1.domain.loc/gitlab/) |
|     \[url=XXX]\[/url]     | Crée un lien hypertexte qui affichera un texte de substitution                                                  | `[url=https://poolailler1.domain.loc/gitlab/]Texte à afficher[/url]`                                                                                   | [Texte à afficher](https://poolailler1.domain.loc/gitlab/)                       |
|     \[table]\[/table]     | Crée un tableau                                                                                                 | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[tr]\[/tr]        | Crée une nouvelle ligne dans un tableau                                                                         | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[td]\[/td]        | Crée une cellule dans une ligne. La balise peut prendre en argument un nombre, utilisé comme `colspan`          | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[th]\[/th]        | Crée une cellule d’entête dans une ligne. La balise peut prendre en argument un nombre, utilisé comme `colspan` | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|       \[bg=XXX]\[/]       | Change la couleur de l’arrière-plan d’une cellule                                                               | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|    \[title\]\[/title\]    | Ajoute une légende à un tableau. Doit être utilisé entre les balises \[table\]                                  | `[table][title]Mon tableau[/title][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]` |

Lorsqu’un texte contient les caractères `[` et `]`, et qu’ils ne doivent pas
être interprétés, il est nécessaire de les **échapper**. Pour cela, il suffit
de doubler les caractères :

- `[[` sera traité comme `[` ;
- `]]` sera traité comme `]`.

### L’objet Markup

Dans les filtres, il est possible de retourner du texte formaté dans le langage
intermédiaire. Il est toutefois nécessaire de spécifier les sections de texte
qui doivent être interprétées comme un langage intermédiaire, et celles qui
doivent être échappées (notamment ce qui provient des extraits de
configuration).

Pour cela, la classe `Markup` a été créée dans le _package_ `engine.bbcode`. Il
est possible de l’importer avec la ligne suivante :

```python
from engine.bbcode import Markup as M
```

Toute chaine de caractère passée au constructeur de la classe, sera considérée
comme sûr pour être interprétée en tant que langage intermédiaire.

Par exemple, le code :

```python
M("Du texte en [b]gras[/b]")
```

sera rendu comme : « Du texte en **gras** ».

Au contraire, si le texte n’est pas passé au constructeur de `Markup`, il sera
rendu tel-quel : « Du texte en [b]gras[/b] ».

L’objet `Markup` ainsi instancié peut-être traité comme une chaine de
caractères, et en possède les mêmes méthodes :

```python
M("Texte avec des [b]balises[/b]") + " et d’autres sans [ ou ]" == M("Texte avec des [b]balises[/b] et d’autres sans [[ ou ]]")
M("Texte en [b]%s[/b]") % "gras, même avec des [balises]" == M("Texte en [b]gras, même avec des [[balises]][/b]")
M("Marche aussi avec [b]{}[/b]").format("format") == M("Marche aussi avec [b]format[/b]")
M("[list][*]") + M("[*]").join(["Liste à", "points"]) + M("[/list]") == M("[list][*]Liste à[*]point[/list]")
M("\n").join([M("[*] Liste à"), "points avec des caractères échappés []"]) == M("[*]Liste à\npoint avec des caractères échappés [[]]")
```

[script]: #script-dextraction
[guide]: #fichier-guide-technojson-
[filtres]: #fichier-filtres-technopy-
[bbcode]: #langage-intermédiaire
[rendered_table]: assets/rendered_table.png
[pep8]: https://www.python.org/dev/peps/pep-0008/
[pep257]: https://www.python.org/dev/peps/pep-0257/
[lint]: https://jsonlint.com/
