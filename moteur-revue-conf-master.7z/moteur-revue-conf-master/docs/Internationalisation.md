# Comment ajouter une nouvelle langue sur une techno ?

## Démarche générale

Afin d'ajouter une nouvelle langue pour toutes les technologies, il est
nécessaire de créer dans l'ordre:

- Réaliser la procédure de traduction I18N
- Créer les fichiers de template Jinja

## Procédure I18N

Dans le cas où cette langue n'a jamais été utilisée auparavant au sein du
moteur. Il est nécessaire de créer le dossier de celle-ci dans le répertoire
_/locales/_.

La structure attendue de ce dossier est la suivante :

```
locales/
 `--- en/LC_MESSAGES/
 `--- fr/LC_MESSAGES/
 `--- Abréviation de la langue/LC_MESSAGES/
```

Exemple :

Je souhaite rajouter l'Italien comme langue prise en charge au sein du moteur.
Je remarque que cette langue n'a jamais été pris en charge au sein du moteur
pour n'importe quelle technologie. Je crée donc le dossier **it/LC_MESSAGES**
dans le répertoire _/locales/_ :

```
locales/
 `--- en/LC_MESSAGES/
 `--- fr/LC_MESSAGES/
 `--- it/LC_MESSAGES/
```

Puis dans une console bash, lancer le script **translation.sh** :

- Extraire les chaînes à traduire

```
./translation.sh extract
```

- Créer le fichier de traduction et le remplir des chaînes nécessitant une
  traduction

```
./translation.sh translate windows <abréviation langue>
```

- Compiler le fichier de traduction

```
./translation.sh compile
```

La procédure I18N est maintenant terminée et vous pouvez passer à la création
du template Jinja. **Attention** : lancer le moteur avec la nouvelle langue et
en n'ayant fait que la procédure I18N le fera crasher !

## Créer les templates Jinja

Il est nécessaire de prendre un des templates jinja existants pour ensuite
traduire tout le texte dans la langue voulue.

Dans le cas où cette langue n'a jamais été utilisé auparavant au sein du
moteur. Il est nécessaire de créer le dossier de celle-ci dans le répertoire
_/engine/templates/(techno)/_ avec (techno) la technologie dont nous voulons
rajouter une langue.

La structure attendue de ce dossier est la suivante :

```
/engine/templates/(techno)/
 `--- en
 `--- fr
 `--- Abréviation de la langue
```

Exemple :

Je souhaite rajouter l'Italien comme langue prise en charge au sein du moteur.

Je remarque que cette langue n'a jamais été pris en charge au sein du moteur
pour n'importe quelle technologie.

Je crée donc le dossier **it** dans le répertoire _/engine/templates/(techno)/_
:

```
/engine/templates/(techno)/
 `--- en
 `--- fr
 `--- it
```

Puis dans un second temps, il est nécessaire de reprendre la même architecture
de dossier et de fichier que dans les autres langues.

**Attention**: Le nommage des dossiers et des fichiers doit rester le même

**Astuce**: Copier/Coller le dossier _en_ et le renommer dans la langue
choisis.

Enfin, il est nécessaire de traduire tout le contenu des fichiers _.jinja_ dans
la langue désirée. L'encodage utilisé par le moteur est **UTF_8**.

Un langage intermédiaire (type bbcode) est utilisé par le moteur pour le rendu
du rapport. Il est donc impératif de faire attention à ne pas **supprimer** les
balises.

### Liste des balises Bbcode

|          Balise           | Description                                                                                                     | Exemple                                                                                                                                                | Rendu                                                                            |
| :-----------------------: | :-------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------- |
|         \[b]\[/b]         | Met un texte en valeur                                                                                          | `texte [b]en valeur[/b]`                                                                                                                               | texte **en valeur**                                                              |
|         \[i]\[/i]         | Met un texte en italique                                                                                        | `texte [i]en italique[/i]`                                                                                                                             | texte _en italique_                                                              |
|      \[code]\[/code]      | Affiche du texte comme du code en ligne                                                                         | `morceau de [code]code[/code]`                                                                                                                         | morceau de `code`                                                                |
| \[codeblock]\[/codeblock] | Affiche du texte comme un bloc de code                                                                          | `[codeblock]mon bloc de code[/codeblock]`                                                                                                              | <pre>mon bloc de code</pre>                                                      |
|   \[list]\[\*]\[/list]    | Crée un list à point                                                                                            | `[list][*] Liste à [*] points[/list]`                                                                                                                  | <ul><li>Liste à</li><li>points</li></ul>                                         |
|       \[url]\[/url]       | Crée un lien hypertexte qui affichera le lien                                                                   | `[url]https://poolailler1.domain.loc/gitlab/[/url]`                                                                                                    | [https://poolailler1.domain.loc/gitlab/](https://poolailler1.domain.loc/gitlab/) |
|     \[url=XXX]\[/url]     | Crée un lien hypertexte qui affichera un texte de substitution                                                  | `[url=https://poolailler1.domain.loc/gitlab/]Texte à afficher[/url]`                                                                                   | [Texte à afficher](https://poolailler1.domain.loc/gitlab/)                       |
|     \[table]\[/table]     | Crée un tableau                                                                                                 | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[tr]\[/tr]        | Crée une nouvelle ligne dans un tableau                                                                         | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[td]\[/td]        | Crée une cellule dans une ligne. La balise peut prendre en argument un nombre, utilisé comme `colspan`          | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|        \[th]\[/th]        | Crée une cellule d’entête dans une ligne. La balise peut prendre en argument un nombre, utilisé comme `colspan` | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|       \[bg=XXX]\[/]       | Change la couleur de l’arrière-plan d’une cellule                                                               | `[table][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]`                           | ![Rendered table][rendered_table]                                                |
|    \[title\]\[/title\]    | Ajoute une légende à un tableau. Dois être utilisé entre les balises \[table\]                                  | `[table][title]Mon tableau[/title][tr][th]th1[/th][th]th2[/th][/tr][tr][td]td11[/td][td][bg=c63939]td12[/bg][/td][/tr][tr][td=2]td2[/td][/tr][/table]` |
|       \[section=\]        | crée un titre de section                                                                                        |

Lorsqu’un texte contient les caractères `[` et `]`, et qu’ils ne doivent pas
être interprétés, il est nécessaire de les **échapper**. Pour cela, il suffit
de doubler les caractères :

- `[[` sera traité comme `[` ;
- `]]` sera traité comme `]`.

De même, il est important à ne pas modifier les appels de fonctions de la
technologie. Celles-ci apparaissent de la manière suivante au sein du template
jinja :

```
% call(tech) common.review(techs) %}
{{ common.oldstyle_review(tech, 'function', 'title') }}
{% endcall %}
```

Enfin, veuillez ajouter le template jinja principal (ici _full.jinja_) au sein
de la description de la technologie :

Dans le fichier _/engine/techs/(techno)/filters.py/_ avec (techno) la
technologie dont nous voulons rajouter une langue:

```
    desc = {
        "name": "(techno)",
        "templates": {
            "full": {
                "fr": "(techno)/fr/full.jinja",
                "en": "(techno)/en/full.jinja",
                "<abréviation langue>": "(techno)/<abréviation langue>/full.jinja"
            },
        },
        "default language": "fr",
        "default template": "full",
    }

```

Ainsi, la technologie possède maintenant la nouvelle langue ajoutée dans sa
liste de template disponible.
