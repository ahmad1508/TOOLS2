# Fonctionnement du moteur

Cette partie est destinée à tout auditeur souhaitant utiliser le moteur dans le
cadre d’une revue de configuration.

## TD;DR

Il y a deux étapes à suivre pour utiliser le moteur :

1. Obtenir la configuration à auditer
2. Lancer le moteur sur ce fichier. La commande suivante peut être utilisée :

```shell
./moteur.py --type linux --input config.txt --output rapport.docx --format docx
```

## Comment obtenir la configuration à auditer

L’extraction de la configuration est propre à chaque technologie à auditer.

Le dossier `scripts`, à la racine du moteur, contient un ensemble de script qui
permettent d’extraire la configuration de certaines technologies. Certains
équipements, notamment les équipements réseau, possèdent déjà des
fonctionnalités d’extraction de la configuration. Aucun script n’est donc
associé à ces équipements.

Pour lancer une extraction de la configuration d’un système Linux, il suffit
par exemple de lancer la commande :

```shell
sudo bash scripts/script_linux.sh
```

## Comment générer le rapport

Le fichier à exécuter pour le moteur se trouve à la racine du projet. Il s’agit
du fichier `moteur.py`. Il peut prendre en entrée 4 arguments :

- `--type` : spécifie la technologie auditée (Linux, Windows, VMware, etc.)

  - Il doit correspondre aux fichiers présents dans le dossier `engine/techs`
  - Il est possible d’en avoir une liste exhaustive en lancant `./moteur.py -h`
  - _Exemple : vmware_

- `--input` : spécifie le chemin vers le fichier contenant l’extraction de
  configuration

  - _Exemple : Wavestone_Audit_VMware.res_

- `--output` : spécifie le chemin du fichier de sortie désiré

  - _Exemple : Rapport_vmware.docx_

- `--format`: spécifie le format du fichier de sortie désiré (html ou docx)
  - Il doit correspondre aux formats présents dans le dossier
    `engine/renderers`
  - Il est possible d’en avoir une liste exhaustive en lancant `./moteur.py -h`
  - Si l’option n’est pas spécifiée, le moteur va tenter de résoudre le
  - format à partir de l’extension du fichier de sortie
  - _Exemple : docx_
