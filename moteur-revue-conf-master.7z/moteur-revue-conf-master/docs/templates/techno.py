# -*- coding: utf-8 -*-

"""Provides filters for MyTech"""

# Project imports
from engine.core import i18n
from engine.core.technology import Technology

# I18N
# TODO: change the domain for translations for something specific
# to your technology
_ = i18n.domain("mytech")._
N_ = i18n.domain("mytech").N_
pgettext = i18n.domain("mytech").pgettext
ngettext = i18n.domain("mytech").ngettext


class MyTech(Technology):
    """MyTech technology class"""

    desc = {
        "name": "mytech",
        "templates": {"full": {"fr": "techno.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    # TODO: either extend the method to parse the input file or
    # delete the function.
    def parse_input(self, extract):
        """Parse the input file.

        This method take the path to a file/folder (or anything else
        which is given in the ``-i`` option). It shuold open the file
        and provide extractions within ``self.extracts``.

        This methods can be extended to change the parsing behavior.
        Defaults behavior is to open as binary file.

        Args:
            extract (str): the file name to be parsed

        """

    # TODO: if needed, add parsing it. Preprocessors will be run before
    # filtering. Also set the hostname attribute within
    def preprocessors(self):
        """Perform preprocessors on extracts.

        This method is used to analyze/parse extracts prior to
        templating filters. This method can store parsed data within
        the ``dict`` :py:attr:`self.artifacts`.

        To be better handle multi-input reviews, this methods should
        also set the :py:attr:`self.hostname` of the reviewed device,
        when possible.

        The default behavior is to do nothing.
        """

    # TODO: Add any additional functions which may be called from
    # within templates
    def my_filter(self):
        """A filter"""
        # A filter should rely on self.extracts and self.artifacts to
        # analyse what it wants.
        # To be able to keep track of findings, in each filter you can
        # use self.findings to state what:
        # - is good, using the method
        #:  self.findings.good(_("Description"))
        # - can be improved, using the method
        #:  self.findings.improvement(_("Description"))
        # - is a vulnerability, using the method
        #:  self.findings.vuln(_("Description"))
