#!/bin/bash

# Generate the translation files for the project
# it supposes gettext is install on the system


#####################################
# Some constants
#####################################

BASE="locales"

# Defines some constants for output coloring
if [ -t 1 ]; then
    RED=$'\x1b[1;31m'
    GREEN=$'\x1b[1;32m'
    BROWN=$'\x1b[1;33m'
    BLUE=$'\x1b[1;34m'
    PURPLE=$'\x1b[1;35m'
    BOLD=$'\x1b[1m'
    UNDER=$'\x1b[4m'
    NOCOL=$'\x1b[0m'
else
    RED=""
    GREEN=""
    BROWN=""
    BLUE=""
    PURPLE=""
    BOLD=""
    UNDER=""
    NOCOL=""
fi

#####################################
# utils functions
#####################################

# function to check whether a program exists
function exists() {
    type "$@" &> /dev/null
    return $?
}

function prechecks() {
    # ensure gettext is install
    if ! exists pybabel; then
        error "Python Babel package does not seem to be installed"
        exit 1
    fi
}

function info() {
    echo "[${BLUE}INFO${NOCOL}] $1"
}
function error() {
    echo "[${RED}ERROR${NOCOL}] $1" >&2
}
function success() {
    echo "[${GREEN}SUCCESS${NOCOL}] $1"
}
function warning() {
    echo "[${PURPLE}WARNING${NOCOL}] $1"
}
function fail() {
    echo "[${BROWN}FAIL${NOCOL}] $1"
}

function xargs0() {
    # Implement a similar interface as xargs -0, capable to call functions
    # Usage: find […] -print0 | xargs command arguments
    local -a args=()
    while IFS= read -r -d '' arg; do
        args=("${args[@]}" "$arg")
    done

    eval "$@" "${args[@]}"
    return $?
}

function print_if_file() {
  # helper to print a file path if it exists
  [[ -f "$1" ]] && echo -n "$1" && echo -ne '\0'
}
function find_if_dir() {
  # helper to find files if first arg is a directory
  [[ -d "$1" ]] && find "$@" -print0
}
function find_tech_files() {
  # find all files associated to a given technology
  local tech="$1"
  # filter files
  print_if_file "engine/techs/$tech.py"
  find_if_dir "engine/techs/$tech/" -name "*.py"
  print_if_file "engine/templates/$tech.bbcode"
  print_if_file "engine/templates/$tech.jinja"
  find_if_dir "engine/templates/$tech/" -name "*.bbcode" -o -name "*.jinja"
}

#####################################
# gettext functions arguments
#####################################

# compute the location of a pot/po/mo file
function pot() {
    local domain="$1"
    echo "$BASE/$domain.pot"
}
function po() {
    local domain="$1"
    local locale="$2"
    echo "$BASE/$locale/LC_MESSAGES/$domain.po"
}
function mo() {
    local domain="$1"
    local locale="$2"
    echo "$BASE/$locale/LC_MESSAGES/$domain.mo"
}

# wrapper to extract all keywords
function extract_pot() {
    local domain="$1"
    shift
    command pybabel extract \
        --no-location \
        --mapping=".babel.conf" \
        \
        --project="Moteur de revue de configuration" \
        --version="" \
        --msgid-bugs-address="#Pool audit" \
        --copyright-holder="Wavestone" \
        \
        --no-default-keywords \
        --keyword="_" \
        --keyword="N_" \
        --keyword="M_" \
        --keyword="gettext" \
        --keyword="dgettext:2" \
        --keyword="ngettext:1,2" \
        --keyword="dngettext:2,3" \
        --keyword="pgettext:1c,2" \
        --keyword="dpgettext:2c,3" \
        --keyword="npgettext:1c,2,3" \
        --keyword="dnpgettext:2c,3,4" \
        --keyword="lgettext" \
        --keyword="ldgettext:2" \
        --keyword="lngettext:1,2" \
        --keyword="ldngettext:2,3" \
        \
        --add-comments=TRANSLATION: \
        --strip-comment-tags \
        \
        -o "$(pot "$domain")" \
        "$@"

    return $?
}

# wrapper around xgettext to do xgettext and check if string was found
function extract_and_check() {
    local domain="$1"
    shift
    extract_pot "$domain" "$@"

    if [[ -f "$(pot "$domain")" ]]; then
        success "Created file ${BOLD}$pot${NOCOL}"
    else
        fail "No translatable strings found for ${BOLD}$domain${NOCOL}"
    fi
}

# wrapper to merge pot into po
function update_po() {
    local domain="$1"
    local locale="$2"
    # merge po in a smart way: do not consider POT-Date a relevant
    # data to update the PO
    # To do it work on a temporary po file
    cp "$(po "$domain" "$locale")" "$(po "$domain.tmp" "$locale")"
    if ! command pybabel update \
        --previous \
        --width 79 \
        -D "$domain" \
        -l "$locale" \
        -i "$(pot "$domain")" \
        -o "$(po "$domain.tmp" "$locale")"; then

        # stop here if update failed
        rm "$(po "$domain.tmp" "$locale")"
        return 1
    fi

    # ensure PO files differ
    if diff -q \
      <(grep -vF 'POT-Creation-Date: ' "$(po "$domain" "$locale")") \
      <(grep -vF 'POT-Creation-Date: ' "$(po "$domain.tmp" "$locale")") \
      &> /dev/null; then
        # Files does not differ
        rm "$(po "$domain.tmp" "$locale")"
    else
        # Files differ
        mv "$(po "$domain.tmp" "$locale")" "$(po "$domain" "$locale")"
    fi

    return $?
}

# wrapper to initialize pot into po
function init_po() {
    local domain="$1"
    local locale="$2"
    command pybabel init \
        --width 79 \
        -D "$domain" \
        -l "$locale" \
        -i "$(pot "$domain")" \
        -o "$(po "$domain" "$locale")"

    return $?
}

# wrapper to compile messages
function compile_mo() {
    command pybabel compile \
        --statistics \
        "$@"

    return $?
}

#####################################
# Functions to handle each actions
#####################################

function usage() {
    cat <<EOF
Usage: $(basename "$0") <action> [options]

Manage translations for the engine. Translations are based on GNU gettext.
The process for translations is simple:
    1. Extract from the sources strings which can be translated. This create
       a POT file in the locales directory.
    2. Create a new translation file or merge an existing one with the latest
       POT file. This create a PO file for the target language.
    3. Translate strings in the PO file.
    4. Generate a machine-understandable translation file from the PO. This
       create a MO file.

${UNDER}Available actions:${NOCOL}
    ${BOLD}extract${NOCOL}
        Extract the translatable strings from the engine sources.

    ${BOLD}translate <domain> <language>${NOCOL}
        Create or merge a translation file for the given domain and language.
        The domain can be "all", "core", "renderers" or a technology name.

    ${BOLD}compile${NOCOL}
        Compile all PO files into the machine-understandable translation

    ${BOLD}help${NOCOL}
        Show this message.

EOF
}

function do_extract() {
    # Generate all pot files
    info "Generating POT file for ${BOLD}core${NOCOL}"
    find engine \( -path engine/techs -o -path engine/renderers \) -prune \
        -o -name '*.py' -print0 | \
        xargs0 extract_and_check core

    # do a similar thing for renderer
    info "Generating POT file for ${BOLD}renderers${NOCOL}"
    find engine/renderers -name '*.py' -print0 | \
        xargs0 extract_and_check renderers

    # do a similar thing for each tech
    for f in engine/techs/*; do
        # extract the tech name from file
        if [[ -f "$f" && "$f" == *.py && "$f" != *"/__init__.py" ]]; then
            tech="$(basename "${f%.py}")"
        elif [[ -d "$f" && -f "$f/__init__.py" ]]; then
            tech="$(basename "$f")"
        else
          continue
        fi
        # generate pot
        info "Generating POT file for ${BOLD}$tech${NOCOL}"
        find_tech_files "$tech" | \
            xargs0 extract_and_check "$tech"
    done
}

function do_translate() {
    # merge or create a new language
    local domain="$1" lang="$2"

    # handle the special domain all
    if [[ "$domain" == "all" ]]; then
        local d
        for f in "$BASE"/*.pot; do
            d="$(basename "${f%.pot}")"
            do_translate "$d" "$lang"
        done
        return
    fi

    # handle the special lang all
    if [[ "$lang" == "all" ]]; then
        local l
        for f in "$BASE"/*/LC_MESSAGES; do
            l="$(basename "$(dirname "$f")")"
            do_translate "$domain" "$l"
        done
        return
    fi

    # check whether pot file exist
    if ! [[ -f "$(pot "$domain")" ]]; then
        error "Could not find a POT file for domain $domain"
        exit 1
    fi

    # check the existence of the language directories
    info "Add translation file for domain $domain and language $lang"
    # either create or update the locale
    if [[ -f "$(po "$domain" "$lang")" ]]; then
        info "Merging $domain PO file with existing"
        if update_po "$domain" "$lang"; then
            success "Merge succeeded"
        else
            fail "Merge failed"
        fi
    else
        info "Creating new $domain PO file"
        init_po "$domain" "$lang"
    fi
}

function do_compile() {
    # compile PO files into MO
    find "$BASE" -type f -a -name "*.po" -print0 | \
        while IFS= read -r -d '' po; do
            domain="${po%.po}"
            info "Compiling ${BOLD}$domain${NOCOL}"
            local output="$(compile_mo -o "$domain.mo" -i "$domain.po" 2>&1)"
            local result="$?"
            echo "$output"
            if [[ "$result" -eq 0 ]]; then
                # check whether all messages have been translated
                if grep -F "0 of 0 messages" &>/dev/null <<<"$output"; then
                  # case of no message
                  # no need to anything
                  :
                elif ! grep -F "100%" &>/dev/null <<<"$output"; then
                  # case of missing translations
                  warning "Not all messages have been translated"
                fi
                success "Created ${BOLD}$domain.mo${NOCOL}"
            else
                fail "Failed compilation"
            fi
        done
}

# change the directory to be the base of the script
cd "$(dirname "$0")" || exit 1

case "$1" in
    extract)
        do_extract;;

    translate)
        if [[ $# -lt 3 ]]; then
            error "Missing arguments"
            usage
            exit 1
        else
            do_translate "$2" "$3"
        fi;;

    compile)
        do_compile;;

    help)
        usage
        exit 0;;

    *)
        usage
        exit 1;;
esac
