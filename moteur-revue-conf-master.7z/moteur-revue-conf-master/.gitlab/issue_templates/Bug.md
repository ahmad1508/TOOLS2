# Informations sur le bug

## Description

METTRE ICI UNE DESCRIPTION DU BUG

## Criticité

- [ ] Critique : empêche la revue de configuration
- [ ] Forte : nécessite un surplus de travail conséquent de l’auditeur
- [ ] Minime : peu de travail supplémentaire

## Technologie

Le bug a été constaté sur une revue de configuration `TECHNO`.

## Catégorie

- [ ] Script d’extraction
- [ ] Moteur de revue
- [ ] Rapports générés

## OS utilisé pour lancer le moteur

- [ ] Linux
- [ ] Windows

## Informations supplémentaires

Toute information supplémentaire est utile pour résoudre des bugs.

### Traceback

```
METTRE ICI LA TRACE D’EXÉCUTION DU MOTEUR
```

### Fichier d’extraction

Le fichier d’extraction **anonymisé** peut fortement aider pour reproduire le
bug. Il peut être intéressant :

- soit de poster tout le fichier en pièce jointe à l’*issue* ;
- soit de poster les sections causant l’erreur dans cette partie.

/label ~bug
