## Contenu de la MR

<!--
Décrire en détail ce que fait cette merge request et pourquoi elle le fait.

Penser à garder la description à jour en fonction des discussions qui peuvent
avoir lieu.
-->

AJOUTER UNE DESCRIPTION À LA _MERGE REQUEST_.

## Issues associées

<!--
Ajouter les références vers les issues qui sont associées.

Si la merge request résoud totalement une issue, utiliser la syntaxe :
    Fix #ID, #ID

où ID correspond aux numéros des issues à fermer.

Si la merge request participe à la résolution d’une issue, mais ne la corrige
pas entièrement, utiliser la syntaxe :
    Related to #ID, #ID
-->

/label ~documentation
