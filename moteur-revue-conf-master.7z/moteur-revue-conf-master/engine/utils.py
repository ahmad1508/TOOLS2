# -*- coding: utf-8 -*-

"""Some utilities for the rest of the program

This module provides a base class for technologies
"""


class ClassPropertyDescriptor(object):
    """Descriptor for the @classproperty decorator

    It is used to provide a similar interface as @property
    at the class level
    """

    def __init__(self, fget, fset=None):
        """Initialize the Descriptor

        Arguments
        ---------
        fget -- the getter function
        fset -- the optional setter function

        """
        self.fget = fget
        self.fset = fset

    def __get__(self, obj, klass=None):
        """Retrieve the value of the property by calling the getter"""
        if klass is None:
            klass = type(obj)
        return self.fget.__get__(obj, klass)()

    def __set__(self, obj, value):
        """Set the value of the property by calling the setter"""
        if not self.fset:
            raise AttributeError("can't set attribute")
        type_ = type(obj)
        return self.fset.__get__(obj, type_)(value)

    def setter(self, func):
        """Define the setter of the property through a decorator

        It provides a similar interface as @property:
        ```python
        class foo(object):
            @classproperty
            def bar(self):
                pass

            @bar.setter
            def bar_set(self, val):
                pass
        ```
        """
        if not isinstance(func, (classmethod, staticmethod)):
            func = classmethod(func)
        self.fset = func
        return self


def classproperty(func):
    """Create a class property with its getter

    This is a decorator and it should be used like @property:
    ```python
    class foo(objetct)
        @classproperty
        def bar(self):
            pass

        @bar.setter
        def bar_set(self, val):
            pass
    ```
    """
    if not isinstance(func, (classmethod, staticmethod)):
        func = classmethod(func)

    return ClassPropertyDescriptor(func)
