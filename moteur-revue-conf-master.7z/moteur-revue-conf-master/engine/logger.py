# -*- coding: utf-8 -*-

"""Provides logging capabilities to the engine

This module is to be used to configure the loggers
"""

# Standard libraries
import io
import logging
import sys


class PrettyPrintFormatter(logging.Formatter):
    """A Formatter used to pretty print messages"""

    console_codes = {
        "normal": 0,
        "bold": 1,
        "half-bright": 2,
        "underscore": 4,
        "reverse": 7,
        "black": 30,
        "red": 31,
        "green": 32,
        "brown": 33,
        "blue": 34,
        "magenta": 35,
        "cyan": 36,
        "white": 37,
    }

    level_to_console_code = {
        "CRITICAL": ["bold", "red"],
        "ERROR": ["red"],
        "WARNING": ["brown"],
        "INFO": ["blue"],
        "DEBUG": ["magenta"],
        "NOTSET": ["half-bright", "white"],
    }

    def __init__(self, isatty, *args, **kargs):
        """Initialize the logger

        Arguments
        ---------
        isatty -- wether the output stream is a tty, to enable color

        """
        super(PrettyPrintFormatter, self).__init__(*args, **kargs)
        # keep track wether we print to a tty
        self.isatty = isatty

    def format(self, record):  # noqa: A003
        """Format a record by providing an optional prefix"""
        # add the prefix
        record.prefix = "[%s]" % self._add_console_code(
            record.levelname,
            self.level_to_console_code[record.levelname],
        )
        return super(PrettyPrintFormatter, self).format(record)

    def _add_console_code(self, txt, codes):
        """Prepend and append txt with console codes"""
        if self.isatty:
            return "\x1b[%sm%s\x1b[0m" % (
                ";".join(
                    map(lambda code: str(self.console_codes[code]), codes),
                ),
                txt,
            )
        else:
            return txt


def setup(output, level=logging.INFO, formatter=None):
    """Set up the logger correctly

    Arguments
    ---------
    output -- the output stream or path to a file
    level -- log level to use for the logger. Default: logging.INFO
    formatter -- id of the formatter to use. Default: None
                 When None, it is derived from output, whether it is:
                    - a tty
                    - a file
                    - a pipe

    """
    # configuration for available formatters
    formatters = {
        # simple logger which only prints the message
        "brief": logging.Formatter(
            "%(message)s",
        ),
        # simple logger which prints all details
        "full": logging.Formatter(
            "%(asctime)s %(name)-12s %(levelname)-8s %(message)s",
        ),
        # custom formatter which prints message with a prefix tag
        # and colors
        "pretty": PrettyPrintFormatter(
            isatty=False,  # will be overriden after
            fmt="%(prefix)-10s %(message)s",
        ),
    }

    # fail safe
    if not (formatter is None or formatter in formatters.keys()):
        raise RuntimeError("Unexpected formatter received: %s" % formatter)

    # configure the handler based on the output
    #  if output is a string, it is the filename for the file logger
    #  if output is a BaseIO, it is a stream logger
    if isinstance(output, str):
        # filename
        handler = logging.FileHandler(output)
        if formatter is None:
            handler.setFormatter(formatters["full"])
        else:
            handler.setFormatter(formatters[formatter])
    elif isinstance(output, io.IOBase):
        # update PrettyPrintFormatter, to ensure to enable colors
        formatters["pretty"].isatty = output.isatty
        handler = logging.StreamHandler(output)
        if formatter is None:
            handler.setFormatter(formatters["pretty"])
        else:
            handler.setFormatter(formatters[formatter])
    else:
        # defaults to doing nothing
        handler = logging.NullHandler()

    # register the handler to the root logger and set proper log level
    root = logging.getLogger("engine")
    for hdl in root.handlers:
        root.removeHandler(hdl)
    root.addHandler(handler)
    root.setLevel(level)


# Set the default root logger to PrettyPrintFormatter & stdout
setup(sys.stdout)


# export functions and constants of logging
# this is done to be able to use this pkg to get the logger
# and doing so, ensure a default logger is set up
getLogger = logging.getLogger  # noqa: N816
getLoggerClass = logging.getLoggerClass  # noqa: N816
addLevelName = logging.addLevelName  # noqa: N816
getLevelName = logging.getLevelName  # noqa: N816
getLevelName = getLevelName  # noqa: N816

CRITICAL = logging.CRITICAL
ERROR = logging.ERROR
FATAL = logging.FATAL
WARNING = logging.WARNING
WARN = logging.WARN
INFO = logging.INFO
DEBUG = logging.DEBUG
NOTSET = logging.NOTSET
