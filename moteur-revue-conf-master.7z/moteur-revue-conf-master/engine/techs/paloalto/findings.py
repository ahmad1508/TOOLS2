# -*- coding: utf-8 -*-

# Project imports
from engine.bbcode import Markup as M  # noqa: N814


def typologie(name):
    def wrapper(self, sec, desc):
        self._ensure_sec(sec)
        self.findings[sec][name].append(desc)

    return wrapper


class Findings(object):
    def __init__(self, findings=None):
        self.findings = {} if findings is None else findings

    def _ensure_sec(self, sec):
        if sec not in self.findings:
            self.findings[sec] = {"vuln": [], "better": []}

    vuln = typologie("vuln")
    better = typologie("better")

    def render(self, sec, sec_desc=""):
        self._ensure_sec(sec)
        # title
        title = M("La configuration %s" % sec_desc).strip()

        f = self.findings[sec]
        if len(f["vuln"]) > 0:
            ret = title + M(
                " [b]n’est pas satisfaisante[/b] :"
                "[list][*]%s.[/list]" % M(" ;[*]").join(f["vuln"]),
            )
            if len(f["better"]) > 0:
                ret += title + M(
                    " pourrait également être améliorée :"
                    "[list][*]%s.[/list]" % M(" ;[*]").join(f["better"]),
                )
            return ret
        elif len(f["better"]) > 0:
            return title + M(
                " [b]est satisfaisante[/b], mais pourrait "
                "être améliorée :"
                "[list][*]%s.[/list]" % M(" ;[*]").join(f["better"]),
            )
        else:
            return title + M(" [b]est satisfaisante [/b].")

    @staticmethod
    def _diff(a, b):
        new = []
        same = []
        rem = []
        for i in a:
            if i in b:
                same.append(i)
            else:
                new.append(i)
        for i in b:
            if i not in a:
                rem.append(i)
        return new, same, rem

    def diff(self, ofindings, sec, sec_desc=""):
        self._ensure_sec(sec)
        ofindings._ensure_sec(sec)
        # title
        title = f"La configuration {sec_desc}".strip()

        ret = M("[table][tr][th]Actuel[/th][th]Reférence[/th][/tr]")

        f = self.findings[sec]
        of = ofindings.findings[sec]

        # vulns
        ret += M("[tr]")
        n, s, r = self._diff(f["vuln"], of["vuln"])
        if len(f["vuln"]) > 0:
            ret += (
                M(f"[td]{title} [b]n’est pas satisfaisante[/b] :[list]")
                + M("").join([M("[*] %s") % i for i in s])
                + M("").join([M("[*][added]%s[/added]") % i for i in n])
                + M("[/list][/td]")
            )
        else:
            ret += M(f"[td]{title} [b]est satisfaisante[/b][/td]")

        if len(of["vuln"]) > 0:
            ret += (
                M(f"[td]{title} [b]n’est pas satisfaisante[/b] :[list]")
                + M("").join([M("[*] %s") % i for i in s])
                + M("").join([M("[*][removed]%s[/removed]") % i for i in r])
                + M("[/list][/td]")
            )
        else:
            ret += M(f"[td]{title} [b]est satisfaisante[/b][/td]")
        ret += M("[/tr]")

        # better
        ret += M("[tr]")
        n, s, r = self._diff(f["better"], of["better"])
        if len(f["better"]) > 0:
            ret += (
                M(f"[td]{title} pourrait également est améliorée :[list]")
                + M("").join([M("[*] %s") % i for i in s])
                + M("").join([M("[*][added]%s[/added]") % i for i in n])
                + M("[/list][/td]")
            )
        else:
            ret += M("[td][/td]")

        if len(of["better"]) > 0:
            ret += (
                M(f"[td]{title} pourrait également est améliorée :[list]")
                + M("").join([M("[*] %s") % i for i in s])
                + M("").join([M("[*][removed]%s[/removed]") % i for i in r])
                + M("[/list][/td]")
            )
        else:
            ret += M("[td][/td]")
        ret += M("[/tr]")

        ret += M("[/table]")
        return ret

    def bind(self, sec):
        return BoundedFindings(self, sec)


class BoundedFindings(object):
    def __init__(self, findings, sec):
        self.f = findings
        self.sec = sec
        self.sec_desc = ""

    @property
    def findings(self):
        return self.f.findings

    def render(self):
        return self.f.render(self.sec, self.sec_desc)

    def diff(self, ofindings):
        return self.f.diff(ofindings, self.sec, self.sec_desc)

    def vuln(self, desc):
        return self.f.vuln(self.sec, desc)

    def better(self, desc):
        return self.f.better(self.sec, desc)
