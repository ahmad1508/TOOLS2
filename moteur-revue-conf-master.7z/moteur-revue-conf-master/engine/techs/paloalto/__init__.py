# -*- coding: utf-8 -*-

"""Load the Palo Alto filters"""

# Project imports
import engine.techs.paloalto.filters  # noqa: F401
