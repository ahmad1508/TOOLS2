# -*- coding: utf-8 -*-

"""Provide filters for Palo Alto firewall"""

#############
# Guideline
# CIS Palo Alto Firewall 8 Benchmark v1.0.0
#############

# Third party libraries
import defusedxml.ElementTree as ET

# Project imports
from engine.core import i18n
from engine.core.technology import Technology
from engine.techs.common import dict2table, table2bbcode

# I18N
_ = i18n.domain("paloalto")._
M_ = i18n.domain("paloalto").M_


class PaloAlto(Technology):
    """Palo Alto technology class"""

    desc = {
        "name": "paloalto",
        "templates": {"full": {"fr": "paloalto/fr/paloalto_full.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    def __init__(self):
        super().__init__()
        # to store the XML trea
        self.tree = None

    def preprocessors(self):
        """Perform preprocessors on extracts.

        Extend the parent method to parse required data
        """
        # parse the script info
        self.artifacts["tree"] = self.tree = ET.fromstring(
            self.extracts.decode("utf-8"),
        )
        # retrieve the hostname
        self.hostname = self.get_text(".//deviceconfig/system/hostname")

    def get_text(self, xpath, root=None):
        """Get the text of a node or None."""
        # set root to the tree if none given
        if root is None:
            root = self.tree

        # Can only retrieve text if a node is found
        if root.find(xpath) is not None:
            return root.find(xpath).text
        return None

    def fw_version(self):
        """Review the version"""
        return M_(
            "The reviewed PaloAlto is [code]{hostname}[/code], with "
            "version: [codeblock]{version}[/codeblock]",
        ).format(
            hostname=self.hostname,
            version=self.tree.get("version"),
        )

    def vsys_list(self):
        """Review the virtual systems"""
        res = []
        for vsys in self.tree.findall(".//vsys/entry"):
            vsys_name = vsys.attrib["name"]
            for zone in vsys.find("zone").getchildren():
                zone_name = zone.attrib["name"]
                for member in zone.iter("member"):
                    res.append(
                        {
                            M_("VSYS"): vsys_name,
                            M_("Zone"): zone_name,
                            M_("Members"): member.text,
                        },
                    )
        return table2bbcode(dict2table(inp=res), M_("Configuration of VSYS"))

    def list_users(self):
        """Review the users"""
        res = []
        for user in self.tree.findall("mgt-config/users/entry"):
            s_user = self.get_text("permissions/role-based/superuser", user) == "yes"
            s_reader = (
                self.get_text("permissions/role-based/superreader", user) == "yes"
            )
            res.append(
                {
                    M_("Name"): user.attrib["name"],
                    M_("Is superuser"): M_("Yes") if s_user else M_("No"),
                    M_("Is superreader"): M_("Yes") if s_reader else M_("No"),
                },
            )
        return table2bbcode(dict2table(inp=res), M_("List of users"))

    def pwd_strength(self):
        """Review the password strength"""
        res = []
        # Parse information for each user
        for user in self.tree.findall("mgt-config/users/entry"):
            c_only = self.get_text("client-certificate-only", user) == "yes"
            password = self.get_text("phash", user)
            res.append(
                {
                    M_("Username"): user.attrib["name"],
                    M_("Password"): M_("None") if password is None else password,
                    M_("Certificate only"): M_("Yes") if c_only else M_("No"),
                },
            )
        return table2bbcode(table=dict2table(inp=res))

    def check_permitted_ip(self):
        """Check IPs authorized to admin the firewall"""
        res = []
        for permitted_ip in self.tree.findall(
            ".//deviceconfig/system/permitted-ip/entry",
        ):
            res.append(
                {
                    M_("Name"): self.get_text("description", permitted_ip) or "",
                    M_("Allowed IP Addresses"): permitted_ip.attrib["name"],
                },
            )
        return table2bbcode(
            dict2table(inp=res),
            M_("List of IP addresses allowed to manage the firewall"),
        )

    def all_manage_interface(self):
        """Review activated admin services"""
        res = []
        for protocol in self.tree.findall(".//system/service/"):
            is_active = True
            if protocol.text == "yes":
                is_active = False
            protocol_name = protocol.tag.replace("disable-", "")
            if (protocol_name == "telnet" and is_active) or (
                protocol_name == "http" and is_active
            ):
                self.findings.vuln(M_("HTTP and Telnet should not be activated"))
            else:
                self.findings.good(M_("HTTP and Telnet are not activated"))
            res.append(
                {
                    M_("Service"): protocol_name,
                    M_("Is active"): M_("Yes") if is_active else M_("No"),
                },
            )
        return table2bbcode(
            dict2table(inp=res),
            M_("Administration services activated on the firewall"),
        )

    def manage_interface(self):
        """Review exposed admin services"""
        res = []
        interfaces = self.tree.findall(".//interface-management-profile/entry")
        for interface in interfaces:
            interface_name = interface.get("name")
            for protocol in interface.getchildren():
                protocol_name = protocol.tag
                is_active = protocol.text == "yes"
                if (protocol_name == "telnet" and is_active) or (
                    protocol_name == "http" and is_active
                ):
                    self.findings.vuln(
                        M_(
                            "HTTP and Telnet should not be activated on "
                            "the interface %s",
                        )
                        % interface_name,
                    )
                else:
                    self.findings.good(
                        M_(
                            "HTTP and Telnet are not activated on " "the interface %s",
                        )
                        % interface_name,
                    )
                res.append(
                    {
                        M_("Interface"): interface_name,
                        M_("Service"): protocol_name,
                        M_("Is active"): M_("Yes") if is_active else M_("No"),
                    },
                )
        return table2bbcode(
            dict2table(inp=res),
            M_("Administration services exposed on interfaces"),
        )

    def check_snmp(self):
        """Review SNMP configuration"""
        res = []
        if self.tree.findall(".//snmp-setting"):
            snmp_version = self.tree.find(".//snmp-setting/access-setting/version").tag
            snmp_sentence = M_("The deployed version of SNMP is: {0}.").format(
                snmp_version,
            )
            for user in self.tree.findall(".//snmp-setting//users/entry"):
                res.append(
                    {
                        M_("Name"): user.attrib["name"],
                        M_("Authentication password"): user.find("authpwd").text,
                        M_("Private password"): user.find("privpwd").text,
                    },
                )
            snmp_users = table2bbcode(dict2table(inp=res), M_("List of SNMP users"))
        else:
            snmp_sentence = M_("The firewall does not use SNMP.")
            snmp_users = ""

        return snmp_sentence + snmp_users

    def firewall_rules(self):
        """Review firewall rules"""
        res = []
        for rule in self.tree.findall(".//rulebase/security/rules/entry"):
            rule_name = rule.attrib["name"]
            service = rule.find("service")[0].text
            action = rule.find("action").text
            if service == "any" and action == "allow":
                self.findings.vuln(M_("A rule allowing any service is defined"))
            res.append(
                {
                    M_("Name"): rule_name,
                    M_("From"): rule.find("from")[0].text,
                    M_("To"): rule.find("to")[0].text,
                    M_("Source"): rule.find("source")[0].text,
                    M_("Destination"): rule.find("destination")[0].text,
                    M_("Service"): service,
                    M_("Action"): action,
                },
            )

        # Add a good findings if nothing bad was neen
        if len(self.findings.vulns()) == 0:
            self.findings.good(
                M_("All firewall rules are correctly defined"),
            )
        return table2bbcode(dict2table(inp=res), M_("Filtering rules of the firewall"))

    def high_availability(self):
        """Check whether HA is activated"""
        res = []
        if self.tree.find(".//high-availability/enabled") is not None:
            is_enable = self.tree.find(".//high-availability/enabled").text
            mode = self.tree.find(".//passive-link-state")

            table = [
                {
                    M_("Is enabled"): is_enable,
                    M_("Mode"): M_("N/A") if not mode else mode[0].text,
                },
            ]
            res = table2bbcode(
                dict2table(inp=table),
                M_("Status of the High Availability feature"),
            )
        else:
            res = M_("The High Availability feature is not activated.")
        return res

    def config_high_availability(self):
        """Review HA config"""
        path = ".//high-availability/group/mode/active-passive/passive-link-state"

        if self.tree.find(path) is not None:
            passiv_link_state = self.tree.find(path).text
            preemptive = self.tree.find(
                ".//high-availability/group/election-option/preemptive",
            ).text
            if preemptive == "yes":
                self.findings.vuln(M_("The preemptive option should be disabled"))
            else:
                self.findings.good(M_("The preemptive option is disabled"))

            if passiv_link_state == "shutdown":
                self.findings.vuln(
                    M_("The passive link state option should set to auto"),
                )
            else:
                self.findings.good(M_("The passive link state option is set to auto"))

            res = M_(
                "Passive Link State: [b]{0}[/b]\nPreemptive: [b]{1}[/b]\n",
            ).format(passiv_link_state, preemptive)
        else:
            res = M_("The High Availability feature is not activated.")
        return res
