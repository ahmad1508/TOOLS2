# -*- coding: utf-8 -*-

"""Provide useful functions for all technologies"""

# Standard libraries
import functools
import re

# Project imports
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n

# I18N
pgettext = i18n.domain("common").pgettext


# Functions to ease the management of encoding
def _cast_encoding(string, encoding):
    """Convert a bytes() into a str() using the given encoding"""
    if isinstance(string, bytes):
        return string.decode(encoding, errors="ignore")
    else:
        return string


def to_utf8(string):
    """Convert bytes() to str() using UTF-8"""
    return _cast_encoding(string, "utf-8")


def to_latin1(string):
    """Convert bytes() to str() using latin1"""
    return _cast_encoding(string, "latin1")


def to_cp437(string):
    """Convert bytes() to str() using CP437"""
    return _cast_encoding(string, "cp437")


def decode(enc):
    """Wrap a filter function to automatically decode the extract

    It should be used as a decorator on filters. When applied on a
    filter, it will receive str() as argument instead of a bytes()

    Usage
    -----
    ```python
    class MyTech(Technology):
        @encode("utf-8")
        def myfilter(self, extract):
            pass
    ```

    Arguments
    ---------
    enc -- encoding to use to decode the bytes()

    """

    def decor(f):
        @functools.wraps(f)
        def wrap(self, extract, *args, **kargs):
            return f(self, _cast_encoding(extract, enc), *args, **kargs)

        return wrap

    return decor


def table2dict(table):
    """Convert a table to a python dictionnary

    Arguments
    ---------
    table -- input table to convert

    Output
    --------
    a dictionnary of the input or nothing if the table is empty

    """
    if 1 < len(table):
        keys = table.pop(0)
        return [dict(zip(keys, row)) for row in table]
    else:
        return []


def separator2table(
    inp,
    col_sep=":",
    row_sep="\n",
    header=None,
    maxsplit=None,
    has_headline=False,
):
    """Split a content into a table

    Split the content using the given column and row separators.

    If `maxsplit` is provided, it limits number of split for columns.
    A value of -1 would force the non-limitation of the column while
    a value of None would enable an automatic resolution: if it is None
    and `header` is provided, `maxsplit` will fit to ensure rows will
    not be split in more columns than `header`.

    **Important**: all empty line in the input are ignored

    Arguments
    ---------
    inp -- input content to split
    col_sep -- column separator. Default: ":"
    row_sep -- rows separator. Default: "\n"
    header -- optional header line. Default: None
    maxsplit -- maximal number of split. Default: None
    has_headline -- whether to skip the first line in the input if
                    `header` is provided. Default: False

    """
    ret = []
    rows = inp.strip(row_sep).split(row_sep)

    if header is not None:
        ret.append(header)
        if maxsplit is None:
            maxsplit = len(header) - 1
        if has_headline:
            del rows[0]
    elif maxsplit is None:
        maxsplit = -1

    for row in rows:
        if row != "":
            ret.append(row.split(col_sep, maxsplit))

    return ret


def key_value2dict(inp, sep="="):
    """Transform a list of key/value pair into a dict

    Split each line into two part using the given separator, if the
    line contains the separator.
    Each line is considered as a key/value pair, in that order.
    It is used to populate the returned dict.

    Note: keys and values are striped

    Arguments
    ---------
    inp -- input to be transformed
    sep -- separator used between keys and values

    """
    # data to be returned
    ret = {}
    # loop through each line, looking for the key values
    for line in inp.splitlines():
        # only split if the separator is within the line
        if sep in line:
            # split and save the data
            k, v = line.split(sep, 1)
            ret[k.strip()] = v.strip()
    # return transformed data
    return ret


# Helpers to remove comments from configuration files
def extract_without_comment(inp, comments="#", strip=False):
    """Delete all comment lines from a input text

    Each empty line and each line which starts with any of the symbols
    in `comments`, will be removed from the output

    Arguments
    ---------
    inp -- input content to filter
    comments -- characters which introduce a comment
    strip -- whether to strip all lines in the output

    """
    lines = []
    for line in inp.splitlines():
        striped = line.strip()
        # reject empty lines & comments
        if striped == "" or striped[0] in comments:
            continue
        else:
            lines.append(striped if strip else line)

    return "\n".join(lines)


# Helper to transform a list of attributes into dict
def attributelist2dict(inp, col_sep=":", row_sep="\n"):
    """Transform a list of attribute into a dict

    The string
    '''
      attribute1: value1
      attribute2: value2

      attribute1: value1bis
      attribute3: value3
    '''
    will be transformed into
    [
      {"attribute1": "value1", "attribute2": "value2"}
      {"attribute1": "value1bis", "attribute3": "value3"}
    ]

    Arguments
    ---------
    inp -- content to be transformed

    """
    # to temporary store parsed data
    attributes = []
    data = []
    attributes = []
    # to temporary track the latest parsed attribute
    last_attr = None
    # to temporary store the currently parsed object
    current = {}
    for row in inp.strip(row_sep).splitlines():
        # Blank line between list of attributes ==> new table line
        if len(row) == 0:
            # store the parsed data if it contains attributes
            if len(current) > 0:
                data.append(current)
            # reset the current parsing context
            current = {}
            last_attr = None

        # Line starting with spaces are continuation of the previous
        # attribute (for multi-line attributes)
        elif row[0] == " " or row[0] == "\t":
            # can only append when an attribute has been parsed
            # otherwise discard the line
            if last_attr is not None:
                current[last_attr] += row_sep + row.strip()

        # Line with a rule property ("key: value")
        # Split and clean each item
        elif col_sep in row:
            attr, val = row.split(col_sep, 1)
            attr = attr.strip()
            val = val.strip()

            # Add the attribute to the list of attributes
            if attr not in attributes:
                attributes.append(attr)

            # Save the property
            current[attr] = val
            last_attr = attr
        # Discard all other row
    # ensure the last parsed object is saved
    if len(current) > 0:
        data.append(current)
    # return all parsed objects
    return data


def dict2table(inp, keys=None):
    """Transform a list of dict objects into a two-dimensional table

    The input
    [
      {"attribute1": "value1", "attribute2": "value2"}
      {"attribute1": "value1bis", "attribute3": "value3"}
    ]
    will become
    [
      ['attribute1', 'attribute2', 'attribute3'],
      ['value1', 'value2', ''],
      ['value1bis', '', 'value3']
    ]

    Additionally, a list of keys to extract can be given in input

    Arguments
    ---------
    inp -- list of dict to transform
    keys -- list of keys to extract from dict

    """
    # to keep track of attributes
    attributes = []
    if keys is not None:
        attributes = keys
    else:
        # iterate over each object and each attribute
        # to get all attributes used within objects
        for o in inp:
            for k in o:
                if k not in attributes:
                    attributes.append(k)

    # transform all dict into the table
    ret = [attributes]
    for o in inp:
        ret.append([o.get(k, "") for k in attributes])
    return ret


_BASE_RE_BYTES = rb"""["']?%s\s+(\S|\S.*\S)\s+%s['"]?\r?\n"""
_BASE_RE = _BASE_RE_BYTES.decode("utf-8")
TITLES_RE = [
    # H1
    re.compile(_BASE_RE % ("=====", "====="), re.MULTILINE),
    # H2
    re.compile(_BASE_RE % ("--===", "===--"), re.MULTILINE),
    # H3
    re.compile(_BASE_RE % ("--", "--"), re.MULTILINE),
    # H4
    re.compile(_BASE_RE % ("##", "##"), re.MULTILINE),
]
TITLES_RE_BYTES = [
    # H1
    re.compile(_BASE_RE_BYTES % (b"=====", b"====="), re.MULTILINE),
    # H2
    re.compile(_BASE_RE_BYTES % (b"--===", b"===--"), re.MULTILINE),
    # H3
    re.compile(_BASE_RE_BYTES % (b"--", b"--"), re.MULTILINE),
    # H4
    re.compile(_BASE_RE_BYTES % (b"##", b"##"), re.MULTILINE),
]


def split_on_title(inp, lvl):
    """Split the input based on titles

    It splits the input using the title indexed by `lvl` and returns
    the dict of all sub-sections. Each key is the title name and values
    are the section content.
    If no title is found, it returns an empty dict.

    Note: the input can be either a str or bytes. The returned type is
    untouched

    Arguments
    ---------
    inp -- input to split
    lvl -- level of the title to use to split

    Returns
    -------
    A dict of all sub-sections content identified by the section name

    """
    if isinstance(inp, bytes):
        splits = TITLES_RE_BYTES[lvl].split(inp)
    else:
        splits = TITLES_RE[lvl].split(inp)
    return dict(zip(splits[1::2], splits[2::2]))


def parse_ini(inp):
    """Parse a file content formatted as INI

    INI format is composed of [sections] which contains list of
    key=value pairs.
    Each line which starts with ; or # are comments.
    Values can single-quoted or double-quoted

    Arguments
    ---------
    inp -- content of the INI file

    Returns
    -------
    A dict of dict. The first dict is indexed by sections, and the
    second dict in the key=value part

    """
    # remove comments & empty lines
    content = extract_without_comment(inp, "#;")

    # read line by line
    ret = {}
    cur = None
    for line in content.splitlines():
        if line[0] == "[" and line[-1] == "]":
            # new section
            cur = {}
            ret[line[1:-1]] = cur
        elif "=" in line and cur is not None:
            # new key/value
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip()
            if v[0] == v[-1] and v[0] in ("'", '"'):
                v = v[1:-1]
            cur[k] = v
    return ret


# helper to transform integer text into int, with automatic base
# detection
def int_with_base(s):
    """Transform string to int with base discovery

    Available prefix can be:
        - 0b (binary),
        - 0o (octal),
        - 0 (octal),
        - 0x (hexadecimal)
    """
    # since Python 3, int("0777", 0) will raise an error
    # it needs to be handled manually
    if (len(s) >= 2 and s[0] == "0" and s.isdigit()) or (
        len(s) >= 3 and s[0:2] == "-0" and s[1:].isdigit()
    ):
        return int(s, 8)
    return int(s, 0)


def cell_background(color, content):
    """Render a colored cell

    The color may be an hexadecimal version of it, or a plain color.
    Supported plain colors are:
        - green
        - orange
        - red

    Args:
        color (str): color for the cell background
        content (str): text content of the cell

    Returns:
        the bbcode of the colored cell content

    """
    # first resolve plain colors
    color = (
        "9ACD32"
        if color == "green"
        else "FFA500"
        if color == "orange"
        else "FF0000"
        if color == "red"
        else color
    )

    return M("[bg=%s]%s[/bg]") % (color, content)


def conformity_cell(c, a=False):
    """Render a conformity cell

    Arguments
    ---------
    c -- whether to generate a conform cell
    a -- whether to generate an acceptable cell (default: False)

    """
    # resolve conformity
    cell = (
        cell_background("green", pgettext("Conformity", "OK"))
        if c
        else cell_background("orange", pgettext("Conformity", "Arbitrage"))
        if a
        else cell_background("red", pgettext("Conformity", "NOK"))
    )
    return cell


def conformity_row(crit, reco, found, default, conform, acceptable=False):
    """Ease the generation of conformity table rows

    This helpers create a row for conformity table, for the given
    criteria. It compares the found value (or default value if the
    value is None) to the recommended value.
    Comparison comes from conform & acceptable callables:
        conform is used to check whether conformity is matched
        acceptable is used to check whether non-conformity is still
        acceptable and needs to be arbitrated.
        Both take as arguments:
            - The value found
            - The recommended value

    Both conform & acceptable can be boolean. In that case, they are
    considered as fixed value, no matter what found, reco and default
    are

    Rows created with this method follow the structure:
        | Criteria | Recommended value | Found value | Status |

    Arguments
    ---------
    crit -- text describing the criteria
    reco -- recommended value
    found -- found value or None if not found
    default -- the default value for the criteria or None if none exists
    conform -- callable whether conformity is matched
    acceptable -- callable whether non-conformity is still acceptable

    Returns
    -------
    A tuple (row, conformity):
        row -- created row for the conformity table (list)
        conformity -- whether conformity is matched (boolean)

    """
    # resolve value & printed value
    if found is not None:
        val = found
        val_t = str(val)
    elif default is not None:
        val = default
        val_t = pgettext("conformity", "%s (par défaut)") % str(val)
    else:
        val = None
        val_t = ""
    # ensure conform & acceptable are called if needed
    if callable(conform):
        c = conform(val, reco)
    else:
        c = conform
    if callable(acceptable):
        a = acceptable(val, reco)
    else:
        a = acceptable
    # resolve conformity
    conformity = conformity_cell(c, a)

    return ([crit, reco, val_t, conformity], c)


def transpose(m):
    """Transpose the matrix"""
    return [[m[j][i] for j in range(len(m))] for i in range(len(m[0]))]


# Helper to extract only few columns from a table
def filter_columns(table, col_lst):
    """Extract only given columns from a table

    Arguments
    ---------
    table -- 2-dimensional list representing the table
    col_lst -- list of indexes or header name of columns to extract

    """
    # handle specific cases
    if len(table) == 0:
        return []

    # parse name to index
    header = {}
    for i, c in enumerate(table[0]):
        header[c] = i

    # resolve header name to column if necessary
    col_idx = []
    for c in col_lst:
        if isinstance(c, str):
            col_idx.append(header[c])
        else:
            col_idx.append(c)

    # return the filtered table
    return [[r[i] for i in col_idx] for r in table]


def remove_column(table, col):
    """Remove the given column from a table

    Args:
        table (list): 2-dimensional list representing the table.
        col (int, str): the index or header name of the column to
            remove.

    Returns:
        The filtered table.

    """
    # handle specific cases
    if len(table) == 0:
        return []

    # parse name to index
    header = {}
    for i, c in enumerate(table[0]):
        header[c] = i

    # resolve header name to column if necessary
    if isinstance(col, str):
        col = header[col]

    # return the filtered table
    return [[r[i] for i in range(len(table[0])) if i != col] for r in table]


def list2bbcode(lst, with_ponctuation=True):
    """Transform a list into a bbcode text"""
    if with_ponctuation:
        sep = M(pgettext("Séparateur de liste", " ;"))
        end = M(pgettext("Fin de liste", "."))
        return M("[list]%s[/list]") % (sep.join([M("[*] %s") % i for i in lst]) + end)
    return M("[list]%s[/list]") % M("").join([M("[*] %s") % i for i in lst])


def table2bbcode(table, caption=None):
    """Transform a table into a bbcode text"""
    ret = ""
    # need to ensure the generated table is clean,
    # i.e. no [table] without [tr] and no [tr] without [th] or [td]
    if len(table) == 0:
        return ""
    # header row
    if len(table[0]) > 0:
        ret += M("[tr]%s[/tr]") % M("").join([M("[th]%s[/th]") % c for c in table[0]])

    # content
    cols = len(table[0])
    for line in table[1:]:
        if len(line) == 0:
            continue
        ret += M("[tr]%s[/tr]") % M("").join(
            [
                M("[td=%d]%s[/td]") % (max(cols - i, 1), c)
                if i == len(line) - 1
                else M("[td]%s[/td]") % c
                for i, c in enumerate(line)
            ],
        )

    if len(ret) > 0:
        if caption is not None:
            ret += M("[title]%s[/title]") % caption
        return M("[table]%s[/table]") % ret
    else:
        return ""


def netmask_to_cidr(netmask):
    """Transform an IPv4 netmask to the CIDR prefix"""
    # just count the number of 1 the binary representation of
    # each part of the netmask
    return sum(bin(int(x)).count("1") for x in netmask.split("."))


def cidr_to_netmask(cidr):
    """Transform a CIDR prefix into a IPv4 netmask"""
    # create each part of the netmask
    parts = []
    for _ in range(4):
        # extract the number of bits set in the current part and update
        # the remaining number of bits
        nb_bits = min(8, cidr)
        cidr -= nb_bits
        # create the part
        parts.append(str(((2**nb_bits) - 1) << 8 - nb_bits))
    return ".".join(parts)
