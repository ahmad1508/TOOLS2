# -*- coding: utf-8 -*-

"""Provides a do-nothing tech to only render bbcode files"""

# Project imports
from engine.core.technology import Technology


class RenderTech(Technology):
    """Technology to do nothing but render a BBcode file"""

    desc = {
        "name": "render_only",
        "templates": {"full": {"fr": "render.jinja", "en": "render.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    def parse_input(self, extract):
        """Parse the input file.

        Override parent to read file as UTF8

        Args:
            extract (str): the file name to be parsed

        """
        with open(extract, "rt", encoding="utf-8") as f:
            self.extracts = f.read()
