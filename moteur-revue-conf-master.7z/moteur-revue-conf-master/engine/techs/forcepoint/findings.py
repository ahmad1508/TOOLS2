# -*- coding: utf-8 -*-

"""Provide an interface for findings"""

# Project imports
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n
from engine.techs.common import list2bbcode, table2bbcode

# I18N
_ = i18n.domain("forcepoint")._
pgettext = i18n.domain("forcepoint").pgettext


def typology(name):
    """Define a function to declare a given typology of finding"""

    def wrapper(self, sec, desc):
        self._ensure_sec(sec)  # pylint: disable=protected-access
        self.findings[sec][name].append(desc)

    return wrapper


class Findings:
    """Main class to declare findings

    Example:
        ```python
        f = Findings()
        f.vuln("Authentication", "This is a vuln")
        f.better("Authentication", "This could be better")
        f.render("Authentication")
        ```

    """

    def __init__(self, findings=None):
        """Iniatilize a finding, possibly with a pre-existing one"""
        self.findings = {} if findings is None else findings

    def _ensure_sec(self, sec):
        """Ensure a section is properly initialized before use"""
        if sec not in self.findings:
            self.findings[sec] = {"vuln": [], "better": []}

    # defines the typologies of findings
    vuln = typology("vuln")
    better = typology("better")

    def render(self, sec, sec_desc=""):
        """Render a text to sum up findings

        Args:
            sec (str): section whose findings should be rendered
            sec_desc (str, optional): an optional description for the
                rendered section

        """
        self._ensure_sec(sec)
        # title
        title = M(_("The configuration %s") % sec_desc).strip()

        f = self.findings[sec]
        if len(f["vuln"]) > 0:
            ret = M(_("%s is [b]unsatisfactory[/b]:")) % title + list2bbcode(f["vuln"])
            if len(f["better"]) > 0:
                ret += M(_("%s could be improved:")) % title + list2bbcode(f["better"])
            return ret
        if len(f["better"]) > 0:
            return M(
                _("%s is [b]satisfactory[/b], but may be improved:"),
            ) % title + list2bbcode(f["better"])
        return M(_("%s is [b]satisfactory[/b].")) % title

    @staticmethod
    def _diff(list_a, list_b):
        """Do list_a diff between 2 lists"""
        new = []
        same = []
        rem = []
        for i in list_a:
            if i in list_b:
                same.append(i)
            else:
                new.append(i)
        for i in list_b:
            if i not in list_a:
                rem.append(i)
        return new, same, rem

    def diff(self, ofindings, sec, sec_desc=""):
        """Print a difference between two findings

        Args:
            ofindings (Findings): the Findings instance to use as
                a reference
            sec (str): section whose findings should be compared
            sec_desc (str, optional): an optional description for the
                rendered section

        """
        self._ensure_sec(sec)
        ofindings._ensure_sec(sec)  # pylint: disable=protected-access
        # title
        title = M(_("The configuration %s") % sec_desc).strip()

        ret = [
            [
                pgettext("Finding diff", "Current review"),
                pgettext("Finding diff", "Reference review"),
            ],
        ]

        findings_sec = self.findings[sec]
        other_findings_sec = ofindings.findings[sec]

        # vulns
        line = []
        new, same, removed = self._diff(
            findings_sec["vuln"],
            other_findings_sec["vuln"],
        )
        if len(findings_sec["vuln"]) > 0:
            line.append(
                M(_("%s is [b]unsatisfactory[/b]:")) % title
                + list2bbcode(same + ["[added]%s[/added]" % i for i in new]),
            )
        else:
            line.append(M(_("%s is [b]satisfactory[/b].")) % title)

        if len(other_findings_sec["vuln"]) > 0:
            line.append(
                M(_("%s is [b]unsatisfactory[/b]:")) % title
                + list2bbcode(same + ["[removed]%s[/removed]" % i for i in removed]),
            )
        else:
            line.append(M(_("%s is [b]satisfactory[/b].")) % title)
        ret.append(line)

        # better
        line = []
        new, same, removed = self._diff(
            findings_sec["better"],
            other_findings_sec["better"],
        )
        if len(findings_sec["better"]) > 0:
            line.append(
                M(_("%s could be improved:")) % title
                + list2bbcode(same + ["[added]%s[/added]" % i for i in new]),
            )
        else:
            line.append("")

        if len(other_findings_sec["better"]) > 0:
            line.append(
                M(_("%s could be improved:")) % title
                + list2bbcode(same + ["[removed]%s[/removed]" % i for i in removed]),
            )
        else:
            line.append("")
        # only add the line if there is something to show
        if line != ["", ""]:
            ret.append(line)

        return table2bbcode(ret)

    def bind(self, sec):
        """Create a findings bound to a section"""
        return BoundFindings(self, sec)


class BoundFindings:
    """Wrapper to Findings to ease working with sections

    This is usually such an instance which is exposed to filters

    Attributes:
        sec_desc (str): description for the bound section

    """

    def __init__(self, findings, sec):
        """Initialize the finding with a section and a Findings"""
        self.f = findings
        self.sec = sec
        self.sec_desc = ""

    @property
    def findings(self):
        """Expose findings of the bound Findings"""
        return self.f.findings

    def render(self):
        """Render the bound section"""
        return self.f.render(self.sec, self.sec_desc)

    def diff(self, ofindings):
        """Compare the bound section of the Findings"""
        return self.f.diff(ofindings, self.sec, self.sec_desc)

    def vuln(self, desc):
        """Add a new vuln to the bound section"""
        return self.f.vuln(self.sec, desc)

    def better(self, desc):
        """Add a new better to the bound section"""
        return self.f.better(self.sec, desc)
