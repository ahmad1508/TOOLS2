# -*- coding: utf-8 -*-

"""Provide a helper class to manage firewall rules"""

# Project imports
from engine import logger
from engine.core import i18n
from engine.techs.forcepoint.firewall_objects import (
    CustomService,
    GlobalAlias,
    Host,
    Interface,
    LocalAlias,
    Network,
    NetworkAddress,
    NetworkGroup,
    Policy,
    ServiceGroup,
    UnresolvedHost,
)

# I18N
_ = i18n.domain("forcepoint")._
pgettext = i18n.domain("forcepoint").pgettext


class Firewall:
    """This class defines the firewall objects

    Attributes:
        name (str): name of the firewall
        policy_name (str): name of the policy loaded on the firewall
        interfaces (dict): dict of `Interface`, indexed by their nicid
        addresses (dict): a dict of `NetworkObject`, indexed by their
            name
        services (dict): a dict of `Service`, indexed by their name
        policies (dict): a dict of `Policy`, indexed by their name

    """

    def __init__(self, name):
        """Initialize the firewall from its node"""
        self.name = name
        self._objects = {
            "interfaces": {},
            "addresses": {},
            "services": {},
            "policies": {},
            "subpolicies": {},
            "local_aliases": {},
            "global_aliases": {},
        }

    @property
    def aliases(self):
        """Return the active aliases for the configuration"""
        # local aliases have precedence over globals
        ret = self._objects["global_aliases"].copy()
        ret.update(self._objects["local_aliases"])
        return ret

    @property
    def addressable(self):
        """Return a dict of address and alias for the configuration"""
        # local aliases have precedence over globals
        ret = self._objects["addresses"].copy()
        ret.update(self.aliases)
        return ret

    @classmethod
    def from_node(cls, root, cluster_id):
        """Initialize a firewall instance from its ID."""
        # first try to find the XML node associated to the firewall
        cluster = None
        for clust in root.findall("fw_cluster"):
            if clust.get("db_key") == cluster_id:
                cluster = clust
                break
        if cluster is None:
            logger.getLogger(__name__).error(
                "Could not found a firewall cluster matching ID: %s",
                cluster_id,
            )
            return None

        # Initialize the Firewall and parse the tree
        ret = cls(cluster.get("name"))
        ret.parse(root, cluster)
        return ret

    def register(self, type_, name, instance):
        """Register an instance of an object on the firewall"""
        if type_ in self._objects:
            if name not in self._objects[type_]:
                self._objects[type_][name] = instance
            else:
                logger.getLogger(__name__).warning(
                    "Duplicate definition of %s: %s",
                    type_,
                    name,
                )
        else:
            logger.getLogger(__name__).error(
                "Unknown firewall object: %s",
                type_,
            )

    def __getattr__(self, key):
        """Extend the base method to expose firewall treated objects"""
        if key in self._objects:
            return self._objects[key]
        raise AttributeError(
            "'%s' object has no attribute '%s'" % (self.__class__.__name__, key),
        )

    def parse(self, root, fw_node):
        """Parse the firewall tree"""
        Interface.from_node(self, fw_node)

        self.parse_nodes(root.findall("alias"), GlobalAlias)
        self.parse_nodes(fw_node.findall("alias_value"), LocalAlias)

        self.parse_nodes(root.findall("network"), Network)

        self.parse_nodes(root.findall("host"), Host)
        self.parse_nodes(root.findall("router"), Host)
        self.parse_nodes(root.findall("dns_server"), Host)

        self.parse_nodes(root.findall("domain_name"), UnresolvedHost)
        self.parse_nodes(
            root.findall("interface_zone"),
            UnresolvedHost,
            default_comment="interface",
        )
        self.parse_nodes(
            root.findall("log_server"),
            UnresolvedHost,
            default_comment="Log server",
        )
        self.parse_nodes(root.findall("fw_cluster"), UnresolvedHost)
        self.parse_nodes(root.findall("fw_single"), UnresolvedHost)

        self.parse_nodes(root.findall("group"), NetworkGroup)

        # Add the implicit addresses
        for name in (
            "NOT Loopback network",
            "ANY",
        ):
            # firewall, name, ipv6, type_, address, is_all
            NetworkAddress(self, name, "implicit", name, name, True)
        for name in (
            "NONE",
            "Loopback network",
            "PortScan Sources Exceptions",
            "PortScan Destinations Exceptions",
            "$$ Local Cluster",
        ):
            # firewall, name, ipv6, type_, address, is_all
            NetworkAddress(self, name, "implicit", name, name, False)

        self.parse_nodes(root.findall("service_tcp"), CustomService)
        self.parse_nodes(root.findall("service_udp"), CustomService)
        self.parse_nodes(root.findall("service_ip"), CustomService)
        self.parse_nodes(root.findall("service_ethernet"), CustomService)
        self.parse_nodes(root.findall("service_icmp"), CustomService)
        self.parse_nodes(root.findall("service_icmpv6"), CustomService)
        self.parse_nodes(root.findall("service_rpc"), CustomService)

        self.parse_nodes(root.findall("gen_service_group"), ServiceGroup)

        # Add the implicit ANY rule
        CustomService(
            self,
            "ANY",
            address="ANY",
            tcp_ports=[(1, 65535)],
            udp_ports=[(1, 65535)],
            is_all=True,
        )

        self.parse_nodes(root.findall("fw_policy"), Policy)
        self.parse_nodes(root.findall("fw_template_policy"), Policy)
        self.parse_nodes(root.findall("fw_sub_policy"), Policy)

    def parse_nodes(self, nodes, cls, **extras):
        """Parse a list of nodes using the given class"""
        if nodes is None:
            return
        for node in nodes:
            cls.from_node(self, node, **extras)
