# -*- coding: utf-8 -*-

"""Load the Forcepoint filters"""

# Project imports
import engine.techs.forcepoint.filters  # noqa: F401
