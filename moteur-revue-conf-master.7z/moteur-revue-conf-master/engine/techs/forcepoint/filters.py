# -*- coding: utf-8 -*-

"""Provides filters for forcepoint review"""

# Standard libraries
from collections import OrderedDict
import functools
import ipaddress
from operator import itemgetter
import re

# Third party libraries
import defusedxml.ElementTree as ET

# Project imports
from engine import logger
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n
from engine.core.extracts import Extracts
from engine.core.technology import Technology
from engine.techs.common import cell_background, list2bbcode, table2bbcode
from engine.techs.forcepoint.firewall import Firewall
from engine.techs.forcepoint.firewall_objects import (
    Alias,
    CustomService,
    GlobalAlias,
    NetworkAddress,
    NetworkGroup,
    ServiceGroup,
    UnresolvedHost,
)

# I18N
_ = i18n.domain("forcepoint")._
N_ = i18n.domain("forcepoint").N_
pgettext = i18n.domain("forcepoint").pgettext
ngettext = i18n.domain("forcepoint").ngettext


class DefaulterI18nDict(dict):
    """Extend dict to provide a default entry if not found"""

    def __getitem__(self, key):
        """Override to provide the default entry if needed"""
        # Because of the dict position in the class body, we use
        # this class to defer translation
        try:
            return M(_(super().__getitem__(key)))
        except KeyError:
            return (
                # TRANSLATION: No need to be transtaled
                M(_(self["_default_with_value"])) % key
                if "_default_with_value" in self
                # TRANSLATION: No need to be transtaled
                else M(_(self["_default"]))
            )


def cached(func):
    """Decorate a functions whose returned value should be cached"""

    @functools.wraps(func)
    def wrapper(self, *args):
        name = func.__name__

        # check the cache
        if name in self._cache and args in self._cache[name]:
            return self._cache[name][args]

        # do the normal call
        ret = func(self, *args)

        # save the result in the cache
        if name not in self._cache:
            self._cache[name] = {}
        self._cache[name][args] = ret

        return ret

    return wrapper


def ordereddict_value(func):
    """Wrap a key getter for sorted() for OrderedDict"""

    def wrap(item):
        return func(item[1])

    return wrap


class Forcepoint(Technology):
    """Forcepoint technology class"""

    desc = {
        "name": "forcepoint",
        "templates": {"full": {"fr": "forcepoint/fr/forcepoint_full.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    def __init__(self):
        super().__init__()
        # dict to cache some functions
        self._cache = {}

    def parse_input(self, extract):
        """Parse input file.

        This method take the path to a file/folder (or anything else
        which is given in the ``-i`` option). It shuold open the file
        and provide extractions within ``self.extracts``.

        Extend the parent method to parse files as Extracts

        Args:
            extract (str): the file name to be parsed

        """
        with open(extract, "rb") as inp:
            content = inp.read()
        self.extracts = Extracts(content)

    def preprocessors(self):
        """Perform preprocessors on extracts.

        This method is used to analyze/parse extracts prior to
        templating filters. This method can store parsed data within
        the ``dict`` :py:attr:`self.artifacts`.

        To be better handle multi-input reviews, this methods should
        also set the :py:attr:`self.hostname` of the reviewed device,
        when possible.

        Override the parent method to parse inputs.
        """
        # parse the config
        self.parse_sysinfo()  # hostname is set here
        self.parse_tree()

    def parse_sysinfo(self):
        """Parse the sysinfo part of the extracts"""
        # Parse sysinfo
        log = logger.getLogger(__name__)
        log.debug("Parsing SysInfo")
        self.artifacts["sysinfo"] = Forcepoint.split_sysinfo(
            self.extracts["SysInfo"].decode("utf8"),
        )
        self.artifacts["mgmt_server"] = None
        self.artifacts["log_server"] = None

        # Parse status inforamtion
        for line in self.artifacts["sysinfo"]["Status information"].splitlines():
            if line.startswith("Hostname:"):
                # defined the hostname
                self.hostname = line.split(":", 1)[1].strip()
                log.debug("Found hostname: %s", self.hostname)
            elif line.startswith("Software version:"):
                self.artifacts["version"] = line.split(":", 1)[1].strip()
                log.debug("Found software version: %s", self.artifacts["version"])
            elif line.startswith("Security policy:"):
                self.artifacts["policy"], self.artifacts["policy_date"], _ = (
                    line.split(":", 1)[1].strip().split(",")
                )
                log.debug("Found policy name: %s", self.artifacts["policy"])
                log.debug("Found policy date: %s", self.artifacts["policy_date"])
            elif line.startswith("Management IP:"):
                self.artifacts["mgmt_server"] = line.split(":", 1)[1].strip()
                log.debug(
                    "Found Management Server: %s",
                    self.artifacts["mgmt_server"],
                )
            elif line.startswith("Log server IP:"):
                self.artifacts["log_server"] = line.split(":", 1)[1].strip()
                log.debug("Found Log Server: %s", self.artifacts["log_server"])

        # Parse cluster status information
        for line in self.artifacts["sysinfo"][
            "NGFW Cluster Status Information"
        ].splitlines():
            # need to use regex, becaus spaces may vary and some lines
            # starts with the same strings, without :
            if re.match(r"^Cluster ID\s*:", line):
                self.artifacts["cluster_id"] = line.split(":", 1)[1].strip()
                log.debug("Found cluster ID: %s", self.artifacts["cluster_id"])
            elif re.match(r"^Node ID\s*:", line):
                self.artifacts["node_id"] = line.split(":", 1)[1].strip()
                log.debug("Found node ID: %s", self.artifacts["node_id"])

    def parse_tree(self):
        """Parse the console extract as a tree"""
        # parse the XML data
        logger.getLogger(__name__).debug("Parsing XML data")
        self.artifacts["tree"] = ET.fromstring(
            self.extracts["Forcepoint Console Extract"].decode("utf8"),
        )
        self.artifacts["root"] = self.artifacts["tree"]

    @staticmethod
    def split_sysinfo(sysinfo):
        """Split the sysinfo file into its different sections

        It separates the content of each files with a header
        ###################################################################
        NAME
        Optional extra lines
        ###################################################################

        Args:
            sysinfo (str): the sysinfo section

        Returns:
            dict: each separated section

        """
        ret = {}
        # State to know the action of the current line
        state = "out"
        data = ""
        name = ""
        for line in sysinfo.splitlines():
            # Manage long ###### lines
            if line.startswith("#" * 31):
                if state in ("out", "data"):
                    state = "title"
                    # sate the current file (if any)
                    if name:
                        ret[name] = data
                    # reset data & name
                    name = data = ""
                elif state in ("title", "subtitle"):
                    state = "data"
                continue
            # manage the line, depending of the state
            if state == "data":
                data += line + "\n"
            elif state == "title":
                name = line
                state = "subtitle"

        # finally save the last file
        if name:
            ret[name] = data

        return ret

    @cached
    def get_firewall(self):
        """get the firewall configuration"""
        logger.getLogger(__name__).debug("Parsing Firewall nodes")
        return Firewall.from_node(self.artifacts["root"], self.artifacts["cluster_id"])

    @cached
    def get_policy(self, ipv6, include_disable):
        """get the firewall policy configuration"""
        # get rules from the applied policy
        fw = self.get_firewall()
        if "policy" in self.artifacts:
            pol_name = self.artifacts["policy"]
            if pol_name in fw.policies:
                logger.getLogger(__name__).debug(
                    "Generating firewall IPv%d policy",
                    6 if ipv6 else 4,
                )
                ret = fw.policies[pol_name].get_effective_rules(ipv6, include_disable)
                logger.getLogger(__name__).debug("Found %d rules", len(ret))
                return ret

            # If the policy cannot be found do an error and return
            # an empty list
            logger.getLogger(__name__).error(
                "Could not find firewall policy named: %s",
                pol_name,
            )
        else:
            # If the policy name was not retrieved
            logger.getLogger(__name__).error(
                "Could not find the name of the policy loaded on the firewall",
            )
        return []

    @cached
    def get_interfaces(self):
        """Retrieve the list of interfaces"""
        # Create a usable object from the tree
        ifaces = OrderedDict()
        for n in self.get_firewall().interfaces.values():
            # save the interface
            iface = {
                "nicid": n.nicid,
                "mac": n.mac,
                "zone": n.zone,
                "comment": n.comment,
                "vip": None if n.vip is None else ipaddress.IPv4Interface(n.vip),
                "vip6": None if n.vip6 is None else ipaddress.IPv6Interface(n.vip6),
                "nodes": {
                    k: {k2: ipaddress.ip_interface(v2) for k2, v2 in v.items()}
                    for k, v in n.nodes.items()
                },
                "iface": n,
            }
            ifaces[n.nicid] = iface

        return ifaces

    @cached
    def has_ipv6(self):
        """Return whether IPv6 is used on the firewall"""
        return (
            len(
                [i for i in self.get_interfaces().values() if i["vip6"]],
            )
            > 0
        )

    def fw_version(self):
        """Check the version of the FW."""
        return M(
            _(
                "The reviewed Forcepoint is [code]{hostname}[/code], with "
                "version: [codeblock]{version}[/codeblock]",
            ),
        ).format(
            hostname=self.hostname,
            version=self.artifacts["version"],
        )

    def network_ifaces(self):
        """List the net interfaces"""
        # retrieve the list of interfaces
        ifaces = self.get_interfaces()

        # sort the OrderedDict to be displayed
        ifaces = OrderedDict(
            sorted(
                ifaces.items(),
                key=ordereddict_value(itemgetter("nicid")),
            ),
        )

        tbl = [
            [
                pgettext("List of interfaces", "Interface ID"),
                pgettext("List of interfaces", "Zone"),
                pgettext("List of interfaces", "Comment"),
                pgettext("List of interfaces", "MAC Address"),
                pgettext("List of interfaces", "Address"),
                pgettext("List of interfaces", "IPv6"),
                pgettext("List of interfaces", "Cluster IPs"),
                pgettext("List of interfaces", "Public"),
            ],
        ]
        # List all interfaces
        for iface in ifaces.values():
            # Add the line to the table
            tbl.append(
                [
                    iface["nicid"],
                    iface["zone"] or "",
                    iface["comment"] or "",
                    iface["mac"] or "",
                    "" if iface["vip"] is None else iface["vip"].with_prefixlen,
                    "" if iface["vip6"] is None else iface["vip6"].with_prefixlen,
                    list2bbcode(
                        [
                            M(_("Node {num}: {addr}")).format(
                                num=k,
                                addr=", ".join([v.with_prefixlen for v in n.values()]),
                            )
                            for k, n in iface["nodes"].items()
                        ],
                        with_ponctuation=True,
                    ),
                    # public
                    _("Yes")
                    if (iface["vip"] is not None and iface["vip"].ip.is_global)
                    or (iface["vip6"] is not None and iface["vip6"].ip.is_global)
                    else _("No")
                    if iface["vip"] is not None or iface["vip6"] is not None
                    else "",
                ],
            )

        # return the interfaces
        return M(
            _("The following table lists all network interfaces on the" " firewall"),
        ) + table2bbcode(tbl, _("List of network interfaces on the firewall"))

    def check_ipv6(self):
        """Check whether ipv6 is used"""
        # handle the case of no IPv6
        if not self.has_ipv6():
            return M(
                _(
                    "The firewall is not configured to expose any IPv6" " interface.\n",
                ),
            )

        # for interfaces with IPv6,
        # verify that a IPv6 policy is configured
        good = True
        if len(self.get_policy(True, False)) == 0:
            self.findings.vuln(
                M(
                    _(
                        "IPv6 is used by some interfaces, but no "
                        "IPv6 filtering policies are configured",
                    ),
                ),
            )
            good = False
        else:
            self.findings.good(
                M(
                    _(
                        "The firewall exposes IPv6 interfaces and has IPv6 "
                        "filtering policies configured.\n",
                    ),
                ),
            )

        return (
            M(
                _(
                    "The firewall exposes IPv6 interfaces and has IPv6 "
                    "filtering policies configured.\n",
                ),
            )
            if good
            else ""
        )

    def syslog(self):
        """Check syslog configuration"""
        # Check whether the log server is configured
        if self.artifacts["log_server"] is not None:
            ret = (
                M(
                    _(
                        "The firewall is configured to send events to: "
                        "[code]%s[/code].",
                    ),
                )
                % self.artifacts["log_server"]
            )
            self.findings.good(M(_("A Log Servers is configured on the firewall")))
        else:
            ret = M(
                _(
                    "No configuration about a Log Server was found. The "
                    "firewall's event logs will not be centralised.",
                ),
            )
            self.findings.vuln(M(_("No Log Servers are configured on the firewall")))

        return ret + "\n"

    # dicts to save the translations of firewall objects
    RULES_ACTION = DefaulterI18nDict(
        {
            "allow": N_("Allow"),
            "discard": N_("Discard"),
            "refuse": N_("Refuse"),
            "jump": N_("Jump"),
            "_default_with_value": N_("Unknown action - %s"),
        },
    )

    def firewall_rules(self):
        """List FW rules"""
        # Render each rules
        txt = ""

        if "policy" in self.artifacts and "policy_date" in self.artifacts:
            txt += M(
                _(
                    "The policy currently implemented in the firewall is:"
                    "[codeblock]{policy}[/codeblock]"
                    "It was applied on the firewall on:"
                    "[codeblock]{date}[/codeblock]",
                ),
            ).format(
                policy=self.artifacts["policy"],
                date=self.artifacts["policy_date"],
            )

        # review IPv4 policy
        # Get the firewall policy
        rules = self.get_policy(False, False)
        if len(rules) == 0:
            # No policy
            txt += M(_("No IPv4 filtering policies are configured.\n"))
            # add a issues
            self.findings.vuln(
                M(
                    _(
                        "No IPv4 filtering policies are configured on the" " firewall",
                    ),
                ),
            )
        else:
            # Add a introducing text
            txt += M(
                _(
                    "The following IPv4 filtering policy is "
                    "configured on the firewall:",
                ),
            )
            self.findings.good(
                M(
                    _(
                        "An IPv4 filtering policies is configured on the" " firewall",
                    ),
                ),
            )
            # Render the policy as a table and retrieve issues
            tab, bad, better = self.render_firewall_policy(
                rules,
                self.get_firewall(),
                False,
            )
            # Add the filtering policy table
            txt += table2bbcode(tab, M(_("IPv4 filtering policy of the firewall")))
            # Add each issue if any
            if len(bad) > 0:
                self.findings.vuln(
                    M(
                        _(
                            "The IPv4 filtering policy of the "
                            "firewall has the following issues:%s",
                        ),
                    )
                    % list2bbcode(bad),
                )
            if len(better) > 0:
                self.findings.improvement(
                    M(
                        _(
                            "The IPv4 filtering policy of the "
                            "firewall has the following issues:%s",
                        ),
                    )
                    % list2bbcode(better),
                )

        # do the same to review IPv6 policy
        rules = self.get_policy(True, False)
        if len(rules) == 0:
            # No policy
            txt += M(_("No IPv6 filtering policies are configured.\n"))
            # No need to add an issues if IPv6 is enabled in the
            # VDOM because it is already done in interfaces review
        else:
            # Add a introducing text
            txt += M(
                _(
                    "The following IPv6 filtering policy is "
                    "configured on the firewall:",
                ),
            )
            # Render the policy as a table and retrieve issues
            tab, bad, better = self.render_firewall_policy(
                rules,
                self.get_firewall(),
                True,
            )
            # Add the filtering policy table
            txt += table2bbcode(
                tab,
                M(_("IPv6 filtering policy of the firewall")),
            )
            # Add each issue if any
            if len(bad) > 0:
                self.findings.vuln(
                    M(
                        _(
                            "The IPv6 filtering policy of the "
                            "firewall has the following issues:%s",
                        ),
                    )
                    % list2bbcode(bad),
                )
            if len(better) > 0:
                self.findings.improvement(
                    M(
                        _(
                            "The IPv6 filtering policy of the "
                            "firewall has the following issues:%s",
                        ),
                    )
                    % list2bbcode(better),
                )

        return txt + M(
            _(
                "In the previous tables, all dangerous rules have been "
                "highlighted in red.\n",
            ),
        )

    def render_firewall_policy(self, policy, firewall, ipv6):
        """Render a firewall policy

        Args:
            policy (list): rules to render, taken from a Firewall
                object
            firewall (Firewall): the instance of the firewall

        Returns:
            tuple: A `tuple` composed of the table of the policy, a
                `list` of issues and a `list` of rules which may be
                improved.

        """

        # pylint: disable=too-many-locals
        # a set of functions to format the firewall rules
        def hi_better(row):
            """Highlight as a better row"""
            return [cell_background("orange", c) for c in row]

        def hi_bad(row):
            """Highlight as a bad row"""
            return [cell_background("red", c) for c in row]

        def format_alias(alias, aliasable, formatter):
            """Format an alias

            Args:
                alias (Alias): alias instance
                aliasable (dict): the dict of objects which can be
                    aliased (different between hosts and services)
                formatter (Callable): function to format the aliased obj

            """
            #  Aliases starting with $$ seem to be special variables,
            # setup by the Mgmt server when loading policies
            # They cannot be resolved
            if isinstance(alias, GlobalAlias) and alias.name.startswith("$$"):
                return M("[code]%s[/code]") % alias.name

            return M("[code]%s[/code]=%s") % (
                alias.name,
                list2bbcode([formatter(aliasable[v]) for v in alias.value], False),
            )

        def format_net_obj(addr):
            """Format a NetworkObject"""
            # delegate to the per-type formatter
            if isinstance(addr, NetworkAddress):
                return format_net_addr(addr)
            if isinstance(addr, NetworkGroup):
                return format_net_group(addr)
            if isinstance(addr, Alias):
                return format_alias(
                    addr,
                    firewall.addressable,
                    format_net_obj,
                )
            raise RuntimeError("Unknown NetworkObject: %s" % type(addr))

        def format_net_addr(addr):
            """Format a NetworkAddress"""
            # different display for implicit addresses
            if addr.type == "implicit":
                return M("[b]%s[/b]") % addr.name

            # different display for unresolved objects
            if isinstance(addr, UnresolvedHost):
                return M("[b]%s[/b]") % addr.name

            # default display
            address = addr.address6 if ipv6 else addr.address
            # Ensure we got an address
            if address is None:
                # Use the implicit NONE value
                address = "NONE"
            return M("[b]%s[/b] ([code]%s[/code])") % (addr.name, address)

        def format_net_group(addr):
            """Format a NetworkGroup"""
            return M(_("Group [b]{name}[/b] composed of:{members}")).format(
                name=addr.name,
                members=list2bbcode(
                    [format_net_obj(obj) for obj in addr.members],
                    False,
                ),
            )

        def format_service(srv):
            """Format a service"""
            if isinstance(srv, CustomService):
                return format_serv_cust(srv)
            if isinstance(srv, ServiceGroup):
                return format_serv_group(srv)
            if isinstance(srv, Alias):
                return format_alias(
                    srv,
                    firewall.addressable_service,
                    format_service,
                )
            raise RuntimeError("Unknown Service: %s" % type(srv))

        def format_serv_cust(srv):
            """Format a CustomService"""
            # different display for ANY
            if srv.name == "ANY":
                return M(_("[b]ANY[/b]"))
            return M("[b]%s[/b] (%s)") % (srv.name, srv.address)

        def format_serv_group(srv):
            """Format a ServiceGroup"""
            return M(_("Group [b]{name}[/b] composed of:{members}")).format(
                name=srv.name,
                members=list2bbcode(
                    [format_service(obj) for obj in srv.members],
                    False,
                ),
            )

        def format_src_dest_cell(addrs):
            """Format a source or destination cell"""
            # handle the no address case
            if len(addrs) == 0:
                logger.getLogger(__name__).warning(
                    "A rule was found with no Source or Destination: this "
                    "behavior is unknown. It may either mean 'No service' or "
                    "'Any service'",
                )
                return M(_("[b]No host (unknown behavior)[/b]"))
            # format as a list
            return list2bbcode([format_net_obj(n) for n in addrs], False)

        def format_srv_cell(services):
            """Format a service cell"""
            # handle the no service case
            if len(services) == 0:
                logger.getLogger(__name__).warning(
                    "A rule was found with no Service: this behavior is "
                    "unknown. It may either mean 'No service' or 'Any"
                    " service'",
                )
                return M(_("[b]No service (unknown behavior)[/b]"))
            # format as a list
            return list2bbcode([format_service(n) for n in services], False)

        # A list to keep track of all issues
        issues = []
        better = []

        # start the table
        tab = [
            [
                pgettext("Policy", "#"),
                pgettext("Policy", "Name"),
                pgettext("Policy", "Comment"),
                pgettext("Policy", "Source"),
                pgettext("Policy", "Destination"),
                pgettext("Policy", "Service"),
                pgettext("Policy", "Action"),
                pgettext("Policy", "Traffic log"),
            ],
        ]

        # iterate over each rules
        idx = 0
        for rule in policy:
            # Manage comment rules
            if rule.type == "comment":
                # Add a single column grey line
                tab.append([cell_background("D4D4D4", rule.comment)])
                continue

            # skip disabled rules
            if not rule.enabled:
                continue

            # Create the row for the table
            idx += 1
            row = [
                str(idx),
                rule.name or "",
                rule.comment or "",
                format_src_dest_cell(rule.srcaddr),
                format_src_dest_cell(rule.dstaddr),
                format_srv_cell(rule.services),
                "" if rule.action is None else self.RULES_ACTION[rule.action],
                _("Yes")
                if rule.logtraffic
                else ""
                if rule.logtraffic is None
                else _("No"),
            ]

            # do the review for issues
            def isall(items):
                """Return whether the list covers everything"""
                return any(m.is_all for m in items)

            src_isall = isall(rule.srcaddr)
            dst_isall = isall(rule.dstaddr)
            srv_isall = isall(rule.services)

            # check any -> any: any accept rules
            if src_isall and dst_isall and srv_isall and rule.action == "allow":
                issues.append(
                    M(_("The rule #%s widely accepts network traffic")) % idx,
                )
                row = hi_bad(row)

            # check completely exposed hosts
            elif src_isall and srv_isall and rule.action == "allow":
                issues.append(
                    M(
                        _(
                            "The rule #%s exposes destination hosts to anyone "
                            "on any protocol",
                        ),
                    )
                    % idx,
                )
                row = hi_bad(row)

            # check admin services
            elif src_isall and rule.action == "allow":
                admin_srv = []
                # check all admin services
                for name, serv in (
                    (M(_("SSH")), ("tcp", 22)),
                    (M(_("Telnet")), ("tcp", 23)),
                    (M(_("RPC")), ("tcp", 135)),
                    (M(_("NetBIOS")), ("tcp", 139)),
                    (M(_("SMB")), ("tcp", 445)),
                    (M(_("rexec")), ("tcp", 512)),
                    (M(_("rlogin")), ("tcp", 513)),
                    (M(_("rsh")), ("tcp", 514)),
                    (M(_("SNMP")), ("udp", 161)),
                    (M(_("RDP")), ("tcp", 3389)),
                    (M(_("VNC")), ("tcp", 5900)),
                    (M(_("WinRM HTTP")), ("tcp", 5985)),
                    (M(_("WinRM HTTPS")), ("tcp", 5986)),
                ):
                    if any(m.allow_port(*serv) for m in rule.services):
                        admin_srv.append(name)
                # highlight row & add finding if any admin srv matches
                if len(admin_srv) > 0:
                    better.append(
                        M(
                            _(
                                "The rule #{index} exposes administrative "
                                "services ({admin_srv}) to anyone",
                            ),
                        ).format(
                            index=idx,
                            admin_srv=M(", ").join(admin_srv),
                        ),
                    )
                    row = hi_better(row)

            # add the row to the table
            tab.append(row)

        # Return
        return tab, issues, better
