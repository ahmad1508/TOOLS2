# -*- coding: utf-8 -*-

"""Provide a helper classes to represent firewall objects"""
# pylint: disable=too-many-lines

# Standard libraries
import functools
from ipaddress import (
    ip_address,
    ip_interface,
    ip_network,
    IPv4Interface,
    IPv4Network,
    IPv6Network,
)
from operator import attrgetter

# Third party libraries
from defusedxml import ElementTree

# Project imports
from engine import logger
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n

# I18N
_ = i18n.domain("forcepoint")._
pgettext = i18n.domain("forcepoint").pgettext


def deferred_get(name, names_prop, cache_prop, firewall_prop):
    """Defer the resolution of firewall sub-objects instances

    Args:
        name (str): human readable definition of the property
            (for logger warnings)
        names_prop (str): name of the property of self to retrieve the
            list of names to resolve
        cache_prop (str): name of the property of self to retrieve the
            cache of resolved instances
        firewall_prop (str): name of the property of Firewall to
            retrieve the dict of instances

    """

    def wrapper(self):
        # check the cache first
        if getattr(self, cache_prop) is not None:
            return getattr(self, cache_prop)

        # create a function to do the resolution for a given name
        def _resolve(n):
            # allow None type
            if n is None:
                return None
            # else resolve as expected
            if n in getattr(self.firewall, firewall_prop):
                return getattr(self.firewall, firewall_prop)[n]
            logger.getLogger(__name__).warning("Unknown %s named: %s", name, n)
            return None

        # do the resolution from name to instances
        # adapt the behavior depending on wether it is a list or a uniq
        # name
        names = getattr(self, names_prop)
        if isinstance(names, (list, tuple)):
            ret = list(map(_resolve, names))
        else:
            ret = _resolve(names)

        # save the cache and return
        setattr(self, cache_prop, ret)
        return ret

    return wrapper


class FirewallBoundObject:  # pylint: disable=too-few-public-methods
    """Class to bind the instances to the firewall

    This class is intended to be bound subclassed

    Example:
        ```python
        class NetworkObject(FirewallBound):
            def __init__(self, firewall, *data):
                super().__init__(firewall, "addresses")
        ```

    """

    __slots__ = ("firewall",)

    def __init__(self, firewall, type_, name):
        """Register on the firewall"""
        self.firewall = firewall
        self.firewall.register(type_, name, self)


def log_node(func):
    """Decorator to log nodes of from_node function"""

    @functools.wraps(func)
    def wrapper(cls, firewall, node, *args, **kargs):
        # Log node on error
        try:
            return func(cls, firewall, node, *args, **kargs)
        except Exception as exc:
            raise Exception(
                "Failed to parse node for %s: %s"
                % (
                    cls.__name__,
                    ElementTree.tostring(node, encoding="utf-8", method="xml").decode(
                        "utf-8",
                    ),
                ),
            ) from exc

    return wrapper


class Interface(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Represents the interfaces of a firewall cluster."""

    __slots__ = (
        "nicid",
        "mac",
        "zone",
        "comment",
        "vip",
        "vip6",
        "nodes",
    )

    def __init__(
        self,
        firewall,
        nicid,
        mac,
        zone,
        comment,
        vip,
        vip6,
        nodes,
    ):
        """Initialize the object"""
        super().__init__(firewall, "interfaces", nicid)
        self.nicid = nicid
        self.mac = mac
        self.zone = zone
        self.comment = comment
        self.vip = vip
        self.vip6 = vip6
        self.nodes = nodes

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the interface from a fw_cluster node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): fw_cluster node to search

        Returns:
            list: list of Interfaces associated to a cluster

        """
        # pylint: disable=too-many-locals
        # pylint: disable=too-many-branches
        ifaces = {}
        for phy in node.findall("physical_interface"):
            # first try to parse the vlan interface
            nb_vlan = 0
            for vlan in phy.findall("vlan_interface"):
                nb_vlan = nb_vlan + 1
                ifaces[vlan.get("interface_id")] = {
                    "nicid": vlan.get("interface_id"),
                    "mac": phy.get("macaddress"),
                    "zone": vlan.get("zone_ref"),
                    "comment": vlan.get("comment"),
                    "vip": None,
                    "vip6": None,
                    "nodes": {},
                }

            # if no vlans are defined, fall back to a physical interface
            if nb_vlan == 0:
                ifaces[phy.get("interface_id")] = {
                    "nicid": phy.get("interface_id"),
                    "mac": phy.get("macaddress"),
                    "zone": phy.get("zone_ref"),
                    "comment": phy.get("comment"),
                    "vip": None,
                    "vip6": None,
                    "nodes": {},
                }

        # Retrieve the VIP and network associated to each interface
        for cvi in node.findall("cluster_virtual_interface"):
            for mvia in cvi.findall("mvia_address"):
                nicid = cvi.get("nicid")
                if nicid in ifaces:
                    # the  network & address may be either ipv4 or 6
                    net = ip_network(cvi.get("network_value"))
                    ip = ip_address(mvia.get("address"))
                    iface = ip_interface("%s/%d" % (str(ip), net.prefixlen))
                    if isinstance(iface, IPv4Interface):
                        ifaces[nicid]["vip"] = iface.with_prefixlen
                    else:
                        ifaces[nicid]["vip6"] = iface.with_prefixlen

        # Retrieve the list of nodes in the cluster, and their
        # respective addresses
        for fw in node.findall("firewall_node"):
            for node_ifaces in fw.findall("node_interface"):
                nicid = node_ifaces.get("nicid")
                for addr in node_ifaces.findall("mvia_address"):
                    if nicid in ifaces:
                        # create the dict to be able to store ipv4/6
                        if fw.get("nodeid") not in ifaces[nicid]["nodes"]:
                            ifaces[nicid]["nodes"][fw.get("nodeid")] = {}
                        node_details = ifaces[nicid]["nodes"][fw.get("nodeid")]

                        # the  network & address may be either ipv4 or 6
                        net = ip_network(node_ifaces.get("network_value"))
                        ip = ip_address(addr.get("address"))
                        iface = ip_interface("%s/%d" % (str(ip), net.prefixlen))
                        if isinstance(iface, IPv4Interface):
                            node_details["ip"] = iface.with_prefixlen
                        else:
                            node_details["ip6"] = iface.with_prefixlen

        # Finally register and return all the interfaces
        return [cls(firewall, **iface) for iface in ifaces.values()]


class Alias(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for Alias objects

    An Alias can either be a `GlobalAlias` or a `LocalAlias`.
    """

    __slots__ = ("name", "value")

    def __init__(self, firewall, name, value, is_global):
        """Initialize the object"""
        super().__init__(
            firewall,
            "global_aliases" if is_global else "local_aliases",
            name,
        )
        self.name = name
        self.value = value

    def resolve(self):
        """Resolve the Alias to NetworkObjects."""
        ret = set()
        for v in self.value:
            # find the target (currently only ipv4 is supported)
            target = self.firewall.addressable[v]
            # Resolve aliases recursively
            if isinstance(target, Alias):
                ret.update(target.resolve())
            else:
                ret.add(target)
        return list(ret)

    @property
    def is_all(self):
        """Return True if the alias represents all assets"""
        return any(addr.is_all for addr in self.resolve())


class GlobalAlias(Alias):
    """Global aliases are default values of aliases.

    They are shared between all firewalls.

    Attributes:
        name (str): name of the alias
        value (list): value of the alias

    """

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the alias from its alias node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): the alias node

        Returns:
            GlobalAlias: the alias

        """
        return cls(
            firewall,
            name=node.get("name"),
            value=[node.findall("default_alias_value")[0].get("ne_ref")],
            is_global=True,
        )


class LocalAlias(Alias):
    """Local aliases are values of aliases for the current cluster.

    Attributes:
        name (str): name of the alias
        value (str): value of the alias

    """

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the alias from its alias_value node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): the alias_value node

        Returns:
            LocalAlias: the alias

        """
        return cls(
            firewall,
            name=node.get("alias_ref"),
            value=[ne.get("ref") for ne in node.findall("ne_list")],
            is_global=False,
        )


class NetworkObject(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for network objects

    A NetworkObject can either be a `NetworkAddress` or a `NetworkGroup`
    """

    __slots__ = ("name", "comment")

    def __init__(self, firewall, name, comment=""):
        """Initialize the object"""
        super().__init__(firewall, "addresses", name)
        self.name = name
        self.comment = comment


class NetworkAddress(NetworkObject):  # pylint: disable=too-few-public-methods
    """Provide a base class for addresses

    Attributes:
        name (str): name of the object
        comment (str): comment added on the object
        type (str): type of the address object
        address (str): human-representation of the address
        address6 (str): human-representation of the IPv6 address
        is_all (bool): whether the address cover all addresses

    """

    __slots__ = ("type", "address", "address6", "is_all")

    def __init__(
        self,
        firewall,
        name,
        type_,
        address,
        address6,
        is_all=False,
        comment="",
    ):
        """Initialize the address from data"""
        super().__init__(firewall, name, comment)
        self.type = type_
        self.address = address
        self.address6 = address6
        self.is_all = is_all


class Network(NetworkAddress):  # pylint: disable=too-few-public-methods
    """Reprents the network addressable by a firewall."""

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the network from its network node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): the network node

        Returns:
            Network: the network

        """
        # Get both ipv4 and ipv6
        addr = None
        addr6 = None
        is_all = False
        if node.get("ipv4_network"):
            addr = IPv4Network(node.get("ipv4_network"))
            is_all |= addr == IPv4Network("0.0.0.0/0")
        else:
            addr6 = IPv6Network(node.get("ipv6_network"))
            is_all |= addr6 == IPv6Network("::/0")
        # return the instance
        return cls(
            firewall,
            name=node.get("name"),
            comment=node.get("comment", ""),
            type_="network",
            address=None if addr is None else addr.with_prefixlen,
            address6=None if addr6 is None else addr6.with_prefixlen,
            is_all=is_all,
        )


class Host(NetworkAddress):  # pylint: disable=too-few-public-methods
    """Reprents a host addressable by a firewall."""

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the host from its a host node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): the host node

        Returns:
            Host: the host

        """
        # Try to get both ipv4 and ipv6
        addr = None
        addr6 = None
        if len(node.findall("mvia_address")) > 0:
            addr = node.findall("mvia_address")[0].get("address")
        elif node.get("ipv4_address"):
            # not sure this case may happen, but still a good
            # thing to keep it, as it may appear later
            addr = node.get("ipv4_address")

        if node.get("ipv6_address"):
            addr6 = node.get("ipv6_address")

        # create the instance
        return cls(
            firewall,
            name=node.get("name"),
            type_="host",
            address=addr,
            address6=addr6,
            comment=node.get("comment", ""),
            is_all=False,
        )


class UnresolvedHost(NetworkAddress):  # pylint: disable=too-few-public-methods
    """Reprents a unresolved host addressable by a firewall.

    Unresolved hosts are hosts whose address cannot be statically
    computed. For instance, DNS may be used as source/destination, but
    their real target depends of the execution.
    """

    @classmethod
    @log_node
    def from_node(cls, firewall, node, default_comment=""):
        """Initialize the host from its a host node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): the host node
            default_comment (str): the default comment to apply

        Returns:
            UnresolvedHost: the host

        """
        return cls(
            firewall,
            name=node.get("name"),
            type_="unresolved_host",
            address=node.get("name"),
            address6=node.get("name"),
            comment=node.get("comment", default_comment),
            is_all=False,
        )


class NetworkGroup(NetworkObject):
    """Provide a class for network groups

    Attributes:
        name (str): name of the object
        ipv6 (bool): whether the object is for IPv6
        comment (str): comment added on the object
        members (list): the list of members of the group. The items
            of this list are `NetworkObject`

    """

    __slots__ = ("_members_names", "_members")

    def __init__(self, firewall, name, members, comment=""):
        """Initialize the group from data"""
        super().__init__(firewall, name, comment)
        self._members_names = members
        self._members = None

    members = property(
        deferred_get("address", "_members_names", "_members", "addressable"),
    )

    @property
    def is_all(self):
        """Return True if the group represents all assets"""
        return any(member.is_all for member in self.members)

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the group from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): Node of the group

        Returns:
            NetworkGroup: the initialized group

        """
        # get basic info
        name = node.get("name")
        comment = node.get("comment", "")
        members = list(map(lambda n: n.get("ref"), node.findall("ne_list")))
        return cls(firewall, name, members, comment)


class Service(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for services

    A service can either be a `CustomService` or a `ServiceGroup`
    """

    __slots__ = ("name", "comment")

    def __init__(self, firewall, name, comment=""):
        """Initialize the object"""
        super().__init__(firewall, "services", name)
        self.name = name
        self.comment = comment

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        raise NotImplementedError("port_list must be implemented in subclasses")

    def allow_port(self, protocol, port):
        """Check whether this service match the given port

        Args:
            protocol (str): protocol to check (tcp or udp)
            port (int): port to check

        Returns:
            True if the port is matched

        """
        port_list = self.port_list()
        # Ensure only using authorized protocols
        if protocol not in port_list:
            return False
        for start, end in port_list[protocol]:
            if start <= port <= end:
                return True
        return False


class CustomService(Service):
    """Provide a class for services

    Attributes:
        name (str): name of the object
        comment (str): comment added on the object
        address (str): human-representation of the address
        tcp_ports (list): all matching TCP ports ranges (= a tuple)
        udp_ports (list): all matching UDP ports ranges (= a tuple)
        is_all (bool): whether the address cover all addresses

    """

    __slots__ = ("address", "tcp_ports", "udp_ports", "is_all")

    def __init__(
        self,
        firewall,
        name,
        address,
        tcp_ports,
        udp_ports,
        is_all,
        comment="",
    ):
        """Initialize the service from data"""
        super().__init__(firewall, name, comment)
        self.address = address
        self.tcp_ports = tcp_ports
        self.udp_ports = udp_ports
        self.is_all = is_all

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        return {
            "tcp": self.tcp_ports[:],
            "udp": self.udp_ports[:],
        }

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the service from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): Node of the service

        Returns:
            CustomService: the service definition

        """
        # pylint: disable=too-many-statements
        # pylint: disable=too-many-branches,too-many-locals
        # pylint: disable=too-many-locals
        # get basic data
        name = node.get("name")
        comment = node.get("comment", "")
        is_all = False
        tcp_ports = []
        udp_ports = []

        # Try to resolve the address, depending on the protocol
        # also compute whether the object cover all addresses
        if node.tag == "service_ip":
            # IP uses protocol-number
            protocol_number = node.get("protocol_number")
            # all if all IP protocols (0), encapsulated IPv4 (4),
            # :IPv6 (41), TCP (6), UDP (17), SCTP (132)
            is_all = protocol_number in ("0", "4", "6", "17", "41", "132")
            # all tcp_ports if TCP or all
            if protocol_number in ("0", "6"):
                tcp_ports.append((1, 65535))
            # all udp_ports if UDP or all
            if protocol_number in ("0", "17"):
                udp_ports.append((1, 65535))
            address = (
                pgettext("Network service IP proto", "IP protocol #%s")
                % protocol_number
                if protocol_number != "0"
                else pgettext("Network service IP proto", "all IP protocols")
            )

        elif node.tag == "service_ethernet":
            # Ethernet has a type for the L2, with eth2 being the
            # usually-called ethernet protocol
            frame_type = node.get("frame_type")
            if frame_type == "eth2":
                protocol_number = int(node.get("value1"))
                # all if IP protocols (0x0800) or IPv6 protocol (0x86DD)
                is_all = protocol_number in (0x0800, 0x86DD)
                # all tcp_ports if IP protocol
                if protocol_number in (0x0800, 0x86DD):
                    tcp_ports.append((1, 65535))
                # all udp_ports if IP protocol
                if protocol_number in (0x0800, 0x86DD):
                    udp_ports.append((1, 65535))
                address = (
                    pgettext("Network service Ether proto", "all IPv4")
                    if protocol_number == 0x0800
                    else pgettext("Network service Ether proto", "all IPv6")
                    if protocol_number == 0x086DD
                    else pgettext(
                        "Network service Ether proto",
                        "Ethernet of Ethertype #%s",
                    )
                    % protocol_number
                )
            else:
                # For other values retrieve all the values (there may
                # be several)
                protocol_number = []
                i = 1
                while node.get("value%d" % i) is not None:
                    protocol_number.append(str(node.get("value%d" % i)))
                    i += 1
                address = pgettext(
                    "Network service Ether proto",
                    "Ethernet Frame {frame_type}/{proto}",
                ).format(
                    frame_type=frame_type.upper(),
                    proto="/".join(protocol_number),
                )

        elif node.tag == "service_icmp":
            # ICMP uses icmptype and icmpcode
            icmptype = node.get("icmp_type", None)
            icmpcode = node.get("icmp_code", None)
            is_all = False
            address = []
            if icmptype is not None:
                address.append(
                    pgettext("Network service ICMP", "ICMP type %s") % icmptype,
                )
            if icmpcode is not None:
                address.append(
                    pgettext("Network service ICMP", "ICMP code %s") % icmpcode,
                )
            if address == []:
                address.append(
                    pgettext("Network service ICMP", "All ICMP"),
                )
            address = "\n".join(address)

        elif node.tag == "service_icmpv6":
            # ICMP uses icmptype and icmpcode
            icmptype = node.get("icmp_type", None)
            is_all = False
            if icmptype is not None:
                address = pgettext("Network service ICMP", "ICMPv6 type %s") % icmptype
            else:
                address = pgettext("Network service ICMP", "All ICMPv6")

        elif node.tag == "service_tcp":
            is_all = False
            # get the start and stop
            start = int(node.get("min_dst_port"))
            stop = int(node.get("max_dst_port", start))
            tcp_ports.append((start, stop))
            # Update is_all
            if start <= 1 and stop >= 65535:
                is_all = True
            # Make the human string
            if start == stop:
                address = pgettext("Network service TCP", "TCP/%s") % str(start)
            else:
                address = pgettext("Network service TCP", "TCP/%s") % (
                    "%d-%d" % (start, stop),
                )

        elif node.tag == "service_udp":
            is_all = False
            address = []
            # get the start and stop
            start = int(node.get("min_dst_port"))
            stop = int(node.get("max_dst_port", start))
            udp_ports.append((start, stop))
            # Update is_all
            if start <= 1 and stop >= 65535:
                is_all = True
            # Make the human string
            if start == stop:
                address = pgettext("Network service UDP", "UDP/%s") % str(start)
            else:
                address = pgettext("Network service UDP", "UDP/%s") % (
                    "%d-%d" % (start, stop),
                )

        elif node.tag == "service_rpc":
            is_all = False
            rpc_number = node.get("program_number")
            address = pgettext("Network service RPC", "RPC/%s") % str(rpc_number)

        else:
            logger.getLogger(__name__).warning(
                "Unknown protocol for Forcepoint network service: %s",
                node.tag,
            )
            address = ""

        # create the network object
        return cls(
            firewall,
            name=name,
            address=address,
            tcp_ports=tcp_ports,
            udp_ports=udp_ports,
            is_all=is_all,
            comment=comment,
        )


class ServiceGroup(Service):
    """Provide a base class for groups

    Attributes:
        name (str): name of the object
        comment (str): comment added on the object
        members (list): the list of members of the group. The items
            of this list are `Service`

    """

    __slots__ = ("_members_names", "_members")

    def __init__(self, firewall, name, members, comment=""):
        """Initialize the group from data"""
        super().__init__(firewall, name, comment)
        self._members_names = members
        self._members = None

    members = property(
        deferred_get("service", "_members_names", "_members", "services"),
    )

    def allow_port(self, protocol, port):
        """Check whether this service match the given port

        Args:
            protocol (str): protocol to check (tcp or udp)
            port (int): port to check

        Returns:
            True if the port is matched

        """
        # A group only match if any of its member match
        for member in self.members:
            if member.allow_port(protocol, port):
                return True
        return False

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        # merge all member's port list
        ret = {}

        for member in self.members:
            for proto, ports in member.port_list().items():
                if proto not in ret:
                    ret[proto] = ports
                else:
                    ret[proto].extend(ports)

        return ret

    @property
    def is_all(self):
        """Return True if the group represents all assets"""
        return any(member.is_all for member in self.members)

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the group from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): Node of the group

        Returns:
            ServiceGroup: the service group

        """
        name = node.get("name")
        comment = node.get("comment", "")
        members = list(map(lambda n: n.get("ref"), node.findall("service_ref")))
        return cls(firewall, name, members, comment)


class Policy(FirewallBoundObject):
    """Represent a policy"""

    # Use slots to reduce memory consumption
    __slots__ = (
        "name",
        "type",
        "comment",
        "_parent_policy_names",
        "_parent_policy",
        "inspection_policy_ref",
        "rules",
        "rules6",
    )

    def __init__(  # pylint: disable=too-many-arguments,too-many-locals
        self,
        firewall,
        name,
        type_,
        comment,
        parent_policy,
        inspection_policy_ref,
        rules,
        rules6,
    ):
        """Initialize the rules with the data"""
        super().__init__(
            firewall,
            "subpolicies" if type_ == "subpolicy" else "policies",
            name,
        )
        self.name = name
        self.type = type_
        self.comment = comment
        self._parent_policy_names = parent_policy
        self._parent_policy = None
        self.inspection_policy_ref = inspection_policy_ref
        self.rules = rules
        self.rules6 = rules6

    parent_policy = property(
        deferred_get(
            "Parent policy",
            "_parent_policy_names",
            "_parent_policy",
            "policies",
        ),
    )

    def get_effective_rules(
        self,
        ipv6,
        include_disable,
        insertion_points=None,
        treated=None,
    ):
        """Resolve the list of rules current applied."""
        # The resolution is done as such:
        #   - for the policy, keep a list of each rules per-insertion
        #       point
        #   - sort them per-rank
        #   - Include subpolicies
        #   - resolve the parent template, providing it with insertion
        #       points
        #   - When the top-template is reached, return the rules
        insertion_points = insertion_points or {}
        treated = treated or []

        # dict to keep track of where rules are to be inserted
        inserted_rules = {}
        for rule in self.rules6 if ipv6 else self.rules:
            if not include_disable and not rule.enabled:
                # skip disabled rules
                continue
            # Ensure the insert point list exists
            if rule.insert_point not in inserted_rules:
                inserted_rules[rule.insert_point] = []
            # insert the rules
            inserted_rules[rule.insert_point].append(rule)

        # Sort rules per-rank
        for k in inserted_rules:
            inserted_rules[k].sort(key=attrgetter("rank"))

        # Resolve inserted rules: do it after the sort to prevent
        # inserted rules to be sorted
        # Also include subpolicies
        for k in inserted_rules:
            rules = inserted_rules[k]
            i = 0
            while i < len(rules):
                rule = rules[i]
                #  Treat insert_points
                if rule.type == "insert_point":
                    # replace the insert_point rules with subrules
                    inserted_rules[k] = (
                        rules[:i] + insertion_points.get(rule.name, []) + rules[i + 1 :]
                    )
                    # force i not being increased to ensure the current
                    # location (replaced with inserted rules) get
                    # rescanned
                    i -= 1
                #  Treat insert_points
                elif rule.action == "jump" and rule not in treated:
                    # mark the rule as treated to prevent further
                    # resolution on this rule, when rendering parents
                    treated.append(rule)
                    # Insert the subpolicy between 2 comment rows
                    inserted_rules[k] = (
                        rules[: i + 1]
                        + [
                            Rule(
                                self.firewall,
                                name=None,
                                rule_type="comment",
                                comment=(
                                    M(_("Start of the sub-policy %s"))
                                    % rule.subpolicy.name
                                ),
                                enabled=True,
                            ),
                        ]
                        + rule.subpolicy.get_effective_rules(ipv6, include_disable)
                        + [
                            Rule(
                                self.firewall,
                                name=None,
                                rule_type="comment",
                                comment=(
                                    M(_("End of the sub-policy %s"))
                                    % rule.subpolicy.name
                                ),
                                enabled=True,
                            ),
                        ]
                        + rules[i + 1 :]
                    )
                i += 1
                # rules needs to be update at every loop
                # because we may modify it every cycle
                rules = inserted_rules[k]

        # Render the parent or return the list of rules if top template
        if self.parent_policy is None:
            # top template ==> return all rules
            if None in inserted_rules:
                return inserted_rules[None]
            return []
        # else, render the parent policy
        return self.parent_policy.get_effective_rules(
            ipv6,
            include_disable,
            inserted_rules,
            treated,
        )

    @classmethod
    @log_node
    def from_node(cls, firewall, node):
        """Initialize the rule from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): Node of the policy

        Returns:
            Policy: the policy

        """
        # pylint: disable=too-many-branches,too-many-locals
        # init the basic infos
        name = node.get("name")
        comment = node.get("comment", "")
        policy_type = (
            "subpolicy"
            if node.tag == "fw_sub_policy"
            else "template"
            if node.tag == "fw_template_policy"
            else "policy"
        )
        template_policy_ref = node.get("template_policy_ref")
        inspection_policy_ref = node.get("inspection_policy_ref")

        # Parse each ipv4 rules
        rules = []
        for rule in node.findall("./access_entry/rule_entry"):
            rules.append(Rule.from_node(firewall, rule, False))

        # Parse ipv6 rules
        rules6 = []
        for rule in node.findall("./ipv6_access_entry/rule_entry"):
            rules6.append(Rule.from_node(firewall, rule, True))

        # Create the object
        return cls(
            firewall,
            name,
            policy_type,
            comment,
            template_policy_ref,
            inspection_policy_ref,
            rules,
            rules6,
        )


class Rule:
    """This clase is used to describe a rule of a policy"""

    # Use slots to reduce memory consumption
    __slots__ = (
        "firewall",
        "type",
        "name",
        "comment",
        "action",
        "enabled",
        "_srcaddr_names",
        "_srcaddr",
        "_dstaddr_names",
        "_dstaddr",
        "_services_names",
        "_services",
        "_subpolicy_names",
        "_subpolicy",
        "logtraffic",
        "rank",
        "insert_point",
    )

    def __init__(  # pylint: disable=too-many-arguments,too-many-locals
        self,
        firewall,
        rule_type,
        name,
        action=None,
        srcaddr=None,
        dstaddr=None,
        services=None,
        subpolicy=None,
        logtraffic=None,
        rank=0.0,
        insert_point=None,
        comment="",
        enabled=True,
    ):
        """Initialize the rules with the data"""
        self.firewall = firewall
        self.type = rule_type
        self.name = name
        self.comment = comment
        self.action = action
        self.enabled = enabled
        self._srcaddr_names = srcaddr
        self._srcaddr = None
        self._dstaddr_names = dstaddr
        self._dstaddr = None
        self._services_names = services
        self._services = None
        self._subpolicy_names = subpolicy
        self._subpolicy = None
        self.rank = rank
        self.insert_point = insert_point
        self.logtraffic = logtraffic

    # register the deferred getter for firewall objects
    srcaddr = property(
        deferred_get("address", "_srcaddr_names", "_srcaddr", "addressable"),
    )
    dstaddr = property(
        deferred_get("address", "_dstaddr_names", "_dstaddr", "addressable"),
    )
    services = property(
        deferred_get("service", "_services_names", "_services", "services"),
    )
    subpolicy = property(
        deferred_get(
            "subpolicy",
            "_subpolicy_names",
            "_subpolicy",
            "subpolicies",
        ),
    )

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join(
                "%s=%r" % (v, getattr(self, v))
                for v in ("name", "insert_point", "rank", "enabled", "comment")
            ),
        )

    @classmethod
    @log_node
    def from_node(cls, firewall, node, ipv6):
        """Initialize the rule from the associated rule_entry node

        Args:
            firewall (Firewall): the associated firewall instance
            node (xml.etree.ElementTree): Node of the rule
            ipv6 (bool): whether the rule is IPv6

        Returns:
            Rule: the rule

        """
        # pylint: disable=too-many-branches,too-many-locals
        # init the base of the rule
        name = node.get("name")
        rule_type = (
            "insert_point"
            if node.findall("./insert_point_rule")
            else "comment"
            if node.findall("./comment_rule")
            else "rule"
        )
        comment = node.get("comment", "")
        rank = float(node.get("rank"))
        insert_point = node.get("parent_rule_ref")
        enabled = node.get("is_disabled") == "false"
        action = None
        srcaddr = []
        dstaddr = []
        services = []
        subpolicy = None
        logtraffic = None

        # the first subnode differ between IPv6 and IPv4
        rule_n = node.findall("ipv6_rule") if ipv6 else node.findall("access_rule")

        # for comment and insert point rules, stop here
        if rule_type in ("insert_point", "comment") or rule_n == []:
            return cls(
                firewall,
                rule_type,
                name,
                action,
                srcaddr,
                dstaddr,
                services,
                subpolicy,
                logtraffic,
                rank,
                insert_point,
                comment,
                enabled,
            )

        # only take the first node of rules
        rule_n = rule_n[0]
        # retrieve action details
        for action_tag in rule_n.findall("./action"):
            action = action_tag.get("type")
            subpolicy = action_tag.get("subrule_ref")

        # retrieve logging policy
        for action_tag in rule_n.findall("./option/log_policy"):
            if action_tag.get("log_level", "none") in (
                "undefined",
                "none",
                "transient",
            ):
                logtraffic = False
            elif action_tag.get("log_level") in ("stored", "alert", "essential"):
                logtraffic = True
            else:
                logger.getLogger(__name__).warning(
                    "Unknown log level for a rule: %s",
                    action_tag.get("log_level"),
                )
                logtraffic = False

        # retrieve sources
        for src in rule_n.findall("./match_part/match_sources/match_source_ref"):
            srcaddr.append(src.get("value"))

        # retrieve destinations
        for dst in rule_n.findall(
            "./match_part/match_destinations/match_destination_ref",
        ):
            dstaddr.append(dst.get("value"))

        # retrieve services
        for srv in rule_n.findall(
            "./match_part/match_services/match_service_ref",
        ):
            services.append(srv.get("value"))

        return cls(
            firewall,
            rule_type,
            name,
            action,
            srcaddr,
            dstaddr,
            services,
            subpolicy,
            logtraffic,
            rank,
            insert_point,
            comment,
            enabled,
        )
