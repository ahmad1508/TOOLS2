# -*- coding: utf-8 -*-

"""Provide filters for Oracle BD OS"""

# Squelette du fichier filtres v0.1, par TDU (08/2015)
# ====================================================

# Project imports
from engine.core.technology import TechnologyV1
from engine.techs.common import decode, separator2table, table2bbcode


class OracleDbOs(TechnologyV1):
    """Oracle DB OS technology class"""

    desc = {
        "name": "oracledbos",
        "templates": {"full": {"fr": "oracledbos.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    # Fonctions "snippets" utilisées par les fonctions filtres
    # --------------------------------------------------------

    # Fonctions de filtres
    # --------------------
    @decode("utf-8")
    def infos_bdd(self, extract):
        return table2bbcode(
            separator2table(
                extract,
                "@@",
                header=[
                    "INSTANCE_NUMBER",
                    "INSTANCE_NAME",
                    "HOST_NAME",
                    "VERSION",
                    "STARTUP_TIME",
                    "STATUS",
                    "PARALLEL",
                    "THREAD#",
                    "ARCHIVER",
                    "LOG_SWITCH_WAIT",
                    "LOGINS",
                    "SHUTDOWN_PENDING",
                    "DATABASE_STATUS",
                    "INSTANCE_ROLE",
                    "ACTIVE_STATE",
                    "BLOCKED",
                    "CON_ID",
                    "INSTANCE_MODE",
                    "EDITION",
                    "FAMILY",
                ],
            ),
        )

    @decode("utf-8")
    def privileges(self, extract):
        return table2bbcode(
            separator2table(
                extract,
                "@@",
                header=[
                    "GRANTEE",
                    "PRIVILEGE",
                    "ADMIN_OPTION",
                    "COMMON",
                ],
            ),
        )

    @decode("utf-8")
    def release(self, extract):
        release = extract[8:]
        return "{0}.{1}.{2}.{3}".format(
            release[0:2],
            release[2:4],
            release[4:6],
            release[6:8],
        )

    @decode("utf-8")
    def confparameter(self, extract):
        return table2bbcode(
            separator2table(
                extract,
                "@@",
                header=[
                    "Parameter",
                    "Type",
                    "Value",
                ],
            ),
        )

    @decode("utf-8")
    def etc_passwd(self, extract):
        return table2bbcode(
            separator2table(
                extract,
                ":",
                header=[
                    "Nom d'utilisateur",
                    "Mot de passe",
                    "UID",
                    "GID",
                    "Commentaire",
                    "Home",
                    "Shell",
                ],
            ),
        )
