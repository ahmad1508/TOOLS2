# -*- coding: utf-8 -*-

"""Provide a helper class to manage firewall rules"""

# Project imports
from engine import logger
from engine.core import i18n
from engine.techs.fortigate.firewall_objects import (
    CustomService,
    NetworkAddress,
    NetworkGroup,
    Rule,
    ServiceGroup,
    Vip,
    VipGroup,
)

# I18N
_ = i18n.domain("fortigate")._
pgettext = i18n.domain("fortigate").pgettext


class Firewall:
    """This class defines the firewall policy objects

    Attributes:
        services (dict): a dict of `Service`, indexed by their name
        policies (list): a list of `Rule` which defines the IPv4
            filtering policy
        addresses (dict): a dict of IPv4 `NetworkObject`, indexed by
            their name
        policies6 (list): a list of `Rule` which defines the IPv4
            filtering policy
        addresses6 (dict): a dict of IPv4 `NetworkObject`, indexed by
            their name

    """

    def __init__(self):
        """Initialize the firewall from its node"""
        self._objects = {
            "services": {},
            "policies": {},
            "addresses": {},
            "vips": {},
            "vips6": {},
            "policies6": {},
            "addresses6": {},
        }

    @property
    def addresses_vips(self):
        """Return the concatenation of addresses and VIPs"""
        ret = self._objects["vips"].copy()
        ret.update(self._objects["addresses"])
        return ret

    @property
    def addresses_vips6(self):
        """Return the concatenation of addresses and VIPs"""
        ret = self._objects["vips6"].copy()
        ret.update(self._objects["addresses6"])
        return ret

    @classmethod
    def from_node(cls, node):
        """Initialize a firewall instance from a firewall node"""
        ret = cls()
        ret.parse(node)
        return ret

    def register(self, type_, name, instance):
        """Register an instance of an object on the firewall"""
        if type_ in self._objects:
            if name not in self._objects[type_]:
                self._objects[type_][name] = instance
            else:
                logger.getLogger(__name__).warning(
                    "Duplicate definition of %s: %s",
                    type_,
                    name,
                )
        else:
            logger.getLogger(__name__).error(
                "Unknown firewall object: %s",
                type_,
            )

    def __getattr__(self, key):
        """Extend the base method to expose firewall treated objects"""
        if key in self._objects:
            return self._objects[key]
        raise AttributeError(
            "'%s' object has no attribute '%s'" % (self.__class__.__name__, key),
        )

    def parse(self, node):
        """Parse the firewall tree"""
        self.parse_section(node["service"]["custom"], CustomService)
        self.parse_section(node["service"]["group"], ServiceGroup)

        self.parse_section(node["address"], NetworkAddress)
        self.parse_section(node["address6"], NetworkAddress)

        self.parse_section(node["addrgrp"], NetworkGroup)
        self.parse_section(node["addrgrp6"], NetworkGroup)

        self.parse_section(node["vip"], Vip)
        self.parse_section(node["vip6"], Vip)

        self.parse_section(node["vipgrp"], VipGroup)
        self.parse_section(node["vipgrp6"], VipGroup)

        self.parse_section(node["policy"], Rule)
        self.parse_section(node["policy6"], Rule)

    def parse_section(self, section, cls):
        """Parse a section using the given class"""
        if section is None:
            return
        for n in section.children:
            cls.from_node(self, n)
