# -*- coding: utf-8 -*-

"""Contains class definitions for tree nodes"""

# Standard libraries
import functools


class Node:
    """This class represent a node in a tree

    A node has one parent and has several children
    When a node has no parents, it is called an root node
    When a node has no children, it is called an leaf node

    Attributes:
        name (str): name of the node
        type (str): type of the node
        params (dict): the different parameters associated to the node
        parent (Node): instance of the parent, or None for root nodes
        children (list): list of all children

    """

    # Use __slots__ to reduce the memory space as much as possible
    # because configuration may contain many nodes
    __slots__ = ("name", "type", "params", "parent", "children")

    def __init__(self, name, type_, params=None, parent=None, children=None):
        """Initialize a node

        The node may be initialized with all attributes already set

        Args:
            name (str): name of the node
            type_ (str): type of the node
            params (dict, optional): dictionary of all parameters
                associated to the node
            parent (Node, optional): parent node
            children (list, optional): list of all child nodes

        Examples:
            >>> r = Node("root", "root")
            >>> n = Node("system", "config", parent=r)

        """
        self.name = name
        self.type = type_
        self.params = params or {}
        self.parent = parent
        self.children = children or []

    def __repr__(self):
        """Get the representation of the node"""
        return "<Node {type} {name}{params}>".format(
            name=self.name,
            type=self.type,
            params="".join(" %s=%r" % (k, v) for k, v in self.params.items()),
        )

    def __getattr__(self, key):
        """Get params like attributes"""
        if key in self.params:
            return self.get_param(key)
        raise AttributeError(
            "'%s' object has no attribute '%s'" % (self.__class__.__name__, key),
        )

    def __getitem__(self, key):
        """Get child as item"""
        ret = self.find(name=key)
        if len(ret) > 0:
            return ret[0]
        return None

    @property
    def is_config(self):
        """Check whether the node is a config node"""
        return self.type == "config"

    def new_child(self, name, type_):
        """Create a new child to the node

        The child is initialized with a name and a type

        Args:
            name (str): name for the child
            type_ (str): type for the child

        Returns:
            The instance of the newly created child

        """
        n = Node(name, type_, parent=self)
        self.children.append(n)
        return n

    @staticmethod
    def _to_predicate(dct):
        """Transform a dict to a predicate

        All items are considered to be conditions which should be
        matched by nodes

        Examples:
            _to_predicate({"name": "myname", "type": "config"})

            will return a callable which would return True if and only
            if both name is "myname" and type is "config"

        Args:
            dct (dict): the dict of key/value which should be matched by
            nodes

        """

        def pred(node):
            for k, v in dct.items():
                if not hasattr(node, k) or getattr(node, k) != v:
                    return False
            return True

        return pred

    def get_param(self, name, default=None, as_list=False):
        """Get a parameter on the node

        If the Node does not have such param, `default` is returned
        When the parameter is single-valued, the value is flattenned,
        unless `as_list` is True.

        Args:
            name (str): name of the param to retrieve the node
            default (optional): default value to return if the element
            does not have the parameter
            as_list (bool, optinal): whether the result should always be
                a list. Default: False

        Returns:
            The value of the attribute or `default`

        """
        if name in self.params:
            ret = self.params[name]
            # flatten single-valued params
            if len(ret) == 1 and not as_list:
                return ret[0]
            return ret
        return default

    def has(self, predicate=None, **kargs):
        """Check if first-level-child nodes validates a predicate

        The predicate is a function which is called with a node as
        argument and should return True if the node is to be selected.

        Args:
            predicate (function, optional): predicate to validate
            **kargs (dict): attributes which should be matched to create
                a predicate

        Returns:
            a `bool` which states whether the predicate has matched

        """
        return len(self.find(predicate, **kargs)) > 0

    def find(self, predicate=None, **kargs):
        """Select first-level-child nodes that validate a predicate

        The predicate is a function which is called with a node as
        argument and should return True if the node is to be selected.

        Args:
            predicate (function, optional): predicate to validate to be
                selected
            **kargs (dict): attributes which should be matched to create
                a predicate

        Returns:
            a `NodeSet` of all selected nodes

        """
        predicate = predicate or self._to_predicate(kargs)
        selected = NodeSet()
        # try to select all child nodes
        for child in self.children:
            if predicate(child):
                selected.append(child)
        return selected

    def __truediv__(self, other):
        """Find by name a child, using operator /

        Two forms are allowed:
        ```
        node / "name" == node.find(name="name")
        node / ("type", "name") == node.find(name="name, type="type")
        ```

        Args:
            other: parameters to find subnodes

        Returns:
            a `NodeSet` of all selected nodes

        Raises:
            TypeError if other is not valid

        """
        if isinstance(other, str):
            return self.find(name=other)
        if isinstance(other, tuple) and len(other) == 2:
            type_, name = other
            if isinstance(type_, str) and isinstance(name, str):
                return self.find(name=name, type=type_)
        raise TypeError(
            "unsupported operand type(s) for /: '%s' and '%s'"
            % (type(self).__name__, type(other).__name__),
        )

    def find_all(self, predicate=None, **kargs):
        """Select all child nodes that validate a predicate

        The predicate is a function which is called with a node as
        argument and should return True if the node is to be selected.

        Args:
            predicate (function, optional): predicate to validate to be
                selected
            **kargs (dict): attributes which should be matched to create
                a predicate

        Returns:
            a `NodeSet` of all selected nodes

        """
        predicate = predicate or self._to_predicate(kargs)
        selected = NodeSet()
        # check whether to select the current node
        if predicate(self):
            selected.append(self)

        # delegate to all child nodes to select sub-nodes
        for child in self.children:
            selected.extend(child.find_all(predicate))
        return selected

    def __floordiv__(self, other):
        """Find by name all children, using operator //

        Two forms are allowed:
        ```
        node // "name" == node.find_all(name="name")
        node // ("type", "name")
        == node.find_all(name="name, type="type")
        ```

        Args:
            other: parameters to find subnodes

        Returns:
            a `NodeSet` of all selected nodes

        Raises:
            TypeError if other is not valid

        """
        if isinstance(other, str):
            return self.find_all(name=other)
        if isinstance(other, tuple) and len(other) == 2:
            type_, name = other
            if isinstance(type_, str) and isinstance(name, str):
                return self.find_all(name=name, type=type_)
        raise TypeError(
            "unsupported operand type(s) for //: '%s' and '%s'"
            % (type(self).__name__, type(other).__name__),
        )

    def find_first(self, predicate=None, **kargs):
        """Select the first child that validate a predicate

        This method is similar to `select_all` except that it stops
        on the first child which validate the predicate in each branch.

        The predicate is a function which is called with a node as
        argument and should return True if the node is to be selected.

        Args:
            predicate (function, optional): predicate to validate to be
                selected
            **kargs (dict): attributes which should be matched to create
                a predicate

        Returns:
            a `NodeSet` of all selected nodes

        """
        predicate = predicate or self._to_predicate(kargs)
        selected = NodeSet()
        # check whether to select the current node
        if predicate(self):
            selected.append(self)
        else:
            # delegate to all child nodes to select sub-nodes
            for child in self.children:
                selected.extend(child.find_first(predicate))
        return selected


def _apply_to_each(func):
    """Call a given method on each element of self"""
    name = func.__name__

    @functools.wraps(func)
    def wrapper(self, *args, **kargs):
        selected = NodeSet()
        for i in self:
            selected.extend(getattr(i, name)(*args, **kargs))
        return selected

    return wrapper


class NodeSet(list):
    r"""A NodeSet is a list of Nodes

    It mainly provides helpers to search for nodes and chain methods

    Examples:
        >>> def with_name(name):
        ...     return lambda n: n.name == name
        >>> mynode.find_all(with_name("system"))\
        ... .find(with_name("settings"))

    """

    def __init__(self, base=None):
        """Initialize the NodeSet

        Args:
            base (list, optional): a list of Node to include in the set

        """
        super().__init__()
        if base is not None:
            self.extend(base)

    # mirror each search functions of Nodes
    find = _apply_to_each(Node.find)
    __truediv__ = _apply_to_each(Node.__truediv__)  # /
    find_all = _apply_to_each(Node.find_all)
    __floordiv__ = _apply_to_each(Node.__floordiv__)  # //
    find_first = _apply_to_each(Node.find_first)

    def get(self, attr, default=None):
        """Get an attribute of the first Node in the set

        If the NodeSet is empty, or the first Node does not have such
        attribute, `default` is returned

        Args:
            attr (str): name of the attribute to retrieve on the first
                node in the set
            default (optional): default value to return if the NodeSet
                is empty or the first element does not have the
                attribute

        Returns:
            The value of the attribute or `default`

        """
        if len(self) == 0:
            return default
        return getattr(self[0], attr, default)

    def get_all(self, attr, keep_exist=True, default=None):
        """Get an attribute on all Nodes in the set

        If `keep_exist` is True, get_all will only return the value of
        Nodes which have the attribute.
        If a Node does not have such attribute and `keep_exist` is
        False, `default` is returned.

        Args:
            attr (str): name of the attribute to retrieve on all nodes
                in the set
            keep_exist (bool, optional): whether to keep only existent
                attributes on nodes
            default (optional): default value to return if a Node
                does not have the attribute and `keep_exist` is False

        Returns:
            A `list` of values of the attribute on all nodes

        """
        ret = []
        for n in self:
            if keep_exist:
                if hasattr(n, attr):
                    ret.append(getattr(n, attr))
            else:
                ret.append(getattr(self[0], attr, default))
        return ret
