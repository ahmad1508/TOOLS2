# Standard libraries
import base64
import hashlib

dictionary_file = "/opt/wavestone/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt"
hashes = """
{hashes}
"""

# Pre-compute some data on hashes
to_be_cracked = []
for fhash in hashes.strip().splitlines():
    raw = base64.b64decode(fhash[3:])
    to_be_cracked.append((fhash, raw[:12], raw[12:]))

# Do the heavy work
with open(dictionary_file, "rb") as f:
    for passwd in f:
        found_hashes = []
        for i, (fhash, salt, phash) in enumerate(to_be_cracked):
            pwdhash = hashlib.sha256()
            pwdhash.update(salt)
            pwdhash.update(passwd[:-1])
            pwdhash.update(
                b"\\xA3\\x88\\xBA\\x2E\\x42\\x4C\\xB0\\x4A\\x53\\x79\\x30\\xC1\\x31\\x07\\xCC\\x3F\\xA1\\x32\\x90\\x29\\xA9\\x81\\x5B\\x70",
            )
            if pwdhash.digest() == phash:
                print("Found password for %s ==> %s" % (fhash, passwd[:-1]))
                found_hashes.append(i)
        for i in found_hashes[::-1]:
            to_be_cracked.pop(i)
        if len(to_be_cracked) == 0:
            print("No more hashes to crack")
            break

if len(to_be_cracked) > 0:
    print("Could not crack all hashes")
