# -*- coding: utf-8 -*-

"""Load the Fortigate filters"""

# Project imports
import engine.techs.fortigate.filters  # noqa: F401
