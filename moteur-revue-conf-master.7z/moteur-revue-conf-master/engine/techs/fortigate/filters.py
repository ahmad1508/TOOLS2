# -*- coding: utf-8 -*-

"""Provides filters for Fortigate review"""

# Standard libraries
from collections import OrderedDict
import functools
import ipaddress
from operator import itemgetter
import os

# Project imports
from engine import logger
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n
from engine.core.technology import Technology
from engine.techs.common import (
    cell_background,
    conformity_row,
    list2bbcode,
    remove_column,
    table2bbcode,
)
from engine.techs.fortigate.firewall import Firewall
from engine.techs.fortigate.firewall_objects import (
    CustomService,
    NetworkAddress,
    NetworkGroup,
    NetworkObject,
    ServiceGroup,
    Vip,
    VipGroup,
    VipObject,
)
from engine.techs.fortigate.parser import Parser

# I18N
_ = i18n.domain("fortigate")._
N_ = i18n.domain("fortigate").N_
pgettext = i18n.domain("fortigate").pgettext
ngettext = i18n.domain("fortigate").ngettext


class DefaulterI18nDict(dict):
    """Extend dict to provide a default entry if not found"""

    def __getitem__(self, key):
        """Override to provide the default entry if needed"""
        # Because of the dict position in the class body, we use
        # this class to defer translation
        try:
            return M(_(super().__getitem__(key)))
        except KeyError:
            return (
                # TRANSLATION: No need to be transtaled
                M(_(self["_default_with_value"])) % key
                if "_default_with_value" in self
                # TRANSLATION: No need to be transtaled
                else M(_(self["_default"]))
            )


def cached(func):
    """Decorate a functions whose returned value should be cached"""

    @functools.wraps(func)
    def wrapper(self, *args):
        name = func.__name__

        # check the cache
        if name in self._cache and args in self._cache[name]:
            return self._cache[name][args]

        # do the normal call
        ret = func(self, *args)

        # save the result in the cache
        if name not in self._cache:
            self._cache[name] = {}
        self._cache[name][args] = ret

        return ret

    return wrapper


def ordereddict_value(func):
    """Wrap a key getter for sorted() for OrderedDict"""

    def wrap(item):
        return func(item[1])

    return wrap


def get_config_or_param(node, name):
    """Get list content which may be stored as config or param

    Sometime, list may be stored as::
    ```
    config <name>
        edit <item1>
           set name <item1>
        next
        edit <item2>
           set name <item2>
        next
    end
    ```

    or as

    ```
    set <name> <item1> <item2>
    ```

    Args:
        node (Node): root node to search
        name (str): name of the list to retrieve

    Returns:
        the `list` of items

    """
    # first try to use the config subnode
    if node.has(name=name, type="config"):
        # if config, either use the name param or the node name
        return [n.get_param("name", n.name) for n in node[name].children]
    return node.get_param(name, [], as_list=True)


class Fortigate(Technology):
    """Fortigate technology class"""

    desc = {
        "name": "fortigate",
        "templates": {"full": {"fr": "fortigate/fr/fortigate_full.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    def __init__(self):
        """Extend the base class"""
        super().__init__()
        # cache to prevent recomputing several time the same thing
        self._cache = {}

    def preprocessors(self):
        """Perform preprocessors on extracts.

        This method is used to analyze/parse extracts prior to
        templating filters. This method can store parsed data within
        the ``dict`` :py:attr:`self.artifacts`.

        To be better handle multi-input reviews, this methods should
        also set the :py:attr:`self.hostname` of the reviewed device,
        when possible.

        Override the parent method to parse inputs.
        """
        # decode the config file
        config = self.extracts.decode("utf-8")

        # parse the data of the fortigate (in the initial comments)
        lines = config.splitlines()
        for line in lines:
            # stop after the first non-comment line
            if not line.startswith("#"):
                break
            # the initial comments are colon-separated key=values
            for conf in line[1:].split(":"):
                key, val = conf.strip().split("=", 1)
                self.artifacts[key] = val

        # parse tree
        self.artifacts["tree"] = Parser.parse(config)

        # variable to check whether VDOMs are activated
        self.artifacts["vdom"] = (self.artifacts["tree"] // "system" / "global").get(
            "vdom-admin",
            "disable",
        ) == "enable"

        # Retrieve the hostname of the firewall
        hostname = (self.artifacts["tree"] // "system" / "global").get("hostname")
        # do not update hostname if failed to retrieve it (keep default)
        if hostname:
            self.hostname = hostname

    @staticmethod
    def to_ip(ip, mask):
        """Transform a IP + netmask to a CIDR notation"""
        return ipaddress.IPv4Interface("%s/%s" % (ip, mask))

    def vdom_based_message(self, msg_novdom, msg_vdom, vdom):
        """Return a message with VDOM info only for VDOM enabled devices

        Args:
            msg_novdom (str): message to return when VDOMS are not
                enabled.
            msg_vdom (str): message to return when VDOMS are enabled.
                The message must contain a `{VDOM}` format where to
                insert the VDOM name.
            vdom (str): name of the VDOM to associate the message with.

        Returns:
            `msg_novdom` if VDOMs are not enabled or `msg_vdom`
            formatted with the VDOM name, if VDOMs are enabled.

        """
        if not self.artifacts["vdom"] and vdom == "root":
            # VDOM-agnostic messages when VDOMs are not enabled
            return msg_novdom
        return msg_vdom.format(VDOM=vdom)

    @cached
    def get_version(self):
        """Retrieve the version of the Fortigate as a tuple"""
        # the version is contained in the initial comments
        # for instance
        # #config-version=FG10E0-6.0.9-FW-build0335-200121
        return tuple(
            int(x) for x in self.artifacts["config-version"].split("-")[1].split(".")
        )

    @cached
    def get_vdoms(self):
        """Retrieve the list of VDOMs"""
        # first get the nodes which defines an VDOM
        vdoms = (self.artifacts["tree"] / ("config", "vdom")).find()

        # get the name and the status for each vdom
        # pre-init with the root VDOM
        ret = OrderedDict({"root": {"name": "root", "enabled": True}})
        for n in vdoms:
            ret[n.name] = {
                "name": n.name,
                "enabled": not (n / "system" / "settings").get("status", "enable")
                == "disable",
            }
        return ret

    @cached
    def get_firewall(self, vdom):
        """Get the firewall configuration for a given VDOM"""
        # in case VDOMs are not configured, the firewall node may
        # be stored at the root level
        if not self.artifacts["vdom"]:
            node = self.artifacts["tree"] // ("config", "firewall")
        else:
            node = (
                self.artifacts["tree"]
                / ("config", "vdom")
                / vdom
                // ("config", "firewall")
            )
        if len(node) > 0:
            return Firewall.from_node(node[0])
        logger.getLogger(__name__).error(
            "Could not find firewall node for VDOM: %s",
            vdom,
        )
        return Firewall()

    @cached
    def get_interfaces(self):
        """Retrieve the list of interfaces"""
        # first get the nodes which defines interfaces
        ifaces_tree = (
            self.artifacts["tree"] // ("config", "system") / ("config", "interface")
        ).find()

        # Create a usable object from the tree
        ifaces = OrderedDict()
        aggregated = []
        for n in ifaces_tree:
            # save the interface
            iface = {
                "name": n.name,
                "alias": n.get_param("alias", ""),
                "type": n.get_param("type", "physical"),
                "status": n.get_param("status", "up"),
                "ip": self.to_ip(*n.ip) if hasattr(n, "ip") else None,
                "ipv6": ipaddress.IPv6Interface(getattr(n["ipv6"], "ip6-address"))
                if n.has(name="ipv6", type="config")
                and n["ipv6"].get_param("ip6-address") is not None
                else None,
                "vlan": int(n.get_param("vlanid", -1)),
                "vdom": n.get_param("vdom", "root"),
                "aggregated": n.get_param("member", []),
                "admin_services": n.get_param("allowaccess", [], as_list=True),
                "node": n,
            }
            ifaces[n.name] = iface

            # save all aggregated links
            if iface["type"] == "aggregate":
                aggregated.extend(iface["aggregated"])

        # filter aggregated links
        for iface in aggregated:
            if iface in ifaces:
                del ifaces[iface]

        return ifaces

    @cached
    def get_user_group(self):
        """Retrieve the list of users and groups

        Both users and groups are provided in a dict, indexed
        by the tuple `(vdom, name)` or only `name` for admins.
        It ease the resolution of group membership.
        The values correspond to the tuple composed of
        the node type (e.g. local, ldap, tacacs+ for users) and the node
        which is indexed.

        Returns:
            a `tuple` of the `dict` of admins, the `dict` of users and
            the `dict` of groups.

        """
        # first get the admins
        admins = {
            n.get_param("name", n.name): n
            for n in (self.artifacts["tree"] // "system" / "admin").find()
        }

        # then get all user
        users = {}
        for type_ in ("local", "ldap", "tacacs+", "radius"):
            # may be either linked to a vdom or at the root if vdoms are
            # disabled
            if self.artifacts["vdom"]:
                subnodes = [
                    (v, n)
                    for v in self.get_vdoms()
                    for n in (
                        self.artifacts["tree"] / "vdom" / v / "user" / type_
                    ).find()
                ]
            else:
                subnodes = [
                    ("root", n)
                    for n in (self.artifacts["tree"] / "user" / type_).find()
                ]
            for vdom, node in subnodes:
                users[(vdom, node.get_param("name", node.name))] = (
                    type_,
                    node,
                )

        # finally get the group
        groups = {}
        for type_ in ("group",):
            # may be either linked to a vdom or at the root if vdoms are
            # disabled
            if self.artifacts["vdom"]:
                subnodes = [
                    (v, n)
                    for v in self.get_vdoms()
                    for n in (
                        self.artifacts["tree"] / "vdom" / v / "user" / type_
                    ).find()
                ]
            else:
                subnodes = [
                    ("root", n)
                    for n in (self.artifacts["tree"] / "user" / type_).find()
                ]
            for vdom, node in subnodes:
                groups[(vdom, node.get_param("name", node.name))] = (
                    type_,
                    node,
                )

        # returns all 3 dict
        return admins, users, groups

    @cached
    def get_pwd_policy(self):
        """Retrieve the password policy

        Depending on the version of the firewall, the policy is
        configured differently.

        The returned value is normalized the as following::
        ```python
        {
            "status": bool(),
            "apply-to": list(),
            "min-len": int(),
            "lower": bool(),
            "upper": bool(),
            "number": bool(),
            "special": bool(),
            "force-diff": bool(),
            "expire": bool(),
            "max-age": int(),
        }
        ```

        Returns:
            A `dict` with the policy

        """
        if self.get_version() < (5, 0):
            return self._get_pwd_policy_v4()
        return self._get_pwd_policy_v5()

    def _get_pwd_policy_v4(self):
        """Retrieve the password policy for Fortigate V4 and earlier"""
        # get the password policy node in the global node
        node = self.artifacts["tree"] // "system" / "password-policy"

        def as_list(item):
            if isinstance(item, list):
                return item
            return [item]

        def w_def(item, lam):
            # retrieve the item while respecting the default value
            # and call the lambda with it if not the default value
            ret = node.get(item, None)
            if ret is not None:
                ret = lam(ret)
            return ret

        return {
            "status": w_def(
                "status",
                lambda v: _("Enable") if v == "enable" else _("Disable"),
            ),
            "applied-on-admin": w_def(
                "apply-to",
                lambda v: _("Yes") if "admin-password" in as_list(v) else _("No"),
            ),
            "min-len": w_def("minimum-length", lambda v: int(v)),
            "lower": w_def(
                "must-contain",
                lambda v: _("Yes") if "lower-case-letter" in as_list(v) else _("No"),
            ),
            "upper": w_def(
                "must-contain",
                lambda v: _("Yes") if "upper-case-letter" in as_list(v) else _("No"),
            ),
            "number": w_def(
                "must-contain",
                lambda v: _("Yes") if "number" in as_list(v) else _("No"),
            ),
            "special": w_def(
                "must-contain",
                lambda v: _("Yes") if "non-alphanumeric" in as_list(v) else _("No"),
            ),
            "force-diff": w_def(
                "minimum-characters-change",
                lambda v: _("Yes") if int(v) > 4 else _("No"),
            ),
            "expire": w_def(
                "admin-password-expire",
                lambda v: _("Enabled") if int(v) > 0 else _("Disabled"),
            ),
            "max-age": w_def("admin-password-expire", lambda v: int(v)),
        }

    def _get_pwd_policy_v5(self):
        """Retrieve the password policy for Fortigate V5.4 and later"""
        # get the password policy node in the global node
        node = self.artifacts["tree"] // "system" / "password-policy"

        def as_list(item):
            if isinstance(item, list):
                return item
            return [item]

        def w_def(item, lam):
            # retrieve the item while respecting the default value
            # and call the lambda with it if not the default value
            ret = node.get(item, None)
            if ret is not None:
                ret = lam(ret)
            return ret

        return {
            "status": w_def(
                "status",
                lambda v: _("Enabled") if v == "enable" else _("Disabled"),
            ),
            "applied-on-admin": w_def(
                "apply-to",
                lambda v: _("Yes") if "admin-password" in as_list(v) else _("No"),
            ),
            "min-len": w_def("minimum-length", lambda v: int(v)),
            "lower": w_def(
                "min-lower-case-letter",
                lambda v: _("Yes") if int(v) > 0 else _("No"),
            ),
            "upper": w_def(
                "min-upper-case-letter",
                lambda v: _("Yes") if int(v) > 0 else _("No"),
            ),
            "number": w_def(
                "min-number",
                lambda v: _("Yes") if int(v) > 0 else _("No"),
            ),
            "special": w_def(
                "min-non-alphanumeric",
                lambda v: _("Yes") if int(v) > 0 else _("No"),
            ),
            "force-diff": w_def(
                "change-4-characters",
                lambda v: _("Yes") if v == "enable" else _("No"),
            ),
            "expire": w_def(
                "expire-status",
                lambda v: _("Enabled") if v == "enable" else _("Disabled"),
            ),
            "max-age": w_def("expire-day", lambda v: int(v)),
        }

    @cached
    def has_ipv6(self, vdom):
        """Return whether IPv6 is used on the vdom"""
        return (
            len(
                [
                    i
                    for i in self.get_interfaces().values()
                    if i["ipv6"] and i["vdom"] == vdom
                ],
            )
            > 0
        )

    def fw_version(self):
        """Check the version of the FW"""
        return M(
            _(
                "The reviewed Fortigate is [code]{hostname}[/code], with "
                "the configuration:[codeblock]{config}[/codeblock]"
                "The version of FortiOS installed on the device is then "
                "[b]{version}[/b]",
            ),
        ).format(
            hostname=self.hostname,
            config=self.artifacts["config-version"],
            version=".".join(str(x) for x in self.get_version()),
        )

    def vdom_list(self):
        """Retrieve the list of VDOMs"""
        if not self.artifacts["vdom"]:
            return M(_("The firewall [b]does not use VDOM feature[/b]."))

        # if it is enabled, retrieve the list of VDOM and their status
        vdoms = self.get_vdoms()

        # get the name and the status for each vdom
        tbl = [[pgettext("VDOM", "Name"), pgettext("VDOM", "Status")]]
        for v in vdoms.values():
            tbl.append([v["name"], _("Enabled") if v["enabled"] else _("Disabled")])

        return table2bbcode(tbl, _("List of VDOMs on the firewall"))

    def network_ifaces(self):
        """List the net interfaces"""
        # retrieve the list of interfaces
        ifaces = self.get_interfaces()

        # sort the OrderedDict to be displayed
        ifaces = OrderedDict(
            sorted(
                ifaces.items(),
                key=ordereddict_value(itemgetter("vdom", "type", "vlan", "name")),
            ),
        )

        tbl = [
            [
                pgettext("List of interfaces", "VDOM"),
                pgettext("List of interfaces", "Name"),
                pgettext("List of interfaces", "Alias"),
                pgettext("List of interfaces", "Type"),
                pgettext("List of interfaces", "Address"),
                pgettext("List of interfaces", "IPv6"),
                pgettext("List of interfaces", "Public"),
                pgettext("List of interfaces", "Extra"),
            ],
        ]
        # List all interfaces
        for iface in ifaces.values():
            # add the line only if the iface is up
            if iface["status"] != "down":
                # create the extra field
                extra = []
                if iface["vlan"] >= 0:
                    extra.append(
                        pgettext("List of interfaces", "VLAN: {0}").format(
                            iface["vlan"],
                        ),
                    )
                if iface["type"] == "aggregate":
                    extra.append(
                        pgettext(
                            "List of interfaces",
                            "Aggregated interfaces: {0}",
                        ).format(", ".join(iface["aggregated"])),
                    )

                # Add the line to the table
                tbl.append(
                    [
                        iface["vdom"],
                        iface["name"],
                        iface["alias"],
                        iface["type"],
                        "" if iface["ip"] is None else iface["ip"].with_prefixlen,
                        "" if iface["ipv6"] is None else iface["ipv6"].with_prefixlen,
                        _("Yes")
                        if (iface["ip"] is not None and iface["ip"].ip.is_global)
                        or (iface["ipv6"] is not None and iface["ipv6"].ip.is_global)
                        else _("No"),
                        " ".join(extra),
                    ],
                )

        # filter the table depending on the VDOM configuration
        if not self.artifacts["vdom"]:
            tbl = remove_column(tbl, pgettext("List of interfaces", "VDOM"))

        return M(
            _("The following table lists all network interfaces on the" " firewall:"),
        ) + table2bbcode(tbl, _("List of network interfaces on the firewall"))

    def check_ipv6(self):
        """Check whether ipv6 is used"""
        # Check whether an interface is IPv6 enabled
        ifaces = self.get_interfaces()
        ipv6_ifaces = []
        for iface in ifaces.values():
            if iface["ipv6"]:
                ipv6_ifaces.append(iface)

        # get the associated VDOMs
        vdoms = {x["vdom"] for x in ipv6_ifaces}

        # handle the case of no IPv6
        if len(ipv6_ifaces) == 0:
            return M(
                _(
                    "The firewall is not configured to expose any IPv6" " interface.\n",
                ),
            )

        # for interfaces with IPv6,
        # verify that each vdom with IPv6 also has a policy6
        good = True
        for vdom in vdoms:
            if len(self.get_firewall(vdom).policies6) == 0:
                self.findings.vuln(
                    self.vdom_based_message(
                        # VDOM-agnostic messages
                        M(
                            _(
                                "IPv6 is used by some interfaces, but no "
                                "IPv6 filtering policies are configured",
                            ),
                        ),
                        # VDOM-based messages
                        M(
                            _(
                                "The VDOM [code]{VDOM}[/code] uses IPv6 "
                                "but has no filtering policies",
                            ),
                        ),
                        vdom,
                    ),
                )
                good = False
            else:
                self.findings.good(
                    self.vdom_based_message(
                        # VDOM-agnostic messages
                        M(
                            _(
                                "IPv6 is used by some interfaces and an "
                                "IPv6 filtering policy is configured",
                            ),
                        ),
                        # VDOM-based messages
                        M(
                            _(
                                "The VDOM [code]{VDOM}[/code] uses IPv6 "
                                "and has an IPv6 filtering policy",
                            ),
                        ),
                        vdom,
                    ),
                )

        return (
            _("Every IPv6 interface also has a IPv6 filtering policy" " configured.\n")
            if good
            else ""
        )

    def check_net_services(self):
        """Check network services"""
        global_status = False

        # Get the status of the DHCP, DNS & proxy service
        status_tab = [
            [
                pgettext("List of network services", "Service"),
                pgettext("List of network services", "Status"),
                pgettext("List of network services", "Interfaces"),
            ],
        ]

        # helper to manage status colors
        def _status(enabled):
            return (
                cell_background("orange", M(pgettext("Service status", "Enabled")))
                if enabled
                else cell_background("green", M(pgettext("Service status", "Disabled")))
            )

        # DHCP service: check if some dhcp servers are created
        # doc: https://docs.fortinet.com/document/fortigate/6.2.0/
        #      cookbook/783526/dhcp-server
        dhcp_srv = (self.artifacts["tree"] / "system" / "dhcp" / "server").find(
            lambda n: n.get_param("status", "enable") == "enable",
        )
        status = len(dhcp_srv) > 0
        status_tab.append(
            [
                M(pgettext("List of network services", "DHCP")),
                _status(status),
                list2bbcode(
                    (M("[code]%s[/code]") % d.interface for d in dhcp_srv),
                    False,
                ),
            ],
        )
        global_status |= status

        # DNS service: check if some DNS zones are created
        # doc: https://docs.fortinet.com/document/fortigate/6.2.0/
        #      cookbook/121810/using-a-fortigate-as-a-dns-server
        dns_srv = (self.artifacts["tree"] / "system" / "dns" / "server").find()
        status = len(dns_srv) > 0
        status_tab.append(
            [
                M(pgettext("List of network services", "DNS")),
                _status(status),
                list2bbcode((M("[code]%s[/code]") % d.name for d in dns_srv), False),
            ],
        )
        global_status |= status

        # Explicit proxy service: check if it is enable and list ifaces
        # doc: https://docs.fortinet.com/document/fortigate/6.2.0/
        #      cookbook/300428/explicit-web-proxy
        status = (self.artifacts["tree"] / "web-proxy" / "explicit").get(
            "status",
            "disable",
        ) == "enable"
        exp_proxy_ifaces = (self.artifacts["tree"] / "system" / "interface").find_all(
            lambda n: n.get_param("explicit-web-proxy", "disable") == "enable",
        )
        status_tab.append(
            [
                M(pgettext("List of network services", "Explicit proxy")),
                _status(status),
                list2bbcode(
                    (M("[code]%s[/code]") % d.name for d in exp_proxy_ifaces),
                    False,
                ),
            ],
        )
        global_status |= status

        # return the text to display
        return (
            _("The following services were found on the Fortigate:\n")
            + table2bbcode(
                status_tab,
                _("Status of network services provided by the firewall"),
            )
            + (
                M(
                    _(
                        "It is advised to [b]check whether the each service"
                        " has to be exposed[/b] on the interfaces.",
                    ),
                )
                if global_status
                else ""
            )
        )

    def auth_sources_ldap(self):
        """Check LDAP authentication sources"""
        # parse the list of LDAP connections:
        __, users, __ = self.get_user_group()
        ldap_srv = [
            (vdom, node)
            for (vdom, __), (type_, node) in users.items()
            if type_ == "ldap"
        ]

        # stop here if LDAP is not configured
        if len(ldap_srv) == 0:
            return M(
                _("[b]No LDAP connections[/b] are configured in the" " Fortigate.")
            )

        # parse all servers and create a compliance table
        tab = [
            [
                pgettext("Authentication sources", "VDOM"),
                pgettext("Authentication sources", "Name"),
                pgettext("Authentication sources", "Server"),
                pgettext("Authentication sources", "LDAPS"),
                pgettext("Authentication sources", "Minimum TLS version"),
            ],
        ]
        # to keep track of vulnerabilities
        ldaps_vuln = []
        tls_vuln = []
        ldaps_good = []
        tls_good = []

        # retrieve the default TLS version
        global_tls = (self.artifacts["tree"] // "system" / "global").get(
            "ssl-min-proto-version",
            "TLSv1-2",
        )

        # browse each LDAP server
        GOOD_TLS = ("TLSv1-2", "TLSv1-3")  # noqa: N806
        BAD_TLS = ("SSLv3", "TLSv1", "TLSv1-1")  # noqa: N806
        for vdom, srv in ldap_srv:
            # parse interesting options
            sec = srv.get_param("secure", "disable")
            tls = srv.get_param("ssl-min-proto-version", "default")
            if tls == "default":
                tls = global_tls

            # update the table
            tab.append(
                [
                    # VDOM
                    vdom,
                    # name
                    srv.name,
                    # server
                    srv.server,
                    # LDAPS
                    cell_background("green", M(_("Yes")))
                    if sec == "ldaps"
                    else cell_background("green", M(_("StartTLS")))
                    if sec == "starttls"
                    else cell_background("red", M(_("No")))
                    if sec == "disable"
                    else cell_background(
                        "orange",
                        M(_("Unknown configuration: %s")) % sec,
                    ),
                    # TLS version
                    cell_background("red", M(_("N/A")))
                    if sec == "disable"
                    else cell_background("green", tls)
                    if tls in GOOD_TLS
                    else cell_background("red", tls)
                    if tls in BAD_TLS
                    else cell_background(
                        "orange",
                        M(_("Unknown configuration: %s")) % tls,
                    ),
                ],
            )

            # update the vulnerability/good tables
            if sec == "disable":
                ldaps_vuln.append(srv.name)
            else:
                ldaps_good.append(srv.name)
                if tls in BAD_TLS:
                    tls_vuln.append(srv.name)
                else:
                    tls_good.append(srv.name)

        # Create the vulnerabilities text
        if len(ldaps_vuln) > 0:
            self.findings.vuln(
                M(
                    _(
                        "The following LDAP connections are performed through"
                        " an unsecured LDAP channel:%s",
                    ),
                )
                % list2bbcode(ldaps_vuln),
            )
        if len(ldaps_good) > 0:
            self.findings.good(
                M(
                    _(
                        "The following LDAP connections are correctly"
                        " performed through a secured LDAPS channel:%s",
                    ),
                )
                % list2bbcode(ldaps_good),
            )
        if len(tls_vuln) > 0:
            self.findings.vuln(
                M(
                    _(
                        "The following encrypted LDAP connections allow the"
                        " use of unsecured SSL/TLS protocols:%s",
                    ),
                )
                % list2bbcode(tls_vuln),
            )
        if len(tls_good) > 0:
            self.findings.vuln(
                M(
                    _(
                        "The following encrypted LDAP connections only support"
                        " secured SSL/TLS protocols:%s",
                    ),
                )
                % list2bbcode(tls_good),
            )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("Authentication sources", "VDOM"))

        # return the text for the report
        return M(
            _("The following LDAP connections were configured on the" " firewall:"),
        ) + table2bbcode(tab, _("List of configured LDAP connections"))

    def auth_sources_radius(self):
        """Check RADIUS authentication sources"""
        # parse the list of RADIUS connections:
        __, users, __ = self.get_user_group()
        radius_srv = [
            (vdom, node)
            for (vdom, __), (type_, node) in users.items()
            if type_ == "radius"
        ]

        # stop here if RADIUS is not configured
        if len(radius_srv) == 0:
            return M(
                _("[b]No RADIUS connections[/b] are configured in the" " Fortigate.")
            )

        # parse all servers and create a compliance table
        tab = [
            [
                pgettext("Authentication sources", "VDOM"),
                pgettext("Authentication sources", "Name"),
                pgettext("Authentication sources", "Server"),
                pgettext("Authentication sources", "Authentication Scheme"),
            ],
        ]

        # browse each RADIUS server
        for vdom, srv in radius_srv:
            # update the table
            tab.append(
                [
                    # VDOM
                    vdom,
                    # name
                    srv.name,
                    # server
                    srv.server,
                    # authentication scheme
                    srv.get_param("auth-type", "auto"),
                ],
            )

        # Create the vulnerabilities text
        self.findings.vuln(
            M(
                _(
                    "The use of RADIUS for user authentication is to be"
                    " avoided: authentication schemes supported by the"
                    " Fortigate are not sufficient to ensure password stay"
                    " secure",
                ),
            ),
        )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("Authentication sources", "VDOM"))

        # return the text for the report
        return M(
            _("The following RADIUS connections were configured on the" " firewall:"),
        ) + table2bbcode(tab, _("List of configured RADIUS connections"))

    def auth_sources_tacacs(self):
        """Check TACACS+ authentication sources"""
        # parse the list of TACACS+ connections:
        __, users, __ = self.get_user_group()
        tacacs_srv = [
            (vdom, node)
            for (vdom, __), (type_, node) in users.items()
            if type_ == "tacacs+"
        ]

        # stop here if TACACS+ is not configured
        if len(tacacs_srv) == 0:
            return M(
                _("[b]No TACACS+ connections[/b] are configured in the" " Fortigate."),
            )

        # parse all servers and create a compliance table
        tab = [
            [
                pgettext("Authentication sources", "VDOM"),
                pgettext("Authentication sources", "Name"),
                pgettext("Authentication sources", "Server"),
                pgettext("Authentication sources", "Authentication Scheme"),
            ],
        ]

        # browse each TACACS+ server
        for vdom, srv in tacacs_srv:
            # update the table
            tab.append(
                [
                    # VDOM
                    vdom,
                    # name
                    srv.name,
                    # server
                    srv.server,
                    # authentication scheme
                    srv.get_param("authen-type", "auto"),
                ],
            )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("Authentication sources", "VDOM"))

        # return the text for the report
        return M(
            _("The following TACACS+ connections were configured on the" " firewall:"),
        ) + table2bbcode(tab, _("List of configured TACACS+ connections"))

    # dict to save the formatting of remote groups
    USER_TYPE = DefaulterI18nDict(
        {
            "ldap": N_("LDAP - %s"),
            "radius": N_("RADIUS - %s"),
            "tacacs+": N_("TACACS+ - %s"),
            "local": N_("Local user - %s"),
            "_default": N_("Unknown type - %s"),
        },
    )

    # dict to save the formatting of groups types
    GROUP_TYPE = DefaulterI18nDict(
        {
            "group": N_("Local group"),
            "_default_with_value": N_("Unknown group type - %s"),
        },
    )

    def list_admins(self):
        """List all the administrators"""
        # parse the list of users
        admins, users, groups = self.get_user_group()

        # parse all users
        tab = [
            [
                pgettext("List of users", "Name"),
                pgettext("List of users", "Profile"),
                pgettext("List of users", "Local/Remote"),
                pgettext("List of users", "Remote connection"),
                pgettext("List of users", "Two factor authentication"),
                pgettext("List of users", "Restrictions"),
            ],
        ]
        mfa_better = False

        # browse each admins
        for name, adm in admins.items():
            # handle remote connection resolution
            remote = adm.get_param("remote-auth", "disable") == "enable"
            if remote:
                try:
                    rem_group = groups[("root", adm.get_param("remote-group"))][1]

                    # members of a group may be:
                    #  - a param (set member <name1> <name2>…)
                    #  - a config (config member { edit <name1> next …})
                    rem_members = get_config_or_param(rem_group, "member")

                    # try to find each member the users (root vdom)
                    h_members = []
                    for m in rem_members:
                        if ("root", m) in users:
                            type_ = users[("root", m)][0]
                            h_members.append(self.USER_TYPE[type_] % m)
                        else:
                            h_members.append(
                                M(_("Remote group member not found: %s")) % m,
                            )
                    remote_conn = list2bbcode(h_members, False)
                except KeyError:
                    remote_conn = M(_("Remote group not found"))
            else:
                remote_conn = ""
            # handle MFA vuln
            mfa = adm.get_param("two-factor", "disable")
            mfa_better |= mfa == "disable"

            # handle resolution of restrictions
            restrictions = []
            # VDOM
            vdom_rest = get_config_or_param(adm, "vdom")
            if len(vdom_rest) > 0:
                restrictions.append(M(_("VDOM:%s")) % list2bbcode(vdom_rest, False))
            # Trusted hosts
            trusted_h = []
            for i in range(1, 11):
                if adm.get_param("trusthost%d" % i):
                    trusted_h.append(
                        self.to_ip(*adm.get_param("trusthost%d" % i)).with_prefixlen,
                    )
            for i in range(1, 11):
                if adm.get_param("ip6-trusthost%d" % i):
                    trusted_h.append(
                        ipaddress.IPv6Interface(
                            adm.get_param("ip6-trusthost%d" % i),
                        ).with_prefixlen,
                    )
            if len(trusted_h) > 0:
                restrictions.append(
                    M(_("Trusted hosts:%s")) % list2bbcode(trusted_h, False),
                )

            # update the table
            tab.append(
                [
                    # name
                    name,
                    # profile
                    adm.accprofile,
                    # remote
                    pgettext("List of users", "Remote")
                    if remote
                    else pgettext("List of users", "Local"),
                    # remote connection
                    remote_conn,
                    # MFA
                    cell_background("orange", M(_("Disabled")))
                    if mfa == "disable"
                    else cell_background("green", mfa),
                    # restrictions
                    M("\n").join(restrictions),
                ],
            )

        # Create the vulnerabilities text
        if mfa_better:
            self.findings.improvement(
                M(
                    _(
                        "It is recommended to activate multifactor "
                        "authentication on administrator accounts",
                    ),
                ),
            )
        else:
            self.findings.good(
                M(
                    _(
                        "Multifactor authentication is activated for all "
                        "administrator accounts",
                    ),
                ),
            )

        # return the text for the report
        return M(
            _("The following administrator accounts were found on the" " firewall:"),
        ) + table2bbcode(tab, _("List of administrator accounts"))

    def list_users(self):
        """List all the users"""
        # parse the list of users
        __, users, __ = self.get_user_group()
        users = [
            (vdom, node)
            for (vdom, __), (type_, node) in users.items()
            if type_ == "local"
        ]

        # stop here if no users are configured
        if len(users) == 0:
            return M(_("[b]No local users[/b] are configured in the Fortigate."))

        # parse all users
        tab = [
            [
                pgettext("List of users", "VDOM"),
                pgettext("List of users", "Name"),
                pgettext("List of users", "Status"),
                pgettext("List of users", "Type"),
                pgettext("List of users", "Two factor authentication"),
            ],
        ]

        # browse each admins
        for vdom, usr in users:
            # handle remote connection resolution
            usr_type = usr.get_param("type")
            if usr_type == "password":
                type_ = M(_("Local account"))
            elif usr_type == "radius":
                type_ = M(_("From RADIUS %s")) % usr.get_param("radius-server")
            elif usr_type == "tacacs+":
                type_ = M(_("From TACACS+ %s")) % usr.get_param("tacacs+-server")
            elif usr_type == "ldap":
                type_ = M(_("From LDAP %s")) % usr.get_param("ldap-server")
            else:
                type_ = M(_("Unknown type: %s")) % usr_type

            mfa = usr.get_param("two-factor", "disable")

            # update the table
            tab.append(
                [
                    # VDOM
                    vdom,
                    # name
                    usr.name,
                    # status
                    _("Enabled")
                    if usr.get_param("status", "enable") == "enable"
                    else _("Disabled"),
                    # type
                    type_,
                    # MFA
                    cell_background("orange", M(_("Disabled")))
                    if mfa == "disable"
                    else cell_background("green", mfa),
                ],
            )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("List of users", "VDOM"))

        # return the text for the report
        return M(
            _("The following user accounts were found on the firewall:"),
        ) + table2bbcode(tab, _("List of user accounts"))

    def list_groups(self):
        """List all the groups"""
        # parse the list of users
        __, users, groups = self.get_user_group()

        # parse all users
        tab = [
            [
                pgettext("List of users", "VDOM"),
                pgettext("List of users", "Name"),
                pgettext("List of users", "Type"),
                pgettext("List of users", "Members"),
            ],
        ]

        # browse each groups
        for (vdom, name), (grp_type, grp) in groups.items():
            # members of a group may be:
            #  - a param (set member <name1> <name2>…)
            #  - a config (config member { edit <name1> next …})
            members = get_config_or_param(grp, "member")

            # try to find each member in users
            h_members = []
            for m in members:
                if (vdom, m) in users:
                    usr_type = users[(vdom, m)][0]
                    h_members.append(self.USER_TYPE[usr_type] % m)
                else:
                    h_members.append(M(_("Group member not found: %s")) % m)

            # update the table
            tab.append(
                [
                    # VDOM
                    vdom,
                    # name
                    name,
                    # type
                    self.GROUP_TYPE[grp_type],
                    # members
                    list2bbcode(h_members, False),
                ],
            )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("List of users", "VDOM"))

        # return the text for the report
        return M(_("The following groups were found on the firewall:")) + table2bbcode(
            tab,
            _("List of groups"),
        )

    def pwd_policy(self):
        """Check the password policy"""
        # get the policy
        policy = self.get_pwd_policy()

        # build the conformity table
        tab = [
            [
                pgettext("conformity", "Policy"),
                pgettext("conformity", "Recommended value"),
                pgettext("conformity", "Seen value"),
                pgettext("conformity", "Status"),
            ],
        ]

        def new_row(policy, desc, *args):
            t, c = conformity_row(policy, *args)
            tab.append(t)
            if not c:
                self.findings.vuln(desc)

        # Activate password policy
        new_row(
            M(pgettext("pwd policy", "Activate the password policy")),
            M(pgettext("pwd policy", "The password policy should be enabled")),
            _("Enabled"),
            policy.get("status"),
            _("Disabled"),
            lambda v, r: v == r,
        )

        # Enforce the password policy on admin password
        new_row(
            M(
                pgettext(
                    "pwd policy",
                    "Password policy is enforced on administrator passwords",
                ),
            ),
            M(
                pgettext(
                    "pwd policy",
                    "The password policy should be enforced on administrator"
                    " passwords",
                ),
            ),
            _("Yes"),
            policy.get("applied-on-admin"),
            _("Yes"),
            lambda v, r: v == r,
        )

        # Minlen row
        new_row(
            M(pgettext("pwd policy", "Minimum length")),
            M(
                pgettext(
                    "pwd policy",
                    "Password should be at least 12 characters long",
                )
            ),
            12,
            policy.get("min-len"),
            8,
            lambda v, r: v >= r,
        )

        # upper character classes row
        new_row(
            M(pgettext("pwd policy", "Need uppercase letters")),
            M(pgettext("pwd policy", "Password should contain an uppercase letter")),
            _("Yes"),
            policy.get("upper"),
            _("No"),
            lambda v, r: v == r,
        )

        # lower character classes row
        new_row(
            M(pgettext("pwd policy", "Need lowercase letters")),
            M(pgettext("pwd policy", "Password should contain a lowercase letter")),
            _("Yes"),
            policy.get("lower"),
            _("No"),
            lambda v, r: v == r,
        )

        # number character classes row
        new_row(
            M(pgettext("pwd policy", "Need numbers")),
            M(pgettext("pwd policy", "Password should contain a number")),
            _("Yes"),
            policy.get("number"),
            _("No"),
            lambda v, r: v == r,
        )

        # special character classes row
        new_row(
            M(pgettext("pwd policy", "Need non-alphanumeric characters")),
            M(
                pgettext(
                    "pwd policy",
                    "Password should contain a non-alphanumeric letter",
                ),
            ),
            _("Yes"),
            policy.get("special"),
            _("No"),
            lambda v, r: v == r,
        )

        # Different password row
        new_row(
            M(pgettext("pwd policy", "Prevent similar password")),
            M(
                pgettext(
                    "pwd policy",
                    "Password should be different enough from the previous" " password",
                ),
            ),
            _("Yes"),
            policy.get("force-diff"),
            _("No"),
            lambda v, r: v == r,
        )

        # max life row
        new_row(
            M(pgettext("pwd policy", "Limit password duration")),
            M(pgettext("pwd policy", "Password should be limited in time")),
            _("Enabled"),
            policy.get("expire"),
            _("Disabled"),
            lambda v, r: v == r,
        )

        # max life row
        # OK if v = 90 +/- 10; Arbitrage if 30 < v < 180;
        new_row(
            M(pgettext("pwd policy", "Maximum password duration")),
            M(
                pgettext(
                    "pwd policy",
                    "Password life-time should be at most 90 days",
                )
            ),
            90,
            policy.get("max-age"),
            90,
            lambda v, r: v is not None and r - 10 <= v <= r + 10,
            lambda v, r: v is not None and r - 30 <= v <= r + 90,
        )

        # if no vuln, add a good finding
        if len(self.findings.vulns()) == 0:
            self.findings.good(
                M(
                    _("All password policy settings are correctly configured"),
                ),
            )

        # return the data
        return M(
            _(
                "The configured password policy is summarized in the following"
                " table:",
            ),
        ) + table2bbcode(tab, _("Password policy for admins"))

    def pwd_strength(self):
        """Check the strength of each passwords"""
        admins, __, __ = self.get_user_group()

        # filter users with passwords and sort them per type
        f_users = {}
        for name, adm in admins.items():
            phash = adm.get_param("password", None, as_list=True)
            if phash and phash[0] == "ENC":
                ptype = phash[1][:3]
                if ptype not in f_users:
                    f_users[ptype] = []
                f_users[ptype].append((name, phash[1]))

        # create the table of passwords and the blocks of passwords
        ret = [
            [
                pgettext("pwd_strength", "Name"),
                pgettext("pwd_strength", "Password hash"),
            ],
        ]
        blocks = {}

        # Add the hashes, grouped by type & compute the group of hashes
        for ptype in f_users:
            # add the header
            if ptype == "AK1":
                ret.append([M(_("Fortigate hash computed with SHA1"))])
            elif ptype == "SH2":
                ret.append([M(_("Fortigate hash computed with SHA256"))])
            else:
                ret.append([M(_("Unknown Fortigate hash (%s)")) % ptype])

            blocks[ptype] = []
            for name, phash in f_users[ptype]:
                ret.append([name, phash])
                blocks[ptype].append(phash)

        # create the text from blocks
        txt = M(
            _(
                "The following passwords should be tested to recover the "
                "cleartext using the cracking station or the given script.\n",
            ),
        )

        # SHA1 based has an hashcat mode
        if "AK1" in blocks:
            txt += M(
                _(
                    "The following hashes can be cracked using the cracking "
                    "station with mode 'FortiGate (FortiOS)' "
                    "([code]-m 7000[/code]):[codeblock]%s[/codeblock]",
                ),
            ) % M("\n").join(blocks["AK1"])

        # SHA256 cannot be handled by hashcat
        if "SH2" in blocks:
            # read the cracking program
            with open(
                os.path.join(os.path.dirname(__file__), "password_cracker.py"),
            ) as f:
                crack_prgm = f.read()
            # Add the text for the user
            txt += M(
                _(
                    "The following hashes cannot be cracked using the "
                    "cracking station nor hashcat.[codeblock]%s[/codeblock]",
                ),
            ) % M("\n").join(blocks["SH2"])
            txt += M(
                _(
                    "The python3 script given below can be used instead."
                    "[codeblock]%s[/codeblock]",
                ),
            ) % crack_prgm.format(hashes=M("\n").join(blocks["SH2"]))

        # return all data
        return (
            M(
                _(
                    "The following table sum up the the administrators' "
                    "password hashes. Hashes are also given after the table "
                    "in a easy-to-copy manner.",
                ),
            )
            + table2bbcode(ret, _("List of administrators' password hashes"))
            + txt
        )

    # dict to save the SNMP security human strings
    SNMP_SECURITY = DefaulterI18nDict(
        {
            "no-auth-no-priv": N_("No authentication and no encryption"),
            "auth-no-priv": N_("Authentication but no encryption"),
            "auth-priv": N_("Authentication and encryption"),
            "_default_with_value": N_("Unknown security - %s"),
        },
    )

    def snmp_service(self):
        """Check snmp service"""
        # Analyse the SNMP config
        snmp_txt = ""

        # check the enabled communities (=SNMPv1 or SNMPv2)
        communities = [
            {
                "name": node.get_param("name", node.name),
                # the hosts are saved like
                # set ip 10.68.4.97 255.255.255.255
                "hosts": [
                    # TO BE CHECKED: default value, not being documented
                    # anywhere
                    self.to_ip(
                        *n.get_param(
                            "ip",
                            ["0.0.0.0", "0.0.0.0"],  # nosec
                            as_list=True,
                        ),
                    )
                    for n in (node / "hosts").find()
                ],
                "hosts6": [
                    ipaddress.IPv6Interface(n.ipv6) for n in (node / "hosts6").find()
                ],
            }
            for node in (
                self.artifacts["tree"] // "system" / "snmp" / "community"
            ).find()
            if node.get_param("status", "enable") == "enable"
        ]
        # check the enabled users (=SNMPv3)
        users = [
            {
                "name": node.get_param("name", node.name),
                "security": node.get_param("security-level"),
            }
            for node in (self.artifacts["tree"] // "system" / "snmp" / "user").find()
            if node.get_param("status", "enable") == "enable"
        ]
        # compute some stats
        snmp_conf = {
            "num_communities": len(communities),
            "num_unrestricted": len(
                [
                    c
                    for c in communities
                    if (
                        (len(c["hosts"]) == 0 and len(c["hosts6"]) == 0)
                        or any(
                            h == ipaddress.IPv4Interface("0.0.0.0/0")
                            for h in c["hosts"]
                        )
                        or any(
                            h == ipaddress.IPv6Interface("::/0") for h in c["hosts6"]
                        )
                    )
                ],
            ),
            "num_users": len(users),
            "num_noauth_users": len(
                [u for u in users if u["security"] == "no-auth-no-priv"],
            ),
            "num_nopriv_users": len(
                [u for u in users if u["security"] == "auth-no-priv"],
            ),
            "num_secure_users": len([u for u in users if u["security"] == "auth-priv"]),
        }
        # Create the text for snmp
        if len(communities) > 0:
            tbl = [
                [
                    pgettext("SNMP conf", "Communities"),
                    pgettext("SNMP conf", "Authorized hosts"),
                ],
            ]
            for c in communities:
                count = len(c["hosts"]) + len(c["hosts6"])
                tbl.append(
                    [
                        c["name"],
                        M(_("All"))
                        if count == 0
                        else (
                            "\n".join([h.with_prefixlen for h in c["hosts"]])
                            + "\n".join([h.with_prefixlen for h in c["hosts6"]])
                        ),
                    ],
                )

            snmp_txt += M(
                _("The following SNMPv1 and SNMPv2c communities were" " found:%s"),
            ) % table2bbcode(tbl, M(_("List of SNMP communities")))

        if len(users) > 0:
            tbl = [
                [
                    pgettext("SNMP conf", "Users"),
                    pgettext("SNMP conf", "Security"),
                ],
            ]
            for u in users:
                tbl.append([u["name"], self.SNMP_SECURITY[u["security"]]])

            snmp_txt += M(
                _("The following SNMPv3 users were found:%s"),
            ) % table2bbcode(tbl, M(_("List of SNMP users")))

        snmp_txt += M(
            ngettext(
                "{num_communities} SNMPv1/2 community was found on the"
                " firewall. Among it, ",
                "{num_communities} SNMPv1/2 communities were found on the"
                " firewall. Among them, ",
                snmp_conf["num_communities"],
            ),
        ).format(**snmp_conf)
        snmp_txt += M(
            ngettext(
                "[b]{num_unrestricted} community is unrestricted[/b].\n",
                "[b]{num_unrestricted} communities are unrestricted[/b].\n",
                snmp_conf["num_unrestricted"],
            ),
        ).format(**snmp_conf)
        snmp_txt += M(
            ngettext(
                "{num_users} SNMPv3 user was found on the firewall. Among" " it, ",
                "{num_users} SNMPv3 users were found on the firewall. Among" " them, ",
                snmp_conf["num_users"],
            ),
        ).format(**snmp_conf)
        snmp_txt += M(
            ngettext(
                "{num_noauth_users} does not authenticate ",
                "{num_noauth_users} do not authenticate ",
                snmp_conf["num_noauth_users"],
            ),
        ).format(**snmp_conf)
        snmp_txt += M(
            ngettext(
                "and {num_nopriv_users} does not encrypt communications.\n",
                "and {num_nopriv_users} do not encrypt communications.\n",
                snmp_conf["num_nopriv_users"],
            ),
        ).format(**snmp_conf)

        # add the vulnerabilities
        if snmp_conf["num_communities"] > 0:
            self.findings.improvement(
                M(
                    _(
                        "SNMPv1 and SNMPv2 are insecure and should not be "
                        "used anymore",
                    ),
                ),
            )
            if snmp_conf["num_unrestricted"] > 0:
                self.findings.vuln(
                    M(
                        _(
                            "Some SNMPv1/2 communities are not restricted to "
                            "few allowed hosts",
                        ),
                    ),
                )
            else:
                self.findings.good(
                    M(
                        _(
                            "All SNMPv1/2 communities are restricted to few "
                            "allowed hosts",
                        ),
                    ),
                )
        else:
            self.findings.good(
                M(
                    _(
                        "SNMPv1 and SNMPv2 are not used",
                    ),
                ),
            )
        if snmp_conf["num_noauth_users"] > 0:
            self.findings.vuln(
                M(_("Some SNMPv3 users are not configured to authenticate")),
            )
        else:
            self.findings.good(M(_("All SNMPv3 users must authenticate")))
        if snmp_conf["num_nopriv_users"] > 0:
            self.findings.improvement(
                M(_("Some SNMPv3 users are not encrypting communications")),
            )
        else:
            self.findings.good(
                M(_("All SNMPv3 users must use encrypted connections")),
            )

        return snmp_txt

    # dict to save the admin services human strings
    ADMIN_SRV = DefaulterI18nDict(
        {
            "ping": N_("Ping"),
            "http": N_("HTTP"),
            "https": N_("HTTPS"),
            "ssh": N_("SSH"),
            "snmp": N_("SNMP"),
            "telnet": N_("Telnet"),
            "fgfm": N_("FortiManager"),
            "radius-acct": N_("Radius accounting"),
            "probe-response": N_("Probe"),
            "capwap": N_("CAPWAP"),
            "ftm": N_("FTM"),
            "_default_with_value": N_("Unknown service - %s"),
        },
    )

    def admin_services(self):
        """Check administration services"""
        # retrieve the list of interfaces
        ifaces = self.get_interfaces()

        # Parse each interface to find the admin services on it
        # make a dict {(vdom, service_name): [ifaces name]}
        adm_services = {}
        for name, iface in ifaces.items():
            for service in iface["admin_services"]:
                # ensure sub list are created
                key = (iface["vdom"], service)
                if key not in adm_services:
                    adm_services[key] = []
                adm_services[key].append(name)

        # sort the OrderedDict to be displayed
        # sort by key (default behavior), i.e. by vdom then service
        adm_services = OrderedDict(sorted(adm_services.items()))

        # create the table to display
        tbl = [
            [
                pgettext("List of admin services", "VDOM"),
                pgettext("List of admin services", "Service name"),
                pgettext("List of admin services", "Interfaces"),
            ],
        ]

        # Parse the enabled services and update the table + the issues
        dangereous_services = ("http", "telnet")
        issues = {}
        # snmp is treated differently as it requires config analysis
        snmp_ifaces = []
        for (vdom, service), ifaces in adm_services.items():
            # update the table
            tbl.append([vdom, self.ADMIN_SRV[service], "\n".join(ifaces)])
            # update the list of issues
            if service in dangereous_services:
                if service not in issues:
                    issues[service] = []
                issues[service].extend(ifaces)
            elif service == "snmp":
                snmp_ifaces.extend(ifaces)

        # Create the text for dangereous_services
        for service in issues:
            self.findings.vuln(
                M(
                    _(
                        "The unsecured service {service} is enable on the "
                        "following interfaces:{ifaces}",
                    ),
                ).format(
                    service=self.ADMIN_SRV[service],
                    ifaces=list2bbcode(
                        [M(_("[code]%s[/code]")) % iface for iface in issues[service]],
                    ),
                ),
            )
        if len(issues) == 0:
            self.findings.good(
                M(
                    _("All interfaces expose only secured administration" " services"),
                ),
            )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tbl = remove_column(tbl, pgettext("List of admin services", "VDOM"))

        # Analyse the SNMP config if needed
        snmp_txt = ""
        if len(snmp_ifaces) > 0:
            # Create the text for snmp
            snmp_txt = M(
                _(
                    "A SNMP service is exposed on some interfaces. The "
                    "FortiGate SNMP implementation is read-only, but it is "
                    "sufficient to leak sensitive data. SNMP configuration "
                    "has to be reviewed.\n",
                ),
            )
            snmp_txt += self.snmp_service()

        return (
            M(_("The firewall exposes the following admin services:"))
            + table2bbcode(tbl, M(_("List of admin services")))
            + snmp_txt
        )

    def syslog(self):
        """Check syslog configuration"""
        # create conformity table
        tab = [
            [
                pgettext("syslog", "VDOM"),
                pgettext("syslog", "Event log system"),
                pgettext("syslog", "Status"),
                pgettext("syslog", "Remote servers"),
                pgettext("syslog", "Configuration keys"),
            ],
        ]

        def check_status(node):
            """Check status of a node"""
            return node.get("status", "disable") == "enable"

        def check_status_and(attr):
            def _wrapped(node):
                return check_status(node) and node.get(attr, "disable") == "enable"

            return _wrapped

        # Some configs store as
        #:  {
        #:      type ==> {
        #:          (list of log settings to check) ==> (
        #:              text for table,
        #:              check function,
        #:              remote extract function,
        #:          )
        #:      }
        #:  }
        syslog_configs = {
            "volatile": {
                ("memory",): (
                    M(pgettext("syslog", "Memory")),
                    check_status,
                    lambda n: "",
                ),
            },
            "persistent": {
                ("disk",): (
                    M(pgettext("syslog", "Disk")),
                    check_status,
                    lambda n: "",
                ),
            },
            "remote": {
                ("disk",): (
                    M(pgettext("syslog", "Disk with FTP upload")),
                    check_status_and("upload"),
                    lambda n: n.get("uploadip", M(_("Missing remote configuration"))),
                ),
                ("fortianalyzer", "fortianalyzer2", "fortianalyzer3"): (
                    M(pgettext("syslog", "FortiAnalyzer")),
                    check_status,
                    lambda n: n.get("server", M(_("Missing remote configuration"))),
                ),
                ("fortianalyzer-cloud",): (
                    M(pgettext("syslog", "FortiAnalyzer Cloud")),
                    check_status,
                    lambda n: M(_("Not configurable")),
                ),
                ("fortiguard",): (
                    M(pgettext("syslog", "FortiCloud")),
                    check_status,
                    lambda n: M(_("Not configurable")),
                ),
                ("syslogd", "syslogd2", "syslogd3", "syslogd4"): (
                    M(pgettext("syslog", "Syslog")),
                    check_status,
                    lambda n: n.get("server", M(_("Missing remote configuration"))),
                ),
            },
        }

        # Go through each vdom
        for vdom in self.get_vdoms():
            syslog_state = {}

            # get the base log node of the current vdom
            if not self.artifacts["vdom"]:
                node = self.artifacts["tree"] // ("config", "log")
            else:
                node = (
                    self.artifacts["tree"]
                    / ("config", "vdom")
                    / vdom
                    // ("config", "log")
                )

            # go through each config to check
            for type_, type_dct in syslog_configs.items():
                # update the state flag for the current vdom & type
                syslog_state[type_] = False

                # Check all logger system in the current type
                for keys, (text, chk, rem) in type_dct.items():
                    # Compute the enabled status for the current system
                    status = False
                    # To keep track of remotes
                    remotes = []
                    for k in keys:
                        subnode = node / k / "setting"
                        status |= chk(subnode)
                        if chk(subnode):
                            remotes.append(rem(subnode))

                    # Add the row to the table and update the state flag
                    tab.append(
                        [
                            vdom,
                            text,
                            cell_background("green", _("Enabled"))
                            if status
                            else cell_background("red", _("Disabled")),
                            M("\n").join(remotes),
                            M("\n").join([M("[i]%s[/i]") % k for k in keys]),
                        ],
                    )
                    syslog_state[type_] |= status

            # Compute the issues based on each state
            if (
                not syslog_state["volatile"]
                and not syslog_state["persistent"]
                and not syslog_state["remote"]
            ):
                self.findings.vuln(
                    self.vdom_based_message(
                        M(_("No event log systems are enabled on the" " firewall")),
                        M(
                            _(
                                "No event log systems are enabled on the VDOM "
                                "[code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
            elif (
                syslog_state["volatile"]
                and not syslog_state["persistent"]
                and not syslog_state["remote"]
            ):
                self.findings.vuln(
                    self.vdom_based_message(
                        M(
                            _(
                                "No persistent event log systems are enabled "
                                "on the firewall",
                            ),
                        ),
                        M(
                            _(
                                "No persistent event log systems are enabled "
                                "on the VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
            elif not syslog_state["remote"]:
                self.findings.improvement(
                    self.vdom_based_message(
                        M(
                            _(
                                "No remote event log systems are enabled on"
                                " the firewall"
                            )
                        ),
                        M(
                            _(
                                "No remote event log systems are enabled on "
                                "the VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
            else:
                self.findings.good(
                    self.vdom_based_message(
                        M(
                            _(
                                "A remote event log systems is enabled on the"
                                " firewall"
                            )
                        ),
                        M(
                            _(
                                "A remote event log system is enabled on "
                                "the VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("syslog", "VDOM"))

        return M(
            _("The following table describes status of event log systems:"),
        ) + table2bbcode(tab, M(_("Status of event log systems")))

    def event_logging(self):
        """Check event logging"""
        # create conformity table
        tab = [
            [
                pgettext("logged events", "VDOM"),
                pgettext("logged events", "Configuration"),
                pgettext("logged events", "Recommended value"),
                pgettext("logged events", "Found value"),
                pgettext("logged events", "Status"),
                pgettext("logged events", "Configuration keys"),
            ],
        ]

        # Go through each vdom
        for vdom in self.get_vdoms():
            # check conformity at a VDOM level
            conform = True

            # get the base log node of the current vdom
            if not self.artifacts["vdom"]:
                node = self.artifacts["tree"] // ("config", "log")
            else:
                node = (
                    self.artifacts["tree"]
                    / ("config", "vdom")
                    / vdom
                    // ("config", "log")
                )

            # create the list of checks to do
            # each items is composed of:
            #  - the key to retrieve the value from node
            #  - the text to describe the configuration
            #  - the recommended value
            #  - the default value
            checks = [
                (
                    "eventfilter.event",
                    M(_("Activate event logs")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.system",
                    M(_("Activate system logs")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.vpn",
                    M(_("Activate VPN logs")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.user",
                    M(_("Activate user authentication logs")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.router",
                    M(_("Activate logging of router state changes")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.wireless-activity",
                    M(_("Activate logging of wireless state changes")),
                    "enable",
                    "enable",
                ),
                (
                    "eventfilter.compliance-check",
                    M(_("Activate logging of FortiClient compliance checks")),
                    "enable",
                    "enable",
                ),
                (
                    "setting.user-anonymize",
                    M(_("Deactivate username anonymization in logs")),
                    "disable",
                    "disable",
                ),
                (
                    "setting.fwpolicy-implicit-log",
                    M(_("Activate logging of implicitly denied IPv4 traffic")),
                    "enable",
                    "disable",
                ),
                (
                    "setting.expolicy-implicit-log",
                    M(
                        _(
                            "Activate logging of implicitly denied requests "
                            "on explicit proxies",
                        ),
                    ),
                    "enable",
                    "disable",
                ),
            ]
            # add IPv6 checks only if ipv6 is enabled
            if self.has_ipv6(vdom):
                checks.append(
                    (
                        "setting.fwpolicy6-implicit-log",
                        M(_("Activate logging of implicitly denied IPv6" " traffic")),
                        "enable",
                        "disable",
                    ),
                )

            # do the review of all relevant config
            for key, txt, rec, default in checks:
                # retrieve the value from the node
                val = node
                # first browse through the node tree
                for part in key.split(".")[:-1]:
                    val /= ("config", part)
                # the final part is the node parameter
                val = val.get(key.split(".")[-1])

                # Do the conformity check
                r, c = conformity_row(txt, rec, val, default, lambda v, r: v == r)
                # update the table & the conformity flag
                tab.append([vdom] + r + [M("[i]log.%s[/i]") % key])
                conform &= c

            # Add a finding vuln if conformity is not sufficient
            if not conform:
                self.findings.vuln(
                    self.vdom_based_message(
                        M(_("Some recommended events are not logged")),
                        M(
                            _(
                                "Some recommended events are not logged on "
                                "the VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
            else:
                self.findings.good(
                    self.vdom_based_message(
                        M(_("All recommended events are logged")),
                        M(
                            _(
                                "All recommended events are logged on "
                                "the VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("logged events", "VDOM"))

        return M(
            _(
                "In addition to logging firewall traffic (see after), "
                "some events related to FortiOS should also be enabled.\n"
                "The following event configuration was found on the "
                "firewall:",
            ),
        ) + table2bbcode(
            tab,
            M(_("Configuration of the logged events on the firewall")),
        )

    # dicts to save the translations of firewall objects
    NET_ADDR_TYPE = DefaulterI18nDict(
        {
            "ipmask": N_("IP network"),
            "ipprefix": N_("IP network"),
            "iprange": N_("IP range"),
            "fqdn": N_("Fully Qualified Domain Name"),
            "geography": N_("Geography"),
            "wildcard": N_("IP wildcard"),
            "_default_with_value": N_("Unknown type - %s"),
        },
    )
    VIP_TYPE = DefaulterI18nDict(
        {
            "static-nat": N_("NAT"),
            "load-balance": N_("Load balancer"),
            "server-load-balance": N_("Server load balancer"),
            "dns-translation": N_("DNS translation"),
            "fqdn": N_("Fully Qualified Domain Name"),
            "_default_with_value": N_("Unknown type - %s"),
        },
    )
    RULES_ACTION = DefaulterI18nDict(
        {
            "accept": N_("Accept"),
            "deny": N_("Deny"),
            "ipsec": N_("IPSec"),
            "_default_with_value": N_("Unknown action - %s"),
        },
    )
    RULES_UTM = DefaulterI18nDict(
        {
            "ips_sensor": N_("IPS sensor %s"),
            "av_profile": N_("Antivirus profile %s"),
            "waf_profile": N_("WAF profile %s"),
            "_default_with_value": N_("Unknown UTM - %s - %%s"),
        },
    )
    RULES_LOG_LEVEL = DefaulterI18nDict(
        {
            "all": N_("Enabled"),
            "utm": N_("UTM alerts"),
            "disable": N_("Disabled"),
            "_default_with_value": N_("Unknown value - %s"),
        },
    )

    def firewall_rules(self):
        """List FW rules"""
        # Render each policy
        txt = ""
        for vdom in self.get_vdoms():
            # Get the firewall object of the current vdom
            firewall = self.get_firewall(vdom)

            # review IPv4 policy
            if len(firewall.policies) == 0:
                # No policy
                txt += self.vdom_based_message(
                    M(_("No IPv4 filtering policies are configured.\n")),
                    M(
                        _(
                            "No IPv4 filtering policies are configured for "
                            "VDOM [code]{VDOM}[/code].\n",
                        ),
                    ),
                    vdom,
                )
                # add a issues
                self.findings.vuln(
                    self.vdom_based_message(
                        M(
                            _(
                                "No IPv4 filtering policies are configured on "
                                "the firewall",
                            ),
                        ),
                        M(
                            _(
                                "No IPv4 filtering policies are configured in "
                                "VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
            else:
                # Add a introducing text
                txt += self.vdom_based_message(
                    M(
                        _(
                            "The following IPv4 filtering policy is "
                            "configured on the firewall:",
                        ),
                    ),
                    M(
                        _(
                            "The following IPv4 filtering policy is "
                            "configured for the VDOM [code]{VDOM}[/code]:",
                        ),
                    ),
                    vdom,
                )
                # Add to findings
                self.findings.good(
                    self.vdom_based_message(
                        M(
                            _(
                                "An IPv4 filtering policy is configured on "
                                "the firewall",
                            ),
                        ),
                        M(
                            _(
                                "An IPv4 filtering policy is configured in "
                                "VDOM [code]{VDOM}[/code]",
                            ),
                        ),
                        vdom,
                    ),
                )
                # Render the policy as a table and retrieve issues
                tab, bad, better = self.render_firewall_policy(vdom, firewall.policies)
                # Add the filtering policy table
                txt += table2bbcode(
                    tab,
                    self.vdom_based_message(
                        M(_("IPv4 filtering policy of the firewall")),
                        M(
                            _(
                                "IPv4 filtering policy of the VDOM"
                                " [code]{VDOM}[/code]"
                            )
                        ),
                        vdom,
                    ),
                )
                # Add each issue if any
                if len(bad) > 0:
                    self.findings.vuln(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv4 filtering policy of the "
                                    "firewall has the following issues:%s",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv4 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] has the following "
                                    "issues:%s",
                                ),
                            ),
                            vdom,
                        )
                        % list2bbcode(bad),
                    )
                if len(better) > 0:
                    self.findings.improvement(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv4 filtering policy of the "
                                    "firewall has the following issues:%s",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv4 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] has the following "
                                    "issues:%s",
                                ),
                            ),
                            vdom,
                        )
                        % list2bbcode(better),
                    )
                if len(bad) == len(better) == 0:
                    self.findings.good(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv4 filtering policy is" " satisfactory",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv4 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] is satisfactory",
                                ),
                            ),
                            vdom,
                        ),
                    )

            # do the same to review IPv6 policy
            if len(firewall.policies6) == 0:
                # No policy
                txt += self.vdom_based_message(
                    M(_("No IPv6 filtering policies are configured.\n")),
                    M(
                        _(
                            "No IPv6 filtering policies are configured for "
                            "VDOM [code]{VDOM}[/code].\n",
                        ),
                    ),
                    vdom,
                )
                # No need to add an issues if IPv6 is enabled in the
                # VDOM because it is already done in interfaces review
            else:
                # Add a introducing text
                txt += self.vdom_based_message(
                    M(
                        _(
                            "The following IPv6 filtering policy is "
                            "configured on the firewall:",
                        ),
                    ),
                    M(
                        _(
                            "The following IPv6 filtering policy is "
                            "configured for the VDOM [code]{VDOM}[/code]:",
                        ),
                    ),
                    vdom,
                )
                # Render the policy as a table and retrieve issues
                tab, bad, better = self.render_firewall_policy(vdom, firewall.policies6)
                # Add the filtering policy table
                txt += table2bbcode(
                    tab,
                    self.vdom_based_message(
                        M(_("IPv6 filtering policy of the firewall")),
                        M(
                            _(
                                "IPv6 filtering policy of the VDOM"
                                " [code]{VDOM}[/code]"
                            )
                        ),
                        vdom,
                    ),
                )
                # Add each issue if any
                if len(bad) > 0:
                    self.findings.vuln(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv6 filtering policy of the "
                                    "firewall has the following issues:%s",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv6 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] has the following "
                                    "issues:%s",
                                ),
                            ),
                            vdom,
                        )
                        % list2bbcode(bad),
                    )
                if len(better) > 0:
                    self.findings.improvement(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv6 filtering policy of the "
                                    "firewall has the following issues:%s",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv6 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] has the following "
                                    "issues:%s",
                                ),
                            ),
                            vdom,
                        )
                        % list2bbcode(better),
                    )
                if len(bad) == len(better) == 0:
                    self.findings.good(
                        self.vdom_based_message(
                            M(
                                _(
                                    "The IPv6 filtering policy is" " satisfactory",
                                ),
                            ),
                            M(
                                _(
                                    "The IPv6 filtering policy of VDOM "
                                    "[code]{VDOM}[/code] is satisfactory",
                                ),
                            ),
                            vdom,
                        ),
                    )

        return txt + M(
            _(
                "In the previous tables, all dangerous rules have been "
                "highlighted in red.\n",
            ),
        )

    def render_firewall_policy(self, vdom, policy):
        """Render a firewall policy

        Args:
            vdom (str): VDOM of the policy
            policy (dict): policy to render, taken from a Firewall
                object

        Returns:
            A `tuple` composed of the table of the policy, a `list`
            of issues and a `list` of rules which may be improved.
        """

        # a set of functions to format the firewall rules
        def hi_better(row):
            """Highlight as a better row"""
            return [cell_background("orange", c) for c in row]

        def hi_bad(row):
            """Highlight as a bad row"""
            return [cell_background("red", c) for c in row]

        def format_net_or_vip(addr):
            """Format a NetworkObject or a VipObject"""
            # delegate to the per-type formatter
            if isinstance(addr, NetworkObject):
                return format_net_obj(addr)
            if isinstance(addr, VipObject):
                return format_vip_obj(addr)
            raise RuntimeError("Unknown object: %s" % type(addr))

        def format_net_obj(addr):
            """Format a NetworkObject"""
            # delegate to the per-type formatter
            if isinstance(addr, NetworkAddress):
                return format_net_addr(addr)
            if isinstance(addr, NetworkGroup):
                return format_net_group(addr)
            raise RuntimeError("Unknown NetworkObject: %s" % type(addr))

        def format_vip_obj(addr):
            """Format a VipObject"""
            # delegate to the per-type formatter
            if isinstance(addr, Vip):
                return format_vip(addr)
            if isinstance(addr, VipGroup):
                return format_vip_group(addr)
            raise RuntimeError("Unknown VipObject: %s" % type(addr))

        def format_net_addr(addr):
            """Format a NetworkAddress"""
            if addr.iface:
                return M("[b]%s[/b] (%s: [code]%s[/code] @ [code]%s[/code])") % (
                    addr.name,
                    self.NET_ADDR_TYPE[addr.type],
                    addr.address,
                    addr.iface,
                )
            return M("[b]%s[/b] (%s: [code]%s[/code])") % (
                addr.name,
                self.NET_ADDR_TYPE[addr.type],
                addr.address,
            )

        def format_net_group(addr):
            """Format a NetworkGroup"""
            return M(_("Group [b]{name}[/b] composed of:{members}")).format(
                name=addr.name,
                members=list2bbcode(
                    [format_net_obj(obj) for obj in addr.members],
                    False,
                ),
            )

        def format_vip_nat(addr):
            """Resolve the NATed IPs & ports"""
            # skip both src_addr and dst_addr as they seem not used
            src_ip = addr.src_ip
            src_iface = addr.src_iface
            dst_ip = ",".join(addr.dst_ip)

            # Only do port resolution if forward is enabled
            if addr.portforward:
                # either services are declared ==> use it
                # or not ==> use protocol + src_port
                if len(addr.src_services) > 0:
                    # flatten all service ports
                    src_ports = []
                    for srv in addr.src_services:
                        for proto, ports in srv.port_list().items():
                            for start, stop in ports:
                                # Add each port range in the format
                                #  tcp/80
                                #  tcp/8890-8895
                                src_ports.append(
                                    "%s/%s"
                                    % (
                                        proto,
                                        "%d" % start
                                        if start == stop
                                        else "%d-%d" % (start, stop),
                                    ),
                                )
                    # join all ports
                    src_port = ",".join(src_ports)
                else:
                    protocol = addr.protocol
                    src_port = "%s/%s" % (protocol, addr.src_port)
                dst_port = addr.dst_port

            # format each data into a single line
            ret = M("[code]%s[/code]") % src_ip
            if addr.portforward:
                ret += M(":[code]%s[/code]") % src_port
            if src_iface:
                ret += M(" @ [code]%s[/code]") % src_iface
            ret += M(" => [code]%s[/code]") % dst_ip
            if addr.portforward:
                ret += M(":[code]%s[/code]") % dst_port
            return ret

        def format_vip(addr):
            """Format a Vip"""
            # Only support exhaustive print of NAT
            if addr.type == "static-nat":
                return M(_("VIP [b]{name}[/b] ({type} {rule})")).format(
                    name=addr.name,
                    type=self.VIP_TYPE[addr.type],
                    rule=format_vip_nat(addr),
                )
            return M(_("VIP [b]{name}[/b] ({type})")).format(
                name=addr.name,
                type=self.VIP_TYPE[addr.type],
            )

        def format_vip_group(addr):
            """Format a VipGroup"""
            return M(_("VIP Group [b]{name}[/b] composed of:{members}")).format(
                name=addr.name,
                members=list2bbcode(
                    [format_vip_obj(obj) for obj in addr.members],
                    False,
                ),
            )

        def format_service(srv):
            """Format a Service"""
            if isinstance(srv, CustomService):
                return format_serv_cust(srv)
            if isinstance(srv, ServiceGroup):
                return format_serv_group(srv)
            raise RuntimeError("Unknown Service: %s" % type(srv))

        def format_serv_cust(srv):
            """Format a CustomService"""
            return M("[b]%s[/b] (%s)") % (srv.name, srv.address)

        def format_serv_group(srv):
            """Format a ServiceGroup"""
            return M(_("Group [b]{name}[/b] composed of:{members}")).format(
                name=srv.name,
                members=list2bbcode(
                    [format_service(obj) for obj in srv.members],
                    False,
                ),
            )

        def format_src_dest_cell(ifaces, addrs, negate):
            """Format a source or destination cell"""
            # add interface restrictions if any
            if len(ifaces) > 0 and "any" not in ifaces:
                iface_txt = M(_("Interfaces: %s")) % M(", ").join(
                    [M("[code]%s[/code]") % iface for iface in ifaces],
                )
            else:
                iface_txt = M(_("Interfaces: [b]any[/b]"))
            # handle the no address case
            if len(addrs) == 0:
                addr_txt = (
                    M(_("Devices: [b]none[/b]"))
                    if negate
                    else M(_("Devices: [b]any[/b]"))
                )
            else:
                # format as a list
                faddrs = list2bbcode([format_net_or_vip(n) for n in addrs], False)
                if negate:
                    addr_txt = M(_("Devices: any but:%s")) % faddrs
                else:
                    addr_txt = M(_("Devices:%s")) % faddrs
            # Return the text
            return M("\n").join([iface_txt, addr_txt])

        def format_srv_cell(services, negate):
            """Format a service cell"""
            # handle the no service case
            if len(services) == 0:
                return M(_("[b]None[/b]")) if negate else M(_("[b]Any[/b]"))
            # format as a list
            fservices = list2bbcode([format_service(n) for n in services], False)
            if negate:
                return M(_("Any but:%s")) % fservices
            return fservices

        # A list to keep track of all issues
        issues = []
        better = []

        # start the table
        tab = [
            [
                pgettext("Policy", "VDOM"),
                pgettext("Policy", "ID"),
                pgettext("Policy", "Source"),
                pgettext("Policy", "Destination"),
                pgettext("Policy", "Service"),
                pgettext("Policy", "Action"),
                pgettext("Policy", "Traffic log"),
                pgettext("Policy", "UTM"),
            ],
        ]

        # iterate over each rules
        for rule in policy.values():
            # skip disabled rules
            if not rule.enabled:
                continue

            # Create the row for the table
            row = [
                vdom,
                rule.policyid,
                format_src_dest_cell(rule.srciface, rule.srcaddr, rule.negate_src),
                format_src_dest_cell(rule.dstiface, rule.dstaddr, rule.negate_dst),
                format_srv_cell(rule.services, rule.negate_services),
                self.RULES_ACTION[rule.action],
                self.RULES_LOG_LEVEL[rule.logtraffic],
                list2bbcode(
                    [
                        self.RULES_UTM[t] % getattr(rule, t)
                        for t in ("ips_sensor", "av_profile", "waf_profile")
                        if getattr(rule, t) is not None
                    ],
                    with_ponctuation=False,
                ),
            ]

            # do the review for issues
            def isall(items, negate):
                """Return whether the list covers everything"""
                return not negate and (any(m.is_all for m in items) or len(items) == 0)

            src_isall = isall(rule.srcaddr, rule.negate_src)
            dst_isall = isall(rule.dstaddr, rule.negate_dst)
            srv_isall = isall(rule.services, rule.negate_services)

            # check any -> any: any accept rules
            if src_isall and dst_isall and srv_isall and rule.action == "accept":
                issues.append(
                    M(_("The rule #%s widely accepts network traffic")) % rule.policyid,
                )
                row = hi_bad(row)

            # check completely exposed hosts
            elif src_isall and srv_isall and rule.action == "accept":
                issues.append(
                    M(
                        _(
                            "The rule #%s exposes destination hosts to anyone "
                            "on any protocol",
                        ),
                    )
                    % rule.policyid,
                )
                row = hi_bad(row)

            # check admin services
            elif src_isall and rule.action == "accept":
                admin_srv = []
                # check all admin services
                for name, serv in (
                    (M(_("SSH")), ("tcp", 22)),
                    (M(_("Telnet")), ("tcp", 23)),
                    (M(_("RPC")), ("tcp", 135)),
                    (M(_("NetBIOS")), ("tcp", 139)),
                    (M(_("SMB")), ("tcp", 445)),
                    (M(_("rexec")), ("tcp", 512)),
                    (M(_("rlogin")), ("tcp", 513)),
                    (M(_("rsh")), ("tcp", 514)),
                    (M(_("SNMP")), ("udp", 161)),
                    (M(_("RDP")), ("tcp", 3389)),
                    (M(_("VNC")), ("tcp", 5900)),
                    (M(_("WinRM HTTP")), ("tcp", 5985)),
                    (M(_("WinRM HTTPS")), ("tcp", 5986)),
                ):
                    if any(
                        not m.allow_port(*serv)
                        if rule.negate_services
                        else m.allow_port(*serv)
                        for m in rule.services
                    ):
                        admin_srv.append(name)
                # highlight row & add finding if any admin srv matches
                if len(admin_srv) > 0:
                    better.append(
                        M(
                            _(
                                "The rule #{policyid} exposes administrative "
                                "services ({admin_srv}) to anyone",
                            ),
                        ).format(
                            policyid=rule.policyid,
                            admin_srv=M(", ").join(admin_srv),
                        ),
                    )
                    row = hi_better(row)

            # add the row to the table
            tab.append(row)

        # Filter the VDOM column if need
        if not self.artifacts["vdom"]:
            tab = remove_column(tab, pgettext("Policy", "VDOM"))

        # Return
        return tab, issues, better
