# -*- coding: utf-8 -*-

"""This module provides parser for Fortigate config"""


# Standard libraries
import shlex

# Project imports
from engine import logger
from engine.techs.fortigate.nodes import Node


class ParserError(Exception):
    """Raised when the parsing fails due to invalid input"""


class Parser:
    """Parser for Fortigate configuration

    Parse to configuration and create a tree of configuration
    """

    stack = []
    node = None

    @classmethod
    def lex(cls, config):
        """Do the lexical parsing

        Args:
            config (str): configuration to parse

        Returns:
            a `list` of lexically parsed lines

        Raises:
            ParserError: when an error occurs while lexing or parsing

        """

        def keep(line):
            return line not in ("", "\n", "\r\n") and not line.startswith("#")

        lines = []
        buff = ""
        for line in config.splitlines():
            # reconstruct the buffer which spans across several lines
            buff += line
            if keep(buff):
                try:
                    # try to lex using shlex, to handle quotation
                    shlexed = shlex.split(buff)
                    lines.append(shlexed)
                    # reset the buffer
                    buff = ""
                except ValueError:
                    # may occur on lines which was not ended
                    pass
            else:
                # reset the buffer if it should not be kept
                buff = ""

        # ensure the whole configuration was parsed
        if buff != "":
            raise ParserError("Failed lexing: EOF received before the end")

        return lines

    @classmethod
    def handle_set(cls, elements):
        """Handle config line 'set param values'"""
        # check the format
        if len(elements) < 2:
            raise ParserError("Failed parsing: `set` requires at least 2 parameters")
        # Some set can have more than 1 value
        # therefore, we stock the values as : params {key : [values]}
        cls.node.params[elements[0]] = elements[1::]

    @classmethod
    def handle_unset(cls, elements):
        """Handle config line 'unset param'"""
        # check the format
        if len(elements) != 1:
            raise ParserError("Failed parsing: `unset` requires 1 parameter")
        if elements[0] in cls.node.params:
            del cls.node.params[elements[0]]

    @classmethod
    def handle_config(cls, elements):
        """Handle config line 'config name1 name2'"""
        # check the format
        if len(elements) < 1:
            raise ParserError("Failed parsing: `config` requires at least 1 parameter")
        # create all config nodes
        current = cls.node
        for n in elements:
            if current.has(name=n):
                current = current.find(name=n)[0]
            else:
                current = current.new_child(n, "config")
        # save the previous node and change the current one
        cls.stack.append(cls.node)
        cls.node = current

    @classmethod
    def handle_edit(cls, elements):
        """Handle config line 'edit section'"""
        # check the format
        if len(elements) != 1:
            raise ParserError("Failed parsing: `edit` requires 1 parameter")

        # check whether the section node already exists
        if cls.node.has(name=elements[0]):
            # save the previous node and change the current one
            cls.stack.append(cls.node)
            cls.node = cls.node.find(name=elements[0])[0]
        else:
            # create a new node for the config
            new = cls.node.new_child(elements[0], "edit")
            # save the previous node and change the current one
            cls.stack.append(cls.node)
            cls.node = new

    @classmethod
    def handle_next(cls, elements):
        """Handle config line 'next'"""
        # check the format
        if len(elements) != 0:
            raise ParserError("Failed parsing: `next` requires no parameters")

        cls.node = cls.stack.pop()

    @classmethod
    def handle_end(cls, elements):
        """Handle config line 'end'"""
        # check the format
        if len(elements) != 0:
            raise ParserError("Failed parsing: `end` requires no parameters")

        while not cls.node.is_config:
            cls.node = cls.stack.pop()
        cls.node = cls.stack.pop()

    @classmethod
    def parse(cls, config):
        """Parse a Fortigate configuration

        Args:
            config (str): configuration to be parsed

        Returns:
            a `Node` which corresponds to the root node

        Raises:
            ParserError: when an error occurs while lexing or parsing

        """
        handlers = {
            "set": cls.handle_set,
            "unset": cls.handle_unset,
            "config": cls.handle_config,
            "edit": cls.handle_edit,
            "next": cls.handle_next,
            "end": cls.handle_end,
        }

        # do the lexing
        lines = cls.lex(config)

        # do the parsing of each line
        log = logger.getLogger(__name__)
        root = cls.node = Node("root", "root")
        for line in lines:
            if line[0] in handlers:
                handlers[line[0]](line[1::])
            else:
                log.warning(
                    "Unhandled line in Fortigate configuration: %s",
                    " ".join(line),
                )
        return root
