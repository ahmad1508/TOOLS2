# -*- coding: utf-8 -*-

"""Provide a helper classes to represent network addresses"""

# Standard libraries
from ipaddress import IPv4Address, IPv4Network, IPv6Address, IPv6Network

# Project imports
from engine import logger
from engine.core import i18n

# I18N
_ = i18n.domain("fortigate")._
pgettext = i18n.domain("fortigate").pgettext


def deferred_get(name, names_prop, cache_prop, firewall_prop, with_ipv6):
    """Defer the resolution of firewall sub-objects instances

    Args:
        name (str): human readable definition of the property
            (for logger warnings)
        names_prop (str): name of the property of self to retrieve the
            list of names to resolve
        cache_prop (str): name of the property of self to retrieve the
            cache of resolved instances
        firewall_prop (str): name of the property of Firewall to
            retrieve the dict of instances
        with_ipv6 (bool): whether to enable IPv6 firewall namespace

    """

    def wrapper(self):
        # check the cache first
        if getattr(self, cache_prop) is not None:
            return getattr(self, cache_prop)

        # unify the use of ipv6
        ipv6 = getattr(self, "ipv6", None) and with_ipv6

        # do the resolution from name to instances
        ret = []
        for n in getattr(self, names_prop):
            if not ipv6 and n in getattr(self.firewall, firewall_prop):
                ret.append(getattr(self.firewall, firewall_prop)[n])
            elif ipv6 and n in getattr(self.firewall, firewall_prop + "6"):
                ret.append(getattr(self.firewall, firewall_prop + "6")[n])
            else:
                logger.getLogger(__name__).warning(
                    "Unknown %s %s named: %s",
                    "IPv6" if ipv6 else "IPv4",
                    name,
                    n,
                )

        # save the cache and return
        setattr(self, cache_prop, ret)
        return ret

    return wrapper


class FirewallBoundObject:  # pylint: disable=too-few-public-methods
    """Class to bind the instances to the firewall

    This class is intended to be bound subclassed

    Example:
        ```python
        class NetworkObject(FirewallBound):
            def __init__(self, firewall, *data):
                super().__init__(firewall, "addresses")
        ```

    """

    __slots__ = ("firewall",)

    def __init__(self, firewall, type_, name):
        """Register on the firewall"""
        self.firewall = firewall
        self.firewall.register(type_, name, self)


class NetworkObject(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for network objects

    A NetworkObject can either be a `NetworkAddress` or a `NetworkGroup`
    """

    __slots__ = ("name", "ipv6", "uuid", "comment")

    def __init__(self, firewall, name, ipv6, uuid="", comment=""):
        """Initialize the object"""
        super().__init__(firewall, "addresses6" if ipv6 else "addresses", name or uuid)
        self.name = name
        self.ipv6 = ipv6
        self.comment = comment
        self.uuid = uuid


class NetworkAddress(NetworkObject):
    """Provide a base class for addresses

    Attributes:
        name (str): name of the object
        ipv6 (bool): whether the object is for IPv6
        uuid (str): UUID of the object
        comment (str): comment added on the object
        type (str): type of the address object
        address (str): human-representation of the address
        iface (str): associated interface
        is_all (bool): whether the address cover all addresses

    """

    __slots__ = ("type", "address", "iface", "is_all")

    def __init__(
        self,
        firewall,
        name,
        ipv6,
        type_,
        address,
        is_all=False,
        uuid="",
        comment="",
        iface="",
    ):
        """Initialize the address from data"""
        super().__init__(firewall, name, ipv6, uuid, comment)
        self.type = type_
        self.address = address
        self.iface = iface
        self.is_all = is_all

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the address from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the address

        Returns:
            an initialized `NetworkAddress`

        """
        # pylint: disable=too-many-branches,too-many-locals
        # get whether it is IPv6
        ipv6 = node.parent is not None and node.parent.name == "address6"

        # get basic data
        name = node.name
        type_ = node.get_param("type", "ipprefix" if ipv6 else "ipmask")
        uuid = node.get_param("uuid", "")
        comment = node.get_param("comment", "")
        iface = node.get_param("associated-interface", "")
        is_all = False

        # Try to resolve the address, depending on the type
        # also compute whether the object cover all addresses
        if type_ == "ipmask" and not ipv6:
            # ipmask uses subnet
            # IPv4 only
            # subnet may be in the form IP/Prefix or IP Netmask
            subnet = node.get_param("subnet", "0.0.0.0/0")
            if isinstance(subnet, list):
                net = IPv4Network(tuple(subnet[:2]))
            else:
                net = IPv4Network(subnet)
            is_all = net == IPv4Network("0.0.0.0/0")
            address = net.with_prefixlen

        elif type_ == "ipprefix" and ipv6:
            # ipprefix uses ip6
            # ip6 should be in the form IP/Prefix (but compatibility
            # with IP and Netmask is kept)
            # IPv6 only
            subnet = node.get_param("ip6", "::/0")
            if isinstance(subnet, list):
                net = IPv6Network(tuple(subnet[:2]))
            else:
                net = IPv6Network(subnet)
            is_all = net == IPv6Network("::/0")
            address = net.with_prefixlen

        elif type_ == "iprange":
            # iprange uses start-ip and end-ip
            if ipv6:
                start = IPv6Address(node.get_param("start-ip", "::"))
                end = IPv6Address(node.get_param("end-ip", "::"))
                all_net = IPv6Network("::/0")
            else:
                start = IPv4Address(node.get_param("start-ip", "0.0.0.0"))  # nosec
                end = IPv4Address(node.get_param("end-ip", "0.0.0.0"))  # nosec
                all_net = IPv4Network("0.0.0.0/0")
            is_all = (start, end) == (all_net[0], all_net[-1])
            address = pgettext("Network object iprange", "{start} to {end}").format(
                start=start,
                end=end,
            )

        elif type_ == "fqdn":
            # fqdn uses fqdn
            all_net = False
            address = node.get_param("fqdn")

        elif type_ == "geography" and not ipv6:
            # geography uses country
            all_net = False
            address = node.get_param("country")

        elif type_ == "wildcard" and not ipv6:
            # wildcard uses wildcard
            # IPv4 only
            ip, mask = node.get_param("wildcard", ["0.0.0.0", "0.0.0.0"])  # nosec
            is_all = mask == "0.0.0.0"  # nosec
            address = pgettext(
                "Network object wildcard",
                "{ip} masked with {mask}",
            ).format(ip=ip, mask=mask)

        else:
            logger.getLogger(__name__).warning(
                "Unknown type for Fortigate network address object: %s",
                type_,
            )
            address = ""

        # create the network object
        return cls(firewall, name, ipv6, type_, address, is_all, uuid, comment, iface)


class NetworkGroup(NetworkObject):
    """Provide a base class for groups

    Attributes:
        name (str): name of the object
        ipv6 (bool): whether the object is for IPv6
        uuid (str): UUID of the object
        comment (str): comment added on the object
        members (list): the list of members of the group. The items
            of this list are `NetworkObject`

    """

    __slots__ = ("_members_names", "_members")

    def __init__(self, firewall, name, ipv6, members, uuid="", comment=""):
        """Initialize the group from data"""
        super().__init__(firewall, name, ipv6, uuid, comment)
        self._members_names = members
        self._members = None

    members = property(
        deferred_get("address", "_members_names", "_members", "addresses", True),
    )

    @property
    def is_all(self):
        """Return True if the group represents all assets"""
        return any(member.is_all for member in self.members)

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the group from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the group

        Returns:
            an initialized `NetworkGroup`

        """
        # get whether it is IPv6
        ipv6 = node.parent is not None and node.parent.name == "addrgrp6"

        # get basic info
        name = node.name
        uuid = node.get_param("uuid", "")
        comment = node.get_param("comment", "")

        # depending on the version of FortiOS, member may be a list of
        # members names or a config whose edit sections are the members
        # name
        # map member config to a list of names
        if node.has(name="member", type="config"):
            members = map(lambda n: n.name, node["member"].children)
        else:
            members = node.get_param("member", as_list=True)

        return cls(firewall, name, ipv6, members, uuid, comment)


class VipObject(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for virtual IP (=NAT)

    A VipObject can either be a `Vip` or a `VipGroup`
    """

    __slots__ = ("name", "ipv6", "uuid", "comment")

    def __init__(self, firewall, name, ipv6, uuid="", comment=""):
        """Initialize the object"""
        super().__init__(firewall, "vips6" if ipv6 else "vips", name or uuid)
        self.name = name
        self.ipv6 = ipv6
        self.comment = comment
        self.uuid = uuid


class Vip(VipObject):
    """Provide a base class for addresses

    Attributes:
        name (str): name of the object
        ipv6 (bool): whether the object is for IPv6
        uuid (str): UUID of the object
        comment (str): comment added on the object
        type (str): type of the vip object
        src_ip (str): source IP range
        src_addr (list): list of source NetworkAddress
        src_iface (str): source interface
        portforward (bool): whether the VIP forward only specific ports
        forward_proto (str): forwarded protocol
        src_services (list): list of source Service
        src_port (str): list of source ports to forward
        dst_ip (str): NATed IP range
        dst_addr (list): list of NATed NetworkAddress
        dst_port (str): list of NATed ports
    """

    __slots__ = (
        "type",
        "src_ip",
        "_src_addr_names",
        "_src_addr",
        "src_iface",
        "portforward",
        "forward_proto",
        "_src_services_names",
        "_src_services",
        "src_port",
        "dst_ip",
        "_dst_addr_names",
        "_dst_addr",
        "dst_port",
    )

    def __init__(
        self,
        firewall,
        name,
        ipv6,
        type_,
        src_ip,
        src_addr,
        src_iface,
        portforward,
        forward_proto,
        src_services,
        src_port,
        dst_ip,
        dst_addr,
        dst_port,
        uuid="",
        comment="",
    ):
        """Initialize the address from data"""
        super().__init__(firewall, name, ipv6, uuid, comment)
        self.type = type_
        self.src_ip = src_ip
        self._src_addr_names = src_addr
        self.src_iface = src_iface
        self.portforward = portforward
        self.forward_proto = forward_proto
        self._src_services_names = src_services
        self.src_port = src_port
        self.dst_ip = dst_ip
        self._dst_addr_names = dst_addr
        self.dst_port = dst_port

    src_addr = property(
        deferred_get("address", "_src_addr_names", "_src_addr", "addresses", True),
    )
    dst_addr = property(
        deferred_get("address", "_dst_addr_names", "_dst_addr", "addresses", True),
    )
    src_services = property(
        deferred_get(
            "service",
            "_src_services_names",
            "_src_services",
            "services",
            False,
        ),
    )

    @property
    def is_all(self):
        """Return False"""
        # does not support is_all for VIP
        return False

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the VIP from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the VIP

        Returns:
            an initialized `Vip`

        """
        # pylint: disable=too-many-branches,too-many-locals
        # get whether it is IPv6
        ipv6 = node.parent is not None and node.parent.name == "vip6"

        # get basic data
        name = node.name
        type_ = node.get_param("type", "static-nat")
        uuid = node.get_param("uuid", "")
        comment = node.get_param("comment", "")

        # get additional data only for static-nat
        src_ip = None
        src_addr = []
        src_iface = None
        portforward = False
        forward_proto = None
        src_services = []
        src_port = None
        dst_ip = None
        dst_addr = []
        dst_port = None
        if type_ == "static-nat":
            src_ip = node.get_param("extip")
            src_addr = node.get_param("extaddr", as_list=True)
            src_iface = node.get_param("extintf")
            src_services = node.get_param("service", as_list=True)
            dst_ip = node.get_param("mappedip", as_list=True)
            dst_addr = node.get_param("mapped-addr", as_list=True)
            # Port-related options are only available if portforward
            # is enabled
            portforward = node.get_param("portforward", "disable") == "enable"
            if portforward:
                forward_proto = node.get_param("protocol", "tcp")
                src_port = node.get_param("extport")
                dst_port = node.get_param("mappedport")

        # create the network object
        return cls(
            firewall,
            name,
            ipv6,
            type_,
            src_ip,
            src_addr,
            src_iface,
            portforward,
            forward_proto,
            src_services,
            src_port,
            dst_ip,
            dst_addr,
            dst_port,
            uuid,
            comment,
        )


class VipGroup(VipObject):
    """Provide a base class for groups

    Attributes:
        name (str): name of the object
        ipv6 (bool): whether the object is for IPv6
        uuid (str): UUID of the object
        comment (str): comment added on the object
        members (list): the list of members of the group. The items
            of this list are `VipObject`

    """

    __slots__ = ("_members_names", "_members")

    def __init__(self, firewall, name, ipv6, members, uuid="", comment=""):
        """Initialize the group from data"""
        super().__init__(firewall, name, ipv6, uuid, comment)
        self._members_names = members
        self._members = None

    members = property(deferred_get("VIP", "_members_names", "_members", "vips", True))

    @property
    def is_all(self):
        """Return True if the group represents all assets"""
        return any(member.is_all for member in self.members)

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the group from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the group

        Returns:
            an initialized `VipGroup`

        """
        # get whether it is IPv6
        ipv6 = node.parent is not None and node.parent.name == "vipgrp6"

        # get basic info
        name = node.name
        uuid = node.get_param("uuid", "")
        comment = node.get_param("comment", "")

        # depending on the version of FortiOS, member may be a list of
        # members names or a config whose edit sections are the members
        # name
        # map member config to a list of names
        if node.has(name="member", type="config"):
            members = map(lambda n: n.name, node["member"].children)
        else:
            members = node.get_param("member", as_list=True)

        return cls(firewall, name, ipv6, members, uuid, comment)


class Service(FirewallBoundObject):  # pylint: disable=too-few-public-methods
    """Base class for services

    A service can either be a `CustomService` or a `ServiceGroup`
    """

    __slots__ = ("name", "comment")

    def __init__(self, firewall, name, comment=""):
        """Initialize the object"""
        super().__init__(firewall, "services", name)
        self.name = name
        self.comment = comment

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        raise NotImplementedError("port_list must be implemented in subclasses")

    def allow_port(self, protocol, port):
        """Check whether this service match the given port

        Args:
            protocol (str): protocol to check (tcp or udp)
            port (int): port to check

        Returns:
            True if the port is matched

        """
        port_list = self.port_list()
        # Ensure only using authorized protocols
        if protocol not in port_list:
            return False
        for start, end in port_list[protocol]:
            if start <= port <= end:
                return True
        return False


class CustomService(Service):
    """Provide a class for services

    Attributes:
        name (str): name of the object
        comment (str): comment added on the object
        protocol (str): protocol of the service
        address (str): human-representation of the address
        tcp_ports (list): all matching TCP ports ranges (= a tuple)
        udp_ports (list): all matching UDP ports ranges (= a tuple)
        is_all (bool): whether the address cover all addresses

    """

    __slots__ = ("protocol", "address", "tcp_ports", "udp_ports", "is_all")

    def __init__(
        self,
        firewall,
        name,
        protocol,
        address,
        tcp_ports,
        udp_ports,
        is_all=False,
        comment="",
    ):
        """Initialize the service from data"""
        super().__init__(firewall, name, comment)
        self.protocol = protocol
        self.address = address
        self.tcp_ports = tcp_ports
        self.udp_ports = udp_ports
        self.is_all = is_all

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        return {
            "tcp": self.tcp_ports[:],
            "udp": self.udp_ports[:],
        }

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the service from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the service

        Returns:
            an initialized `CustomService`

        """
        # pylint: disable=too-many-branches,too-many-locals
        # get basic data
        name = node.name
        protocol = node.get_param("protocol", "TCP/UDP/SCTP")
        comment = node.get_param("comment", "")
        is_all = False
        tcp_ports = []
        udp_ports = []

        # Try to resolve the address, depending on the protocol
        # also compute whether the object cover all addresses
        if protocol == "IP":
            # IP uses protocol-number
            protocol_number = node.get_param("protocol-number", "0")
            # all if all IP protocols (0), encapsulated IPv4 (4),
            # :IPv6 (41), TCP (6), UDP (17), SCTP (132)
            is_all = protocol_number in ("0", "4", "6", "17", "41", "132")
            # all tcp_ports if TCP or all
            if protocol_number in ("0", "6"):
                tcp_ports.append((1, 65535))
            # all udp_ports if UDP or all
            if protocol_number in ("0", "17"):
                udp_ports.append((1, 65535))
            address = (
                pgettext("Network service IP proto", "IP protocol #%s")
                % protocol_number
                if protocol_number != "0"
                else pgettext("Network service IP proto", "all IP protocols")
            )

        elif protocol in ("ICMP", "ICMP6"):
            # ICMP uses icmptype and icmpcode
            icmptype = node.get_param("icmptype", None)
            icmpcode = node.get_param("icmpcode", None)
            is_all = False
            address = []
            if icmptype is not None:
                address.append(
                    pgettext("Network service ICMP", "ICMP type %s") % icmptype,
                )
            if icmpcode is not None:
                address.append(
                    pgettext("Network service ICMP", "ICMP code %s") % icmpcode,
                )
            address = "\n".join(address)

        elif protocol == "TCP/UDP/SCTP":
            # TCP uses tcp-portrange
            # UDP uses udp-portrange
            # SCTP uses sctp-portrange
            tcpports = node.get_param("tcp-portrange", None, as_list=True)
            udpports = node.get_param("udp-portrange", None, as_list=True)
            sctpports = node.get_param("sctp-portrange", None, as_list=True)

            is_all = False
            address = []

            if tcpports is not None:
                for p in tcpports:
                    # parse the ports to update tcp_ports
                    if ":" in p:
                        p = p.split(":")[0]
                    if "-" in p:
                        start, stop = p.split("-", 1)
                    else:
                        start = stop = p

                    # Update tcp_ports
                    start = int(start)
                    stop = int(stop)
                    tcp_ports.append((start, stop))

                    # Update is_all
                    if start <= 1 and 65535 <= stop:
                        is_all = True
                address.append(
                    pgettext("Network service TCP", "TCP ports: %s")
                    % ", ".join(tcpports),
                )

            if udpports is not None:
                for p in udpports:
                    # parse the ports to update udp_ports
                    if ":" in p:
                        p = p.split(":")[0]
                    if "-" in p:
                        start, stop = p.split("-", 1)
                    else:
                        start = stop = p

                    # Update udp_ports
                    start = int(start)
                    stop = int(stop)
                    udp_ports.append((start, stop))

                    # Update is_all
                    if start <= 1 and 65535 <= stop:
                        is_all = True
                address.append(
                    pgettext("Network service UDP", "UDP ports: %s")
                    % ", ".join(udpports),
                )

            if sctpports is not None:
                for p in sctpports:
                    # parse the ports to update is_all
                    if ":" in p:
                        p = p.split(":")[0]
                    if "-" in p:
                        start, stop = p.split("-", 1)
                    else:
                        start = stop = p

                    # Update is_all
                    start = int(start)
                    stop = int(stop)
                    if start <= 1 and 65535 <= stop:
                        is_all = True
                address.append(
                    pgettext("Network service SCTP", "SCTP ports: %s")
                    % ", ".join(sctpports),
                )
            address = "\n".join(address)

        elif node.get_param("proxy", "disable") == "enable":
            is_all = False
            if protocol == "ALL":
                address = pgettext("Network service proxy", "Full web proxy")
            else:
                address = pgettext("Network service proxy", "%s web proxy") % protocol
            protocol = pgettext("Network service", "Web proxy")

        else:
            logger.getLogger(__name__).warning(
                "Unknown protocol for Fortigate network service: %s",
                protocol,
            )
            address = ""

        # create the network object
        return cls(
            firewall,
            name,
            protocol,
            address,
            tcp_ports,
            udp_ports,
            is_all,
            comment,
        )


class ServiceGroup(Service):
    """Provide a base class for groups

    Attributes:
        name (str): name of the object
        comment (str): comment added on the object
        members (list): the list of members of the group. The items
            of this list are `Service`

    """

    __slots__ = ("_members_names", "_members")

    def __init__(self, firewall, name, members, comment=""):
        """Initialize the group from data"""
        super().__init__(firewall, name, comment)
        self._members_names = members
        self._members = None

    members = property(
        deferred_get("service", "_members_names", "_members", "services", False),
    )

    def allow_port(self, protocol, port):
        """Check whether this service match the given port

        Args:
            protocol (str): protocol to check (tcp or udp)
            port (int): port to check

        Returns:
            True if the port is matched

        """
        # A group only match if any of its member match
        for member in self.members:
            if member.allow_port(protocol, port):
                return True
        return False

    def port_list(self):
        """Retrieve the ports in a list

        Returns:
            A `dict` with a entry per protocol and with the value being
            the list of ports

        """
        # merge all member's port list
        ret = {}

        for member in self.members:
            for proto, ports in member.port_list().items():
                if proto not in ret:
                    ret[proto] = ports
                else:
                    ret[proto].extend(ports)

        return ret

    @property
    def is_all(self):
        """Return True if the group represents all assets"""
        return any(member.is_all for member in self.members)

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the group from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the group

        Returns:
            an initialized `ServiceGroup`

        """
        name = node.name
        comment = node.get_param("comment", "")

        # depending on the version of FortiOS, member may be a list of
        # members names or a config whose edit sections are the members
        # name
        # first map member config to a list of names
        if node.has(name="member", type="config"):
            members = map(lambda n: n.name, node["member"].children)
        else:
            members = node.get_param("member", as_list=True)

        return cls(firewall, name, members, comment)


class Rule(FirewallBoundObject):
    """Represent a rule in the matrix"""

    # Use slots to reduce memory consumption
    __slots__ = (
        "policyid",
        "name",
        "ipv6",
        "uuid",
        "action",
        "enabled",
        "_srcaddr_names",
        "_srcaddr",
        "negate_src",
        "srciface",
        "_dstaddr_names",
        "_dstaddr",
        "negate_dst",
        "dstiface",
        "_services_names",
        "_services",
        "negate_services",
        "utm",
        "ips_sensor",
        "av_profile",
        "waf_profile",
        "logtraffic",
    )

    def __init__(  # pylint: disable=too-many-arguments,too-many-locals
        self,
        firewall,
        policyid,
        name,
        ipv6,
        action,
        srcaddr,
        srciface,
        dstaddr,
        dstiface,
        services,
        uuid="",
        enabled=True,
        negate_src=False,
        negate_dst=False,
        negate_services=False,
        utm=False,
        ips_sensor=None,
        av_profile=None,
        waf_profile=None,
        logtraffic="utm",
    ):
        """Initialize the rules with the data"""
        super().__init__(firewall, "policies6" if ipv6 else "policies", policyid)
        self.policyid = policyid
        self.name = name
        self.ipv6 = ipv6
        self.action = action
        self.enabled = enabled
        self._srcaddr_names = srcaddr
        self._srcaddr = None
        self.srciface = srciface
        self._dstaddr_names = dstaddr
        self._dstaddr = None
        self.dstiface = dstiface
        self._services_names = services
        self._services = None
        self.uuid = uuid
        self.negate_src = negate_src
        self.negate_dst = negate_dst
        self.negate_services = negate_services
        self.utm = utm
        self.ips_sensor = ips_sensor
        self.av_profile = av_profile
        self.waf_profile = waf_profile
        self.logtraffic = logtraffic

    # register the deferred getter for firewall objects
    srcaddr = property(
        deferred_get("address", "_srcaddr_names", "_srcaddr", "addresses_vips", True),
    )
    dstaddr = property(
        deferred_get("address", "_dstaddr_names", "_dstaddr", "addresses_vips", True),
    )
    services = property(
        deferred_get("service", "_services_names", "_services", "services", False),
    )

    @classmethod
    def from_node(cls, firewall, node):
        """Initialize the rule from the associated node

        Args:
            firewall (Firewall): the associated firewall instance
            node (Node): Node of the policy

        Returns:
            an initialized `Rule`

        """
        # pylint: disable=too-many-branches,too-many-locals
        # get whether it is IPv6
        ipv6 = node.parent is not None and node.parent.name == "policy6"

        # init the base of the rule
        policyid = int(node.name)
        name = node.get_param("name", "")
        uuid = node.get_param("uuid", "")
        action = node.get_param("action", "deny")
        enabled = node.get_param("status", "enable") == "enable"
        negate_src = node.get_param("srcaddr-negate", "disable") == "enable"
        negate_dst = node.get_param("dstaddr-negate", "disable") == "enable"
        negate_serv = node.get_param("service-negate", "disable") == "enable"
        negate_serv = node.get_param("service-negate", "disable") == "enable"
        logtraffic = node.get_param("logtraffic", "utm")
        utm = node.get_param("utm-status", "disable") == "enable"
        if utm:
            ips_sensor = node.get_param("ips-sensor", None)
            av_profile = node.get_param("av-profile", None)
            waf_profile = node.get_param("waf-profile", None)
        else:
            ips_sensor = av_profile = waf_profile = None

        # retrieve sources
        # source can be either in
        #   - config srcaddr edit name
        #   - config srcaddr6 edit name for ipv6
        #   - set srcaddr
        #   - set srcaddr6 for ipv6
        if node.has(name="srcaddr", type="config"):
            src = map(lambda n: n.name, node["srcaddr"].children)
        elif node.has(name="srcaddr6", type="config") and ipv6:
            src = map(lambda n: n.name, node["srcaddr6"].children)
        else:
            src = node.get_param("srcaddr", [], as_list=True) + node.get_param(
                "srcaddr6",
                [],
                as_list=True,
            )

        # retrieve destinations
        # destinations can be either in
        #   - config dstaddr edit name
        #   - config dstaddr6 edit name for ipv6
        #   - set dstaddr
        #   - set dstaddr6 for ipv6
        if node.has(name="dstaddr", type="config"):
            dst = map(lambda n: n.name, node["dstaddr"].children)
        elif node.has(name="dstaddr6", type="config") and ipv6:
            dst = map(lambda n: n.name, node["dstaddr6"].children)
        else:
            dst = node.get_param("dstaddr", [], as_list=True) + node.get_param(
                "dstaddr6",
                [],
                as_list=True,
            )

        # retrieve source ifaces
        # source can be either in
        #   - config srcintf edit name
        #   - set srcintf
        if node.has(name="srcintf", type="config"):
            srciface = map(lambda n: n.name, node["srcintf"].children)
        else:
            srciface = node.get_param("srcintf", [], as_list=True)

        # retrieve destination ifaces
        # source can be either in
        #   - config dstintf edit name
        #   - set dstintf
        if node.has(name="dstintf", type="config"):
            dstiface = map(lambda n: n.name, node["dstintf"].children)
        else:
            dstiface = node.get_param("dstintf", [], as_list=True)

        # retrieve services
        # services can be either in
        #   - config service edit name
        #   - set service
        if node.has(name="service", type="config"):
            service = map(lambda n: n.name, node["service"].children)
        else:
            service = node.get_param("service", as_list=True)

        return cls(
            firewall,
            policyid,
            name,
            ipv6,
            action,
            src,
            srciface,
            dst,
            dstiface,
            service,
            uuid,
            enabled,
            negate_src,
            negate_dst,
            negate_serv,
            utm,
            ips_sensor,
            av_profile,
            waf_profile,
            logtraffic,
        )
