# -*- coding: utf-8 -*-

"""Implement helpers to parse SSSD configuration files"""

# Standard libraries
import os

# Project imports
from engine.techs.common import parse_ini


def parse_sssd_conf(sssd_files):
    """Parse SSSD configuration

    Read the configuration as SSSD would do and return the parsed INI.
    See help(parse_ini) for output format.

    Arguments
    ---------
    sssd_files -- a dict of file contents indexed by filepath

    """
    # find SSSD conf files
    names = []
    for p in sssd_files:
        if p.startswith("/etc/sssd/conf.d/"):
            # Only not hidden *.conf files are read by sssd
            f = os.path.basename(p)
            if f[0] != "." and len(f) >= 5 and f[-5] == ".conf":
                names.append(p)
    # sort them alphabetically
    names = sorted(names)
    # first read "/etc/sssd/sssd.conf"
    if "/etc/sssd/sssd.conf" in sssd_files:
        names.insert(0, "/etc/sssd/sssd.conf")

    # read and merge all files in the above defined order
    ret = {}
    for p in names:
        tmp = parse_ini(sssd_files[p])
        for s in tmp:
            if s in ret:
                ret[s].update(tmp[s])
            else:
                ret[s] = tmp[s]
    return ret
