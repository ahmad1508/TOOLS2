# -*- coding: utf-8 -*-

"""Implement helpers to parse sysctl configurations"""

# Standard libraries
from functools import reduce

# Project imports
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n
from engine.techs.common import conformity_row, key_value2dict, table2bbcode

# I18N
M_ = i18n.domain("linux").M_
pgettext = i18n.domain("linux").pgettext


def sysctl_review(extract, conf, findings=None):
    """Do a sysctl review

    Parse the extract
    Go through all sysctl in conf (see format below) and create a
    conformity table and a conformitiy message at the end.

    conf is a list of data for each sysctl. Each item is composed of:
        - A short text description (for the table),
        - A longer description (for the conformity message),
        - The sysctl name,
        - The recommanded value,
        - The comparison lambda or "eq", "neq", "gt", "ge", "lt", "le",
        - The accepation lambda (optional),
        - A reduce lambda for globing sysctls

    Arguments
    ---------
    extract -- extract of sysctl -a
    conf -- configuration of sysctl to review

    Returns
    -------
    A tuple:
        - A introducing text
        - The conformity table
        - A conformity message

    """
    # parse sysctl
    sysctl = {}
    # create a nested dict
    for k, v in key_value2dict(extract, sep="=").items():
        cur = sysctl
        parts = k.split(".")
        # create parent dict
        for part in parts[:-1]:
            if part not in cur:
                cur[part] = {}
            cur = cur[part]
        # store the leaf value
        cur[parts[-1]] = v

    # create conformity table
    tab = [
        [
            pgettext("conformity", "Configuration"),
            pgettext("conformity", "Valeur recommandée"),
            pgettext("conformity", "Valeur constatée"),
            pgettext("conformity", "Statut"),
            pgettext("conformity", "Sysctl"),
        ],
    ]
    recom_msg = []

    # helpers for conformity
    conform_helpers = {
        "eq": lambda v, r: v == r,
        "neq": lambda v, r: v != r,
        "gt": lambda v, r: v > r,
        "ge": lambda v, r: v >= r,
        "lt": lambda v, r: v < r,
        "le": lambda v, r: v <= r,
    }

    # helper to extract the right set of sysctl, accepting globing
    def _sysctl_glob(name):
        parts = name.split(".")
        cur = [sysctl]
        for p in parts:
            nxt = []
            for c in cur:
                if p == "*":
                    nxt.extend(c.values())
                elif p in c:
                    nxt.append(c[p])
            cur = nxt
        return cur

    # helper to extract the sysctl into the conformity table
    def _get(desc, att, name, reco, c_lamb, a_lamb=None, red=None):
        sysctl_values = _sysctl_glob(name)
        if len(sysctl_values) == 0:
            return
        else:
            sysctl_values = int(reduce(red, sysctl_values))
        if isinstance(c_lamb, str):
            c_lamb = conform_helpers[c_lamb]
        t, c = conformity_row(desc, reco, sysctl_values, None, c_lamb, a_lamb)
        tab.append(t + [M("[i]%s[/i]") % name])
        if not c:
            if findings is None:
                recom_msg.append(M("[*] [b]%s[/b] : %s") % (name, att))
            else:
                findings.vuln(M("[b]%s[/b] : %s") % (name, att))

    # Iterate through each sysctl using our helpers
    for c in conf:
        _get(*c)

    # Create the conformity message
    if findings is not None:
        recom_t = ""
    elif len(recom_msg) == 0:
        recom_t = M_(
            "La configuration des sysctl [b]est donc satisfaisante[/b].",
        )
    else:
        recom_t = M_(
            "La configuration des sysctl [b]n’est donc pas satisfaisante[/b] :"
            "[list]%s[/list]",
        ) % M("").join(recom_msg)

    return (
        M_("Les configurations du noyau suivantes doivent être revues :")
        + table2bbcode(
            tab,
            M_("Paramètres de configuration du noyau ([i]sysctl[/i])"),
        )
        + recom_t
    )
