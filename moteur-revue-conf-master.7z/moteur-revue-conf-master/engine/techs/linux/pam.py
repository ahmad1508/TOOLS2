# -*- coding: utf-8 -*-

"""Implement helpers to parse PAM configuration files"""

# Standard libraries
import os

# Project imports
from engine.techs.common import extract_without_comment


def _parse_one_pam_conf(inp, pam_files, do_include, with_service=False):
    """Parse one file

    Parse one file and return the list of rules
    It also handles @include statement. If do_include is set, the
    statement will be replaced by rules within the file. Else, the
    inclusion will be added to a special type @include

    Arguments
    ---------
    inp -- content of the file to parse
    pam_files -- the dict of PAM config files
    do_include -- whether @include statements should be expanded
    with_service -- wether to consider first token as service name
                    Default is False

    """
    # remove comments & blank lines
    cont = extract_without_comment(inp)

    # parse each lines
    ret = []
    for line in cont.splitlines():
        if line.startswith("@include"):
            inc_file = line.split(None, 1)[1]
            if do_include:
                ret.extend(
                    _parse_one_pam_conf(
                        pam_files["/etc/pam.d/%s" % inc_file.strip()],
                        pam_files,
                        do_include,
                        with_service,
                    ),
                )
            else:
                ret.append(["@include", inc_file])
        else:
            # dismiss the starting '-' used not to log errors
            if line[0] == "-":
                rem = line[1:]
            else:
                rem = line
            # service
            if with_service:
                service, rem = rem.split(None, 1)
            # type
            tpe, rem = rem.split(None, 1)
            # control
            if rem[0] == "[":
                control, rem = rem[1:].split("]", 1)
                control = "[%s]" % control
                rem = rem.lstrip()
            else:
                control, rem = rem.split(None, 1)
            # module and arguments
            rem = rem.split(None, 1)
            if len(rem) == 1:
                # handle cases with no arguments
                module, args = rem[0], ""
            else:
                module, args = rem
            # store the rule
            if with_service:
                ret.append([service, tpe, control, module, args])
            else:
                ret.append([tpe, control, module, args])
    return ret


def parse_pam_conf(pam_files, do_include=True):
    """Parse Linux PAM configuration

    Read the configuration as PAM would do and create an object
    {
        "service": {
            "type": [
                ["control", "module", "argument"]
            ]
        }
    }

    Arguments
    ---------
    pam_files -- a dict of file contents indexed by filepath
    do_include -- whether @include statements should be expanded
                    Default: True

    """
    ret = {}
    # parse pam.d files
    for path in pam_files:
        if path.startswith("/etc/pam.d/"):
            # get service from filename
            service = os.path.basename(path)
            ret[service] = {}
            # get all rules
            rules = _parse_one_pam_conf(pam_files[path], pam_files, do_include)
            # parse the rules to group per type
            for r in rules:
                if r[0] not in ret[service]:
                    ret[service][r[0]] = []
                ret[service][r[0]].append(r[1:])

    # parse pam.conf
    if "/etc/pam.conf" in pam_files:
        # get all rules
        rules = _parse_one_pam_conf(
            pam_files["/etc/pam.conf"],
            pam_files,
            do_include,
            True,
        )
        # parse the rules to group per service and type
        for r in rules:
            # services in pam.conf are ignored if one is already defined
            # in pam.d/*
            if r[0] in ret:
                continue
            # group per type
            if r[1] not in ret[r[0]]:
                ret[r[0]][r[1]] = []
            ret[r[0]][r[1]].append(r[2:])
    return ret
