# -*- coding: utf-8 -*-

"""Implement helpers to parse network data"""

# Standard libraries
from binascii import unhexlify
import os
import re
import socket
from struct import pack, unpack

# Project imports
from engine import logger
from engine.core import i18n
from engine.techs.common import netmask_to_cidr

# I18N
_ = i18n.domain("linux")._
pgettext = i18n.domain("linux").pgettext


########################################################################
#                              INTERFACES                              #
########################################################################


def parse_network_interfaces(new_style="", old_style=""):
    """Parse the list of network interfaces

    It can use either the new style (ip a) listing or the old style
    (ifconfig -a) listing.

    Arguments
    ---------
    new_style -- the output of ip a. Default: ""
    old_style -- the output of ifconfig -a. Default: ""

    Return
    ------
    A list of all interfaces. Each interface is described in a dict:
        - name: name of the interface
        - addr: list of all interface IPv4 addresses
        - addr6: list of all interface IPv6 addresses
        - hwtype: type of the hardware
        - hwaddr: hardware address of the inteface
        - mtu: MTU of the interface
        - state: state of the interface

    """
    # list to hold values to be returned
    ret = []
    # if the new style output is given, we rely on it first
    # we delegate to the methods which parse each style
    if new_style != "" and "command not found" not in new_style:
        ret = _parse_net_interface_new(new_style)
    elif old_style != "" and "command not found" not in old_style:
        ret = _parse_net_interface_old(old_style)
    # return parsed data
    return ret


# few regex to parse specific lines of ip a
NET_INT_NEW_INTERFACE_RE = re.compile(
    r"^\d: "
    r"(?P<name>[^:]+):"
    r".*mtu (?P<mtu>\d+)"
    r".*(?:state (?P<state>[^ ]+))?"
    r".*$",
)
NET_INT_NEW_INET_RE = re.compile(
    r"^\s*inet (?P<addr>(\d+\.){3}\d+/\d+).*$",
)
NET_INT_NEW_INET6_RE = re.compile(
    r"^\s*inet6 (?P<addr6>[a-f\d]*(:[a-f\d]*){,7}/\d+).*$",
)
NET_INT_NEW_HW_RE = re.compile(
    r"^.*link/(?P<hwtype>[^ ]*) ?(?P<hwaddr>[^ ]*).*$",
)


def _parse_net_interface_new(inp):
    """Parse the list of network interface of ip a

    For info on the returned value, see help(parse_network_interfaces)
    """
    # list to hold the list of interfaces
    ret = []

    # buffer to hold the data of the interface currently being parsed
    dev = None

    # Parse each line and update the interface data accordingly
    for line in inp.splitlines():
        # Match first line of new interface
        m = NET_INT_NEW_INTERFACE_RE.match(line)
        if m:
            # save the previous interface if any
            if dev is not None:
                ret.append(dev)
            # start a new interface
            dev = {
                "name": "",
                "addr": [],
                "addr6": [],
                "hwtype": "",
                "hwaddr": "",
                "mtu": "",
                "state": "Unknown",
            }
            dev.update(m.groupdict(""))
            continue

        # Match hardware address line
        m = NET_INT_NEW_HW_RE.match(line)
        if m:
            if dev:
                dev.update(m.groupdict())
            else:
                logger.getLogger(__name__).warning(
                    "Parsing interfaces, found line matching hardware address "
                    "but no line matching a new interface",
                )
            continue

        # Match inet & inet6 address lines
        for regex in (NET_INT_NEW_INET_RE, NET_INT_NEW_INET6_RE):
            m = regex.match(line)
            if m:
                if dev:
                    # we should append the address in the correct list
                    # named with the group
                    # NOTE: the groupdict should be a single-item dict
                    for t, v in m.groupdict().items():
                        dev[t].append(v)
                    break
                else:
                    logger.getLogger(__name__).warning(
                        "Parsing interfaces, found line matching inet address "
                        "but no line matching a new interface",
                    )

    # save the last parsed interface if any
    if dev is not None:
        ret.append(dev)

    # return the list of interface
    return ret


# few regex to parse specific lines of ifconfig -a
NET_INT_OLD_INTERFACE_RE = re.compile(
    r"^(?P<name>\S+)\s+"
    r"Link encap:(?P<hwtype>\S+)\s+"
    r"(Loopback|HWaddr (?P<hwaddr>\S+)).*$",
)
NET_INT_OLD_INET_RE = re.compile(
    r"^\s+inet addr:\s*(?P<addr>\S+).*Mask:(?P<mask>\S+).*$",
)
NET_INT_OLD_INET6_RE = re.compile(
    r"^\s+inet6 addr:\s*(?P<addr6>[a-f\d]*(:[a-f\d]*){,7}/\d+).*$",
)
NET_INT_OLD_MTU_RE = re.compile(
    r"^\s+.* MTU:(?P<mtu>\d+).*$",
)


def _parse_net_interface_old(inp):
    """Parse the list of network interface of ifconfig -a

    For info on the returned value, see help(parse_network_interfaces)
    """
    # list to hold the list of interfaces
    ret = []

    # buffer to hold the data of the interface currently being parsed
    dev = None

    # Parse each line and update the interface data accordingly
    for line in inp.splitlines():
        # Match first line of new interface
        m = NET_INT_OLD_INTERFACE_RE.match(line)
        if m:
            # save the previous interface if any
            if dev is not None:
                ret.append(dev)
            # start a new interface
            dev = {
                "name": "",
                "addr": [],
                "addr6": [],
                "hwtype": "",
                "hwaddr": "",
                "mtu": "",
                "state": "Unknown",
            }
            dev.update(m.groupdict(""))
            continue

        # Match MTU line
        m = NET_INT_OLD_MTU_RE.match(line)
        if m:
            dev.update(m.groupdict())
            continue

        # Match IPv4 address line
        m = NET_INT_OLD_INET_RE.match(line)
        if m:
            dev["addr"].append(
                "%s/%s"
                % (
                    m.group("addr"),
                    netmask_to_cidr(m.group("mask")),
                ),
            )
            continue

        # Match IPv6 address line
        m = NET_INT_OLD_INET6_RE.match(line)
        if m:
            dev["addr6"].append(m.group("addr6"))
            continue

    # save the last parsed interface if any
    if dev is not None:
        ret.append(dev)

    # return the list of interface
    return ret


########################################################################
#                               SERVICES                               #
########################################################################


def parse_network_services(
    new_style="",
    old_style="",
    procfs_net=None,
    procfs_cmdline=None,
    procfs_fd="",
    sysfs_ifindex=None,
):
    """Parse the list of network services

    It can use either the new style (ss) listing, the old style
    (netstat) listing or procfs/sysfs parsing.

    The order of precedence is:
        - New style (ss), enhanced if possible with procfs_cmdline
            (because program name is truncated to 15 characters)
        - Procfs parsing
        - Old style (netstat)

    Limitations:
        - New style ss:
            The program name is truncated to 15 characters.
            ss use netlink sockets to get listening sockets what is
            the recommended way to do.
        - Procfs parsing:
            May not be available for all extracts.
            It is not possible to determine whether a AF_INET6 socket
            is IPv6 only (cf RFC3493) or has a dual stack IPv6/IPv4.
            It is not possible to determine whether a socket is bound
            to a specific interface.
        - Old style netstat:
            netstat do the same work as procfs parsing. It suffers the
            same limitations.
            netstat has no support for packet sockets.
            Process names are prepended with PID and the whole string is
            trucated to 19 characters.
            IPs trucated in order for IP+port number to be 23-characters
            long. Cause long IPv4 and most IPv6 to be truncated.

    Due to a bug in ss utility, it is not possible to cleanly parse
    columns in new style output: depending on listening services, there
    may be no separators between columns.
    It was corrected in commit 0024089. See:
    https://github.com/shemminger/iproute2/commit/0024089

    To avoid the issue, it is possible to reduce the number of
    supported netid to limit to known line format.
    Only the following netid are supported:
        - udp
        - tcp
        - raw
        - p_dgr and p_raw

    Arguments
    ---------
    new_style -- the output of ss. Default: ""
    old_style -- the output of netstat. Default: ""
    procfs_net -- the files in /proc/net
    procfs_cmdline -- cmdline files in the procfs entry of each process
    procfs_fd -- the output of `stat -c %N` on each fd in procfs
    sysfs_ifindex -- ifindex files in the sysfs entry of each iface

    Return
    ------
    A list of all services. Each service is described in a dict:
        - type: type of the service (tcp, udp, …)
        - laddr: local address
        - lport: local port
        - liface: locally bound interface
        - raddr: remote address
        - rport: remote port
        - recvq: length of data in the receive queue
        - sendq: length of data in the send queue
        - proc: associated process name

    """
    # ensure initialization of dict if None
    if procfs_net is None:
        procfs_net = {}
    if procfs_cmdline is None:
        procfs_cmdline = {}
    if sysfs_ifindex is None:
        sysfs_ifindex = {}
    # list to hold values to be returned
    ret = []
    # Retrieve the dict of full program names to enrich all outputs
    programs = _parse_procfs_cmdline(procfs_cmdline)
    # if the new style output is given, we rely on it first
    # we delegate to the methods which parse each style
    if len(ret) == 0 and new_style != "" and "command not found" not in new_style:
        ret = _parse_net_services_new(new_style, programs)

    if len(ret) == 0 and len(procfs_net) > 0:
        ret = _parse_net_services_procfs(procfs_net, procfs_fd, sysfs_ifindex, programs)
    if len(ret) == 0 and old_style != "" and "command not found" not in old_style:
        ret = _parse_net_services_old(old_style, programs)

    # return parsed data
    return ret


def _get_sock_type(proto):
    """Unify socket type between all parsing methods"""
    return {
        "tcp": "TCP",  # noqa: E241
        "tcp6": "TCP",  # noqa: E241
        "udp": "UDP",  # noqa: E241
        "udp6": "UDP",  # noqa: E241
        "raw": "Raw",  # noqa: E241
        "raw6": "Raw",  # noqa: E241
        "packet": "Packet",  # noqa: E241
        "p_dgr": "Packet",  # noqa: E241
        "p_raw": "Packet",  # noqa: E241
    }[proto]


# few regex to parse lines
# only handle tcp, udp, raw & AF_PACKET sockets (p_dgr & p_raw)
# what changes between socket types are local & remote addresses:
#   tcp & udp       ==> IP:PORT as source & destination
#   raw             ==> IP:PROTOCOL as source, *:* as destination
#   p_dgr & p_raw   ==> ETHERTYPE:INTERFACE as source, * as destination
NET_SERV_NEW_RE = re.compile(
    r"^("
    # Netid column
    r"(?P<proto>tcp|udp|raw|p_dgr|p_raw)\s*"
    # State column
    r"(?P<state>UNKNOWN|UNCONN|LISTEN)\s*"
    # Recv-Q column
    r"(?P<recvq>\d+)\s*"
    # Send-Q column
    r"(?P<sendq>\d+)\s*"
    # Local Address column
    r"(?P<laddr>"
    # IPv6 & Ethertypes are usually enclosed in brackets
    # but sometimes, then are not…
    # can also be IPv4 or *
    r"[^%\s]+"
    r")"
    r"(%(?P<liface>[^:]+))?"  # optional iface binding
    # Local Port column
    r":"
    r"(?P<lport>\S*)\s*"
    # Remote columns
    # can be a 2-part address or 1-part address
    r"("
    # Remote Address column for 2-part address
    r"(?P<raddr>"
    # IPv6 & Ethertypes are usually enclosed in brackets
    # but sometimes, then are not…
    # can also be IPv4 or *
    r"[^%\s]+"
    r")"
    # Remote Port column
    r":"
    r"(?P<rport>\d+|\*)\s*"
    r"|"
    # 1-part address
    r"(?P<remote>\*)"
    r")\s*"
    # Extra data column
    r"("
    r"users:\(\("
    r"\"(?P<proc>[^\"]+)\","  # process name
    r"(pid=)?(?P<pid>\d+),"  # PID
    r".*"
    r"\)\)"
    r")?"
    r"\s*)$",
)  # noqa: E141


def _parse_net_services_new(inp, programs=None):
    """Parse the list of network services of ss -lpn

    For info on the returned value, see help(parse_network_services)
    """
    # ensure programs default
    if programs is None:
        programs = {}
    # list to store parsed services
    ret = []
    # try to match each line
    for line in inp.splitlines():
        m = NET_SERV_NEW_RE.match(line)
        # if we match, store the parsed data
        if m:
            d = m.groupdict("")
            # normalize the socket type/family
            family = _get_sock_type(d["proto"])
            # normalize IPv6 bracket-enclosed addresses
            if len(d["laddr"]) > 2 and d["laddr"][0] == "[" and d["laddr"][-1] == "]":
                d["laddr"] = d["laddr"][1:-1]
            if len(d["raddr"]) > 2 and d["raddr"][0] == "[" and d["raddr"][-1] == "]":
                d["raddr"] = d["raddr"][1:-1]
            # normalize 1-part addr & 2-part addr
            if d["remote"] != "":
                d["raddr"] = d["rport"] = d["remote"]
            # normalize pid
            if d["pid"].isdigit():
                pid = int(d["pid"])
            else:
                pid = 0

            # store the parsed data
            ret.append(
                {
                    "type": family,
                    "laddr": d["laddr"],
                    "lport": d["lport"],
                    "liface": d["liface"],
                    "raddr": d["raddr"],
                    "rport": d["rport"],
                    "recvq": int(d["recvq"]),
                    "sendq": int(d["sendq"]),
                    "proc": programs[pid] if pid in programs else d["proc"],
                },
            )
    # return parsed data
    return ret


def _parse_net_services_old(inp, programs=None):
    """Parse the list of network services of netstat -lpn

    For info on the returned value, see help(parse_network_services)
    """
    # ensure default initialisation
    if programs is None:
        programs = {}
    # list to store parsed services
    ret = []
    # netstat columns are composed as following:
    #   - socket type
    #   - recv queue
    #   - send queue
    #   - laddr:lport
    #   - raddr:lport
    #   - state
    #   - PID/process name
    for line in inp.splitlines():
        # skip empty lines
        if line.strip() == "":
            continue
        # only work on supported socket type
        family = line.split()[0]
        if family in ("tcp", "tcp6", "udp", "udp6", "raw", "raw6"):
            splits = line.split()
            # normalize the socket type/family
            family = _get_sock_type(family)
            # some sockets (e.g. UDP) do not have a state
            # the split has then one less item
            # ensure an empty state is added for these sockets
            if len(splits) == 6:
                splits.insert(5, "")

            # split the right column between pid & prog name
            pid, proc = splits[6].split("/", 1)
            if pid.isdigit():
                pid = int(pid)
            else:
                pid = 0

            # store the parsed data
            ret.append(
                {
                    "type": family,
                    "laddr": splits[3].rsplit(":", 1)[0],
                    "lport": splits[3].rsplit(":", 1)[1],
                    "liface": "",
                    "raddr": splits[4].rsplit(":", 1)[0],
                    "rport": splits[4].rsplit(":", 1)[1],
                    "recvq": int(splits[1]),
                    "sendq": int(splits[2]),
                    "proc": programs[pid] if pid in programs else proc,
                },
            )
    # return parsed data
    return ret


def _parse_net_services_procfs(procfs_net, procfs_fd, sysfs_ifindex, programs):
    """Parse the list of network services using procfs data

    Arguments
    ---------
    procfs_net -- the files in /proc/net
    procfs_fd -- the output of `stat -c %N` on each fd in procfs
    sysfs_ifindex -- ifindex files in the sysfs entry of each iface
    programs -- a dict of programs associating PID to cmdline

    """
    ret = []
    # parse procfs_fd & sysfs_ifindex for enrichment
    fds = _parse_procfs_fd(procfs_fd)
    ifindexes = _parse_sysfs_ifindex(sysfs_ifindex)

    # parse inet procfs files
    for fname in ("tcp", "tcp6", "udp", "udp6", "raw", "raw6"):
        # skip if file does not exist
        if "/proc/net/" + fname not in procfs_net:
            continue
        # do the parsing of each file & add services
        for s in _parse_net_inet(procfs_net["/proc/net/" + fname]):
            # unstack the tuple into more meaningful var
            loc_a, loc_p, rem_a, rem_p, rx_q, tx_q, ino = s

            # resolve socket type
            family = _get_sock_type(fname)
            # resolve socket inode to program name
            if ino in fds and fds[ino][0] in programs:
                proc = programs[fds[ino][0]]
            else:
                proc = ""

            # store the parsed data
            ret.append(
                {
                    "type": family,
                    "laddr": loc_a,
                    "lport": str(loc_p),
                    "liface": "",
                    "raddr": rem_a,
                    "rport": str(rem_p),
                    "recvq": rx_q,
                    "sendq": tx_q,
                    "proc": proc,
                },
            )

    # parse packet procfs file
    if "/proc/net/packet" in procfs_net:
        for s in _parse_net_packet(procfs_net["/proc/net/packet"]):
            # unpack the service tuple
            family, proto, ifindex, ino = s

            # resolve socket type
            family = _get_sock_type(family)
            # resolve socket inode to program name
            if ino in fds and fds[ino][0] in programs:
                proc = programs[fds[ino][0]]
            else:
                proc = ""
            # resolve ifindex to ifname
            if ifindex == 0:
                # special value for all interfaces
                ifname = "*"
            elif ifindex in ifindexes:
                ifname = ifindexes[ifindex]
            else:
                ifname = pgettext("net intefaces", "inconnue")
            # resolve protocol to name
            if proto == 3:
                proto = "*"
            elif proto in _ETH_P:
                proto = _ETH_P[proto]
            else:
                proto = str(proto)

            # store the parsed data
            ret.append(
                {
                    "type": family,
                    "laddr": proto,
                    "lport": ifname,
                    "liface": "",
                    "raddr": "*",
                    "rport": "*",
                    "recvq": 0,
                    "sendq": 0,
                    "proc": proc,
                },
            )

    return ret


def _parse_procfs_cmdline(procfs_cmdline):
    """Parse the list of cmdline files to build a hash program names

    Arguments
    ---------
    procfs_cmdline -- the dict of files /proc/*/cmdline

    Return
    ------
    A dict associating a PID to the program name

    """
    # cmdline correspond to the arguments of the program
    # As usual, the first argument corresponds to the program
    # in the way it was called (e.g. ./path/to/myprogram)
    # Each argument is separated with a null byte
    ret = {}
    for name in procfs_cmdline:
        fd = int(name.split("/")[2])
        ret[fd] = os.path.basename(procfs_cmdline[name].split(b"\0")[0].decode("utf-8"))
    return ret


def _parse_sysfs_ifindex(sysfs_ifindex):
    """Parse the list of ifindex files to build a dict of iface index

    Arguments
    ---------
    sysfs_ifindex -- the dict of files /sys/class/net/*/ifindex

    Return
    ------
    A dict associating a ifindex to a iface name

    """
    ret = {}
    for name in sysfs_ifindex:
        ifname = name.split("/")[4]
        ret[int(sysfs_ifindex[name].strip())] = ifname
    return ret


NET_PROCFS_FD_RE = re.compile(
    r"^.?/proc/(\d+)/fd/(\d+).?\s*->\s*.?socket:\[(\d+)\].?$",
)


def _parse_procfs_fd(procfs_fd):
    """Parse the list of fd to build a hash of socket

    Arguments
    ---------
    procfs_fd -- the output of `stat -c %N` on each fd in procfs

    Return
    ------
    A dict associating a socket inode to a tuple (process ID, fd ID)

    """
    # each line of fd_list which should be parsed has the format
    #   '/proc/PID/fd/FDID' -> 'socket[SOCKET_INODE]'
    ret = {}
    for line in procfs_fd.splitlines():
        m = NET_PROCFS_FD_RE.match(line)
        if m:
            pid, fid, sock_ino = m.groups()
            ret[int(sock_ino)] = (int(pid), int(fid))
    return ret


def _parse_net_inet(content):
    """Parse data of inet family sockets (both INET and INET6)

    The following files can be parsed with this function:
        - /proc/net/tcp
        - /proc/net/tcp6
        - /proc/net/udp
        - /proc/net/udp6
        - /proc/net/raw
        - /proc/net/raw6

    Arguments
    ---------
    content -- content of the file to parse

    Returns
    -------
    A list of listening sockets. Each socket is a tuple:
        - local address
        - local port
        - remote address
        - remote port
        - length of data in the receive queue
        - length of data in the send queue
        - socket inode

    """
    ret = []
    # Each line is composed as such :
    #   sl  local_address rem_address   st tx_queue rx_queue
    #   tr tm->when retrnsmt   uid  timeout inode ref pointer
    #   extradata
    # e.g.
    #    0: 00000000:2282 00000000:0000 0A 00000000:00000000
    #   00:00000000 00000000     0        0 53265 1  000000004fbbc713
    #   100 0 0 10 0
    # the first line is the header, to be skipped
    #
    # Addresses packing depends on the system endianness
    # For little endian
    #   0100007F ==> 127.0.0.1
    #   000000000000000FFFF00000100007F ==> ::ffff:127.0.0.1
    #
    # Addresses are stored in network byte order (big endian)
    # and are printed in procfs as 4-bytes words.
    # IPv6 is composed of 4 4-bytes words treated separately
    #
    for line in content.splitlines()[1:]:
        # extract data from line
        part = line.strip().split()
        loc_a, loc_p = part[1].split(":")
        rem_a, rem_p = part[2].split(":")
        state = int(part[3], 16)
        tx_q, rx_q = part[4].split(":")
        inode = int(part[9])

        # only list listenning sockets
        #  for TCP, LISTEN == state 10
        #  for UDP & Raw, UNCONN == 7
        if state != 10 and state != 7:
            continue

        # parse extracted data
        ip6 = len(loc_a) == 32
        if ip6:
            spack = "!4I"
            sunpack = "=4I"
        else:
            spack = "!I"
            sunpack = "=I"
        ret.append(
            (
                # local address
                socket.inet_ntop(
                    socket.AF_INET6 if ip6 else socket.AF_INET,
                    pack(spack, *unpack(sunpack, unhexlify(loc_a))),
                ),
                # local port
                int(loc_p, 16),
                # remote address
                socket.inet_ntop(
                    socket.AF_INET6 if ip6 else socket.AF_INET,
                    pack(spack, *unpack(sunpack, unhexlify(rem_a))),
                ),
                # remote port
                int(rem_p, 16),
                # receive & send queues
                int(rx_q, 16),
                int(tx_q, 16),
                # socket inode
                int(inode),
            ),
        )
    return ret


def _parse_net_packet(content):
    """Parse data of /proc/net/packet

    Arguments
    ---------
    content -- content of the file to parse

    Returns
    -------
    A list of AF_PACKET sockets. Each socket is a tuple:
        - type
        - protocol
        - ifindex
        - socket inode

    """
    ret = []
    # Each line is composed as such :
    #   sk               RefCnt Type Proto  Iface R Rmem   User   Inode
    # e.g.
    #   0000000043f0b098 3      2    0804   2     1 0      0      158324
    # the first line is the header, to be skipped
    for line in content.splitlines()[1:]:
        # extract data from line
        part = line.strip().split()
        stype = int(part[2])
        prot = int(part[3], 16)
        ifindex = int(part[4])
        ino = int(part[8])

        ret.append(
            (
                # type
                "p_raw" if stype == 3 else "p_dgr",
                # protocol
                prot,
                # ifindex
                ifindex,
                # socket inode
                ino,
            ),
        )
    return ret


_ETH_P = {
    0x0060: "loop",
    0x0200: "pup",
    0x0201: "pupat",
    0x22F0: "tsn",
    0x22EB: "erspan2",
    0x0800: "ipv4",
    0x0805: "x25",
    0x0806: "arp",
    0x08FF: "bpq",
    0x0A00: "ieeepup",
    0x0A01: "ieeepupat",
    0x4305: "batman",
    0x6000: "dec",
    0x6001: "dna_dl",
    0x6002: "dna_rc",
    0x6003: "dna_rt",
    0x6004: "lat",
    0x6005: "diag",
    0x6006: "cust",
    0x6007: "sca",
    0x6558: "teb",
    0x8035: "rarp",
    0x809B: "atalk",
    0x80F3: "aarp",
    0x8100: "802.1Q",
    0x88BE: "erspan",
    0x8137: "ipx",
    0x86DD: "ipv6",
    0x8808: "pause",
    0x8809: "slow",
    0x883E: "wccp",
    0x8847: "mpls_uc",
    0x8848: "mpls_mc",
    0x884C: "atmmpoa",
    0x8863: "ppp_disc",
    0x8864: "ppp_ses",
    0x886C: "link_ctl",
    0x8884: "atmfate",
    0x888E: "pae",
    0x88A2: "aoe",
    0x88A8: "802.1ad",
    0x88B5: "802_ex1",
    0x88CA: "tipc",
    0x88E5: "macsec",
    0x88E7: "8021ah",
    0x88F5: "mvrp",
    0x88F7: "1588",
    0x88F8: "ncsi",
    0x88FB: "prp",
    0x8906: "fcoe",
    0x8915: "iboe",
    0x890D: "tdls",
    0x8914: "fip",
    0x8917: "80221",
    0x892F: "hsr",
    0x894F: "nsh",
    0x9000: "loopback",
    0x9100: "qinq1",
    0x9200: "qinq2",
    0x9300: "qinq3",
    0xDADA: "edsa",
    0xED3E: "ife",
    0xFBFB: "af_iucv",
    0x0600: "802_3_min",
    0x0001: "802_3",
    0x0002: "ax25",
    0x0004: "802_2",
    0x0005: "snap",
    0x0006: "ddcmp",
    0x0007: "wan_ppp",
    0x0008: "ppp_mp",
    0x0009: "localtalk",
    0x000C: "can",
    0x000D: "canfd",
    0x0010: "ppptalk",
    0x0011: "tr_802_2",
    0x0015: "mobitex",
    0x0016: "control",
    0x0017: "irda",
    0x0018: "econet",
    0x0019: "hdlc",
    0x001A: "arcnet",
    0x001B: "dsa",
    0x001C: "trailer",
    0x00F5: "phonet",
    0x00F6: "ieee802154",
    0x00F7: "caif",
    0x00F8: "xdsa",
    0x00F9: "map",
    0x88CC: "lldp",
}
