# -*- coding: utf-8 -*-

"""Load the Linux filters"""

# Project imports
import engine.techs.linux.filters  # noqa: F401
