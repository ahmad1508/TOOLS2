# -*- coding: utf-8 -*-

"""Implement helpers to parse sudo configuration files"""

# Standard libraries
import os
import re

# Project imports
from engine import logger


def _parse_sudoers_directory(name, files):
    """Parse all sudoers files in a directory

    Arguments
    ---------
    name -- name of the files to parse
    files -- list of parsed files

    Returns
    -------
    Parsed config: see help(_parse_sudoers_one_file) for more details

    """
    # ensure name is "/"-terminated
    if name[-1] != "/":
        name += "/"
    # first find all configuration files
    names = []
    for p in files:
        if p.startswith(name):
            # skipping file names that end in ‘~’ or contain a ‘.’
            # character
            f = os.path.basename(p)
            if f[-1] != "~" and "." not in f:
                names.append(p)
    # sort them lexically
    names = sorted(names)
    # parse each sudoer file
    ret = [[], {}, {}, {}, {}, {}, []]
    for p in names:
        _parse_sudoers_merge_config(ret, _parse_sudoers_one_file(p, files))
    return ret


def _parse_sudoers_merge_config(into, frm):
    """Merge to sudoers config

    See help(_parse_sudoers_one_file) for more details on the
    format.

    Arguments
    ---------
    into -- list where config will be merged into
    frm -- list from where config to be merged should be taken

    """
    for i, t in enumerate(frm):
        if isinstance(into[i], list):
            into[i].extend(t)
        else:
            into[i].update(t)


def _parse_sudoers_one_file(name, files):
    """Parse the content of one sudoers file

    Read the configuration, handle inclusions and returns
    aliases, rules and defaults

    Arguments
    ---------
    name -- name of the files to parse
    files -- list of parsed files

    Returns
    -------
    A tuple:
        - rules (a list)
        - defaults (a dict indexed by field of application or "ALL")
        - user aliases (a dict)
        - runas aliases (a dict)
        - host aliases (a dict)
        - command aliases (a dict)
        - rules which couldn't be parsed (a list)
    A rule is a list of:
        - list of users
        - list of hosts
        - list of runas user
        - list of runas group
        - list of option specs
        - list of tags
        - list of commands

    """
    ret = [[], {}, {}, {}, {}, {}, []]
    # get the file content
    if name in files:
        content = files[name]
    else:
        logger.getLogger(__name__).warning(
            "Sudoers: couldn't file `%s'",
            name,
        )
        return ret

    # Parse each line
    lines = content.splitlines()
    cur = 0
    while cur < len(lines):
        line = lines[cur].rstrip()
        # non-comment lines terminated by \ should be continued
        while (
            len(line) > 0
            and cur < len(lines) - 1
            and line[0] != "#"
            and line[-1] == "\\"
        ):
            cur += 1
            line = line[:-1] + " " + lines[cur]
        # next line
        cur += 1

        # do some cleanup
        line = line.strip()
        # skip empty lines
        if len(line) == 0:
            continue

        # comment or include lines
        if line[0] == "#":
            # try to split between directive & path
            sp = line.split(None, 1)
            if len(sp) == 2 and sp[0] in ("#include", "#includedir"):
                directive, path = sp
                # resolve relative path
                if path[0] != "/":
                    path = os.path.normpath(os.path.dirname(name) + "/" + path)
                # TODO: handle the %h modifier if filenames
                # delegate to the right function
                if directive == "#include":
                    sub = _parse_sudoers_one_file(path, files)
                elif directive == "#includedir":
                    sub = _parse_sudoers_directory(path, files)
                # else should not append

                # update the parsed data based on the sub files
                _parse_sudoers_merge_config(ret, sub)
            # the rest is comment lines which are just discarded
            continue

        # other lines are either rules, default or aliases
        # get the first word to find which one it is
        first = line.split(None, 1)[0]
        if first in ("User_Alias", "Runas_Alias", "Host_Alias", "Cmnd_Alias"):
            # All aliases are dissected the same way
            # Only the dict to update is different
            # ==> defines the index to update based on the type
            if first == "User_Alias":
                idx = 2
            elif first == "Runas_Alias":
                idx = 3
            elif first == "Host_Alias":
                idx = 4
            elif first == "Cmnd_Alias":
                idx = 5
            # several aliases can be defined on the same line,
            # they are separated by ":"
            # first XXX_Alias is separated from alias definitions
            # then all definitions are separated
            aliases = line.split(None, 1)[1].split(":")
            # definitions are key = values
            for a in aliases:
                k, v = a.split("=", 1)
                ret[idx][k.strip()] = [u.strip() for u in v.split(",")]

        elif (
            first == "Defaults"
            or first.startswith("Defaults@")
            or first.startswith("Defaults:")
            or first.startswith("Defaults!")
            or first.startswith("Defaults>")
        ):
            # extract the field of application
            fld = first[len("Defaults") :]
            if fld == "":
                fld = "ALL"
            # ensure the list associated with the field is created
            if fld not in ret[1]:
                ret[1][fld] = []
            # Defaults are a list of comma-separated parameters
            # first DefaultsXXX is separated from parameter list
            # then all parameters are separated
            defaults = line.split(None, 1)[1].split(",")
            for d in defaults:
                ret[1][fld].append(d.strip())

        else:
            # else it is a rule line
            rules = _parse_sudoers_one_rule(line)
            if rules is None:
                ret[6].append(line)
            else:
                ret[0].extend(rules)
    # return parsed data
    return ret


# regexes to parse sudo rules
# a rules is defined using the following grammar
#
#     User_List ::= User |
#                   User ',' User_List
#
#     User ::= '!'* user name |
#              '!'* #uid |
#              '!'* %group |
#              '!'* %#gid |
#              '!'* +netgroup |
#              '!'* %:nonunix_group |
#              '!'* %:#nonunix_gid |
#              '!'* User_Alias
#
_USER_R = r"(!*\s*(#|%|%#|\+|%:|%:#)?[\w\-\*\/\\.]+)"
_USER_LIST_R = r"(" + _USER_R + r"(\s*,\s*" + _USER_R + r")*)"

#     Runas_List ::= Runas_Member |
#                    Runas_Member ',' Runas_List
#
#     Runas_Member ::= '!'* user name |
#                      '!'* #uid |
#                      '!'* %group |
#                      '!'* %#gid |
#                      '!'* %:nonunix_group |
#                      '!'* %:#nonunix_gid |
#                      '!'* +netgroup |
#                      '!'* Runas_Alias
#
_RUNAS_R = r"(!*\s*(#|%|%#|%:|%:#|\+)?[\w\-\*\/\\.]+)"
_RUNAS_LIST_R = r"(" + _RUNAS_R + r"(\s*,\s*" + _RUNAS_R + r")*)"

#     Host_List ::= Host |
#                   Host ',' Host_List
#
#     Host ::= '!'* host name |
#              '!'* ip_addr |
#              '!'* network(/netmask)? |
#              '!'* +netgroup |
#              '!'* Host_Alias
#
_HOST_R = r"(!*\s*\+?[\w\-\*\/\\.]+)"
_HOST_LIST_R = r"(" + _HOST_R + r"(\s*,\s*" + _HOST_R + r")*)"

#     digest ::= [A-Fa-f0-9]+ |
#                [[A-Za-z0-9+/=]+
#
#     Digest_Spec ::= "sha224" ':' digest |
#                     "sha256" ':' digest |
#                     "sha384" ':' digest |
#                     "sha512" ':' digest
#
#     Cmnd_List ::= Cmnd |
#                   Cmnd ',' Cmnd_List
#
#     command name ::= file name |
#                      file name args |
#                      file name '""'
#
#     Cmnd ::= Digest_Spec? '!'* command name |
#              '!'* directory |
#              '!'* "sudoedit" |
#              '!'* Cmnd_Alias
#
_DIGEST_R = r"([A-Za-z0-9+/=]+)"
_DIGEST_SPEC_R = r"(sha(224|256|384|512)\s*:\s*" + _DIGEST_R + r")"
_CMND_R = _DIGEST_SPEC_R + r"?\s*!*\s*[\w\-\*\/\\. ]+"


#     User_Spec ::= User_List Host_List '=' Cmnd_Spec_List
#                   (':' Host_List '=' Cmnd_Spec_List)*
#
#     Cmnd_Spec_List ::= Cmnd_Spec |
#                        Cmnd_Spec ',' Cmnd_Spec_List
#
#     Cmnd_Spec ::= Runas_Spec? Option_Spec* Tag_Spec* Cmnd
#
#     Runas_Spec ::= '(' Runas_List? (':' Runas_List)? ')'
#
#     Option_Spec ::= (SELinux_Spec | Date_Spec | Timeout_Spec)
#
#     SELinux_Spec ::= ('ROLE=role' | 'TYPE=type')
#
#     Date_Spec ::= ('NOTBEFORE=timestamp' | 'NOTAFTER=timestamp')
#
#     Timeout_Spec ::= 'TIMEOUT=timeout'
#
#     Tag_Spec ::= ('EXEC:' | 'NOEXEC:' | 'FOLLOW:' | 'NOFOLLOW' |
#                   'LOG_INPUT:' | 'NOLOG_INPUT:' | 'LOG_OUTPUT:' |
#                   'NOLOG_OUTPUT:' | 'MAIL:' | 'NOMAIL:' | 'PASSWD:' |
#                   'NOPASSWD:' | 'SETENV:' | 'NOSETENV:')
_OPTION_SPEC_R = r"((ROLE|TYPE|NOTBEFORE|NOTAFTER|TIMEOUT)=[^\s]+\s+)"
_TAG_SPEC_R = r"((NO)?(EXEC|FOLLOW|LOG_INPUT|LOG_OUTPUT|MAIL|PASSWD|SETENV):\s*)"
_CMND_SPEC_R = (
    r"("
    r"(?P<runas>\(\s*"
    r"(?P<runas_u>" + _RUNAS_LIST_R + r")?\s*"
    r"(:\s*(?P<runas_g>" + _RUNAS_LIST_R + r"))?"
    r"\s*\))?"
    r"\s*"
    r"(?P<option>" + _OPTION_SPEC_R + r"*)"
    r"\s*"
    r"(?P<tag>" + _TAG_SPEC_R + r"*)"
    r"\s*"
    r"(?P<cmd>" + _CMND_R + r")"
    r")"
)  # noqa: E131

SUDO_USER_LIST_RE = re.compile(r"\s*(" + _USER_LIST_R + r")\s*")
SUDO_HOST_LIST_RE = re.compile(r"\s*(" + _HOST_LIST_R + r")\s*")
SUDO_CMND_SPEC_RE = re.compile(_CMND_SPEC_R)


def _parse_sudoers_one_rule(line):
    """Parse one line of rule

    Returns
    -------
    The list of parsed rules or None if could be parsed

    """
    # a rule is a list of:
    #     - list of users
    #     - list of hosts
    #     - list of runas user
    #     - list of runas group
    #     - list of option specs
    #     - list of tags
    #     - list of commands
    rules = []

    # Work on rem which will be truncated after each regex match
    rem = line
    # parse users
    m = SUDO_USER_LIST_RE.match(rem)
    if m:
        users = [u.strip() for u in m.group(0).split(",")]
        rem = rem[m.end() :].strip()
    else:
        # not parsable line
        return None

    # parse Host_List = Cmnd_Spec_List in a loop
    # Prepend ":" to ease the processing in a loop
    rem = ":" + rem
    while len(rem) > 0 and rem[0] == ":":
        # strip initial ":"
        rem = rem[1:].strip()
        # parse host list
        m = SUDO_HOST_LIST_RE.match(rem)
        if m:
            hosts = [u.strip() for u in m.group(0).split(",")]
            rem = rem[m.end() :].strip()
        else:
            # not parsable line
            return None

        # next char must be "="
        if len(rem) == 0 or rem[0] != "=":
            # not parsable line
            return None
        else:
            rem = rem[1:].strip()

        # parse Cmnd_Spec_List in a loop
        # default values for options, tags & runas
        options = []
        tags = []
        runas_u = []
        runas_g = []
        # a flag to keep track of options, tags or runas changes
        new_context = True

        # Prepend "," to ease the processing in a loop
        rem = "," + rem
        while len(rem) > 0 and rem[0] == ",":
            # strip initial ","
            rem = rem[1:].strip()
            # parse host list
            m = SUDO_CMND_SPEC_RE.match(rem)
            if m:
                groups = m.groupdict("")
                # only change runas, options & tags if they are
                # redefined
                if groups["runas"].strip() != "":
                    # update RUNAS user
                    grp = groups["runas_u"].strip()
                    if grp == "":
                        runas_u = []
                    else:
                        runas_u = [u.strip() for u in grp.split(",")]
                    # update RUNAS group
                    grp = groups["runas_g"].strip()
                    if grp == "":
                        runas_g = []
                    else:
                        runas_g = [u.strip() for u in grp.split(",")]
                    # indicate we are changing the context
                    new_context = True
                # update options
                grp = groups["option"].strip()
                if grp != "":
                    options = [u.strip() for u in grp.split()]
                    # indicate we are changing the context
                    new_context = True
                # update tags
                grp = groups["tag"].strip().strip(":")
                if grp != "":
                    tags = [u.strip() for u in grp.split(":")]
                    # indicate we are changing the context
                    new_context = True

                cmd = groups["cmd"].strip()
                # If command is associated to a new context, we create
                # a new list of commands
                # else, we just update the previous line
                if new_context:
                    rules.append([users, hosts, runas_u, runas_g, options, tags, [cmd]])
                    new_context = False
                else:
                    rules[-1][6].append(cmd)

                # consume the amont of parsed line
                rem = rem[m.end() :].strip()
            else:
                # not parsable line
                return None

    # ensure the whole line was parsed
    if len(rem) == 0:
        return rules
    else:
        # not parsable line
        return None


def parse_sudoers(files):
    """Parse sudo configuration

    Read the configuration of sudoers with all inclusions and return
    the list of rules and defaults env.
    All aliases are resolved

    Arguments
    ---------
    files -- a dict of file contents indexed by filepath

    Returns
    -------
    A tuple:
        - list of parsed rules
        - list of defaults
        - list of unparsable rules

    """
    # parse starting on the main file
    (
        rules,
        defaults,
        user_al,
        runas_al,
        host_al,
        cmd_al,
        unparsed,
    ) = _parse_sudoers_one_file("/etc/sudoers", files)

    # resolve all aliases
    # first resolve within aliases themeselves
    # WARNING recursive aliases will end up in infinite loop
    for aliases in (user_al, host_al, runas_al, cmd_al):
        for a in aliases:
            lst = aliases[a]
            # Replace each alias in the list
            i = 0
            while i < len(lst):
                if lst[i] in aliases:
                    al = lst.pop(i)
                    lst.extend(aliases[al])
                else:
                    i += 1
            # update the initial dict
            aliases[a] = lst
    # then resolve within rules
    for rule in rules:
        # do the resolution for users, host runas & cmnd
        for src, aliases in (
            (0, user_al),
            (1, host_al),
            (2, runas_al),
            (3, runas_al),
            (6, cmd_al),
        ):
            # get the list on which we will work
            lst = rule[src]
            # Replace each alias in the list
            i = 0
            while i < len(lst):
                if lst[i] in aliases:
                    al = lst.pop(i)
                    lst.extend(aliases[al])
                else:
                    i += 1
            # update the initial list
            rule[src] = lst
    return rules, defaults, unparsed
