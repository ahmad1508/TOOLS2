# -*- coding: utf-8 -*-

"""Implement the filters for the Linux review"""

# Standard libraries
import base64
from operator import itemgetter
import os
import re
import zlib

# Project imports
from engine import logger
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n
from engine.core.extracts import Extracts
from engine.core.technology import Technology, TechnologyV1
from engine.techs.common import (
    conformity_cell,
    conformity_row,
    decode,
    dict2table,
    extract_without_comment,
    filter_columns,
    int_with_base,
    key_value2dict,
    parse_ini,
    separator2table,
    split_on_title,
    table2bbcode,
    to_utf8,
)
from engine.techs.linux.fs import (
    fs_perm_to_human,
    fs_perm_to_text,
    ls_long_listing_to_table,
    parse_ls_long_listing,
)
from engine.techs.linux.net import (
    parse_network_interfaces,
    parse_network_services,
)
from engine.techs.linux.pam import parse_pam_conf
from engine.techs.linux.proc import parse_ps
from engine.techs.linux.sssd import parse_sssd_conf
from engine.techs.linux.sudo import parse_sudoers
from engine.techs.linux.sysctl import sysctl_review
from engine.techs.linux.users import find_passwd_type, parse_users_and_groups

# I18N
_ = i18n.domain("linux")._
M_ = i18n.domain("linux").M_
pgettext = i18n.domain("linux").pgettext


class Linux(Technology):
    """Linux technology class"""

    desc = {
        "name": "linux",
        "templates": {
            "full": {
                "fr": "linux/fr/linux_full.jinja",
                "en": "linux/en/linux_full.jinja",
            },
            "light": {
                "fr": "linux/fr/linux_light.jinja",
                "en": "linux/en/linux_light.jinja",
            },
        },
        "default language": "fr",
        "default template": "full",
    }

    # Temporary back-port of the run_filter function
    run_filter = TechnologyV1.run_filter
    default_filter = TechnologyV1.default_filter

    # Fonctions "snippets" utilisées par les fonctions filtres
    # --------------------------------------------------------
    GET_FILES_RE = re.compile(r"^/([*#])\1{30}\\\r?\n(.*?)\r?\n\\\1{31}/\r?\n", re.M)
    GET_FILES_RE_B = re.compile(rb"^/([*#])\1{30}\\\r?\n(.*?)\r?\n\\\1{31}/\r?\n", re.M)
    # seperator of the previous version (fallback)
    OLD_GET_FILES_RE = re.compile(r"^(\*){34}\r?\n(.*?)\r?\n\*{34}\r?\n", re.M)
    OLD_GET_FILES_RE_B = re.compile(rb"^(\*){34}\r?\n(.*?)\r?\n\*{34}\r?\n", re.M)

    @staticmethod
    def get_files_content(extract):
        r"""Extract the content of files extracted with get_files

        get_files separate the content of each files with a header
        /*******************************\
        /path/to/the/file
        \*******************************/

        The wildcard (*) may be instead a hash (#), in which case, the
        file was base64 encoded.

        Note: the input may be either str or bytes. The returned types
        will be unchanged.

        Arguments
        ----------
        extract -- the extract to analyse

        Returns
        -------
        A dict of all files: the keys corrrespond to filenames

        """
        # Split using regex (which use capturing group to get the
        # filename
        # The first item is the data before the file header. It is junk
        # item for get_files
        if isinstance(extract, bytes):
            splits = Linux.GET_FILES_RE_B.split(extract)[1:]
            # fall back to old format
            if len(splits) == 0:
                splits = Linux.OLD_GET_FILES_RE_B.split(extract)[1:]
        else:
            splits = Linux.GET_FILES_RE.split(extract)[1:]
            # fall back to old format
            if len(splits) == 0:
                splits = Linux.OLD_GET_FILES_RE.split(extract)[1:]
        # construct the dict
        ret = {}
        for i in range(len(splits) // 3):
            # the regex split with the following 3 pieces
            # - * or #
            # - path
            # - file content
            #
            # if # is used as a separator, the file content is decoded
            # as base64
            if splits[3 * i] == "#":
                ret[splits[3 * i + 1]] = base64.b64decode(splits[3 * i + 2])
            else:
                ret[splits[3 * i + 1]] = splits[3 * i + 2]
        return ret

    # Import from /etc/protocols
    # cannot parse the file dynamically for Windows' users
    # another method would be to use getprotobynumber, but it is not
    # available in Python yet
    IPPROTO = {
        "0": "ip",
        "1": "icmp",
        "2": "igmp",
        "3": "ggp",
        "4": "ipencap",
        "5": "st",
        "6": "tcp",
        "8": "egp",
        "9": "igp",
        "12": "pup",
        "17": "udp",
        "20": "hmp",
        "22": "xns-idp",
        "27": "rdp",
        "29": "iso-tp4",
        "33": "dccp",
        "36": "xtp",
        "37": "ddp",
        "38": "idpr-cmtp",
        "41": "ipv6",
        "43": "ipv6-route",
        "44": "ipv6-frag",
        "45": "idrp",
        "46": "rsvp",
        "47": "gre",
        "50": "esp",
        "51": "ah",
        "57": "skip",
        "58": "ipv6-icmp",
        "59": "ipv6-nonxt",
        "60": "ipv6-opts",
        "73": "rspf",
        "81": "vmtp",
        "88": "eigrp",
        "89": "ospf",
        "93": "ax.25",
        "94": "ipip",
        "97": "etherip",
        "98": "encap",
        "103": "pim",
        "108": "ipcomp",
        "112": "vrrp",
        "115": "l2tp",
        "124": "isis",
        "132": "sctp",
        "133": "fc",
        "135": "mobility-header",
        "136": "udplite",
        "137": "mpls-in-ip",
        "138": "manet",
        "139": "hip",
        "140": "shim6",
        "141": "wesp",
        "142": "rohc",
    }

    def __init__(self):
        """Extend the base class"""
        super().__init__()
        # script info
        self.version = (3, 5, 0)
        self.runas = 0

    def parse_input(self, extract):
        """Parse input file.

        This method take the path to a file/folder (or anything else
        which is given in the ``-i`` option). It shuold open the file
        and provide extractions within ``self.extracts``.

        Extend the parent method to parse files as Extracts

        Args:
            extract (str): the file name to be parsed

        """
        with open(extract, "rb") as inp:
            content = inp.read()
        self.extracts = Extracts(content)

    def preprocessors(self):
        """Perform preprocessors on extracts.

        Extend the parent method to parse required data
        """
        # parse the script info
        if "Informations script" in self.extracts:
            s = split_on_title(to_utf8(self.extracts["Informations script"]), 1)
            self.version = tuple(int(x) for x in s["Version"].split("."))
            self.runas = int(s["Run as"])

    # Fonctions de filtres
    # --------------------

    # ## filtre pour la section 1.1
    # -- Extract 1
    @decode("utf-8")
    def review_hostname(self, extract):
        return M_("Le nom de la machine est [code]{0}[/code]").format(extract.strip())

    # -- Extract 2
    @decode("utf-8")
    def system_version(self, extract):
        ret = [
            [
                pgettext("Version du système", "Serveur"),
                pgettext("Version du système", "Version du noyau"),
                pgettext("Version du système", "Date du noyau"),
                pgettext("Version du système", "Architecture"),
                pgettext("Version du système", "Type de système"),
                pgettext("Version du système", "Distribution"),
            ],
        ]

        # try to split on title 3
        sections = split_on_title(extract, 3)

        # for older extract, there are no subsections
        if len(sections) == 0:
            # fall back to previous version
            # the first line is the output of uname -a
            # the rest is lsb_release
            first_line = extract.splitlines()[0].split()
            first_line[7] = first_line[7].replace("(", "").replace(")", "")

            # get the kernel version
            # NOTE: this does not work for all distributions
            #   That's way a new version exists
            row = [first_line[i] for i in [1, 2, 7, 8, 9]]
            lsb_section = extract.splitlines()[1:]

        else:
            # extract data from uname command outputs
            # in order:
            #  - nodename
            #  - kernel release
            #  - kernel version
            #  - machine type (architecture)
            #  - operating system
            row = sections["uname"].splitlines()
            # get lsb_release output
            lsb_section = sections["lsb_release"].splitlines()

        # get the distribution data
        for line in lsb_section:
            if "Description:" in line:
                row.append(line.split(":", 1)[1].strip())
                break
        else:
            row.append(M_("[i]non trouvé[/i]"))

        ret.append(row)
        return table2bbcode(ret, M_("Informations sur le système Linux"))

    # ## filtre pour la section 2.1
    # -- Extract 1
    @decode("utf-8")
    def is_dot_in_path(self, extract):
        # need to check that a directory in PATH is relative to the
        # current directory, i.e starts with . or ..
        conform = not (extract.startswith(".") or ":." in extract)
        return table2bbcode(
            [
                [
                    pgettext("is_dot_in_path", "Vérification"),
                    pgettext("is_dot_in_path", "Contrôle"),
                ],
                [
                    M_("Absence de chemin relatif dans le PATH de l’utilisateur root"),
                    conformity_cell(conform),
                ],
            ],
            M_("Présence de chemin relatif dans le PATH de root"),
        )

    # -- Extract 2
    @decode("utf-8")
    def root_path_rights(self, extract):
        # TODO, handle root in a better way than matching "root".

        # get rights
        rights = parse_ls_long_listing(extract)
        tab = ls_long_listing_to_table(rights)

        # analyse rights
        issues = []
        if rights[0]["user"] != "root":
            issues.append(
                M_(
                    "[*] Le propriétaire du dossier n’est pas [code]root[/code]",
                ),
            )
        if rights[0]["group"] != "root":
            issues.append(
                M_(
                    "[*] Le groupe du dossier n’est pas [code]root[/code]",
                ),
            )
        if rights[0]["perm"] & 0o007 and rights[0]["type"] != "l":
            issues.append(
                M_(
                    "[*] Les permissions du dossier pour les autres "
                    "utilisateurs sont trop permissives",
                ),
            )

        if len(issues) > 0:
            txt = M_(
                "La configuration du répertoire personnel de root [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            txt = M_(
                "La configuration du répertoire personnel de root [b]est "
                "satisfaisante[/b].",
            )

        return table2bbcode(tab, M_("Droits des dossiers du PATH de root")) + txt

    # -- Extract 3
    @decode("utf-8")
    def root_home_content(self, extract):
        # simply show directory content
        ret = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(ret, M_("Droits du répertoire personnel de root"))

    # -- Extract 4
    @decode("utf-8")
    def root_env(self, extract):
        ret = [[M_("Variable d’environnement"), M_("Valeur")]]

        for line in extract.splitlines():
            if line == "":
                continue
            ret.append(line.split("=", 1))
        return table2bbcode(ret, M_("Environnement de l’utilisateur root"))

    # ## filtre pour la section 2.2
    # -- Extract 1
    @decode("utf-8")
    def etc_passwd_users(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        users, __, __, __, users_by_uid, users_by_gid, __ = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter on users with password or with locked passwords
        # e.g. with password not being fully made of * and !
        filtered_users = []
        for u in users:
            if u["pwd_usable"]:
                filtered_users.append(u)

        tab = [
            [
                M_("Nom d’utilisateur"),
                M_("Mot de passe vide"),
                M_("Fichier du mot de passe"),
                M_("Statut"),
                M_("UID"),
                M_("GID"),
                M_("Commentaire"),
                M_("Home"),
                M_("Shell"),
            ],
        ]
        for u in filtered_users:
            tab.append(
                [
                    u["name"],
                    M_("Oui") if u["password"] == "" else "",
                    u["pwd_file"],
                    M_("Désactivé") if u["disabled"] else M_("Activé"),
                    u["UID"],
                    u["GID"],
                    u["comment"],
                    u["home"],
                    u["shell"],
                ],
            )

        # do automatic vuln detection
        issues = []
        # check empty passwords
        for u in filtered_users:
            if u["password"] == "":
                issues.append(
                    M_(
                        "[*] l’utilisateur [code]%s[/code] n’a pas de mot de passe",
                    )
                    % u["name"],
                )
        # check world-readable password
        for u in filtered_users:
            if u["pwd_file"] == "passwd":
                issues.append(
                    M_(
                        "[*] le mot de passe de l’utilisateur [code]%s[/code] est "
                        "lisible par tout le monde (défini dans passwd)",
                    )
                    % u["name"],
                )
        # check disabled users have no shell
        valid_no_shell = [
            "/bin/false",
            "/usr/bin/false",
            "/sbin/nologin",
            "/usr/sbin/nologin",
        ]
        for u in filtered_users:
            if u["disabled"] and u["shell"] not in valid_no_shell:
                issues.append(
                    M_(
                        "[*] l’utilisateur [code]%s[/code] est désactivé "
                        "mais possède un [i]shell[/i] valide",
                    )
                    % u["name"],
                )
        # check for uniq UID
        for uid, usrs in users_by_uid.items():
            if len(usrs) > 1 and any(u in filtered_users for u in usrs):
                issues.append(
                    M_(
                        "[*] les utilisateurs suivants utilisent le même UID "
                        "([code]{uid}[/code]) :[list]{users}[/list]",
                    ).format(
                        uid=uid,
                        users=M("").join(
                            [M("[*][code]%s[/code]") % u["name"] for u in usrs],
                        ),
                    ),
                )
        # check for uniq GID
        for gid, usrs in users_by_gid.items():
            if len(usrs) > 1 and any(u in filtered_users for u in usrs):
                issues.append(
                    M_(
                        "[*] les utilisateurs suivants utilisent le même GID "
                        "([code]{gid}[/code]) :[list]{users}[/list]",
                    ).format(
                        gid=gid,
                        users=M("").join(
                            [M("[*][code]%s[/code]") % u["name"] for u in usrs],
                        ),
                    ),
                )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des comptes des utilisateurs [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des comptes des utilisateurs [b]est "
                "satisfaisante[/b].",
            )

        return (
            M_(
                "Les utilisateurs suivants existent sur le système. Il est "
                "nécessaire de les revoir et de s’assurer qu’ils sont légitimes. "
                "Les comptes utilisateur correspondent à l’ensemble des comptes "
                "possédant un mot de passe.",
            )
            + table2bbcode(tab, M_("Liste des comptes des utilisateurs"))
            + vulns
        )

    # ## filtre pour la section 2.3
    # -- Extract 1
    @decode("utf-8")
    def etc_passwd_system(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        (
            users,
            __,
            __,
            groups_by_name,
            users_by_uid,
            users_by_gid,
            __,
        ) = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter on users without password
        filtered_users = []
        for u in users:
            if not u["pwd_usable"]:
                filtered_users.append(u)

        tab = [
            [
                M_("Nom d’utilisateur"),
                M_("UID"),
                M_("GID"),
                M_("Commentaire"),
                M_("Home"),
                M_("Shell"),
            ],
        ]
        for u in filtered_users:
            tab.append(
                [
                    u["name"],
                    u["UID"],
                    u["GID"],
                    u["comment"],
                    u["home"],
                    u["shell"],
                ],
            )

        # do automatic vuln detection
        issues = []
        # check system accounts have no shell
        valid_no_shell = [
            "/bin/false",
            "/usr/bin/false",
            "/sbin/nologin",
            "/usr/sbin/nologin",
        ]
        for u in filtered_users:
            if u["shell"] not in valid_no_shell:
                issues.append(
                    M_(
                        "[*] l’utilisateur [code]%s[/code] "
                        "possède un [i]shell[/i] valide",
                    )
                    % u["name"],
                )
        # check for uniq UID
        for uid, usrs in users_by_uid.items():
            if len(usrs) > 1 and any(u in filtered_users for u in usrs):
                issues.append(
                    M_(
                        "[*] les utilisateurs suivants utilisent le même UID "
                        "([code]{uid}[/code]) :[list]{users}[/list]",
                    ).format(
                        uid=uid,
                        users=M("").join(
                            [M("[*][code]%s[/code]") % u["name"] for u in usrs],
                        ),
                    ),
                )
        # check for uniq GID
        # accept the group `nogroup` being given to several system
        # accounts
        nogroup = (
            groups_by_name["nogroup"]["GID"] if "nogroup" in groups_by_name else None
        )
        for gid, usrs in users_by_gid.items():
            if (
                len(usrs) > 1
                and any(u in filtered_users for u in usrs)
                and gid != nogroup
            ):
                issues.append(
                    M_(
                        "[*] les utilisateurs suivants utilisent le même GID "
                        "([code]{gid}[/code]) :[list]{users}[/list]",
                    ).format(
                        gid=gid,
                        users=M("").join(
                            [M("[*][code]%s[/code]") % u["name"] for u in usrs],
                        ),
                    ),
                )
        if len(issues) > 0:
            vulns = M_(
                "La configuration des comptes système [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des comptes système [b]est satisfaisante[/b].",
            )

        return (
            M_("Les comptes système suivants existent :")
            + table2bbcode(tab, M_("Liste des comptes système"))
            + vulns
        )

    # ## filtre pour la section 2.4
    @decode("utf-8")
    def primary_group_list(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        __, groups, __, __, __, users_by_gid, groups_by_gid = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter on primary groups, i.e. pointed by a user GID
        filtered_groups = []
        for g in groups:
            if g["GID"] in users_by_gid:
                filtered_groups.append(g)

        tab = [
            [
                M_("Nom du groupe"),
                M_("Présence d’un mot de passe"),
                M_("GID"),
                M_("Membres"),
                M_("Administrateurs"),
            ],
        ]
        for g in filtered_groups:
            tab.append(
                [
                    g["name"],
                    M_("Oui") if g["pwd_usable"] and not g["disabled"] else M_("Non"),
                    g["GID"],
                    "\n".join([u["name"] for u in g["members"]]),
                    "\n".join([u["name"] for u in g["gshadow_admins"]]),
                ],
            )

        # do automatic vuln detection
        issues = []
        # check for member singleness
        # only the commonly used nogroup can be an exection
        for g in filtered_groups:
            if len(g["members"]) > 1 and g["name"] != "nogroup":
                issues.append(
                    M_(
                        "[*] le groupe primaire [code]%s[/code] "
                        "contient plusieurs membres",
                    )
                    % g["name"],
                )
        # check for password usage
        for g in filtered_groups:
            if g["pwd_usable"]:
                issues.append(
                    M_(
                        "[*] le groupe primaire [code]%s[/code] "
                        "possède un mot de passe",
                    )
                    % g["name"],
                )
        # check for administrator presence
        for g in filtered_groups:
            if len(g["gshadow_admins"]) > 0:
                issues.append(
                    M_(
                        "[*] le groupe primaire [code]%s[/code] "
                        "possède des administrateurs",
                    )
                    % g["name"],
                )
        # check for uniq GID
        for gid, grps in groups_by_gid.items():
            if len(grps) > 1 and gid in users_by_gid:
                issues.append(
                    M_(
                        "[*] les groupes suivants utilisent le même GID "
                        "([code]{gid}[/code]) :[list]{groups}[/list]",
                    ).format(
                        gid=gid,
                        groups=M("").join(
                            [M("[*][code]%s[/code]") % g["name"] for g in grps],
                        ),
                    ),
                )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des groupes primaires [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des groupes primaires [b]est satisfaisante[/b].",
            )

        return (
            M_(
                "Les groupes suivants sont associés à des utilisateurs en tant "
                "que groupe primaire",
            )
            + table2bbcode(tab, M_("Liste des groupes primaires"))
            + vulns
        )

    # ## filtre pour la section 2.5
    @decode("utf-8")
    def secondary_group_list(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        __, groups, __, __, __, users_by_gid, groups_by_gid = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter on primary groups, i.e. pointed by a user GID
        filtered_groups = []
        for g in groups:
            if g["GID"] not in users_by_gid:
                filtered_groups.append(g)

        tab = [
            [
                M_("Nom du groupe"),
                M_("Présence d’un mot de passe"),
                M_("GID"),
                M_("Membres"),
                M_("Administrateurs"),
            ],
        ]
        for g in filtered_groups:
            tab.append(
                [
                    g["name"],
                    M_("Oui") if g["pwd_usable"] and not g["disabled"] else M_("Non"),
                    g["GID"],
                    "\n".join([u["name"] for u in g["members"]]),
                    "\n".join([u["name"] for u in g["gshadow_admins"]]),
                ],
            )

        # do automatic vuln detection
        issues = []
        # check for password usage
        for g in filtered_groups:
            if g["pwd_usable"]:
                issues.append(
                    M_(
                        "[*] le groupe secondaire [code]%s[/code] "
                        "possède un mot de passe",
                    )
                    % g["name"],
                )
        # check for administrator presence
        for g in filtered_groups:
            if len(g["gshadow_admins"]) > 0:
                issues.append(
                    M_(
                        "[*] le groupe secondaire [code]%s[/code] "
                        "possède des administrateurs",
                    )
                    % g["name"],
                )
        # check for uniq GID
        for gid, grps in groups_by_gid.items():
            if len(grps) > 1 and gid not in users_by_gid:
                issues.append(
                    M_(
                        "[*] les groupes suivants utilisent le même GID "
                        "([code]{gid}[/code]) :[list]{groups}[/list]",
                    ).format(
                        gid=gid,
                        groups=M("").join(
                            [M("[*][code]%s[/code]") % g["name"] for g in grps],
                        ),
                    ),
                )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des groupes secondaires [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des groupes secondaires [b]est satisfaisante[/b].",
            )

        return (
            M_("Les groupes suivants ne sont associés à aucun utilisateur")
            + table2bbcode(tab, M_("Liste des groupes secondaires"))
            + vulns
        )

    # ## filtre pour la section 2.6
    @decode("utf-8")
    def system_group_list(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        accounts, __, __, groups_by_name, __, __, __ = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter on user accounts
        users = []
        for u in accounts:
            if u["pwd_usable"]:
                users.append(u)

        # list of system groups
        sys_grps = [
            "lp",
            "lpadmin",
            "scanner ",
            "sys",
            "adm",
            "systemd-journal",
            "plugdev",
            "netdev",
            "cdrom",
            "floppy",
            "tape",
            "storage",
            "audio",
            "dialout",
            "dip",
            "fax",
            "voice",
            "users",
            "src",
            "ftp",
            "games",
            "http",
            "www-data",
            "rfkill",
            "uucp",
            "mail",
            "smmsp",
        ]
        # list of dangerous system groups
        dangerous_grps = [
            "video",
            "input",
            "tty",
            "staff",
            "shadow",
            "utmp",
            "disk",
            "kmem",
            "proc",
            "fuse",
            "rdma",
        ]
        # list of groups for user only
        usr_only_grps = [
            "wheel",
        ]

        tab = [
            [
                M_("Nom du groupe"),
                M_("Comptes utilisateur ayant accès"),
                M_("Comptes système ayant accès"),
            ],
        ]
        # populate table and keep track of groups not compliant
        sys_grps_issues = []
        for n in sys_grps:
            if n in groups_by_name:
                g = groups_by_name[n]
                tab.append(
                    [
                        g["name"],
                        "\n".join([u["name"] for u in g["members"] if u in users]),
                        "\n".join([u["name"] for u in g["members"] if u not in users]),
                    ],
                )
                # system groups should not contains user accounts
                if len([u for u in g["members"] if u in users]) > 0:
                    sys_grps_issues.append(n)

        dangerous_grps_issues = []
        for n in dangerous_grps:
            if n in groups_by_name:
                g = groups_by_name[n]
                tab.append(
                    [
                        g["name"],
                        "\n".join([u["name"] for u in g["members"] if u in users]),
                        "\n".join([u["name"] for u in g["members"] if u not in users]),
                    ],
                )
                # dangerous groups should not contains any accounts
                if len(g["members"]) > 0:
                    dangerous_grps_issues.append(n)

        usr_only_grps_issues = []
        for n in usr_only_grps:
            if n in groups_by_name:
                g = groups_by_name[n]
                tab.append(
                    [
                        g["name"],
                        "\n".join([u["name"] for u in g["members"] if u in users]),
                        "\n".join([u["name"] for u in g["members"] if u not in users]),
                    ],
                )
                # user-only groups should not contains system accounts
                if len([u for u in g["members"] if u not in users]) > 0:
                    usr_only_grps_issues.append(n)

        # do automatic vuln detection
        issues = []
        # system groups issues
        if len(sys_grps_issues) > 0:
            issues.append(
                M_(
                    "[*]les groupes systèmes suivants contiennent des comptes "
                    "utilisateurs :[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % g for g in sys_grps_issues]),
            )
        # dangerous groups issues
        if len(dangerous_grps_issues) > 0:
            issues.append(
                M_(
                    "[*]les groupes systèmes dangereux suivants contiennent des "
                    "comptes :[list]%s[/list]",
                )
                % M("").join(
                    [M("[*][code]%s[/code]") % g for g in dangerous_grps_issues],
                ),
            )
        # user-only groups issues
        if len(usr_only_grps_issues) > 0:
            issues.append(
                M_(
                    "[*]les groupes suivants contiennent des comptes "
                    "système :[list]%s[/list]",
                )
                % M("").join(
                    [M("[*][code]%s[/code]") % g for g in usr_only_grps_issues],
                ),
            )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des groupes système [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des groupes système [b]est satisfaisante[/b].",
            )

        return (
            M_("Les groupes systèmes suivants ont été trouvés sur la machine :")
            + table2bbcode(tab, M_("Liste des groupes système"))
            + vulns
        )

    # ## filtre pour la section 3.1
    # -- Extract 1
    @decode("utf-8")
    def authentications_methods(self, extract):
        # there are 2 way to add authentication methods:
        # - by adding an authentication module within PAM
        # - by adding a shadow module within NSS (used later by
        #   pam_linux)
        files = self.get_files_content(extract)

        # try to parse NSS config files
        nss_authn = []
        if "/etc/nsswitch.conf" in files:
            nss = extract_without_comment(files["/etc/nsswitch.conf"])
            authn = []
            # find passwd entry configuration
            for line in nss.splitlines():
                if re.match(r"^passwd\s*:", line):
                    authn = line.split(":", 1)[1].strip().split()
                    break
            # do some cleanup: remove actions
            for a in authn:
                if a[0] == "[" and a[-1] == "]":
                    continue
                nss_authn.append(a)

        pam_authn = []
        # try to parse PAM config files
        # read all auth rules for all services
        # discard some known PAM modules
        pam_to_discard = [
            "pam_access.so",
            "pam_cap.so",
            "pam_debug.so",
            "pam_deny.so",
            "pam_echo.so",
            "pam_env.so",
            "pam_faildelay.so",
            "pam_filter.so",
            "pam_gdm.so",
            "pam_gnome_keyring.so",
            "pam_group.so",
            "pam_issue.so",
            "pam_kwallet.so",
            "pam_kwallet5.so",
            "pam_lastlog.so",
            "pam_listfile.so",
            "pam_localuser.so",
            "pam_mail.so",
            "pam_nologin.so",
            "pam_permit.so",
            "pam_rootok.so",
            "pam_securetty.so",
            "pam_shells.so",
            "pam_succeed_if.so",
            "pam_tally.so",
            "pam_tally2.so",
            "pam_timestamp.so",
            "pam_warn.so",
            "pam_wheel.so",
            "pam_fprintd.so",
            "pam_selinux_permit.so",
            "pam_sepermit.so",
            "pam_reauthorize.so",
            "pam_unix_auth.so",
            "pam_console.so",
        ]
        for __, sv in parse_pam_conf(files, False).items():
            # only auth type is interesting for authentication methods
            if "auth" in sv:
                for r in sv["auth"]:
                    # ignore include and substack control as they are
                    # already covered by the loop over services.
                    # also ensure a module remains uniq within pam_authn
                    if (
                        r[0] not in ("include", "substack")
                        and r[1] not in pam_to_discard
                        and r[1] not in pam_authn
                    ):
                        pam_authn.append(r[1])

        # try to parse SSSD config files
        sssd_authn = {}
        sssd_config = parse_sssd_conf(files)
        # try to find all auth_provider in all configured domains
        if "sssd" in sssd_config and "domains" in sssd_config["sssd"]:
            for d in sssd_config["sssd"]["domains"].split(","):
                # find section associated with the current domain
                section_name = "domain/%s" % d.strip()
                if section_name not in sssd_config:
                    logger.getLogger(__name__).warning(
                        "Could not found SSSD configuration for domain %s",
                        d,
                    )
                    continue
                section = sssd_config[section_name]

                # auth_provider defaults to id_provider
                if "auth_provider" in section:
                    sssd_authn[d.strip()] = section["auth_provider"]
                elif "id_provider" in section:
                    sssd_authn[d.strip()] = section["id_provider"]

        # transforms authn into a human readable version
        nss_mapping = {
            "nis": pgettext("Source authn", "NIS"),
            "nisplus": pgettext("Source authn", "NIS+"),
            "hesiod": pgettext("Source authn", "Hesiod"),
            "winbind": pgettext("Source authn", "AD"),
            "compat": pgettext("Source authn", "Locale"),
            "files": pgettext("Source authn", "Locale"),
            "ldap": pgettext("Source authn", "LDAP"),
            "sss": pgettext("Source authn", "SSSD"),
        }
        nss_authn_h = {}
        for a in nss_authn:
            if a in nss_mapping:
                k = nss_mapping[a]
            else:
                k = pgettext("Source authn", "Inconnue")
            if k not in nss_authn_h:
                nss_authn_h[k] = []
            nss_authn_h[k].append(M_("Module NSS [code]%s[/code]") % a)

        pam_mapping = {
            "pam_exec.so": pgettext("Source authn", "Indéfini"),
            "pam_ftp.so": pgettext("Source authn", "Anonyme"),
            "pam_rhosts.so": pgettext("Source authn", "Rhosts"),
            "pam_unix.so": pgettext("Source authn", "NSS"),
            "pam_unix2.so": pgettext("Source authn", "NSS"),
            "pam_ldap.so": pgettext("Source authn", "LDAP"),
            "pam_sss.so": pgettext("Source authn", "SSSD"),
            "pam_userdb.so": pgettext("Source authn", "Locale non sécurisée"),
            "pam_winbind.so": pgettext("Source authn", "AD"),
            "pam_krb5.so": pgettext("Source authn", "Kerberos"),
            "pam_radius.so": pgettext("Source authn", "Radius"),
            "pam_pin.so": pgettext("Source authn", "Code PIN"),
            "pam_pkcs11.so": pgettext("Source authn", "Certificat"),
            "pam_smbpass.so": pgettext("Source authn", "AD"),
        }
        pam_authn_h = {}
        for a in pam_authn:
            if a in pam_mapping:
                k = pam_mapping[a]
            else:
                k = pgettext("Source authn", "Inconnue")
            if k not in pam_authn_h:
                pam_authn_h[k] = []
            pam_authn_h[k].append(M_("Module PAM [code]%s[/code]") % a)

        sssd_mapping = {
            "proxy": pgettext("Source authn", "NSS"),
            "files": pgettext("Source authn", "Locale"),
            "local": pgettext("Source authn", "Locale"),
            "ldap": pgettext("Source authn", "LDAP"),
            "ipa": pgettext("Source authn", "IPA"),
            "ad": pgettext("Source authn", "AD"),
            "krb5": pgettext("Source authn", "Kerberos"),
            "none": None,
        }
        sssd_authn_h = {}
        for d, a in sssd_authn.items():
            if a in sssd_mapping:
                k = sssd_mapping[a]
                # discard None type (because no authentication is
                # possible)
                if k is None:
                    continue
            else:
                k = pgettext("Source authn", "Inconnue")
            if k not in sssd_authn_h:
                sssd_authn_h[k] = []
            sssd_authn_h[k].append(
                M_(
                    "Fournisseur [code]{0}[/code] du domaine SSSD [code]{1}[/code]",
                ).format(a, d),
            )

        # authentication is developped as such
        #   PAM modules
        #   |-- NSS modules if depends on NSS
        #   |   |-- SSSD modules if depends on SSSD
        #   |-- SSSD modules if depends on SSSD
        #   |   |-- NSS modules if depends on NSS
        # merge helper for authn dict
        def _merge(d1, d2):
            for k in d2:
                if k in d1:
                    d1[k].extend(d2[k])
                else:
                    d1[k] = d2[k]

        # expand NSS in PAM & SSSD
        if pgettext("Source authn", "NSS") in pam_authn_h:
            # delete the NSS entry
            del pam_authn_h[pgettext("Source authn", "NSS")]
            # merge with nss
            _merge(pam_authn_h, nss_authn_h)

        if pgettext("Source authn", "NSS") in sssd_authn_h:
            # delete the NSS entry
            del sssd_authn_h[pgettext("Source authn", "NSS")]
            # merge with nss
            _merge(sssd_authn_h, nss_authn_h)

        # expand SSSD in PAM
        # if applicable SSSD is already expended with NSS
        if pgettext("Source authn", "SSSD") in pam_authn_h:
            # delete the SSSD entry
            del pam_authn_h[pgettext("Source authn", "SSSD")]
            # merge with sss
            _merge(pam_authn_h, sssd_authn_h)

        # transform into humanly readable table
        tab = [[M_("Méthode d’authentification"), M_("Sources de la méthode")]]
        for a, src in pam_authn_h.items():
            tab.append(
                [
                    a,
                    M("[list]%s[/list]") % M("").join([M("[*] %s") % s for s in src]),
                ],
            )

        # automatic vuln détection
        issues = []
        # all weak sources which should raise an alert
        weak_sources = [
            pgettext("Source authn", "NIS"),
            pgettext("Source authn", "NIS+"),
            pgettext("Source authn", "Hesiod"),
            pgettext("Source authn", "Indéfini"),
            pgettext("Source authn", "Anonyme"),
            pgettext("Source authn", "Rhosts"),
            pgettext("Source authn", "Locale non sécurisée"),
            pgettext("Source authn", "Code PIN"),
        ]
        for a in pam_authn_h:
            if a in weak_sources:
                issues.append(
                    M_(
                        "[*] la source d’authentification [code]%s[/code] "
                        "n’est pas sécurisé et ne devrait pas être utilisée",
                    )
                    % a,
                )

        # unknown sources
        if pgettext("Source authn", "Inconnue") in pam_authn_h:
            issues.append(
                M_(
                    "[*] certains modules PAM, NSS ou SSSD ne sont pas connus : "
                    "[b]leur sécurité doit être étudiée au cas par cas[/b]. "
                    "N’hésitez pas à remonter ces cas au KM Linux pour améliorer "
                    "le moteur",
                ),
            )

        if len(issues) > 0:
            vulns = M_(
                "Les sources d’authentification [b]ne sont "
                "pas satisfaisantes[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "Les sources d’authentification [b]sont satisfaisantes[/b].",
            )
        return (
            M_("Les sources d’authentification suivantes ont pu être trouvées :")
            + table2bbcode(tab, M_("Liste des sources d’authentification"))
            + vulns
        )

    # ## filtre pour la section 3.2
    # -- Extract 1
    @decode("utf-8")
    def pwd_policy(self, extract):
        # Extract files & shadow from the extract
        splits = split_on_title(extract, 2)
        files = self.get_files_content(splits["Fichiers"])
        # TODO: check that users have been created with the current
        # policy
        # get shadow with shadow = splits["Shadow"]

        # parse PAM config
        pam_conf = parse_pam_conf(files)
        # remove comments for login.defs
        login_defs = extract_without_comment(files["/etc/login.defs"], "#")

        # Find relevant lines within config files
        # find PAM conf, for passwd service
        pam_code = []
        pam_args = {}
        pam_args_defaults = {}
        if "passwd" in pam_conf and "password" in pam_conf["passwd"]:
            for r in pam_conf["passwd"]["password"]:
                if r[1] in ("pam_cracklib.so", "pam_pwquality.so"):
                    pam_code.append("password\t" + "\t".join(r))
                    # parse arguments
                    # only keep required arguments.
                    #   TODO: handle complex controls
                    if r[0] in ("required", "requisite"):
                        # update args with defaults
                        pam_args_defaults.update({"minlen": 9, "difok": 5})
                        for a in r[2].split():
                            k, v = a.split("=", 1) if "=" in a else (a, True)
                            # filter on interesting arguments
                            if k in (
                                "minlen",
                                "minclass",
                                "difok",
                                "lcredit",
                                "ucredit",
                                "dcredit",
                                "ocredit",
                            ):
                                # WARNING: simply override: can be
                                # tricked
                                pam_args[k] = int(v)
                elif r[1] in ("pam_pwhistory.so",):
                    pam_code.append("password\t" + "\t".join(r))
                    # parse arguments
                    # only keep required arguments.
                    #   TODO: handle complex controls
                    if r[0] in ("required", "requisite"):
                        # update args with defaults
                        pam_args_defaults.update({"remember": 10})
                        for a in r[2].split():
                            k, v = a.split("=", 1) if "=" in a else (a, True)
                            # filter on interesting arguments
                            if k in ("remember",):
                                # WARNING: simply override: can be
                                # tricked
                                pam_args[k] = int(v)
                elif r[1] in ("pam_unix.so",):
                    pam_code.append("password\t" + "\t".join(r))
                    # parse arguments
                    # only keep required arguments.
                    #   TODO: handle complex controls
                    if r[0] in ("required", "requisite"):
                        for a in r[2].split():
                            k, v = a.split("=", 1) if "=" in a else (a, True)
                            # filter on interesting arguments
                            if k in ("remember",):
                                # WARNING: simply override: can be
                                # tricked
                                pam_args[k] = int(v)

        # find login.defs conf for password configuration
        login_code = []
        login_args = {}
        for line in login_defs.splitlines():
            # clean the line to get both key and value
            k, v = line.strip().split(None, 1)
            if k in ("PASS_MAX_DAYS", "PASS_MIN_DAYS", "PASS_WARN_AGE"):
                login_code.append(line)
                # values may be in octal or hexa format
                login_args[k] = int_with_base(v)

        # transform parsed code into printable text
        codeblocks_txt = ""
        if len(pam_code) > 0:
            codeblocks_txt += M_(
                "Dans la configuration de PAM, plusieurs règles "
                "permettant de configurer la politique de mot de passe ont "
                "été trouvées :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(pam_code)
        else:
            codeblocks_txt += M_(
                "PAM ne comporte aucune règle permettant de "
                "configurer la politique de mots de passe de la machine.\n",
            )

        if len(login_code) > 0:
            codeblocks_txt += M_(
                "Les règles suivantes sont configurées dans le "
                "fichier [code]/etc/login.defs[/code] :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(login_code)
        else:
            codeblocks_txt += M_(
                "Aucune politique d’expiration des mots de "
                "passe n’est configurée dans [code]/etc/login.defs[/code].\n",
            )

        # build the conformity table
        tab = [
            [
                pgettext("conformity", "Politique"),
                pgettext("conformity", "Valeur recommandée"),
                pgettext("conformity", "Valeur constatée"),
                pgettext("conformity", "Statut"),
            ],
        ]
        conform = True

        # Minlen row
        t, c = conformity_row(
            pgettext("pwd policy", "Taille minimale"),
            12,
            pam_args.get("minlen"),
            pam_args_defaults.get("minlen"),
            lambda v, r: v is not None and v >= r,
        )
        conform &= c
        tab.append(t)

        # character classes row
        # check min class
        minclass = pam_args.get("minclass", 0)
        found_class = "minclass" in pam_args
        # check {l,u,d,o}credit
        credit_class = 0
        for a in ("lcredit", "ucredit", "dcredit", "ocredit"):
            v = pam_args.get(a)
            if v is not None:
                found_class = True
                credit_class += 1 if v < 0 else 0
        # add row to the table
        t, c = conformity_row(
            pgettext("pwd policy", "Classes de caractères"),
            4,
            max(minclass, credit_class) if found_class else None,
            None,
            lambda v, r: v is not None and v >= r,
        )
        conform &= c
        tab.append(t)

        # Different password row
        t, c = conformity_row(
            pgettext("pwd policy", "Différence de mot de passe"),
            5,
            pam_args.get("difok"),
            pam_args_defaults.get("difok"),
            lambda v, r: v is not None and v >= r,
        )
        conform &= c
        tab.append(t)

        # history row
        t, c = conformity_row(
            pgettext("pwd policy", "Historique de mots de passe"),
            5,
            pam_args.get("remember"),
            pam_args_defaults.get("remember"),
            lambda v, r: v is not None and v >= r,
        )
        conform &= c
        tab.append(t)

        # max life row
        # OK if v = 90 +/- 10; Arbitrage if 30 < v < 180;
        t, c = conformity_row(
            pgettext("pwd policy", "Nombre de jours maximal de validité"),
            90,
            login_args.get("PASS_MAX_DAYS"),
            None,
            lambda v, r: v is not None and r - 10 <= v <= r + 10,
            lambda v, r: v is not None and r - 30 <= v <= r + 90,
        )
        conform &= c
        tab.append(t)

        # min life row
        # OK if v = 1 or 2; Arbitrage if 2 < v < 10
        t, c = conformity_row(
            pgettext(
                "pwd policy",
                "Nombre de jours minimal autorisé avant la modification",
            ),
            1,
            login_args.get("PASS_MIN_DAYS"),
            None,
            lambda v, r: v is not None and 0 < v <= r + 1,
            lambda v, r: v is not None and r + 2 <= v <= 10,
        )
        conform &= c
        tab.append(t)

        # pass warn row
        t, c = conformity_row(
            pgettext(
                "pwd policy",
                "Nombre de jours durant lesquels l’utilisateur recevra un "
                "avertissement avant que son mot de passe arrive en fin de "
                "validité",
            ),
            7,
            login_args.get("PASS_WARN_AGE"),
            None,
            lambda v, r: v is not None and v >= r,
        )
        conform &= c
        tab.append(t)

        # global conformity sentence
        if conform:
            conform_t = M_(
                "La configuration de la politique de mot de passe "
                "[b]est donc satisfaisante[/b].",
            )
        else:
            conform_t = M_(
                "La configuration de la politique de mot de passe "
                "[b]n’est donc pas satisfaisante[/b].",
            )

        # TODO: add the validation of expiration policy on user accounts
        #       based on the shadow file

        # return the data
        return (
            codeblocks_txt
            + M_(
                "La politique de mots de passe est résumée dans le tableau "
                "suivant :",
            )
            + table2bbcode(tab, M_("Politique des mots de passe"))
            + conform_t
        )

    # ## filtre pour la section 3.3
    # -- Extract 1
    @decode("utf-8")
    def account_lock(self, extract):
        files = self.get_files_content(extract)

        # try to find pam_tally in an auth statement
        tally_args = {}
        tally_code = []
        for __, sv in parse_pam_conf(files, False).items():
            # only auth type is interesting for authentication methods
            if "auth" in sv:
                for r in sv["auth"]:
                    # ignore include and substack control as they are
                    # already covered by the loop over services.
                    # also ensure a module remains uniq within pam_authn
                    if r[0] in ("include", "substack"):
                        continue
                    if r[1] in ("pam_tally.so", "pam_tally2.so"):
                        # save the current line, if not found yet
                        v = "auth\t" + "\t".join(r)
                        if v not in tally_code:
                            tally_code.append(v)
                        # parse arguments
                        # only keep required arguments.
                        #   TODO: handle complex controls
                        if r[0] in ("required", "requisite"):
                            for a in r[2].split():
                                k, v = a.split("=", 1) if "=" in a else (a, True)
                                # filter on interesting arguments
                                if k in ("deny", "unlock_time"):
                                    # WARNING: can override relevant
                                    # data
                                    tally_args[k] = int(v)
                                if k in ("onerr",):
                                    # WARNING: can override relevant
                                    # data
                                    tally_args[k] = v

        # create the conformity table
        tab = [
            [
                pgettext("conformity", "Configuration"),
                pgettext("conformity", "Valeur recommandée"),
                pgettext("conformity", "Valeur constatée"),
                pgettext("conformity", "Statut"),
            ],
        ]
        conform = True
        # onerr
        default = "fail" if len(tally_code) > 0 else None
        t, c = conformity_row(
            pgettext("account_lock", "Comportement en cas d’erreur"),
            "fail",
            tally_args.get("onerr"),
            default,
            lambda v, r: v is not None and v != "succeed",
        )
        conform &= c
        tab.append(t)
        # deny
        # target is 5 +/-2
        # acceptable till 10
        t, c = conformity_row(
            pgettext("account_lock", "Nombre de tentatives avant verrouillage"),
            5,
            tally_args.get("deny"),
            None,
            lambda v, r: v is not None and r - 2 <= v <= r + 2,
            lambda v, r: v is not None and r <= v <= r + 5,
        )
        conform &= c
        tab.append(t)
        # unlock_time
        # target is 300 or more
        # acceptable is not configured (never unlocked)
        default = pgettext("account_lock", "jamais") if "deny" in tally_args else None
        t, c = conformity_row(
            pgettext("account_lock", "Nombre de secondes avant déverrouillage"),
            300,
            tally_args.get("unlock_time"),
            default,
            lambda v, r: isinstance(v, int) and r <= v,
            lambda v, r: (
                isinstance(v, str) and pgettext("account_lock", "jamais") in v
            ),
        )
        conform &= c
        tab.append(t)

        # global conformity sentence
        if conform:
            conform_t = M_(
                "La configuration de la politique de verrouillage "
                "[b]est donc satisfaisante[/b].",
            )
        else:
            conform_t = M_(
                "La configuration de la politique de verrouillage "
                "[b]n’est donc pas satisfaisante[/b].",
            )
        # add an additional warning for pam_tally
        for r in tally_code:
            if "pam_tally.so" in r:
                conform_t += M_(
                    "\n\nPar ailleurs, le module "
                    "[code]pam_tally.so[/code] est "
                    "utilisé dans PAM. Il est aujourd’hui préférable "
                    "d’utiliser son successeur [code]pam_tally2.so[/code].",
                )
                break

        # transform parsed config into printable text
        if len(tally_code) > 0:
            codeblocks_txt = M_(
                "Les modules PAM [code]pam_tally.so[/code] ou "
                "[code]pam_tally2.so[/code] ont été trouvés dans la "
                "configuration de PAM :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(tally_code)
        else:
            codeblocks_txt = M_(
                "PAM ne comporte [b]aucune règle permettant "
                "le verrouillage des comptes[/b] après plusieurs tentatives.",
            )

        # return all data
        return (
            codeblocks_txt
            + M_(
                "\nLa politique de verrouillage des comptes est résumée dans "
                "le tableau suivant :",
            )
            + table2bbcode(tab, M_("Politique de verrouillage des comptes"))
            + conform_t
        )

    # ## filtre pour la section 3.4
    # -- Extract 1
    @decode("utf-8")
    def pwd_hash_method(self, extract):
        files = self.get_files_content(extract)

        # parse PAM config
        pam_conf = parse_pam_conf(files, False)
        # remove comments for login.defs
        login_defs = extract_without_comment(files["/etc/login.defs"], "#")
        # parse libuser.conf
        if "/etc/libuser.conf" in files:
            libuser_conf = parse_ini(files["/etc/libuser.conf"])
        else:
            libuser_conf = ""

        # create a summary table
        tab = [
            [
                pgettext("password hash method", "Sources"),
                pgettext("password hash method", "Méthode"),
                pgettext("password hash method", "Statut"),
            ],
        ]
        # create a lambda for the status columns to know if a method is
        # secure enough (should cover method for PAM, login.defs &
        # libuser
        secure_methods = (
            "sha256",
            "sha512",
            "blowfish",
            "SHA256",
            "SHA512",
        )
        status_l = lambda m: m in secure_methods  # noqa: E731
        conform = True

        # Find relevant lines within PAM config files
        # i.e. pam_unix module for password context and passwd
        for sv in pam_conf:
            if "password" in pam_conf[sv]:
                for r in pam_conf[sv]["password"]:
                    if r[1] in ("pam_unix.so",):
                        # parse arguments
                        for a in r[2].split():
                            k, v = a.split("=", 1) if "=" in a else (a, True)
                            # filter on interesting arguments
                            if k in ("md5", "bigcrypt", "sha256", "sha512", "blowfish"):
                                c = status_l(k)
                                tab.append(
                                    [
                                        M_("Service PAM [code]%s[/code]") % sv,
                                        k,
                                        conformity_cell(c),
                                    ],
                                )
                                conform &= c

        # find login.defs conf for password encryption methods
        login_args = {}
        for line in login_defs.splitlines():
            # clean the line to get both key and value
            k, v = line.strip().split(None, 1)
            if k in ("MD5_CRYPT_ENAB", "ENCRYPT_METHOD"):
                login_args[k] = v
        # update the table based on the analysis
        if "ENCRYPT_METHOD" in login_args:
            c = status_l(login_args["ENCRYPT_METHOD"])
            tab.append(
                [
                    M_("Fichier [code]/etc/login.defs[/code]"),
                    login_args["ENCRYPT_METHOD"],
                    conformity_cell(c),
                ],
            )
            conform &= c
        elif "MD5_CRYPT_ENAB" in login_args and login_args["MD5_CRYPT_ENAB"] == "yes":
            c = status_l("MD5")
            tab.append(
                [
                    M_("Fichier [code]/etc/login.defs[/code]"),
                    M_("MD5"),
                    conformity_cell(c),
                ],
            )
            conform &= c
        else:
            # defaults to DES
            c = status_l("DES")
            tab.append(
                [
                    M_("Fichier [code]/etc/login.defs[/code]"),
                    M_("DES (par défaut)"),
                    conformity_cell(c),
                ],
            )
            conform &= c

        # update the table based on libuser.conf parsing
        if "defaults" in libuser_conf and "crypt_style" in libuser_conf["defaults"]:
            c = status_l(libuser_conf["defaults"]["crypt_style"])
            tab.append(
                [
                    M_("Fichier [code]/etc/libuser.conf[/code]"),
                    libuser_conf["defaults"]["crypt_style"],
                    conformity_cell(c),
                ],
            )
            conform &= c
        elif "/etc/libuser.conf" in files:
            # defaults to DES only if libuser in defined
            c = status_l("DES")
            tab.append(
                [
                    M_("Fichier [code]/etc/libuser.conf[/code]"),
                    M_("DES (par défaut)"),
                    conformity_cell(c),
                ],
            )
            conform &= c

        # global conformity sentence
        if conform:
            conform_t = M_(
                "La configuration des algorithmes de hachage des "
                "mots de passe [b]est donc satisfaisante[/b].",
            )
        else:
            conform_t = M_(
                "La configuration des algorithmes de hachage des "
                "mots de passe [b]n’est donc pas satisfaisante[/b].",
            )

        # return all data
        return (
            M_(
                "Les configurations d’algorithmes de hachage des mots de passe "
                "suivantes ont été trouvées :",
            )
            + table2bbcode(
                tab,
                M_("Algorithmes de hachage des mots de passe configurés"),
            )
            + conform_t
        )

    # ## filtre pour la section 3.5
    # -- Extract 1
    @decode("utf-8")
    def pwd_strength(self, extract):
        # extract passwd, shadow, group & gshadow and parse them
        splits = split_on_title(extract, 2)
        users, groups, __, __, __, __, __ = parse_users_and_groups(
            splits["Liste des comptes"],
            splits["Mot de passe des comptes"],
            splits["Liste des groupes"],
            splits["Mot de passe des groupes"],
        )

        # filter users & groups with passwords and sort them per type
        f_users = {}
        for u in users:
            if u["pwd_usable"]:
                t = find_passwd_type(u["parsed_pwd"])
                if t not in f_users:
                    f_users[t] = []
                f_users[t].append(u)
        f_groups = {}
        for u in groups:
            if u["pwd_usable"]:
                t = find_passwd_type(u["parsed_pwd"])
                if t not in f_groups:
                    f_groups[t] = []
                f_groups[t].append(u)

        # create the table of passwords and the blocks of passwords
        ret = [
            [
                pgettext("pwd_strength", "Nom"),
                pgettext("pwd_strength", "Condensat de mot de passe"),
            ],
        ]
        blocks = {}

        # first add users
        ret.append([M(pgettext("pwd_strength", "[b]Utilisateurs[/b]"))])
        for t in f_users:
            ret.append([M("[i]%s[/i]") % t])
            blocks[t] = []
            for u in f_users[t]:
                ret.append([u["name"], u["password"]])
                if u["password"] != "":
                    blocks[t].append(u["parsed_pwd"]["pwd"])
        # add groups
        ret.append([M(pgettext("pwd_strength", "[b]Groupes[/b]"))])
        for t in f_groups:
            ret.append([M("[i]%s[/i]") % t])
            if t not in blocks:
                blocks[t] = []
            for u in f_groups[t]:
                ret.append([u["name"], u["password"]])
                if u["password"] != "":
                    blocks[t].append(u["parsed_pwd"]["pwd"])

        # create the text from blocks
        txt = M_(
            "Les mots de passe donnés ensuite doivent être testés avec le "
            "serveur de cassage de mot de passe. Le type du condensat à "
            "utiliser correspond à la référence entre parenthèse. Il est "
            "nécessaire de lancer un cassage par type de condensat.\n",
        )
        for t in blocks:
            if len(blocks[t]) > 0:
                txt += M_("\nCondensats obtenus par %s :") % t
                txt += M("[codeblock]%s[/codeblock]") % M("\n").join(blocks[t])

        # return all data
        return (
            M_(
                "Le tableau suivant résume les associations entre les "
                "utilisateurs ou les groupes et leurs condensats de mot de "
                "passe respectifs. Les condensats sont également résumés après "
                "le tableau dans une version permettant de les copier.",
            )
            + table2bbcode(ret, M_("Liste des condensats des mots de passe"))
            + txt
        )

    # ## filtre pour la section 3.6
    # -- Extract 1
    @decode("utf-8")
    def consistency_of_passwd_and_shadow(self, extract):
        # do some basic filtering of some lines
        to_be_filtered = (
            re.compile(r"^user '.*': directory '.*' does not exist$"),
            re.compile(r"^user '.*': program '.*' does not exist$"),
            re.compile(r"^pwck: no changes$"),
        )
        ret = []
        for line in extract.splitlines():
            for f in to_be_filtered:
                if f.match(line):
                    break
            else:
                ret.append(line)

        # create text to be displayed
        if len(ret) == 0:
            txt = M_(
                "La cohérence entre les fichiers [code]/etc/passwd[/code] "
                "et [code]/etc/shadow[/code] [b]est satisfaisante[/b]. Aucune "
                "incohérence n’a été trouvée.",
            )
        else:
            txt = M_(
                "La cohérence entre les fichiers [code]/etc/passwd[/code] "
                "et [code]/etc/shadow[/code] [b]n’est pas satisfaisante[/b]. "
                "Les incohérences suivantes ont été trouvées :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(ret)

        return txt

    # ## filtre pour la section 3.7
    # -- Extract 1
    @decode("utf-8")
    def grpck_check(self, extract):
        # do some basic filtering of some lines
        to_be_filtered = (re.compile(r"^grpck: no changes$"),)
        ret = []
        for line in extract.splitlines():
            for f in to_be_filtered:
                if f.match(line):
                    break
            else:
                ret.append(line)

        # create text to be displayed
        if len(ret) == 0:
            txt = M_(
                "La cohérence entre les fichiers [code]/etc/group[/code] "
                "et [code]/etc/gshadow[/code] [b]est satisfaisante[/b]. "
                "Aucune incohérence n’a été trouvée.",
            )
        else:
            txt = M_(
                "La cohérence entre les fichiers [code]/etc/group[/code] "
                "et [code]/etc/gshadow[/code] [b]n’est pas satisfaisante[/b]. "
                "Les incohérences suivantes ont été trouvées :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(ret)

        return txt

    # ## filtre pour la section 4.1
    # -- Extract 1
    @decode("utf-8")
    def filter_partition(self, extract):
        # split the output from the df output
        # some lines may be split across multiple lines
        tab = [
            [
                pgettext("Partionnement", "Partition"),
                pgettext("Partionnement", "Taille (1K-block)"),
                pgettext("Partionnement", "Occupé"),
                pgettext("Partionnement", "Disponible"),
                pgettext("Partionnement", "%Occupé"),
                pgettext("Partionnement", "Montée sur"),
            ],
        ]
        cur_l = []
        for line in extract.splitlines():
            cur_l.extend(line.strip().split(None, len(tab[0]) - len(cur_l) - 1))
            # append the current line, only if the line is ended
            if len(cur_l) == len(tab[0]):
                tab.append(cur_l)
                cur_l = []
        # raise a warning if cur_l is not ended
        if len(cur_l) != 0:
            logger.getLogger(__name__).warning(
                "The filesystem partition could not be correctly parsed: "
                "the last line is not complete (or any previous line)",
            )
            # fill with empty data
            tab.append([cur_l[i] if i < len(cur_l) else "" for i in range(len(tab[0]))])

        # remove the header line from df output
        tab.pop(1)
        # filter on partition, monted on & %used
        tab = filter_columns(tab, (0, 5, 4))

        # find issues
        issues = []
        # Check for almost full partitions
        for __, m, u in tab[1:]:
            # convert the used% into an int (remove % and convert)
            if u[-1] == "%" and u[:-1].isdigit():
                u = int(u[:-1])
                if u > 85:
                    issues.append(
                        M_(
                            "[*] la partition montée sur [code]%s[/code] est "
                            "presque pleine",
                        )
                        % m,
                    )
            else:
                # the used% has not the expected format
                logger.getLogger(__name__).warning(
                    "Could not parse one value as used%%: %r",
                    u,
                )
        # Check /var/log is in a dedicated partition
        for __, m, __ in tab[1:]:
            if m in ("/var", "/var/log"):
                break
        else:
            issues.append(
                M_(
                    "[*] le dossier [code]/var/log[/code] n’est pas dans une "
                    "partition dédiée",
                ),
            )

        if len(issues) > 0:
            vulns = M_(
                "Le partitionnement [b]n’est pas satisfaisant[/b] :" "[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_("Le partitionnement [b]est satisfaisant[/b].")

        return (
            M_("Les partitions suivantes ont été trouvées sur le système :")
            + table2bbcode(tab, M_("Liste des partitions du système"))
            + vulns
        )

    # ## filtre pour la section 4.2
    # -- Extract 1
    @decode("utf-8")
    def umask(self, extract):
        # resolve umask into an int
        umask = int(extract, 8)

        # Create a table to show how file & directories will be created
        ret = [
            [
                pgettext("umask", "Composant"),
                pgettext("umask", "Propriétaire"),
                pgettext("umask", "Groupe"),
                pgettext("umask", "Autres"),
            ],
        ]
        # New files
        data = [M_("Nouveaux fichiers")]
        mode = 0o666
        human = fs_perm_to_human(mode & ~umask, False)
        text = fs_perm_to_text(mode & ~umask)
        for i in range(3):
            data.append(M("[code]%s[/code] (%s)") % (text[i], human[i]))
        ret.append(data)
        # New directories
        data = [M_("Nouveaux répertoires")]
        mode = 0o777
        human = fs_perm_to_human(mode & ~umask, True)
        text = fs_perm_to_text(mode & ~umask)
        for i in range(3):
            data.append(M("[code]%s[/code] (%s)") % (text[i], human[i]))
        ret.append(data)

        # check for vulns
        # if new permissions are left to others
        if umask & 0o007:
            txt = M_(
                "La configuration du umask [b]n’est pas satisfaisante[/b] "
                "car elle donne des droits à tous les utilisateurs par "
                "défaut.",
            )
        else:
            txt = M_("La configuration du umask [b]est satisfaisante[/b].")

        return (
            # because of the way %o works, formatting needs to be
            # applied before being given to M(). Octal form do not need
            # to be escape for security purpose, so its fine doing so
            M(
                _(
                    "Le umask configuré est [code]%03o[/code]. Il assignera les "
                    "droits suivants aux nouveaux fichiers et répertoires :",
                )
                % umask,
            )
            + table2bbcode(ret, M_("Accès par défaut définis par le umask"))
            + txt
        )

    # check the system directories owner and rights
    @decode("utf-8")
    def check_system_directories(self, extract):
        # parse ls -l output
        rights = parse_ls_long_listing(extract)
        # create the table of rights
        tab = ls_long_listing_to_table(rights)

        # do automatic vuln detection
        issues = []
        # check that directories are own by root:root & other not
        # writable
        # TODO not check root:root but with UID & GID
        root_own = []
        root_grp = []
        other_w = []
        for r in rights:
            # Check for issues
            if r["user"] != "root":
                root_own.append(r["name"])
            if r["group"] != "root":
                root_grp.append(r["name"])
            if r["perm"] & 0o002 and r["type"] != "l":
                other_w.append(r["name"])
        # create issues
        if len(root_own) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires système suivants n’appartiennent pas à "
                    "l’utilisateur [code]root[/code] :"
                    "[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % r for r in root_own]),
            )
        if len(root_grp) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires système suivants n’appartiennent pas au "
                    "groupe [code]root[/code] :"
                    "[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % r for r in root_grp]),
            )
        if len(other_w) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires système suivants sont modifiables par "
                    "tous :[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % r for r in other_w]),
            )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des répertoires [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des répertoires [b]est satisfaisante[/b].",
            )

        return tab, vulns

    # ## filtre pour vérifier des dossiers système
    @decode("utf-8")
    def system_directories_rights(self, extract):
        tab, vulns = self.check_system_directories(extract)
        return (
            M_("Les répertoires suivants ont été trouvés :")
            + table2bbcode(tab, M_("Droits des répertoires système"))
            + vulns
        )

    # ## filtre pour vérifier des dossiers système
    @decode("utf-8")
    def program_directories_rights(self, extract):
        tab, vulns = self.check_system_directories(extract)
        return (
            M_("Les répertoires suivants ont été trouvés :")
            + table2bbcode(tab, M_("Droits des répertoires des programmes"))
            + vulns
        )

    # filtre pour afficher le droits de répertoires
    @decode("utf-8")
    def remains_directories_rights(self, extract):
        # create the table of rights
        tab = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(tab, M_("Reliquats d’anciens utilisateurs"))

    # filtre pour afficher le droits de répertoires
    @decode("utf-8")
    def writable_files_rights(self, extract):
        # create the table of rights
        tab = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(
            tab,
            M_("Liste des fichiers modifiables par tout le monde"),
        )

    # filtre pour afficher le droits de répertoires
    @decode("utf-8")
    def suid_directories_rights(self, extract):
        # create the table of rights
        tab = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(tab, M_("Liste des fichiers avec le bit SetUID"))

    # filtre pour afficher le droits de répertoires
    @decode("utf-8")
    def sgid_directories_rights(self, extract):
        # create the table of rights
        tab = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(tab, M_("Liste des fichiers avec le bit SetGID"))

    # filtre pour afficher le droits de répertoires
    @decode("utf-8")
    def writable_directories_rights(self, extract):
        # create the table of rights
        tab = ls_long_listing_to_table(parse_ls_long_listing(extract))
        return table2bbcode(
            tab,
            M_("Liste des répertoires modifiables par tout le monde sans sticky-bit"),
        )

    # ## filtre pour la section 4.4
    # -- Extract 1
    @decode("utf-8")
    def directories_rights_users(self, extract):
        # extract the section for each user & for passwd, shadow &
        # groups
        splits = split_on_title(extract, 2)
        # remove sections associated w/ passwd, shadow, group & gshadow
        # and parse them
        __, __, users_by_name, __, __, __, groups_by_gid = parse_users_and_groups(
            splits.pop("Liste des comptes"),
            splits.pop("Mot de passe des comptes"),
            splits.pop("Liste des groupes"),
            splits.pop("Mot de passe des groupes"),
        )

        # for each user parse the home directory rights
        users_rights = {}
        for u in splits:
            if users_by_name[u]["pwd_usable"]:
                users_rights[u] = parse_ls_long_listing(splits[u])

        # transform it into a table
        tab = [
            [
                pgettext("Permission du filesystem", "Utilisateur"),
                pgettext("Permission du filesystem", "Répertoire personnel"),
                pgettext("Permission du filesystem", "Propriétaire"),
                pgettext("Permission du filesystem", "Groupe"),
                pgettext("Permission du filesystem", "Droits Propriétaire (u)"),
                pgettext("Permission du filesystem", "Droits Groupe (g)"),
                pgettext("Permission du filesystem", "Droits Autres (o)"),
            ],
        ]
        # add the line associatod to the home directory for each user
        for u in users_rights:
            # skip users with invalid home
            if len(users_rights[u]) > 0:
                tab.append([u] + ls_long_listing_to_table(users_rights[u])[1])

        # do automatic vuln detection
        issues = []
        # check that directories are own by the user & have no other
        # perm
        owner_iss = []
        group_iss = []
        perm_iss = []
        for u in users_rights:
            # skip users with invalid home
            if len(users_rights[u]) > 0:
                # get shorter form for current repository rights
                r = users_rights[u][0]
                # resolve the User's primary group name
                g = groups_by_gid[users_by_name[u]["GID"]][0]["name"]
                # Check for issues
                if r["user"] != u:
                    owner_iss.append(u)
                if r["group"] != g:
                    group_iss.append(u)
                if r["perm"] & 0o007 and r["type"] != "l":
                    perm_iss.append(u)
        # create issues
        if len(owner_iss) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires personnels des utilisateurs suivants "
                    "n’appartiennent pas à l’utilisateur :"
                    "[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % u for u in owner_iss]),
            )
        if len(group_iss) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires personnels des utilisateurs suivants "
                    "n’appartiennent pas au groupe de l’utilisateur :"
                    "[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % u for u in group_iss]),
            )
        if len(perm_iss) > 0:
            issues.append(
                M_(
                    "[*] Les répertoires personnels des utilisateurs suivants "
                    "ont des droits pour « tous » trop permissifs :"
                    "[list]%s[/list]",
                )
                % M("").join([M("[*][code]%s[/code]") % u for u in perm_iss]),
            )

        if len(issues) > 0:
            vulns = M_(
                "La configuration des répertoires personnels [b]n’est "
                "pas satisfaisante[/b] :[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration des répertoires personnels [b]est "
                "satisfaisante[/b].",
            )

        return (
            M_("Les répertoires personnels d’utilisateurs suivants ont été trouvés :")
            + table2bbcode(tab, M_("Droits des répertoires personnels"))
            + vulns
        )

    # -- Extract 5
    @decode("utf-8")
    def special_acl(self, extract):
        # TODO parse the ACL for users
        # currently, it only filter some lines
        to_be_filtered = [
            "Invalid argument",
            "No such file or directory",
            "Removing leading '/' from absolute path names",
        ]
        filtered_text = ""
        # check for each line that it does not contains unwanted data
        for line in extract.splitlines():
            for f in to_be_filtered:
                if f in line:
                    # stop if the line contains unwanted data
                    break
            else:
                # add the line if we didn't break, i.e. no unwanted data
                filtered_text += "%s\n" % line
        return M("[codeblock]%s[/codeblock]") % filtered_text

    # ## filtre pour la section 5.1
    # -- Extract 1
    @decode("utf-8")
    def bootloader_lilo(self, extract):
        if "No such file or directory" in extract:
            return M_(
                "Le [i]bootloader[/i] LILO n’a pas été détecté sur "
                "l’environnement audité.",
            )
        else:
            # parse each section in a list
            conf = [{}]
            for line in extract_without_comment(extract, "#").splitlines():
                line = line.strip()
                # a line is composed of options w/ or w/out values
                if "=" in line:
                    k, v = line.split("=", 1)
                else:
                    k, v = line, True
                # New sections are either introduced by image= or other=
                if k in ("image", "other"):
                    conf.append({})
                # add to the current section
                conf[-1][k] = v

            # helpers to get a section names
            def _get_name(s):
                ret = []
                for i in ("label", "alias"):
                    if i in s:
                        ret.append(s[i])
                for i in ("image", "other"):
                    if i in s:
                        ret.append(os.path.basename(s[i]))
                return ret

            # helper to get a section access control level
            def _get_acl(s):
                pwd = False
                acl = "bypass"
                if "password" in s or "password" in conf[0]:
                    pwd = True
                    acl = "mandatory"
                    # in section configuration has precedence over
                    # global conf
                    for t in (conf[0], s):
                        for a in ("mandatory", "restricted", "bypass"):
                            if a in t:
                                acl = a
                return (pwd, acl)

            # find default entries
            defaults = []
            if "default" in conf[0]:
                n = conf[0]["default"]
                for s in conf[1:]:
                    if n in _get_name(s):
                        defaults.extend(_get_name(s))
                        break
            else:
                # defaults to the first entry
                defaults.extend(_get_name(conf[1]))
            # do the same for vm default
            if "vmdefault" in conf[0]:
                n = conf[0]["vmdefault"]
                for s in conf[1:]:
                    if n in _get_name(s):
                        defaults.extend(_get_name(s))
                        break

            # do a table of all entries
            tab = [
                [
                    pgettext("Bootloader", "Entrée"),
                    pgettext("Bootloader", "Par défaut"),
                    pgettext("Bootloader", "Mot de passe"),
                    pgettext("Bootloader", "Niveau d’accès"),
                ],
            ]
            for s in conf[1:]:
                pwd, acl = _get_acl(s)
                name = _get_name(s)[0]
                tab.append(
                    [
                        name,
                        M_("Oui") if name in defaults else "",
                        M_("Oui") if pwd else M_("Non"),
                        acl,
                    ],
                )

            # do automatic vuln detection
            issues = []

            # all entries should be password protected
            no_pwd = []
            unrestricted = []
            for s in tab[1:]:
                # check for password presence
                if s[2] == M_("Non"):
                    no_pwd.append(s[0])
                elif s[3] == "bypass":
                    unrestricted.append(s[0])
            # transform into issues item
            if len(no_pwd) > 0:
                issues.append(
                    M_(
                        "[*] Les sections suivantes ne possèdent pas de mot de "
                        "passe :"
                        "[list]%s[/list]",
                    )
                    % M("").join([M("[*] [code]%s[/code]") % s for s in no_pwd]),
                )
            if len(unrestricted) > 0:
                issues.append(
                    M_(
                        "[*] Les sections suivantes possèdent un mot de passe "
                        "mais ne sont pas soumise à un contrôle d’accès :"
                        "[list]%s[/list]",
                    )
                    % M("").join([M("[*] [code]%s[/code]") % s for s in unrestricted]),
                )
            # check the access control of default entries is not
            # mandatory
            for s in tab[1:]:
                if s[1] == M_("Oui") and s[3] == "mandatory":
                    issues.append(
                        M_(
                            "[*] La section par défaut [code]%s[/code] nécessite "
                            "un mot de passe pour être lancée",
                        )
                        % s[0],
                    )
            # transform to text
            if len(issues) > 0:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]n’est "
                    "pas satisfaisante[/b] :"
                    "[list]%s[/list]",
                ) % M("").join(issues)
            else:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]est "
                    "satisfaisante[/b].",
                )

            return (
                M_("Les entrées de démarrage suivantes ont été trouvées :")
                + table2bbcode(tab, M_("Entrées de démarrage de LILO"))
                + vulns
            )

    @decode("utf-8")
    def bootloader_grub_legacy(self, extract):
        if "No such file or directory" in extract:
            return M_(
                "Le [i]bootloader[/i] GRUB Legacy n’a pas été détecté sur "
                "l’environnement audité.",
            )
        else:
            # parse each section in a list
            conf = [{}]
            for line in extract_without_comment(extract, "#").splitlines():
                line = line.strip()
                # a line is composed of options w/ or w/out values
                if " " in line or "\t" in line:
                    k, v = line.split(None, 1)
                else:
                    k, v = line, True
                # New sections are either introduced by image= or other=
                if k == "title":
                    conf.append({})
                # add to the current section
                conf[-1][k] = v

            # helper to get a section access control level
            def _get_acl(s):
                pwd = False
                pwd_hash = False
                locked = False
                if "password" in s:
                    pwd = locked = True
                    pwd_hash = "--md5" in s["password"]
                elif "password" in conf[0]:
                    locked = "lock" in s
                return (pwd, pwd_hash, locked)

            # find default entry
            default = int(conf[0]["default"]) if "default" in conf[0] else 0

            # do a table of all entries
            tab = [
                [
                    pgettext("Bootloader", "Entrée"),
                    pgettext("Bootloader", "Par défaut"),
                    pgettext("Bootloader", "Mot de passe"),
                    pgettext("Bootloader", "Verrouillée"),
                ],
            ]
            i = 0
            for s in conf[1:]:
                pwd, hashed, locked = _get_acl(s)
                tab.append(
                    [
                        s["title"],
                        M_("Oui") if i == default else "",
                        pgettext("password", "Condensat")
                        if pwd and hashed
                        else pgettext("password", "Clair")
                        if pwd
                        else pgettext("password", "Non"),
                        M_("Oui") if locked else "",
                    ],
                )
                i += 1

            # do automatic vuln detection
            issues = []

            # check for global password presence
            if "password" not in conf[0]:
                issues.append(
                    M_(
                        "[*] Aucun mot de passe global n’est défini : "
                        "les fonctions avancées de GRUB ne sont pas protégées",
                    ),
                )
            elif "--md5" not in conf[0]["password"]:
                issues.append(
                    M_(
                        "[*] Le mot de passe global n’est pas "
                        "enregistré sous forme de condensat",
                    ),
                )
            # all entries passwords should be md5
            clear_pwd = []
            for s in tab[1:]:
                # check for password presence
                if s[2] == pgettext("password", "Clair"):
                    clear_pwd.append(s[0])
            # transform into issues item
            if len(clear_pwd) > 0:
                issues.append(
                    M_(
                        "[*] Le mot de passe des sections suivantes est "
                        "enregistré en clair :"
                        "[list]%s[/list]",
                    )
                    % M("").join([M("[*] [code]%s[/code]") % s for s in clear_pwd]),
                )
            # check the default entry is not locked
            for s in tab[1:]:
                if s[1] == M_("Oui") and s[3] == M_("Oui"):
                    issues.append(
                        M_(
                            "[*] La section par défaut [code]%s[/code] nécessite "
                            "un mot de passe pour être lancée",
                        )
                        % s[0],
                    )
            # transform to text
            if len(issues) > 0:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]n’est "
                    "pas satisfaisante[/b] :"
                    "[list]%s[/list]",
                ) % M("").join(issues)
            else:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]est "
                    "satisfaisante[/b].",
                )

            return (
                M_("Les entrées de démarrage suivantes ont été trouvées :")
                + table2bbcode(tab, M_("Entrées de démarrage de GRUB Legacy"))
                + vulns
            )

    @decode("utf-8")
    def bootloader_grub(self, extract):
        files = self.get_files_content(extract)
        if len(files) == 0:
            return M_(
                "Le [i]bootloader[/i] GRUB 2 n’a pas été détecté sur "
                "l’environnement audité.",
            )
        else:
            content = extract_without_comment(list(files.values())[0], "#")
            # extract all users
            users = []
            superusers = None
            sections = []
            default = None
            for line in content.splitlines():
                line = line.strip()
                # a line is composed of options w/ or w/out values
                if " " in line or "\t" in line:
                    k, v = line.split(None, 1)
                else:
                    k, v = line, True
                # extract users & superusers
                if k == "password":
                    users.append([v.split()[0], True])
                elif k == "password_pbkdf2":
                    users.append([v.split()[0], False])
                elif k == "set" and v.startswith("superusers="):
                    v = v.split("=", 1)[1]
                    # clean possible quotes
                    if (v[0] == '"' and v[-1] == '"') or (v[0] == "'" and v[-1] == "'"):
                        v = v[1:-1]
                    # superusers is a list of usernames, separated by
                    # any of spaces, commas, semicolons, pipes, or
                    # ampersands
                    for sep in (" ", ",", ";", "|", "&"):
                        if sep in v:
                            superusers = v.split(sep)
                            break
                    else:
                        if v == "":
                            superusers = []
                        else:
                            superusers = [v]
                elif k == "set" and v.startswith("default="):
                    v = v.split("=", 1)[1]
                    # clean possible quotes
                    if (v[0] == '"' and v[-1] == '"') or (v[0] == "'" and v[-1] == "'"):
                        v = v[1:-1]
                    default = v
                elif k == "menuentry":
                    # split on quotes or space to get title
                    if v[0] in ('"', "'"):
                        title = v.split(v[0], 2)[1]
                    else:
                        title = v.split[0]
                    # get entry protection level
                    if "--unrestricted" in v:
                        protection = pgettext("Grub2 protection", "Non restreint")
                    elif "--users" in v:
                        protection = pgettext(
                            "Grub2 protection",
                            "Restreint à certains utilisateurs",
                        )
                    else:
                        protection = pgettext(
                            "Grub2 protection",
                            "Restreint aux superusers",
                        )
                    sections.append([title, protection])

            # find default entry number
            # default can be identified by number, id or title
            if default is None:
                default = 0
            elif default.isdigit():
                default = int(default)
            else:
                # try to find by id or title
                i = 0
                for line in content.splitlines():
                    line = line.strip()
                    if " " in line or "\t" in line:
                        k = line.split()[0]
                        if k == "menuentry":
                            if default in line:
                                default = i
                                break
                            i += 1
                else:
                    # if not found ==> 0
                    default = 0

            # do a table of all users
            tab_users = [
                [
                    pgettext("Bootloader", "Utilisateur"),
                    pgettext("Bootloader", "Mot de passe en clair"),
                    pgettext("Bootloader", "Superuser"),
                ],
            ]
            for s in users:
                if superusers is not None:
                    tab_users.append(
                        [
                            s[0],
                            M_("Oui") if s[1] else M_("Non"),
                            M_("Oui") if s[0] in superusers else M_("Non"),
                        ],
                    )
                else:
                    tab_users.append(
                        [
                            s[0],
                            M_("Oui") if s[1] else M_("Non"),
                            M_("Non"),
                        ],
                    )

            # do a table of all menu entries
            tab_entries = [
                [
                    pgettext("Bootloader", "Entrée"),
                    pgettext("Bootloader", "Par défaut"),
                    pgettext("Bootloader", "Contrôle d’accès"),
                ],
            ]
            i = 0
            for s in sections:
                tab_entries.append(
                    [
                        s[0],
                        M_("Oui") if i == default else "",
                        pgettext("Grub2 protection", "Aucun")
                        if superusers is None
                        else s[1],
                    ],
                )
                i += 1

            # do automatic vuln detection
            issues = []

            # check for superusers definition
            if superusers is None:
                issues.append(
                    M_(
                        "[*] Aucun compte superuser n’est défini : "
                        "les fonctions avancées de GRUB ne sont pas protégées",
                    ),
                )
            # all passwords should be encrypted
            clear_pwd = []
            for s in users:
                # check for password presence
                if s[1]:
                    clear_pwd.append(s[0])
            # transform into issues item
            if len(clear_pwd) > 0:
                issues.append(
                    M_(
                        "[*] Le mot de passe des utilisateurs suivants est "
                        "enregistré en clair :"
                        "[list]%s[/list]",
                    )
                    % M("").join([M("[*] [code]%s[/code]") % s for s in clear_pwd]),
                )
            # check the default entry is not locked
            for s in tab_entries[1:]:
                if s[1] == M_("Oui") and s[2] not in (
                    pgettext("Grub2 protection", "Aucun"),
                    pgettext("Grub2 protection", "Non restreint"),
                ):
                    issues.append(
                        M_(
                            "[*] La section par défaut [code]%s[/code] nécessite "
                            "un mot de passe pour être lancée",
                        )
                        % s[0],
                    )
            # transform to text
            if len(issues) > 0:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]n’est "
                    "pas satisfaisante[/b] :"
                    "[list]%s[/list]",
                ) % M("").join(issues)
            else:
                vulns = M_(
                    "La configuration du [i]bootloader[/i] [b]est "
                    "satisfaisante[/b].",
                )

            # create the text to display
            ret = M_(
                "Les entrées de démarrage suivantes ont été trouvées :%s",
            ) % table2bbcode(tab_entries, M_("Entrées de démarrage de GRUB 2"))
            if len(users) == 0:
                ret += M_("Aucun utilisateur n’est configuré.\n")
            else:
                ret += M_(
                    "Les utilisateurs suivants ont été trouvés :%s",
                ) % table2bbcode(tab_users, M_("Liste des utilisateurs de GRUB 2"))

            return ret + vulns

    # ## filtre pour la section 5.2
    # -- Extract 1
    @decode("utf-8")
    def sysctl_kernel_config(self, extract):
        return sysctl_review(
            extract,
            [
                # sysrq
                [
                    M_("Désactiver les SysReq"),
                    M_(
                        "Les SysReq sont une combinaison de touches auxquelles le "
                        "système répondra toujours (hormis lors d’un "
                        "[i]kernel panic[/i]). Si elles sont activées, quiconque "
                        "ayant accès au clavier de la machine pourra redémarrer le "
                        "système ou le placer en lecture seul, ce qui créera un "
                        "déni de service.",
                    ),
                    "kernel.sysrq",
                    0,
                    "eq",
                ],
                # coredumps setuid
                [
                    M_("Désactiver les [i]CoreDump[/i] des binaires setUID"),
                    M_(
                        "Les [i]CoreDump[/i] sont des rapports générés lors de la "
                        "défaillance de programmes. Ils contiennent un grand "
                        "nombre d’informations, notamment l’ensemble de la mémoire "
                        "du processus à l’instant de la défaillance. Comme les "
                        "binaires setUID traitent des données sensibles du "
                        "système, il est recommandé d’empêcher la génération de "
                        "tels rapports qui seraient lisible par un attaquant.",
                    ),
                    "fs.suid_dumpable",
                    0,
                    "eq",
                ],
                # symlink protect
                [
                    M_("Protection des liens symboliques"),
                    M_(
                        "Sans cette protection, des attaques du type [i]race "
                        "condition[/i] peuvent exister un certains programmes. Si "
                        "ce programme tourne avec les droits [code]root[/code], il "
                        "est possible de l’utiliser pour écrire dans n’importe "
                        "quel fichier du système, ce qui résulterait en un déni de "
                        "service voire permettrait une élévation de privilège. "
                        "Cette protection peut empêcher certains programmes de "
                        "fonctionner correctement. Il reste toutefois recommandé "
                        "de l’appliquer.",
                    ),
                    "fs.protected_symlinks",
                    1,
                    "eq",
                ],
                # hardlink protect
                [
                    M_("Protection des liens durs"),
                    M_(
                        "Sans cette protection, des attaques du type [i]race "
                        "condition[/i] peuvent exister un certains programmes. Si "
                        "ce programme tourne avec les droits [code]root[/code], il "
                        "est possible de l’utiliser pour écrire dans n’importe "
                        "quel fichier du système, ce qui résulterait en un déni de "
                        "service voire permettrait une élévation de privilège. "
                        "Cette protection peut empêcher certains programmes de "
                        "fonctionner correctement. Il reste toutefois recommandé "
                        "de l’appliquer.",
                    ),
                    "fs.protected_hardlinks",
                    1,
                    "eq",
                ],
                # ASRL
                # a value of 1 is to be discussed
                [
                    M_("Activation de l’ASLR"),
                    M_(
                        "L’ASLR ([i]Address Space Layout Randomization[/i]) est "
                        "une protection qui limite fortement l’exploitation de "
                        "binaire en rendant aléatoire l’espace mémoire de chaque "
                        "processus. Sans cette protection, de nombreuses attaques "
                        "contre des binaires sont réalisables. Elles peuvent mener "
                        "à l’exécution de code arbitraire. Une valeur de "
                        "[code]2[/code] permet de rendre aléatoire l’ensemble des "
                        "zones mémoire et devrait être utilisée. Une valeur de "
                        "[code]1[/code] est acceptable pour la compatibilité avec "
                        "d’anciens programmes.",
                    ),
                    "kernel.randomize_va_space",
                    2,
                    "eq",
                    lambda v, r: v == 1,
                ],
                # null derefencing protection
                [
                    M_(
                        "Interdiction de mapper de la mémoire dans les adresses "
                        "basses",
                    ),
                    M_(
                        "Cette protection complexifie les attaques contre le "
                        "noyau. Elle évite qu’un attaquant puisse contrôler un "
                        "espace mémoire dans les adresses basses et ainsi puisse "
                        "exploiter un défaut de déréférencement null. Une valeur "
                        "non nulle de 4096 ou plus est acceptable, même si l’ANSSI "
                        "recommande une valeur de 65536.",
                    ),
                    "vm.mmap_min_addr",
                    65536,
                    "ge",
                    lambda v, r: v >= 4096,
                ],
                # increased PID
                [
                    M_("Augmenter l’espace de choix des PID"),
                    M_(
                        "L’augmentation du nombre de PID permet de limiter le "
                        "risque d’épuisement des PID qui résulterait en un déni de "
                        "service. Par ailleurs, certains programmes basent leur "
                        "sécurité sur le fait de ne pas être lancé deux fois avec "
                        "le même PID. L’augmentation du nombre de PID réduit donc "
                        "ces possibilités.",
                    ),
                    "kernel.pid_max",
                    65536,
                    "ge",
                ],
                # kernet pointers restrictions
                [
                    M_("Activer l’obfuscation des adresses noyau"),
                    M_(
                        "Cette protection empêche tout utilisateur ou programme "
                        "n’ayant pas les droits nécessaires de lire des adresses "
                        "noyau au travers du système de fichier "
                        "[code]procfs[/code]. Ces adresses peuvent être utilisées "
                        "pour attaquer le noyau Linux.",
                    ),
                    "kernel.kptr_restrict",
                    1,
                    "eq",
                ],
                # dmesg restrictions
                [
                    M_("Restriction de l’accès aux messages noyau"),
                    M_(
                        "Cette protection empêche tout utilisateur ou programme "
                        "n’ayant pas les droits nécessaires de lire les journaux "
                        "du noyau ([i]dmesg[/i]). Ces journaux contiennent de "
                        "nombreuses informations sur le noyau qui peuvent être "
                        "utilisées pour l’attaquer.",
                    ),
                    "kernel.dmesg_restrict",
                    1,
                    "eq",
                ],
                # perf restrictions
                [
                    M_(
                        "Restriction de l’accès à la fonctionnalité de mesure de "
                        "performance",
                    ),
                    M_(
                        "Cette protection empêche tout utilisateur ou programme "
                        "n’ayant pas les droits nécessaires d’utiliser la "
                        "fonctionnalité de mesure de performance du noyau. Comme "
                        "elle peut utiliser fortement le CPU, il est conseillé de "
                        "la restreindre pour éviter des dénis de service. Par "
                        "ailleurs, certaines attaques cryptographiques avancées "
                        "utilisent de telles fonctionnalités pour découvrir les "
                        "clés privées, sans y avoir accès directement.",
                    ),
                    "kernel.perf_event_paranoid",
                    2,
                    "ge",
                ],
            ],
        )

    # ## filtre pour la section 5.3
    # -- Extract 1
    @decode("utf-8")
    def sudo_config(self, extract):
        files = self.get_files_content(extract)
        rules, defaults, unparsed = parse_sudoers(files)

        # create a table for rules
        rules_tab = [
            [
                M_("Utilisateurs ou groupes sources"),
                M_("Hôtes"),
                M_("Utilisateurs cibles"),
                M_("Groupes cibles"),
                M_("Options"),
                M_("Tags"),
                M_("Commandes"),
            ],
        ]

        # helper to transform sudo user/group identifier into
        # human-readable
        def _user_to_human(u):
            if u == "ALL":
                return pgettext("sudo users", "Tous")
            elif u.startswith("%:#"):
                return (
                    M_(
                        "groupe non UNIX identifié par le GID [code]%s[/code]",
                    )
                    % u[3:]
                )
            elif u.startswith("%:"):
                return (
                    M_(
                        "groupe non UNIX identifié par [code]%s[/code]",
                    )
                    % u[2:]
                )
            elif u.startswith("%#"):
                return M_("groupe de GID [code]%s[/code]") % u[2:]
            elif u.startswith("%"):
                return M_("groupe [code]%s[/code]") % u[1:]
            elif u.startswith("+"):
                return M_("netgroup [code]%s[/code]") % u[1:]
            elif u.startswith("#"):
                return M_("utilisateur d’UID [code]%s[/code]") % u[1:]
            else:
                return M_("utilisateur [code]%s[/code]") % u

        # helper to transform sudo host identifier into human-readable
        def _host_to_human(u):
            if u == "ALL":
                return pgettext("sudo hosts", "Tous")
            else:
                return u

        # helper to transform sudo cmnd identifier into human-readable
        def _cmnd_to_human(u):
            if u == "ALL":
                return pgettext("sudo commands", "Toutes")
            else:
                return M("[code]%s[/code]") % u

        # transform each rule into human readable format
        for u, h, ru, rg, o, t, c in rules:
            data = []
            # Users
            data.append(M("\n").join([_user_to_human(i) for i in u]))
            # Hosts
            data.append(M("\n").join([_host_to_human(i) for i in h]))
            # Runas users
            data.append(M("\n").join([_user_to_human(i) for i in ru]))
            # Runas groups
            data.append(M("\n").join([_user_to_human(i) for i in rg]))
            # options
            data.append(M("\n").join(o))
            # tags
            data.append(M("\n").join(t))
            # commands
            data.append(M("\n").join([_cmnd_to_human(i) for i in c]))
            rules_tab.append(data)

        # create a table for defaults
        defaults_tab = [[M_("Environnement"), M_("Restrictions")]]
        for d in defaults:
            defaults_tab.append(
                [
                    M("\n").join([M("[code]%s[/code]") % i for i in defaults[d]]),
                    pgettext("sudo env restrictions", "Aucune") if d == "ALL" else d,
                ],
            )

        # do automatic vuln detection
        issues = []

        # check for wildcard in commands and NOPASSWD
        has_wildcard = False
        no_passwd = False
        for r in rules:
            # check for NOPASSWD
            if "NOPASSWD" in r[5]:
                no_passwd = True
            # check for wildcard
            for c in r[6]:
                if "*" in c:
                    has_wildcard = True
                    break
            # speed up if possible
            if has_wildcard and no_passwd:
                break

        # create the found issues
        if has_wildcard:
            issues.append(
                M_(
                    "[*] Certaines règles utilisent une wildcard (*) : ces "
                    "règles doivent être revues avec minutie",
                ),
            )
        if no_passwd:
            issues.append(
                M_(
                    "[*] Certaines règles peuvent être utilisées sans "
                    "entrer de mot de passe",
                ),
            )

        # check wether NOEXEC is set globally
        if "ALL" in defaults and "noexec" not in defaults["ALL"]:
            issues.append(
                M_(
                    "[*] L’environnement [code]noexec[/code] n’est pas "
                    "appliqué par défaut sur l’ensemble des commandes",
                ),
            )

        # transform to text
        if len(issues) > 0:
            vulns = M_(
                "La configuration de la commande sudo "
                "[b]n’est pas satisfaisante[/b] :"
                "[list]%s[/list]",
            ) % M("").join(issues)
        else:
            vulns = M_(
                "La configuration de la commande sudo [b]est satisfaisante[/b].",
            )

        # Create the final text made of vulnerabilities and unparsed
        # lines if any
        txt = ""
        if len(unparsed) > 0:
            txt = M_(
                "Certaines lignes n’ont pas pu être analysées. [b]Il est "
                "important que l’auditeur les analyse lui-même[/b] :"
                "[codeblock]%s[/codeblock]",
            ) % M("\n").join(unparsed)
        txt += vulns

        return (
            M_(
                "Les règles suivantes ont pu être trouvées dans la "
                "configuration de sudo :",
            )
            + table2bbcode(
                rules_tab,
                M_("Règles des changements d’utilisateur de sudo"),
            )
            + M_(
                "Par ailleurs, les environnements d’exécution des commandes "
                "suivants sont configurés :",
            )
            + table2bbcode(
                defaults_tab,
                M_("Environnement des changements d’utilisateur de sudo"),
            )
            + txt
        )

    # ## filtre pour la section 5.4
    # -- Extract 1
    @decode("utf-8")
    def antivirus(self, extract):
        # parse ps output
        processes = parse_ps(extract)

        # try to match running processes againsts known AV processes
        # TODO find more process names
        known_processes = {
            "clamd": "ClamAV",
            "eset-ef": "ESET",
        }
        found = None
        for p in processes:
            for av in known_processes:
                if av in p["CMD"]:
                    found = known_processes[av]
                    break
            # speed up the break of both list if we found what we were
            # looking for
            else:
                continue
            break

        # transform into text
        if found is not None:
            txt = (
                M_(
                    "L’antivirus [b]%s[/b] a été découvert sur la machine. La "
                    "configuration antivirus [b]est donc satisfaisante[/b]",
                )
                % found
            )
        else:
            txt = M_(
                "Aucun antivirus n’a pu être découvert automatiquement. "
                "[b]L’auditeur doit donc revoir les processus suivants à la "
                "recherche d’antivirus.[/b] Pour améliorer le moteur, merci "
                "de remonter le nom du processus aux équipes travaillants sur "
                "le moteur.",
            )
            txt += table2bbcode(
                dict2table(
                    processes,
                    [M_("PID"), M_("UID"), M_("CMD")],
                ),
                M_("Liste des processus actifs sur la machine"),
            )

        return txt

    # ## filtre pour la section 5.5
    # -- Extract 1
    # The extract may contain binary data
    # no decode should be done at this stage
    def namespace_linux(self, extract):
        # extract the two sub sections containing kernel configuration
        # and sysctl
        sections = split_on_title(extract, 2)

        # For the kernel configuration section, we can have
        #   /boot/config-`uname -r` ==> plain text kernel configuration
        #   /proc/config.gz ==> zlib-compress version of the previous
        #   file
        kernel_files = self.get_files_content(sections[b"Kernel compilation options"])
        # find a valid file to use and parse it
        # The plain text version is prefered, not to decompress
        kernel_op = None
        for f in kernel_files:
            if f.startswith(b"/boot/config-"):
                kernel_op = key_value2dict(to_utf8(kernel_files[f]), sep="=")
                break
        else:
            # fallback on /proc/config.gz
            if b"/proc/config.gz" in kernel_files:
                kernel_op = key_value2dict(
                    to_utf8(zlib.decompress(kernel_files[b"/proc/config.gz"])),
                    sep="=",
                )

        # before going further, ensure the kernel config options where
        # found
        if kernel_op is None:
            return M_(
                "Les options de compilation du noyau [b]n’ont pas pu être "
                "trouvées[/b] sur la machine. Il n’est pas possible "
                "d’analyser la configuration des [i]namespaces[/i] Linux.",
            )

        # ensure that the namespaces are compiled with the kernel
        if (
            "CONFIG_NAMESPACES" not in kernel_op
            or kernel_op["CONFIG_NAMESPACES"] == "n"
        ):
            return M_(
                "Le noyau n’est pas compilé avec le support des "
                "[i]namespaces[/i] Linux. "
                "La configuration [b]est donc satisfaisante[/b].",
            )

        # parse the sysctl for extra kernel configuration
        sysctl = key_value2dict(
            to_utf8(sections[b"Namespace sysctl"]),
            sep="=",
        )

        # check the configuration of each namespace
        # we check each known namespace and addtional sysctl, if some
        # exist
        ns_config = [
            [
                pgettext("namespaces", "IPC"),
                "CONFIG_IPC_NS",
                [],
            ],
            [
                pgettext("namespaces", "Réseau"),
                "CONFIG_NET_NS",
                [],
            ],
            [
                pgettext("namespaces", "Montage"),
                "CONFIG_NAMESPACES",
                [],
            ],
            [
                pgettext("namespaces", "PID"),
                "CONFIG_PID_NS",
                [],
            ],
            [
                pgettext("namespaces", "UTS"),
                "CONFIG_UTS_NS",
                [],
            ],
            [
                pgettext("namespaces", "Utilisateur"),
                "CONFIG_USER_NS",
                [
                    "kernel.unprivileged_userns_apparmor_policy",
                    "kernel.unprivileged_userns_clone",
                    "kernel.userns_restrict",
                ],
            ],
        ]
        # parse the config to generate a summary of NS configurations
        ns_tab = [
            [
                M(pgettext("Tableau namespace", "[i]Namespace[/i]")),
                M(pgettext("Tableau namespace", "Activé")),
                M(pgettext("Tableau namespace", "Configuration Supplémentaire")),
            ],
        ]
        for name, conf, sysctl_op in ns_config:
            # check if the option is activated
            if conf not in kernel_op or kernel_op[conf] == "n":
                ns_tab.append([name, M_("Non"), ""])
            else:
                # if activated, check for additional sysctl
                extra = []
                for s in sysctl_op:
                    if s in sysctl:
                        extra.append("%s=%s" % (s, sysctl[s]))
                # add the line to the table
                ns_tab.append([name, M_("Oui"), "\n".join(extra)])

        # do some automatic vuln detection

        # ensure the user namespace is either disable or is restricted
        # with the appropriate sysctl (either userns_restrict or
        # unprivileged_userns_clone)
        if "CONFIG_USER_NS" in kernel_op and kernel_op["CONFIG_USER_NS"] != "n":
            # if userns are active, check restrictions
            if (
                "kernel.unprivileged_userns_clone" in sysctl
                and sysctl["kernel.unprivileged_userns_clone"] == "0"
            ) or (
                "kernel.userns_restrict" in sysctl
                and sysctl["kernel.userns_restrict"] == "1"
            ):
                # restricted
                vuln = M_(
                    "Les [i]namespaces[/i] utilisateur sont activés mais "
                    "sont restreints aux administrateurs. Leur configuration "
                    "[b]est donc satisfaisante[/b].",
                )
            else:
                # unrestricted
                vuln = M_(
                    "Les [i]namespaces[/i] utilisateur sont activés et "
                    "ne sont pas restreints aux administrateurs. Leur "
                    "configuration [b]n’est donc pas satisfaisante[/b].",
                )
        else:
            # userns are not active
            vuln = M_(
                "Les [i]namespaces[/i] utilisateur sont désactivés. Leur "
                "configuration [b]est donc satisfaisante[/b].",
            )

        # create the string to return
        ret = M_(
            "Les [i]namespaces[/i] Linux sont supportés par le noyau. Le "
            "tableau suivant liste l’état de tous les types de "
            "[i]namespace[/i] :",
        )
        ret += table2bbcode(ns_tab, M_("Liste des [i]namespaces[/i] Linux"))
        ret += vuln

        return ret

    # ## filtre pour la section 5.6
    # -- Extract 1
    @decode("utf-8")
    def lsm_apparmor(self, extract):
        # extract the two sub sections containing apparmor status
        # and profiles
        sections = split_on_title(extract, 2)

        # Parse the files in the profile section
        # :profile_files = self.get_files_content(sections["Profiles"])

        # ensure AppArmor is installed
        if "command not found" in sections["Status"]:
            return M_(
                "AppArmor n’est pas installé sur la machine. [b]Cette "
                "section peut être supprimée[/b].",
            )

        # Parse the status section to find the status of each profile
        lines = sections["Status"].splitlines()
        if lines and lines[0] == "apparmor module is loaded.":
            loaded = True
        else:
            loaded = False

        # find all loaded profiles if relevant
        # the format of aa-status output is the following:
        #       apparmor module is loaded.
        #       44 profiles are loaded.
        #       9 profiles are in enforce mode.
        #          /usr/bin/lxc-start
        #          /usr/lib/chromium-browser/chromium-browser//browser_java
        #       […]
        #       35 profiles are in complain mode.
        #          /sbin/klogd
        #       […]
        #       3 processes have profiles defined.
        #       1 processes are in enforce mode.
        #          /usr/sbin/libvirtd (1295)
        #       2 processes are in complain mode.
        #          /usr/sbin/avahi-daemon (941)
        #          /usr/sbin/avahi-daemon (1000)
        #       0 processes are unconfined but have a profile defined.
        if loaded:
            profiles = {"enforce": [], "complain": []}
            # get number of enforce & complain profiles
            nb_enforce = int(lines[2].split()[0])
            nb_complain = int(lines[3 + nb_enforce].split()[0])
            # get all enforce profiles
            for i in range(nb_enforce):
                profiles["enforce"].append(lines[3 + i].strip())
            # get all complain profiles
            for i in range(nb_complain):
                profiles["complain"].append(lines[4 + nb_enforce + i].strip())

        # create the table to be returned and do some vuln detection
        ret = ""
        if loaded:
            ret = M_("Le module noyau d’AppArmor est présent sur le système. ")
            # check that some modules exists
            if len(profiles["enforce"]) == 0 and len(profiles["complain"]) == 0:
                ret += M_(
                    "Aucun profil n’est toutefois chargé.\nLa configuration "
                    "d’AppArmor [b]n’est donc pas satisfaisante[/b]",
                )
            else:
                ret += M_("Les profils suivants ont été configurés :")
                # create the table to list all profiles
                tab = [
                    [
                        pgettext("AppArmor profils", "Programme"),
                        pgettext("AppArmor profils", "Mode"),
                    ],
                ]
                for m in profiles:
                    for p in profiles[m]:
                        tab.append([p, M("[code]%s[/code]") % m])
                # add the table
                ret += table2bbcode(tab, M_("Liste des profils AppArmor chargés"))
                ret += M_(
                    "La configuration d’AppArmor [b]est donc satisfaisante[/b]",
                )
                # TODO add the content of each profile file
        else:
            ret = M_(
                "Le module noyau d’AppArmor n’est pas chargé.\nLa "
                "configuration d’AppArmor [b]n’est donc pas satisfaisante[/b]",
            )

        return ret

    # ## filtre pour la section 5.7
    # -- Extract 1
    @decode("utf-8")
    def selinux(self, extract):
        # extract the subsections containing status and several contexts
        sections = split_on_title(extract, 2)

        # ensure SELinux is installed
        if "command not found" in sections["Status"]:
            return M_(
                "SELinux n’est pas installé sur la machine. [b]Cette "
                "section peut être supprimée[/b].",
            )

        # the extract contains a string like
        #       SELinux status: enabled
        #       SELinuxfs mount: /selinux
        #       Current Mode: permissive
        #       Policy version: 16
        #
        # We split this key-value output into a dict
        status = key_value2dict(sections["Status"], sep=":")

        # create the string to be return which explain the status
        if status["SELinux status"] == "enabled":
            ret = (
                M_(
                    "SELinux est activé sur la machine. Son mode de "
                    "fonctionnement est [code]%s[/code].\n"
                    "La configuration de SELinux "
                    "[b]est donc satisfaisante[/b].",
                )
                % status["Current mode"]
            )
            # if SELinux is enabled, we also add in a codeblock the
            # list of contexts
            ret += M_(
                "\nUne revue des différents contextes de SELinux peut être "
                "nécessaire. "
                "Les contextes utilisateurs suivants ont été trouvés :"
                "[codeblock]{users}[/codeblock]"
                "Les rôles suivants ont été trouvés :"
                "[codeblock]{roles}[/codeblock]"
                "Les contextes de fichiers suivants ont été trouvés :"
                "[codeblock]{files}[/codeblock]"
                "Les règles SELinux suivantes ont été trouvées :"
                "[codeblock]{rules}[/codeblock]",
            ).format(
                users=sections["Users"],
                roles=sections["Roles"],
                files=sections["File contexts"],
                rules=sections["Rules"],
            )
        else:
            ret = M_(
                "SELinux n’est pas activé sur la machine.\n"
                "La configuration de SELinux "
                "[b]n’est donc pas satisfaisante[/b].",
            )

        return ret

    # ## filtre pour la section 6.1
    # -- Extract 1
    @decode("utf-8")
    def network_services(self, extract):
        # extract the subsections containing network interfaces &
        # listening sockets
        sections = split_on_title(extract, 2)

        # parse all interfaces & all listening sockets
        ifaces = parse_network_interfaces(
            sections["Liste des interfaces - systèmes récents"],
            sections["Liste des interfaces - systèmes anciens"],
        )
        # newest extract will contains a section of extract of procfs
        # however, it may not be included in all extracts
        # Arguments given to parse_network_services are set dynamically
        services_extract = {
            "new_style": sections["Liste des services - systèmes récents"],
            "old_style": sections["Liste des services - systèmes anciens"],
        }
        if "Liste des services - via procfs" in sections:
            subsections = split_on_title(sections["Liste des services - via procfs"], 3)
            services_extract.update(
                {
                    "procfs_net": self.get_files_content(subsections["/proc/net"]),
                    "procfs_cmdline": self.get_files_content(
                        subsections["/proc/*/cmdline"],
                    ),
                    "procfs_fd": subsections["/proc/*/fd/*"],
                    "sysfs_ifindex": self.get_files_content(
                        subsections["/sys/class/net/*/ifindex"],
                    ),
                },
            )
        # parse
        services = parse_network_services(**services_extract)

        # sort services for better readabilty, by
        #   - type (TCP, UDP…)
        #   - local port
        services = sorted(services, key=itemgetter("type", "lport"))

        # transform the list of interfaces into a dict of interfaces,
        # indexed with IPs
        ifaces_d = {}
        for iface in ifaces:
            # ipv4
            for ip in iface["addr"]:
                ifaces_d[ip.split("/")[0]] = iface
            # ipv6
            for ip in iface["addr6"]:
                ifaces_d[ip.split("/")[0]] = iface

        # Create a table of exposed services
        tab = [
            [
                pgettext("Network services", "Service"),
                pgettext("Network services", "Port"),
                pgettext("Network services", "Protocole"),
                pgettext("Network services", "Interfaces"),
                pgettext("Network services", "Adresses"),
                pgettext("Network services", "Type de socket"),
            ],
        ]
        for srv in services:
            # the treatment of laddr & lport depends on the socket type
            #   - UDP & TCP:
            #       - laddr can be ipv4, ipv6, ipv4-mapped ipv6, * (for
            #           all ipv4 & ipv6 addresses)
            #           NOTE: old-style service (netstat) cannot
            #               differentiate :: and *
            #           NOTE: old-style service (netstat) truncate
            #               long addresses like ipv6
            #       - lport is the tcp or udp port
            #   - Raw:
            #       - laddr can be ipv4, ipv6, ipv4-mapped ipv6, * (for
            #           all ipv4 & ipv6 addresses)
            #           NOTE: old-style service (netstat) cannot
            #               differentiate :: and *
            #           NOTE: old-style service (netstat) truncate
            #               long addresses like ipv6
            #       - lport can be the IP protocol or 255 for all
            #           protocols
            #   - Packet:
            #       - laddr can be the Ethertype or * for all protocols
            #       - lport can be the interface name or * for all
            #           ifaces
            #
            # TODO: improve the parsing of processes with the output of
            #       rpcinfo: some processes cannot be resolved if they
            #       are provided by the kernel (like NFS). RPC can
            #       provides more details for some of them (in case
            #       they are RPC services)
            #
            #       Also improve with (x)inet.d config
            #
            if srv["type"] in ("TCP", "UDP", "Raw"):
                # first handle ipv4-mapped ipv6
                laddr = srv["laddr"]
                if "." in laddr and ":" in laddr and laddr.startswith("::ffff:"):
                    laddr = laddr[len("::ffff:") :]
                # find the interfaces associated with the IP
                if laddr == "0.0.0.0":  # nosec
                    iface = (
                        pgettext("net interfaces", "Toutes")
                        if srv["liface"] == ""
                        else srv["liface"]
                    )
                    addr = pgettext("net adresses", "Toutes (IPv4)")
                elif laddr == "::":
                    iface = (
                        pgettext("net interfaces", "Toutes")
                        if srv["liface"] == ""
                        else srv["liface"]
                    )
                    addr = pgettext("net adresses", "Toutes (IPv6)")
                elif laddr == "*":
                    iface = (
                        pgettext("net interfaces", "Toutes")
                        if srv["liface"] == ""
                        else srv["liface"]
                    )
                    addr = pgettext("net adresses", "Toutes (IPv4 et IPv6)")
                else:
                    # normal IP
                    addr = laddr
                    # try to resolve the interface
                    # interface can be given
                    # easy case = addr in ifaces_d
                    # but if address is truncated, need to find it
                    if srv["liface"] != "":
                        iface = srv["liface"]
                    elif addr in ifaces_d:
                        iface = ifaces_d[laddr]["name"]
                    else:
                        # try to find the right interface
                        for i in ifaces_d:
                            # stop at the first interface: may be
                            # sufficient for most cases
                            if i.startswith(addr):
                                iface = ifaces_d[i]["name"]
                                # also restore the full address
                                addr = i
                                break
                        else:
                            iface = pgettext("net interfaces", "Interface non trouvée")
                # add a new line to the tables,
                # ports & protocols depends on the type of socket
                if srv["type"] in ("TCP", "UDP"):
                    # for TCP & UDP, its easy protocol = TCP or UDP &
                    # port is directly the parsed port
                    # also filter loopback interface services
                    if iface != "lo":
                        tab.append(
                            [
                                srv["proc"],
                                srv["lport"],
                                srv["type"],
                                iface,
                                addr,
                                srv["type"],
                            ],
                        )
                elif srv["type"] == "Raw":
                    # for Raw, the protocol number is given by lport
                    # and no ports are associated
                    if srv["lport"] == "255":
                        proto = pgettext("net protocols", "Tout protocole IP")
                    elif srv["lport"] in self.IPPROTO:
                        proto = self.IPPROTO[srv["lport"]].upper()
                    else:
                        proto = (
                            pgettext("net protocols", "Protocole IP n°%s")
                            % srv["lport"]
                        )
                    # filter loopback interface services
                    if iface != "lo":
                        tab.append(
                            [srv["proc"], M_("N/A"), proto, iface, addr, srv["type"]],
                        )

            elif srv["type"] == "Packet":
                # handle the wildcard in laddr & lport
                if srv["laddr"] == "*":
                    proto = pgettext("net protocols", "Tout protocole Ethernet")
                elif srv["laddr"].isdigit():
                    proto = (
                        pgettext("net protocols", "Protocole Ethernet n°%s")
                        % srv["laddr"]
                    )
                else:
                    proto = srv["laddr"].upper()
                if srv["lport"] == "*":
                    iface = pgettext("net interfaces", "Toutes")
                else:
                    iface = srv["lport"]
                # add the row to the table
                # filter loopback interface services
                if iface != "lo":
                    tab.append(
                        [srv["proc"], M_("N/A"), proto, iface, M_("N/A"), srv["type"]],
                    )

        # transform to text
        txt = M_("Les services suivants sont exposés sur la machine :")
        txt += table2bbcode(tab, M_("Liste des services réseau"))

        return txt

    # ## filtre pour la section 6.2
    # Extract 1
    @decode("utf-8")
    def iptables(self, extract):
        # TODO
        return self.default_filter(extract)

    # Extract 2
    @decode("utf-8")
    def ip6tables(self, extract):
        # TODO
        return self.default_filter(extract)

    # Extract 3
    @decode("utf-8")
    def ebtables(self, extract):
        # TODO
        return self.default_filter(extract)

    # Extract 4
    @decode("utf-8")
    def arptables(self, extract):
        # TODO
        return self.default_filter(extract)

    # Extract 5
    @decode("utf-8")
    def nftables(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 6.3
    # Extract 1
    @decode("utf-8")
    def kernel_lan(self, extract):
        # TODO improve handling of feature activation based on
        #       conf/all/*
        # and con/interface/* specific configuration
        return sysctl_review(
            extract,
            [
                # icmp echo brdcast
                [
                    M_("Éviter le flood ICMP"),
                    M_(
                        "Le noyaux Linux gère nativement les requêtes ICMP Echo "
                        "(aussi connues sous le nom de [i]ping[/i]) et il renvoit "
                        "une réponse automatiquement. Cette configuration empêche "
                        "le système de répondre lorsque la requête ne s’adresse "
                        "pas directement au système mais à l’ensemble du réseau. "
                        "Il est nécessaire de l’activer pour éviter des attaques "
                        "de déni de service par amplification.",
                    ),
                    "net.ipv4.icmp_echo_ignore_broadcasts",
                    1,
                    "eq",
                ],
                # SYN cookies
                [
                    M_("Éviter les attaques par TCP SYN flood"),
                    M_(
                        "Lors de l’initialisation de session TCP, le système "
                        "alloue des ressources mémoires, même si la session n’est "
                        "pas entièrement établie. Les attaques par TCP SYN flood "
                        "jouent sur cette composante et saturent la mémoire de la "
                        "machine. En activant cette option, le système n’alloue "
                        "plus de ressources au dela d’un certain nombre de "
                        "connexions en parallèle. Il accepte toujours les "
                        "nouvelles connexions en utilisant le réseau pour stocker "
                        "les ressources. Il utilise des cookies SYN.",
                    ),
                    "net.ipv4.tcp_syncookies",
                    1,
                    "eq",
                ],
                # IP forwarding
                [
                    M_("Désactiver le routage IPv4"),
                    M_(
                        "Les serveurs et postes de travail ne devraient pas avoir "
                        "à router des paquets réseaux. Pour éviter que la machine "
                        "ne soit utilisée rebondir sur d’autres réseaux, il est "
                        "nécessaire de désactiver le routage des paquets IPv4.",
                    ),
                    "net.ipv4.ip_forward",
                    0,
                    "eq",
                ],
                [
                    M_("Désactiver le routage IPv6"),
                    M_(
                        "Les serveurs et postes de travail ne devraient pas avoir "
                        "à router des paquets réseaux. Pour éviter que la machine "
                        "ne soit utilisée rebondir sur d’autres réseaux, il est "
                        "nécessaire de désactiver le routage des paquets IPv6.",
                    ),
                    "net.ipv6.conf.all.forwarding",
                    0,
                    "eq",
                ],
                # send_redirects
                [
                    M_("Désactiver les notifications de redirection"),
                    M_(
                        "Les serveurs et postes de travail ne sont pas des "
                        "routeurs. La fonctionnalité d’envoi de requêtes ICMP de "
                        "redirection devrait donc être désactivée sur l’ensemble "
                        "des interfaces.",
                    ),
                    "net.ipv4.conf.*.send_redirects",
                    0,
                    "eq",
                    None,
                    lambda x, y: int(x) or int(y),
                ],
                # rp_filter
                [
                    M_("Activer le filtrage par chemin inverse"),
                    M_(
                        "Lorsque la fonctionnalité de filtrage par chemin inverse "
                        "([i]Reverse Path Filtering[/i]) est activée, le noyau "
                        "vérifie à chaque paquet réseau reçu que le paquet est "
                        "arrivé par la bonne interface. Cette fonctionnalité "
                        "devrait être activée pour éviter des attaques de type "
                        "empoisonnement.",
                    ),
                    "net.ipv4.conf.*.rp_filter",
                    1,
                    "eq",
                    None,
                    lambda x, y: min(int(x), int(y)),
                ],
                # accept_source_route
                [
                    M_("Désactiver le [i]source routing[/i] IPv4"),
                    M_(
                        "Le [i]source routing[/i] permet de définir la route que "
                        "doit suivre un paquet réseau. Cette fonctionnalité "
                        "facilite grandement des attaque de type [i]spoofing[/i] "
                        "et n’est utile que pour du débogage réseau. Elle devrait "
                        "donc être désactivée sur toutes les interfaces.",
                    ),
                    "net.ipv4.conf.all.accept_source_route",
                    0,
                    "eq",
                ],
                [
                    M_("Désactiver le [i]source routing[/i] IPv6"),
                    M_(
                        "Le [i]source routing[/i] permet de définir la route que "
                        "doit suivre un paquet réseau. Cette fonctionnalité "
                        "facilite grandement des attaque de type [i]spoofing[/i] "
                        "et n’est utile que pour du débogage réseau. Elle devrait "
                        "donc être désactivée sur toutes les interfaces.",
                    ),
                    "net.ipv6.conf.*.accept_source_route",
                    0,
                    "eq",
                    None,
                    lambda x, y: max(int(x), int(y)),
                ],
                # accept_redirect
                [
                    M_("Désactiver la redirection ICMP"),
                    M_(
                        "La redirection ICMP permet d’informer un hôte d’un "
                        "changement de route. Si la redirection ICMP est activée, "
                        "un attaquant pourrait rediriger le trafic de l’hôte pour "
                        "l’intercepter. Il est donc recommandé de la désactiver "
                        "sur toutes les interfaces.",
                    ),
                    "net.ipv4.conf.*.accept_redirects",
                    0,
                    "eq",
                    None,
                    lambda x, y: int(x) or int(y),
                ],
                [
                    M_("Désactiver la redirection ICMPv6"),
                    M_(
                        "La redirection ICMP permet d’informer un hôte d’un "
                        "changement de route. Si la redirection ICMP est activée, "
                        "un attaquant pourrait rediriger le trafic de l’hôte pour "
                        "l’intercepter. Il est donc recommandé de la désactiver "
                        "sur toutes les interfaces.",
                    ),
                    "net.ipv6.conf.*.accept_redirects",
                    0,
                    "eq",
                    None,
                    lambda x, y: int(x) or int(y),
                ],
                # secure_redirect
                [
                    M_("Désactiver la redirection ICMP sécurisée"),
                    M_(
                        "La redirection ICMP permet d’informer un hôte d’un "
                        "changement de route. La redirection sécurisée permet de "
                        "limiter le changement aux seules passerelles réseau "
                        "définies. Si la redirection ICMP est activée, même "
                        "sécurisée, un attaquant pourrait rediriger le trafic de "
                        "l’hôte pour l’intercepter. Il est donc recommandé de la "
                        "désactiver sur toutes les interfaces.",
                    ),
                    "net.ipv4.conf.*.secure_redirects",
                    0,
                    "eq",
                    None,
                    lambda x, y: int(x) or int(y),
                ],
                # SACK Panic
                [
                    M_("Désactiver l’acquittement sélectif"),
                    M_(
                        "L’acquittement sélectif (SACK) est une option de TCP qui "
                        "permet l’acquittement de messages reçus, en dehors du "
                        "processus classique d’acquittement de TCP. Il permet "
                        "notamment d’acquitter des messages reçus, alors même "
                        "qu’un message précédent ne l’a pas encore été (chose "
                        "impossible hors de SACK). Une vulnérabilité existe "
                        "toutefois sur Linux, nommée [i]SACK Panic[/i], qui permet "
                        "de causer une défaillance noyau ([i]kernel panic[/i]). Il "
                        "est donc recommandé de désactiver la fonctionnalité.",
                    ),
                    "net.ipv4.tcp_sack",
                    0,
                    "eq",
                ],
            ],
        )

    # ## filtre pour la section 6.4
    # -- Extract 1
    @decode("utf-8")
    def fail2ban(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 2
    @decode("utf-8")
    def pam_shield(self, extract):
        # Extract files
        files = self.get_files_content(extract)

        # try to find pam_shield in an auth statement
        shield_args = {}
        shield_code = []
        for __, sv in parse_pam_conf(files, False).items():
            # only auth type is interesting for authentication methods
            if "auth" in sv:
                for r in sv["auth"]:
                    # ignore include and substack control as they are
                    # already covered by the loop over services.
                    # also ensure a module remains uniq within pam_authn
                    if r[0] in ("include", "substack"):
                        continue
                    if r[1] == "pam_shield.so":
                        # save the current line, if not found yet
                        v = "auth\t" + "\t".join(r)
                        if v not in shield_code:
                            shield_code.append(v)
                        # parse arguments
                        for a in r[2].split():
                            k, v = a.split("=", 1) if "=" in a else (a, True)
                            # filter on interesting arguments
                            if k in ("conf"):
                                # WARNING: can override relevant data
                                shield_args[k] = v

        # transform parsed config into printable text
        if len(shield_code) > 0:
            codeblocks_txt = M_(
                "Le module PAM [code]pam_shield.so[/code] a été trouvé dans "
                "la configuration de PAM :"
                "[codeblock]%s[/codeblock]\n",
            ) % M("\n").join(shield_code)

            if (
                "conf" in shield_args and shield_args["conf"] in files
            ) or "/etc/security/shield.conf" not in files:
                codeblocks_txt += M_(
                    "[b]La configuration du module n’a pas pu être collectée[/b].",
                )
            else:
                codeblocks_txt += (
                    M_(
                        "La configuration de PAM shield est la suivante:"
                        "[codeblock]%s[/codeblock]",
                    )
                    % files["/etc/security/shield.conf"]
                )
        else:
            codeblocks_txt = M_(
                "Le système [b]n’utilise pas le mécanisme PAM Shield[/b] pour "
                "bloquer les tentatives de [i]bruteforce[/i] réseau.",
            )

        # return all data
        return codeblocks_txt

    # ## filtre pour la section 6.5
    # -- Extract 1
    @decode("utf-8")
    def samba(self, extract):
        ret = ""
        files = self.get_files_content(extract)
        for filename, value in files.items():
            value_without_comment = extract_without_comment(value, "#;")

            # Skip files containing only comments
            if value_without_comment != "":
                ret = ret + M("[b]{0}[/b]\n[codeblock]{1}[/codeblock]\n").format(
                    filename,
                    value_without_comment,
                )
        return ret

    # -- Extract 2
    @decode("utf-8")
    def sam(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 6.6
    # -- Extract 1
    @decode("utf-8")
    def nfs(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 6.7
    @decode("utf-8")
    def rpcinfo(self, extract):
        ret = separator2table(
            extract,
            None,
            header=[
                pgettext("RPC info", "Programme"),
                pgettext("RPC info", "Version"),
                pgettext("RPC info", "Protocole"),
                pgettext("RPC info", "Port"),
                pgettext("RPC info", "Service"),
            ],
            has_headline=True,
        )
        return table2bbcode(ret, M_("Liste des services RPC"))

    # ## filtre pour la section 7.1
    # -- Extract 1
    @decode("utf-8")
    def xinetd_services(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 2
    @decode("utf-8")
    def tcp_wrapper(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 7.2
    # -- Extract 1
    @decode("utf-8")
    def ssh_files(self, extract):
        # TODO:  sshd_config statements are CASE-INSENSITIVE
        return self.default_filter(extract)

    # ## filtre pour la section 8.1
    # -- Extract 1
    @decode("utf-8")
    def updates(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 8.2
    # -- Extract 1
    @decode("utf-8")
    def packages_installed(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 4
    @decode("utf-8")
    def java_version(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 8.3
    # -- Extract 2
    @decode("utf-8")
    def cron_restriction(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 3
    @decode("utf-8")
    def programs_called_by_cron(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 4,5,6,7
    @decode("utf-8")
    def cron_files_rights(self, extract):
        # simply show directory content
        tab, vulns = self.check_system_directories(extract)
        return (
            M_("Les fichiers suivants ont été trouvés :")
            + table2bbcode(tab, M_("Droits des fichiers de cron"))
            + vulns
        )

    # -- Extract 8
    @decode("utf-8")
    def files_without_comment(self, extract):
        ret = ""

        files = self.get_files_content(extract)
        for filename, value in files.items():
            value_without_comment = extract_without_comment(value)

            # Skip files containing only comments
            if value_without_comment != "":
                ret = ret + M("[b]{0}[/b]\n[codeblock]{1}[/codeblock]\n").format(
                    filename,
                    value_without_comment,
                )
        return ret

    # ## filtre pour la section 9.1
    # -- Extract 1
    @decode("utf-8")
    def var_log(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 9.2
    # -- Extract 1
    @decode("utf-8")
    def syslog(self, extract):
        # TODO
        return self.default_filter(extract)

    # -- Extract 2
    @decode("utf-8")
    def syslog_ng(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 9.3
    # -- Extract 1
    @decode("utf-8")
    def auditd(self, extract):
        # TODO
        return self.default_filter(extract)

    # ## filtre pour la section 9.4
    # -- Extract 1
    @decode("utf-8")
    def log_rotation(self, extract):
        # TODO
        return self.default_filter(extract)
