# -*- coding: utf-8 -*-

"""Implement helpers to parse filesystem metadata"""

# Standard libraries
from datetime import datetime
import re

# Project imports
from engine.bbcode import Markup as M  # noqa: N814
from engine.core import i18n

# I18N
_ = i18n.domain("linux")._
pgettext = i18n.domain("linux").pgettext


def fs_perm_to_human(perm, isdir):
    """Transform filesystem permissions into human readable text

    Arguments
    ---------
    perm -- the numerical representation of permissions
    isdir -- wether the permissions are associated with a directory

    """

    # helper to do the conversion for one population
    def _to_txt(perm):
        ret = []
        if perm & 0o4:
            ret.append(pgettext("Permission du filesystem", "Lecture"))
        if perm & 0o2:
            ret.append(pgettext("Permission du filesystem", "Écriture"))
        if perm & 0o1 and isdir:
            ret.append(pgettext("Permission du filesystem", "Parcours"))
        elif perm & 0o1 and not isdir:
            ret.append(pgettext("Permission du filesystem", "Exécution"))
        return ret

    # Get permissions as text for user, group and others
    p = []
    for i in [2, 1, 0]:
        p.append(_to_txt((perm >> i * 3) & 0o7))
    # Add special permissions
    if perm & 0o1000:
        p[2].append(pgettext("Permission du filesystem", "Sticky bit"))
    if perm & 0o2000:
        p[1].append(pgettext("Permission du filesystem", "SetGID"))
    if perm & 0o4000:
        p[0].append(pgettext("Permission du filesystem", "SetUID"))
    # Add a default "No rights"
    for i in p:
        if len(i) == 0:
            i.append(pgettext("Permission du filesystem", "Aucun droit"))
    return ["/".join(c) for c in p]


def fs_perm_to_text(perm):
    """Transform a filesystem permissions into text

    For instance, transform 0o644 into "rw-r--r--"

    Arguments
    ---------
    perm -- the int representation of permissions

    """

    # helper to do the conversion for one population
    def _to_txt(perm):
        ret = ["-", "-", "-"]
        if perm & 0o4:
            ret[0] = "r"
        if perm & 0o2:
            ret[1] = "w"
        if perm & 0o1:
            ret[2] = "x"
        return ret

    # Get permissions as text for user, group and others
    p = []
    for i in [2, 1, 0]:
        p.append(_to_txt((perm >> i * 3) & 0o7))
    # Add special permissions
    if perm & 0o1000:
        p[2][2] = "t" if p[2][2] == "x" else "T"
    if perm & 0o2000:
        p[1][2] = "s" if p[1][2] == "x" else "S"
    if perm & 0o4000:
        p[0][2] = "s" if p[0][2] == "x" else "S"
    return ["".join(c) for c in p]


def fs_text_to_perm(ptext):
    """Transform a text representation of filesystem permissions

    For instance, transform "rw-r--r--" into 0o644

    Arguments
    ---------
    ptext -- the text representation of permissions

    """

    # helper to get the OR-mask to apply
    def _get_mask(c, i):
        if c == "r":
            return 0o4 << i * 3
        elif c == "w":
            return 0o2 << i * 3
        elif c == "x":
            return 0o1 << i * 3
        elif c in ("S", "T"):
            return 0o1000 << i
        elif c in ("s", "t"):
            return 0o1000 << i | 0o1 << i * 3
        else:
            return 0

    # parse the text
    perm = 0
    for i in range(9):
        perm |= _get_mask(ptext[i], 2 - (i // 3))
    return perm


# Helpers for ls -l date parsing
def _parse_ls_long_date(month, day, hour_year):
    """Parse the date from ls -l output"""
    # table of monthes short form. The first element is here to start @1
    monthes = [
        "",
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    ]
    # check whether hour_year is an hour or the hour, and affect the
    # right values to hour, minute & year
    if ":" in hour_year:
        year = datetime.today().year
        hour, minute = hour_year.split(":")
        hour, minute = int(hour), int(minute)
    else:
        year = int(hour_year)
        hour, minute = 0, 0
    # construct the date
    return datetime(year, monthes.index(month), int(day), hour, minute)


RE_LS_LONG_START = re.compile(
    r"[-dlcbps]([r-][w-][xsS-]){2}[r-][w-][xtT-].?\s",
)


def parse_ls_long_listing(inp):
    """Parse the output of an ls -l command

    It parse the long listing output of ls and return a dict for each
    file, with the following data:
        - name
        - type (f->file, d->directory, l->symlink, c->caracter device
                b->block device, p->FIFO, s->socket)
        - perm(issions)
        - user (owner)
        - group (owner)
        - inode (count)
        - date
        - has_acl
        - size (only for files, directories & symlinks)
        - target (only for symlinks)
        - major (only for block nodes)
        - minor (only for block nodes)

    Arguments
    ---------
    inp -- Output of a ls -l command

    """
    ret = []
    for line in inp.strip().splitlines():
        # skip invalid lines
        if not RE_LS_LONG_START.match(line):
            continue
        # first parse the type and ensure file type is mapped to f
        t = line[0]
        if t == "-":
            t = "f"

        # TODO, names should also be unquoted.
        # parse files, directories, symlinks, fifo & sockets
        # They all have 9 columns
        if t in ("f", "d", "l", "p", "s"):
            elements = line.split(None, 8)
            data = {
                "type": t,
                "perm": fs_text_to_perm(elements[0][1:10]),
                "has_acl": len(elements[0]) > 10 and elements[0][10] == "+",
                "inode": elements[1],
                "user": elements[2],
                "group": elements[3],
                "size": elements[4],
                "date": _parse_ls_long_date(*elements[5:8]),
                "name": elements[8],
            }
            # do some extra work to extract target from a symlink
            if t == "l":
                name, target = data["name"].split("->", 1)
                data["name"] = name
                data["target"] = target
        elif t in ("c", "b"):
            # parse files, directories, symlinks & fifo
            # They all have 10 columns
            elements = line.split(None, 9)
            data = {
                "type": t,
                "perm": fs_text_to_perm(elements[0][1:10]),
                "has_acl": len(elements[0]) > 10 and elements[0][10] == "+",
                "inode": elements[1],
                "user": elements[2],
                "group": elements[3],
                "major": int(elements[4][:-1]),
                "minor": int(elements[5]),
                "date": _parse_ls_long_date(*elements[6:9]),
                "name": elements[9],
            }
        # add all lines except . and ..
        if data["name"] not in (".", ".."):
            ret.append(data)
    return ret


def ls_long_listing_to_table(parsed_listing):
    """Transform the output of ls -l into a human readable table

    The output table is composed of the following columns:
        - name
        - user owner
        - group owner
        - user permisions
        - group permissions
        - other permissions

    Arguments
    ---------
    parsed_listing -- output of ls -l already parsed with
                    parse_ls_long_listing

    """
    # Transform in dummy readable format
    ret = [
        [
            pgettext("Permission du filesystem", "Nom"),
            pgettext("Permission du filesystem", "Propriétaire"),
            pgettext("Permission du filesystem", "Groupe"),
            pgettext("Permission du filesystem", "Droits Propriétaire (u)"),
            pgettext("Permission du filesystem", "Droits Groupe (g)"),
            pgettext("Permission du filesystem", "Droits Autres (o)"),
        ],
    ]
    for line in parsed_listing:
        # transform the permission into human readable format
        if line["type"] == "l":
            # permissions for symlinks has no sense
            u = g = o = M(
                pgettext("Permission du filesystem", "[code]N/A[/code] (symlink)"),
            )
        else:
            # for all other type, apply a normal resolution
            h_perm = fs_perm_to_human(line["perm"], line["type"] == "d")
            t_perm = fs_perm_to_text(line["perm"])
            u, g, o = (M("[code]%s[/code] (%s)") % p for p in zip(t_perm, h_perm))

        # Ensure directory names are ended with a /
        name = line["name"]
        if line["type"] == "d" and name[-1] != "/":
            name += "/"
        ret.append([name, line["user"], line["group"], u, g, o])
    return ret
