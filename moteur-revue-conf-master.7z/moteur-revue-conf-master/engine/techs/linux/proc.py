# -*- coding: utf-8 -*-

"""Implement helpers to parse processes data"""


def parse_ps(inp):
    """Parse the output of a ps command

    Transform the output of the command into a list of of dict
    indexed by the column name
    """
    # extract the column headers
    lines = inp.splitlines()
    head = lines[0].split()

    # split all remaining lines and indexed them using headers
    ret = []
    for line in lines[1:]:
        # limit the number of split
        ret.append(dict(zip(head, line.split(None, len(head) - 1))))
    return ret
