# -*- coding: utf-8 -*-

"""Implement helpers to parse users and groups"""

# Standard libraries
import re

# Project imports
from engine.core import i18n
from engine.techs.common import separator2table

# I18N
M_ = i18n.domain("linux").M_
pgettext = i18n.domain("linux").pgettext


# regex to locate valid passwords
# see man 3 crypt
# valid caracters are [a-zA-Z0-9./] + $ as separator
# empty password are also valid
# the general password structure is $id$rounds=yyy$salt$encrypted
# all the following format are valid:
#   encrypted                       ==> DES
#   $id$encrypted
#   $id$$salt$encrypted
#   $id$rounds=yyy$encrypted
#   $id$rounds=yyy$salt$encrypted
#   empty
#
# the regex is then
#   /^$|^(\$id\$(rounds=yyy\$)?(salt\$)?)?encrypted$/
#
# disabled users have a ! at the begining of the hash
# User with only ! in their password cannot be enabled
# The regex should match passwords, disabled passwords,
# empty passwords, but not disabled empty passwords
# A look-behind is used to ensure that behavior
# NOTE: the regex is splitted for more readability
PWD_RE = re.compile(
    r"^!?"  # leading ! to disable
    r"(?P<pwd>"  # start pwd group
    r"("  # | optional id+rounds+salt
    r"\$(?P<id>[a-zA-Z0-9]+)\$"  # |   match id
    r"(rounds=(?P<rounds>[0-9]+)\$)?"  # |   match rounds
    r"((?P<salt>[a-zA-Z0-9./]+)\$)?"  # |   match salt
    r")?"  # | end id+rounds+salt
    r"(?P<encrypted>"  # | start encrypted group
    r"[a-zA-Z0-9./]+"  # |   match a real password
    r"|(?<=^)"  # |   match empty passwords
    r")"  # | end encrypted group
    r")$",  # end pwd group
)


def parse_users_and_groups(passwd_c, shadow_c, group_c, gshadow_c):
    """Parse users and groups files to ease processing

    Transform the data in files into lists of dict with data
    contained within files.
    Two lists are created:
        - A list of all users
        - A list of all groups

    Arguments
    ---------
    passwd_c  -- content of the passwd NSS entry
    shadow_c  -- content of the shadow NSS entry
    group_c   -- content of the group NSS entry
    gshadow_c -- content of the gshadow NSS entry

    Returns
    -------
    The function returns 6 elements:
        - a list of user dict
        - a list of group dict

        - a dict of user dict, indexed by the username
        - a dict of group dict, indexed by the groupname

        - a dict of list of user dict, indexed by the UID
        - a dict of list of user dict, indexed by the GID
        - a dict of list of group dict, indexed by the GID

    """
    # split each files
    passwd = separator2table(passwd_c, ":")
    shadow = separator2table(shadow_c, ":")
    group = separator2table(group_c, ":")
    gshadow = separator2table(gshadow_c, ":")

    # transforms shadows into dict for easier access
    shadow_d = {}
    for u in shadow:
        # do not treat NIS entries
        if u[0][0] in ("+", "-"):
            continue
        # if entries are duplicated, it is the first entry which is used
        if u[0] not in shadow_d:
            shadow_d[u[0]] = u
    gshadow_d = {}
    for u in gshadow:
        # do not treat NIS entries
        if u[0][0] in ("+", "-"):
            continue
        # if entries are duplicated, it is the first entry which is used
        if u[0] not in gshadow_d:
            gshadow_d[u[0]] = u

    # create the dicts for users
    users = []
    users_by_name = {}
    users_by_uid = {}
    users_by_gid = {}
    for u in passwd:
        # do not treat NIS entries
        if u[0][0] in ("+", "-"):
            continue
        data = {
            # passwd data
            "name": u[0],
            "passwd_pass": u[1],
            "UID": u[2],
            "GID": u[3],
            "comment": u[4],
            "home": u[5],
            "shell": u[6],
            # shadow data
            "shadow_pass": None,
            "last_pwd_change": None,
            "min_pwd_age": None,
            "max_pwd_age": None,
            "warning": None,
            "inactivity": None,
            "expiration": None,
            "shadow_reserved": None,
            # Groups mapping
            "primary_grp": None,
            "secondary_grps": [],
            # Password logic
            "password": u[1],
            "pwd_file": "passwd",
            "pwd_usable": False,
            "parsed_pwd": None,
            "disabled": None,
        }
        if u[0] in shadow_d:
            s = shadow_d[u[0]]
            data.update(
                {
                    "shadow_pass": s[1],
                    "last_pwd_change": s[2],
                    "min_pwd_age": s[3],
                    "max_pwd_age": s[4],
                    "warning": s[5],
                    "inactivity": s[6],
                    "expiration": s[7],
                    "shadow_reserved": s[8],
                },
            )
        # update password data
        if data["passwd_pass"] == "x":
            data.update(
                {
                    "password": data["shadow_pass"],
                    "pwd_file": "shadow",
                },
            )
        # try to find users with passwords even if they are disabled
        if data["password"] is not None:
            m = PWD_RE.match(data["password"])
            if m:
                data["parsed_pwd"] = m.groupdict()
                data["pwd_usable"] = True
                data["disabled"] = m.group("pwd") != data["password"]

        # add to lists & dicts
        users.append(data)
        if data["name"] not in users_by_name:
            users_by_name[data["name"]] = data
        if data["UID"] not in users_by_uid:
            users_by_uid[data["UID"]] = []
        if data["GID"] not in users_by_gid:
            users_by_gid[data["GID"]] = []
        users_by_uid[data["UID"]].append(data)
        users_by_gid[data["GID"]].append(data)

    # create the dicts for groups
    groups = []
    groups_by_name = {}
    groups_by_gid = {}
    for g in group:
        # do not treat NIS entries
        if g[0][0] in ("+", "-"):
            continue
        data = {
            # group data
            "name": g[0],
            "group_pass": g[1],
            "GID": g[2],
            "group_members": [],
            # gshadow data
            "gshadow_pass": None,
            "gshadow_admins": [],
            "gshadow_members": [],
            # user mapping
            "members": [],
            # Password logic
            "password": g[1],
            "pwd_file": "group",
            "pwd_usable": False,
            "parsed_pwd": None,
            "disabled": None,
        }
        # Do the user/group mapping
        for u in g[3].split(","):
            u = u.strip()
            if u in users_by_name:
                data["group_members"].append(users_by_name[u])
                users_by_name[u]["secondary_grps"].append(data)
        # update with gshadow info
        if g[0] in gshadow_d:
            s = gshadow_d[g[0]]
            data.update(
                {
                    "gshadow_pass": s[1],
                },
            )
            # Do the user/group mapping for members
            for u in s[3].split(","):
                u = u.strip()
                if u in users_by_name:
                    data["gshadow_members"].append(users_by_name[u])
                    if all(
                        g[0] != i["name"] for i in users_by_name[u]["secondary_grps"]
                    ):
                        users_by_name[u]["secondary_grps"].append(data)
            # Do the user/group mapping for admins
            for u in s[2].split(","):
                u = u.strip()
                if u in users_by_name:
                    data["gshadow_admins"].append(users_by_name[u])
                    if all(
                        g[0] != i["name"] for i in users_by_name[u]["secondary_grps"]
                    ):
                        users_by_name[u]["secondary_grps"].append(data)

        # update password data
        if data["group_pass"] == "x":
            data.update(
                {
                    "password": data["gshadow_pass"],
                    "pwd_file": "gshadow",
                },
            )
        # try to find groups with passwords
        # groups with empty passwords is similar to no password:
        # only members can add the group dynamically
        if data["password"] is not None and data["password"] != "":
            m = PWD_RE.match(data["password"])
            if m:
                data["parsed_pwd"] = m.groupdict()
                data["pwd_usable"] = True
                data["disabled"] = m.group("pwd") != data["password"]

        # add to lists & dicts
        groups.append(data)
        if data["name"] not in groups_by_name:
            groups_by_name[data["name"]] = data
        if data["GID"] not in groups_by_gid:
            groups_by_gid[data["GID"]] = []
        groups_by_gid[data["GID"]].append(data)

    # update all user/group associations for the primary groups
    for u in users:
        if u["GID"] in groups_by_gid:
            g = groups_by_gid[u["GID"]][0]
            u["primary_grp"] = g
            if all(u["name"] != i["name"] for i in g["group_members"]):
                g["group_members"].append(u)
    # update all groups members based on all member tables
    # we consider all users which may get access to this group
    # it can be either `group_members` who are granted access on logon,
    # or `gshadow_members` who can use `newgrp` to add the group without
    # password, or `gshadow_admins` who can change password to get
    # access using `newgrp` and the defined password
    for g in groups:
        g["members"].extend(g["group_members"])
        for u in g["gshadow_members"]:
            if u not in g["members"]:
                g["members"].append(u)
        for u in g["gshadow_admins"]:
            if u not in g["members"]:
                g["members"].append(u)

    return (
        users,
        groups,
        users_by_name,
        groups_by_name,
        users_by_uid,
        users_by_gid,
        groups_by_gid,
    )


def find_passwd_type(parsed_pwd):
    """Find the type of a password from its hash

    It works on the parsed version of the password, which is defined
    in parse_users_and_groups().

    The decision is based on the id

    Arguments
    ---------
    parsed_pwd -- dict with component of the password as created in
                    parse_users_and_groups()

    """
    if parsed_pwd["pwd"] == "":
        return M_("Mot de passe vide")
    elif parsed_pwd["id"] is None:
        return M_("DES-based crypt (descrypt)")
    elif parsed_pwd["id"] == "1":
        return M_("MD5-based crypt (md5crypt)")
    elif parsed_pwd["id"] in ("2", "2a", "2b", "2x", "2y"):
        return M_("Blowfish-based crypt (bcrypt)")
    elif parsed_pwd["id"] == "5":
        return M_("SHA256-based crypt (sh256crypt)")
    elif parsed_pwd["id"] == "6":
        return M_("SHA512-based crypt (sh512crypt)")
    else:
        return pgettext("password hash", "Inconnue")
