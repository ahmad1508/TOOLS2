# -*- coding: utf-8 -*-

"""Provides filters for Hadoop"""

# Squelette du fichier filtres v0.1, par TDU (08/2015)
# ====================================================

# Project imports
from engine.core.technology import TechnologyV1


class Hadoop(TechnologyV1):
    """Hadoop technology class"""

    desc = {
        "name": "hadoop",
        "templates": {"full": {"fr": "hadoop.jinja"}},
        "default language": "fr",
        "default template": "full",
    }

    # Fonctions "snippets" utilisées par les fonctions filtres
    # --------------------------------------------------------

    # Fonctions de filtres
    # --------------------
