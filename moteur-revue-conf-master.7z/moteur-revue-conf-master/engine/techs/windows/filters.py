# -*- coding: UTF-8 -*-
# Standard libraries
import configparser
import csv
import re

# Project imports
from engine import logger
from engine.bbcode import Markup as M
from engine.core import i18n
from engine.core.technology import TechnologyV1
from engine.techs.common import (
    attributelist2dict,
    conformity_cell,
    decode,
    dict2table,
    separator2table,
    split_on_title,
    table2bbcode,
    to_utf8,
)
from engine.techs.windows import data
from engine.techs.windows.network import (
    format_network_share,
    parse_default_network,
)
from engine.techs.windows.system_access import (
    format_task,
    parse_acl_extract,
    parse_default_gpo,
    parse_options_security,
)
from engine.techs.windows.update import parse_default_wsus, parse_flash_version

# I18N
_ = i18n.domain("windows")._
M_ = i18n.domain("windows").M_
pgettext = i18n.domain("windows").pgettext


def ps1list2table(extract, keys=None):
    # parse with two back to lines
    lists = extract.strip().split("\r\n\r\n")
    # parse with only one back to lines if keys is defined
    # Else default "Parameters,Value" title will be applied
    if 1 >= len(lists) and keys is not None:
        lists = extract.strip().split("\r\n")

    if 1 < len(lists):
        table = dict2table(attributelist2dict(extract), keys)
    else:
        table = separator2table(
            extract,
            ":",
            "\r\n",
            [M_("Parameter"), M_("Value")],
        )

    for row in table:
        if 2 <= len(row) and row[1].strip() == ".":
            row[1] = M_("Not configured")
        elif all(r == "" for r in row):
            table.remove(row)

    return table


def decode_ps1_list(keys=None):
    def decorator(f):
        @decode("utf-8")
        def wrapper(self, extract):
            return f(self, ps1list2table(extract, keys))

        return wrapper

    return decorator


def default_filter_extract(func):
    """Decorate default filters."""

    @decode_ps1_list(keys=None)
    def wrapper(self, table):
        return table2bbcode(table, caption=func(self))

    return wrapper


class Windows(TechnologyV1):
    """Windows technology class"""

    desc = {
        "name": "windows",
        "templates": {
            "full": {
                "fr": "windows/fr/windows_full.jinja",
                "en": "windows/en/windows_full.jinja",
            },
        },
        "default language": "fr",
        "default template": "full",
    }

    def __init__(self):
        super().__init__()

        # the script info
        self.version = (1, 1, 0)

    def preprocessors(self):
        """Perform preprocessors on extracts.

        Extend the parent method to parse required data
        """
        # INI logger
        log = logger.getLogger(__name__)
        # parse the script info
        if "[0] - Script information" in self.extracts:
            s = split_on_title(to_utf8(self.extracts["[0] - Script information"]), 1)
            self.version = tuple(int(x) for x in s["Script Version"].split("."))

        log.debug("Launching Windows from a script at version: %s", self.version)
        # parse hostname
        if "[1] - Computer information" in self.extracts:
            s = split_on_title(to_utf8(self.extracts["[1] - Computer information"]), 1)[
                "Computer information"
            ]
            self.hostname = attributelist2dict(s)[0]["Name"]

    # Fonctions de filtres, à référencer
    # dans le dictionnaire  dict_filters
    # (en bas)
    # ------------------------------------------------------------------------

    @decode("cp437")
    def default_cp437(self, extract):
        return self.default(extract)

    @decode("latin1")
    def default_latin1(self, extract):
        return self.default(extract)

    @decode("utf-8")
    def remove_extra_ln(self, extract):
        string = ""
        for line in extract.split("\n"):
            string += line
        return string

    def parse_default(self, extract, db):
        re_param = re.compile(r"[^()]+\(([\w\.]+)\)")
        data = separator2table(extract, ":", "\r\n")
        table = [[M_("Parameter"), M_("Recommended value"), M_("Current value")]]
        for line in data:
            if 2 <= len(line):
                match = re_param.match(line[0])
                if match:
                    param = match.group(1)
                    value = db.get(param)

                    if value:
                        if line[1] == " .":
                            if "default" in value:
                                if "value" in value:
                                    val = str(value["value"][value["default"]]) + _(
                                        " (default)"
                                    )
                                else:
                                    val = str(value["default"]) + _(" (default)")
                            else:
                                val = _("Not Defined")
                        elif "value" in value:
                            for k in value["value"].keys():
                                if k in line[1]:
                                    val = k + " - " + _(value["value"][k])
                        else:
                            val = line[1]
                        row = [
                            "{} ({})".format(_(value["name"]), param),
                            value["expected"],
                            val,
                        ]
                        table.append(row)
        return table

    #######################
    # Global Information  #
    #######################

    @default_filter_extract
    def computer_info(self):
        return M_("General informations about the computer")

    @default_filter_extract
    def bios_info(self):
        return M_("BIOS informations about the computer")

    @default_filter_extract
    def windows_version(self):
        return M_("Version informations about the computer")

    @decode("utf-8")
    def filter_environment_variables(self, extract):
        re_line = re.compile(r"^([\w_-]+)\s+(.*)$")

        table = [[M_("Parameter"), M_("Value")]]
        for line in extract.split("\r\n"):
            if 0 < len(line):
                env_var = re_line.match(line)
                if env_var:
                    table.append(env_var.groups())

        return table2bbcode(table, caption=_("Environment variables-") + self.hostname)

    @decode("utf-8")
    def filter_disks(self, extract):
        disks = attributelist2dict(extract)

        drive_type = {
            "0": "Unknown",
            "1": "No Root Directory",
            "2": "Removable Disk",
            "3": "Local Disk",
            "4": "Network Drive",
            "5": "Compact Disc",
            "6": "RAM Disk",
        }

        for disk in disks:
            disk["DriveType"] = drive_type.get(disk["DriveType"])

        table = dict2table(disks)
        table[0] = [
            M_("DeviceID"),
            M_("DriveType"),
            M_("FreeSpace"),
            M_("Size"),
            M_("VolumeName"),
            M_("VolumneSerialNumber"),
            M_("FileSystem"),
        ]

        return table2bbcode(table, caption=_("Disks-") + self.hostname)

    @decode("utf-8")
    def filter_storage_peripherals(self, extract):
        table = self.parse_default(
            extract, data.filter_storage_peripherals.db_storage_peripherals
        )
        # translate paremeter name
        return table2bbcode(table, "Storage peripherals")

    ############
    # NETWORK  #
    ############

    @decode("utf-8")
    def filter_actual_connections_profiles(self, extract):
        profiles = attributelist2dict(extract)

        network_category = {
            "0": "Public",
            "1": "Private",
            "2": "DomainAuthenticated",
        }

        ipvx_connectivity = {
            "0": "Disconnected",
            "1": "NoTraffic",
            "2": "Subnet",
            "3": "LocalNetwork",
            "4": "Internet",
        }
        for profile in profiles:
            profile["NetworkCategory"] = network_category.get(
                profile["NetworkCategory"]
            )
            profile["IPv4Connectivity"] = ipvx_connectivity.get(
                profile["IPv4Connectivity"]
            )
            profile["IPv6Connectivity"] = ipvx_connectivity.get(
                profile["IPv6Connectivity"]
            )

        table = dict2table(profiles)
        table[0] = [
            M_("Name"),
            M_("InterfaceAlias"),
            M_("InterfaceIndex"),
            M_("NetworkCategory"),
            M_("IPv4Connectivity"),
            M_("IPv6Connectivity"),
        ]

        return table2bbcode(table, caption=_("Current connections-") + self.hostname)

    @decode("utf-8")
    def filter_firewall_rules(self, extract):
        rules = attributelist2dict(extract)

        fw_action = {0: "Block", 1: "Allow"}

        fw_direction = {1: "Inbound", 2: "Outbound"}

        fw_protocols = {
            1: "ICMPv4",
            2: "IGMP",
            6: "TCP",
            17: "UDP",
            41: "IPv6",
            43: "IPv6Route",
            44: "IPv6Frag",
            47: "GRE",
            58: "ICMPv6",
            59: "IPv6NoNxt",
            60: "IPv6Opts",
            112: "VRRP",
            113: "PGM",
            115: "L2TP",
            256: "Any",
        }

        rules_filtered = []
        for rule in rules:
            if rule["Enabled"] == "True":
                profiles_number = int(rule["Profiles"])
                if profiles_number == 2147483647:
                    rule["Profiles"] = "Not found"
                else:
                    rule["Profiles"] = ""
                    if (profiles_number >> 0) & 1:
                        rule["Domain"] = True
                        rule["Profiles"] += "Domain|"
                    if (profiles_number >> 1) & 1:
                        rule["Private"] = True
                        rule["Profiles"] += "Private|"
                    if (profiles_number >> 2) & 1:
                        rule["Public"] = True
                        rule["Profiles"] += "Public|"
                    rule["Profiles"] = rule["Profiles"][:-1]

                action_number = int(rule["Action"])
                rule["Action"] = fw_action[action_number]

                direction_number = int(rule["Direction"])
                rule["Direction"] = fw_direction[direction_number]

                protocol_number = int(rule["Protocol"])
                if protocol_number in fw_protocols:
                    rule["Protocol"] = fw_protocols[protocol_number]

                rules_filtered.append(rule)

        table = dict2table(rules_filtered)
        return table2bbcode(table, caption=_("Firewall rules-") + self.hostname)

    @decode_ps1_list(
        keys=["NetEnabled", "Name", "ServiceName", "MACAddress", "AdapterType"]
    )
    def filter_network_interfaces(self, table):
        result = []
        result.append(table.pop(0))
        for row in table:
            if row[0].strip().lower() in ["true", "1"]:
                result.append(row)

        result[0] = [
            _("NetEnabled"),
            _("Name"),
            _("ServiceName"),
            _("MACAddress"),
            _("AdapterType"),
        ]

        return table2bbcode(result, caption=_("Network interfaces-") + self.hostname)

    @decode_ps1_list(
        keys=[
            "IPEnabled",
            "ServiceName",
            "MACAddress",
            "DHCPServer",
            "IPAddress",
            "IPSubnet",
            "Gateway",
            "DNSDomain",
            "WINSPrimaryServer",
        ]
    )
    def filter_ip_configuration(self, table):
        result = []
        result.append(table.pop(0))
        for row in table:
            if row[0].strip().lower() in ["true", "1"]:
                result.append(row)
        result[0] = [
            _("IPEnabled"),
            _("ServiceName"),
            _("MACAddress"),
            _("DHCPServer"),
            _("IPAddress"),
            _("IPSubnet"),
            _("Gateway"),
            _("DNSDomain"),
            _("WINSPrimaryServer"),
        ]
        return table2bbcode(result, caption=_("Ip configuration-") + self.hostname)

    @decode_ps1_list(keys=None)
    def filter_smb_configuration(self, table):
        result = [table.pop(0)]

        for line in table:
            if "smb" in line[0].lower() or "securitysignature" in line[0].lower():
                result.append(line)

        result[0] = [_("Parameter"), _("Value")]

        return table2bbcode(result, caption=_("SMBconfiguration-") + self.hostname)

    @decode("utf8")
    def filter_ipsec_parameters(self, extract):
        table = separator2table(extract, "   ", "\r\n")

        tmp = [[M_("Parameter"), M_("Value")]]
        for line in table:
            tmp.append([item.strip() for item in line if item != ""])

        table = [[M_("Parameter"), M_("Value")]]

        for line in tmp[4:-1]:
            table.append(line)

        return table2bbcode(table, caption=_("Ipsec parameters-" + self.hostname))

    @decode("utf8")
    def filter_network_shares(self, extract):
        tok_start = "@{Name="
        re_str = re.compile(r"\@\{([^{}]+)+\}")
        sep = "--------"

        result = []
        tmp = {}

        row = M(
            "[table][title]"
            + "share_acl"
            + "[/title][tr][th]"
            + _("Name")
            + "[/th][th]"
            + _("Description")
            + "[/th][th]"
            + _("Path")
            + "[/th][th]"
            + _("NTFS ACL")
            + "[/th][th]"
            + _("Share ACL")
            + "[/th][/tr]"
        )

        for line in extract.splitlines():
            if line.startswith(tok_start):
                if tmp:
                    result.append(tmp)
                tmp = {}
                res_regex = re_str.match(line)
                values = res_regex.group(1).strip()
                table_dot = values.split(";")
                values = [i.split("=") for i in table_dot]
                for value in values:
                    if value and len(value) == 2:
                        tmp[value[0]] = value[1]
                tmp["NTFS ACL"] = []
                tmp["Share ACL"] = []
            elif "NTFS ACL" in line:
                key = "NTFS ACL"
            elif "Share ACL" in line:
                key = "Share ACL"
            elif sep in line or not line or "Successfully processed" in line:
                continue
            elif tmp[" Path"] in line:
                tmp[key].append(line.split(tmp[" Path"])[1].strip())
            else:
                tmp[key].append(line.strip())

        if tmp:
            result.append(tmp)

        return (
            row
            + M("").join([format_network_share(share) for share in result])
            + M("[/table]")
        )

    @decode("utf-8")
    def filter_network_parameter(self, extract):
        return parse_default_network(
            extract, data.filter_network_parameter.db_network_parameter
        )

    @default_filter_extract
    def filter_ipsec_rules(self):
        return M_("IPsec rules defined on the computer")

    ##########
    # Update #
    ##########

    @decode_ps1_list(keys=["DisplayName", "DisplayVersion", "Publisher", "InstallDate"])
    def filter_installed_software(self, table):
        """filter on installed software

        Arguments
        ---------
        table : extracted data from the script

        Returns
        ---------
        table with  rights on installed software
        """

        table[0] = [
            _("DisplayName"),
            _("DisplayVersion"),
            _("Publisher"),
            _("InstallDate"),
        ]

        return table2bbcode(table, caption=_("Installed software-") + self.hostname)

    @decode("utf-8")
    def filter_flash_version(self, extract):
        """filter flash version

        Arguments
        ---------
        extract : extracted data from the script

        Returns
        ---------
        bbcode table with differents flash version installed and
        compliant title
        """
        table = parse_flash_version(extract)
        if table != [[]]:
            table[0] = [_("InternalName"), _("Product"), _("ProductVersion")]

        return table2bbcode(table, caption=_("Flash version-") + self.hostname)

    # JSON DONE
    @decode("utf-8")
    def filter_wsus_configuration(self, extract):
        table = parse_default_wsus(
            extract, data.filter_wsus_configuration.db_wsus_configuration
        )
        return table2bbcode(table, caption=_("WSUS configuration-") + self.hostname)

    @decode("utf-8")
    def hotfixes_csv(self, extract):
        data = list(csv.reader(extract.split("\r\n")))
        tmp = []
        tmp += data[-15:]
        tmp[0] = [
            M_("HotFixId"),
            M_("Installed On"),
            M_("Installed By"),
            M_("Description"),
        ]
        return table2bbcode(tmp, caption=_("Hotfixe csv-") + self.hostname)

    ##################
    # Local strategy #
    ##################

    # JSON DONE
    @decode("utf-8")
    def filter_local_password_policy(self, extract):
        table = self.parse_default(
            extract,
            data.filter_local_password_policy.db_local_password_policy,
        )

        return table2bbcode(table, caption=_("Local password policy-") + self.hostname)

    # JSON DONE
    @decode("utf-8")
    def filter_local_account_lockout_policy(self, extract):
        table = self.parse_default(
            extract,
            data.filter_local_account_lockout_policy.db_local_account_lockout_policy,
        )

        return table2bbcode(
            table, caption=_("Local account lockout policy-") + self.hostname
        )

    # JSON DONE
    @decode("utf-8")
    def filter_local_account_auto_lockout_policy(self, extract):
        table = self.parse_default(
            extract,
            data.filter_local_account_auto_lockout_policy.db_local_account_auto_lockout_policy,
        )

        return table2bbcode(
            table, caption=_("Local account auto lockout policy-") + self.hostname
        )

    # JSON DONE
    @decode("utf-8")
    def filter_user_account_control_policy(self, extract):
        table = self.parse_default(
            extract,
            data.filter_user_account_control_policy.db_user_account_control_policy,
        )
        return table2bbcode(
            table, caption=_("User account control policy-") + self.hostname
        )

    # JSON DONE
    @decode("utf-8")
    def filter_autorun_policy(self, extract):
        table = self.parse_default(
            extract, data.filter_autorun_policy.db_autorun_policy
        )

        return table2bbcode(table, caption=_("Autorun policy-") + self.hostname)

    @decode("utf-8")
    def filter_audit_policy(self, extract):
        """Default filter
        Arguments
        ---------
        extract : data extracted from script
        Returns
        ---------
        table with data filter
        """
        db = data.audit_value.db_audit_value
        input_table = extract.split("\r\n")
        table = [[M_("Parameter"), M_("Value")]]
        for row in input_table:
            row = row.split(": ")
            if len(row) > 1:
                if row[1] in db.keys():
                    value = db[row[1]]
                else:
                    value = M_("Error Parsing")
                regex_res = re.search(r'"(.*)"|\((.*)\)', row[0])
                if regex_res.group(1):
                    res = regex_res.group(1)
                elif regex_res.group(2):
                    res = regex_res.group(2)
                else:
                    res = regex_res.group(0)
                table.append([res, _(value)])
        return table2bbcode(table, caption=_("Audit policy-") + self.hostname)

    @decode("utf-8")
    def filter_advanced_audit_policy(self, extract):
        """filter advanced audit policy (with subcategory)

        Arguments
        ---------
        extract : extracted data from the script

        Returns
        ---------
        bbcode table with advanced audit strategy
        """
        # parse extract in table
        lines = list(extract.split("\r\n"))
        extract_table = list(csv.reader(lines))

        # delete title of the table
        extract_table[0] = ""

        # append the title of the output table
        table = []
        table.append(
            [
                M_("Strategy"),
                M_("Recommanded value"),
                M_("Actual setting"),
                M_("Compliance"),
            ]
        )

        # get data to check conformity
        data_db = data.filter_audit_policy.db_audit_policy
        # retrieve the 2 sub tables
        audit_status = data_db["status"]
        audit_policy = data_db["policy"]

        # review all policies and append them within the db dict
        review = {}
        for policy in extract_table:
            if policy and policy[3]:
                dbp = audit_policy[policy[3]]
                review[policy[3]] = [
                    _(dbp["name"]),
                    _(audit_status.get(dbp["expected"])),
                    _(policy[4]),
                    conformity_cell((int(dbp["expected"]) == int(policy[6]))),
                ]

        # transform the db dict to a table
        for guid, dbp in audit_policy.items():
            # Manage section entries
            if "section_name" in dbp:
                table.append([_(dbp["section_name"])])
                continue

            # Manage conformity rows
            if guid in review:  # already reviewed
                table.append(review[guid])
            else:  # policy not reviewed
                table.append(
                    [
                        _(dbp["name"]),
                        _(audit_status.get(dbp["expected"])),
                        M_("Not configured"),
                        conformity_cell(False),
                    ]
                )

        return table2bbcode(table, caption=_("Advanced audit policy-") + self.hostname)

    @decode("utf-8")
    def default_ini(self, extract):
        ini = configparser.ConfigParser()
        ini.read_string(extract)
        result = []
        for section in ini:
            for option in ini[section]:
                result.append(
                    {
                        "section": section,
                        "option": option,
                        "value": ini[section][option],
                    }
                )

        table = dict2table(result)
        table[0] = [M_("Section"), M_("Option"), M_("Value")]

        return table2bbcode(table, caption=_("Security policy-") + self.hostname)

    #############
    # Log Event #
    #############

    @decode("utf-8")
    def filter_windows_event(self, extract):
        tmp = ""
        table = extract.split("\n\r\n")
        tab = [
            [
                M_("File"),
                M_("MaxSize"),
                M_("AutoBackupLogFiles"),
                M_("Retention"),
            ]
        ]

        for i in table:
            tmp = separator2table(i, "):", "\r\n")
            arr = []
            for j in tmp[:4]:
                arr.append(j[1])
            tab.append(arr)
        return table2bbcode(tab, caption=_("Windows event-") + self.hostname)

    @default_filter_extract
    def filter_ntp_sync(self):
        return M_("NTP service configuration")

    #################
    # System Access #
    #################

    @decode_ps1_list(keys=None)
    def filter_default_local_users_status(self, table):
        table[0] = [_("Parameter"), _("Value")]
        return table2bbcode(table, caption=_("Local users status-") + self.hostname)

    @decode_ps1_list(keys=["Name", "Description", "Disabled"])
    def filter_local_users_list(self, table):
        table[0] = [_("Name"), _("Description"), _("Disabled")]
        return table2bbcode(table, caption=_("Local users list-") + self.hostname)

    @decode("utf-8")
    def filter_local_groups_list(self, extract):
        groups = extract.strip().split("\r\n\r\n\r\n")

        table = [[_("Name"), _("Domain"), _("Members")]]
        for group in groups:
            members = group.split(
                # noqa: E950
                "-------------------------------------------------------------------------------\r\n"
            )[1]
            members = re.split("(The|La) command", members)[0]
            name = group.split("Name: ")[1].split("\r\n")[0]
            domain = group.split("Domain: ")[1].split("\r\n")[0]
            table.append([name, domain, members])
        return table2bbcode(table, caption=_("Local groups list-") + self.hostname)

    @decode("utf-8")
    def filter_user_right(self, extract):
        table = parse_default_gpo(extract, data.filter_user_right.db_user_right)

        return table

    # JSON DONE
    @decode("utf-8")
    def filter_display_extensions(self, extract):
        table = self.parse_default(
            extract, data.filter_display_extensions.db_display_extensions
        )

        return table2bbcode(table, caption=_("Display extensions-") + self.hostname)

    @decode("utf-8")
    def filter_services_list(self, extract):
        lists = extract.strip().split("\r\n\r\n\r\n\r\n")

        if 1 < len(lists):
            # Started: TRUE/FALSE
            # StartMode: Auto/Manual/Disabled
            # State: Running/Stopped
            # Status: OK/?
            table = dict2table(
                attributelist2dict(extract.replace("\r\n\r\n", "\r\n"), "=", "\r\n"),
                [
                    "DisplayName",
                    "StartName",
                    "ServiceType",
                    "PathName",
                ],
            )  # , "Description"
        else:
            table = separator2table(
                extract, "=", "\r\n", [M_("Parameter"), M_("Value")]
            )

        table[0] = [
            _("DisplayName"),
            _("StartName"),
            _("ServiceType"),
            _("PathName"),
        ]

        return table2bbcode(table, caption=_("Services list-") + self.hostname)

    @decode_ps1_list(keys=["Name", "CommandLine", "ExecutablePath"])
    def filter_services_running(self, table):
        table[0] = [_("Name"), _("CommandLine"), _("ExecutablePath")]
        return table2bbcode(table, caption=_("Running services-") + self.hostname)

    @decode_ps1_list(keys=["Command", "User"])
    def filter_startup_items_list(self, table):
        table[0] = [_("Command"), _("User")]
        return table2bbcode(table, caption=_("Start-up items-") + self.hostname)

    def filter_right_on_service(self, extract):
        """filter rights on services

        Arguments
        ---------
        extract : extracted data from the script

        Returns
        ---------
        table with rights on all services
        """
        return parse_acl_extract("Service name", extract, self.version)

    def filter_right_on_system_driver(self, extract):
        """filter rights on system drivers

        Arguments
        ---------
        extract : extracted data from the scriptZ

        Returns
        ---------
        table with  rights on all system drivers
        """
        return parse_acl_extract("Driver name", extract, self.version)

    def filter_right_on_critical_directory(self, extract):
        """filter rights on critical directory

        Arguments
        ---------
        extract : extracted data from the script

        Returns
        ---------
        table with  rights on critical directory
        """
        return parse_acl_extract("DirectoryName", extract, self.version)

    # Task Scheduler working progress
    @decode("utf8")
    def filter_scheduled_tasks(self, extract):
        row = M(
            "[table][title]"
            + "scheduled_task"
            + "[/title][tr][th]"
            + _("Task name")
            + "[/th][th]"
            + _("Status")
            + "[/th][th]"
            + _("Last execution")
            + "[/th][th]"
            + _("Next execution")
            + "[/th][th]"
            + _("Author")
            + "[/th][th]"
            + _("Task to execute")
            + "[/th][th]"
            + _("Arguments")
            + "[/th][th]"
            + _("Run as a user")
            + "[/th][/tr]"
        )

        data = attributelist2dict(extract, ":", "\r\n")
        for line in data:
            row += format_task(line)
        row += M("[/table]")
        return row

    @decode("utf-8")
    def filter_security_options(self, extract):
        re_line = re.compile(r"^(.+)\:([^:]*)$")

        options = [["Parameter", "Value"]]
        for line in extract.split("\r\n"):
            if 0 < len(line):
                option = re_line.match(line)
                if option:
                    options.append([v.strip() for v in option.groups()])

        for option in options:
            if 2 <= len(option):
                value = option[1]
                if value == ".":
                    value = _("Not configured")
                else:
                    p = value.split(",", 1)
                    if 2 == len(p):
                        p, v = p
                        if "7" == p:
                            value = "\n".join(v.split(","))
                    option[1] = value

        table = parse_options_security(
            options[1:], data.filter_security_options.db_security_options
        )

        return table

    #####
    # RDP#
    #####

    @default_filter_extract
    def filter_rdp_services(self):
        return M_("Configuration of RDP")

    ########################
    # Antivirus Protection #
    ########################
    @decode("utf-8")
    def filter_antivirus_protection(self, extracts):
        """filter antirivus protection parameter configuration."""
        if (2, 0, 0) <= self.version < (2, 0, 1):
            # fix / changed format at 2.0.1
            tbl = [
                [
                    _("DisplayName"),
                    _("instanceGuid"),
                    _("pathToSignedProductExe"),
                    _("DefinitionStatus"),
                    _("productState"),
                ],
                *ps1list2table(
                    extracts,
                    keys=[
                        "displayName",
                        "instanceGuid",
                        "pathToSignedProductExe",
                        "DefinitionStatus",
                        "productState",
                    ],
                )[1:],
            ]
            return table2bbcode(
                tbl, caption=_("Antivirus protection-") + self.hostname
            ) + M_(
                "[help=Important Note]"
                "The extraction is based on the version 2.0.0 of the "
                "script which has an important bug: DefinitionStatus "
                "and productState [b]are not to be trusted[/b] and "
                "problably false."
                "[/help]",
            )

        # prior 2.0.0 & after 2.0.1, productState is extracted as a int
        # productState is a bit map
        # noqa: W505, B950 # see https://mcpforlife.com/2020/04/14/how-to-resolve-this-state-value-of-av-providers/ for info
        def get_state(product_state):
            """Parse WMI data to ProductState & SignatureState."""
            # ensure product_state is an int
            if not isinstance(product_state, int):
                product_state = int(product_state)
            return (
                # ProductState
                {
                    0x0000: "Off",
                    0x1000: "On",
                    0x2000: "Snoozed",
                    0x3000: "Expired",
                }.get(product_state & 0xF000, "Unknown"),
                # SignatureState
                {
                    0x00: "UpToDate",
                    0x10: "OutOfDate",
                }.get(product_state & 0xF0, "Unknown"),
            )

        # extract the conf of AV
        av_list = ps1list2table(
            extracts,
            keys=[
                "displayName",
                "instanceGuid",
                "pathToSignedProductExe",
                "productState",
            ],
        )[1:]

        # Parse to a table similar to prior v2.0.1
        tbl = [
            [
                _("DisplayName"),
                _("instanceGuid"),
                _("pathToSignedProductExe"),
                _("productState"),
                _("DefinitionStatus"),
            ],
        ]
        for av in av_list:
            tbl.append([*av[:3], *get_state(av[3])])

        return table2bbcode(tbl, caption=_("Antivirus protection-") + self.hostname)

    ###################
    # System security #
    ###################

    @decode("utf-8")
    def filter_device_guard(self, extract):
        table = self.parse_default(extract, data.filter_device_guard.db_device_guard)

        for e in table:
            if "EnableVirtualizationBasedSecurity" in e[0] and "1" in e[2]:
                return table2bbcode(
                    table, caption=_("Device guard configuration-") + self.hostname
                )
        return M_("Virtualization Based Security: Disabled")

    @default_filter_extract
    def filter_credential_guard(self):
        return M_("Configuration of Credential Guard")

    @default_filter_extract
    def filter_smartscreen(self):
        return M_("Configuration of SmartScreen")

    @default_filter_extract
    def filter_applocker_conf(self):
        return M_("Configuration of AppLocker")
