# -*- coding: UTF-8 -*-
# Standard libraries
import csv

# Project imports
from engine.bbcode import Markup as M
from engine.core import i18n
from engine.techs.common import attributelist2dict, dict2table

# I18N
_ = i18n.domain("windows")._
M_ = i18n.domain("windows").M_
pgettext = i18n.domain("windows").pgettext


def parse_default_wsus(extract, db):
    # re_param = re.compile("[^()]+\(([\w\.]+)\)")
    parsed_extract = ""
    for line in extract.splitlines():
        if line[0:2] == "- ":
            parsed_extract += line[2::] + "\n"
    data = {}
    for d in [x for x in parsed_extract.split("\n") if x]:
        data[d.split(":")[0]] = d.split(":")[1]
    table = [[M_("Parameter"), M_("Recommended value"), M_("Current value")]]

    for param in data:
        value = db.get(param)
        if value:
            if data[param] == " .":
                if value["default"] in value["expected"]:
                    val = M("[bg=9ACD32]%s %s[/bg]") % (
                        value["default"],
                        _("(default)"),
                    )
                else:
                    val = M("[bg=FF0000]%s %s[/bg]") % (
                        value["default"],
                        _("(default)"),
                    )
            elif "trad" in value:
                for k in value["trad"].keys():
                    if k in data[param]:
                        if k in value["expected"]:
                            val = M("[bg=9ACD32]%s - %s[/bg]") % (k, value["trad"][k])
                        else:
                            val = M("[bg=FF0000]%s - %s[/bg]") % (k, value["trad"][k])
            else:
                if param in [
                    "WUServer",
                    "WUStatusServer",
                    "TargetGroup",
                    "ScheduledInstallTime",
                ]:
                    val = M("[bg=9ACD32]%s[/bg]") % data[param]
                elif param in [
                    "DetectionFrequency",
                    "RebootRelaunchTimeout",
                    "RebootWarningTimeout",
                    "RescheduleWaitTime",
                ]:
                    # split the expected value to remove the unit part
                    if int(data[param]) <= int(value["expected"].split()[0]):
                        val = M("[bg=9ACD32]%s[/bg]") % data[param]
                    else:
                        val = M("[bg=FF0000]%s[/bg]") % data[param]
                elif data[param] in value["expected"]:
                    val = M("[bg=9ACD32]%s[/bg]") % data[param]
                else:
                    val = M("[bg=FF0000]%s[/bg]") % data[param]
            if "required" in value:
                for r in value["required"]:
                    if (
                        " ." in data[r]
                        and not value["required"][r] == db.get(r)["default"]
                    ):
                        val = M("[bg=B2B2B2]N/A (%s %s %s)[/bg]") % (
                            r,
                            _("required with value"),
                            value["required"][r],
                        )
                    elif " ." not in data[r] and value["required"][r] not in data[r]:
                        val = M("[bg=B2B2B2]N/A (%s %s %s)[/bg]") % (
                            r,
                            _("required with value"),
                            value["required"][r],
                        )
            row = [
                "{} [{}]".format(_(value["name"]), param),
                _(value["expected"]),
                val,
            ]
            table.append(row)
    return table


def parse_flash_version(extract):
    """parse flash extract

    Arguments
    ---------
    extract : extracted data from the script

    Returns
    ---------
    table with differents flash version installed
    """
    raw = []
    for row in csv.reader(
        extract.replace("\r\n", ";").replace('";"', '"\r\n"').split("\r\n")
    ):
        if 7 < len(row):
            raw.append(row[7].replace(";", "\n"))  # 7 = VersionInfo

    if 0 < len(row):
        del row[0]

    res = [
        {k: v[k] for k in ("InternalName", "Product", "ProductVersion") if k in v}
        for v in attributelist2dict("\n\n".join(raw))
        if v["InternalName"]
    ]
    return dict2table(res)
