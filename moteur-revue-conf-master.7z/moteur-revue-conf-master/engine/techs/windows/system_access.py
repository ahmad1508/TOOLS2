# -*- coding: UTF-8 -*-
# Standard libraries
import re

# Project imports
from engine.bbcode import Markup as M
from engine.core import i18n
from engine.techs.common import attributelist2dict, decode, separator2table

# I18N
_ = i18n.domain("windows")._
M_ = i18n.domain("windows").M_
pgettext = i18n.domain("windows").pgettext


@decode("utf-8")
def parse_acl_extract(key, extract, version):
    """Parse ACL in one table

    Arguments
    ---------
    key : dictionnary key of the ACL extract (ServiceName,DriverName or
    DirectoryName)

    extract : extract from the extraction script

    Returns
    ---------
        a bbcode with ACL parsed ""
    """
    tmp = M(
        "[table][title]"
        + key.replace("Name", "")
        + "_ACL"
        + "[/title]"
        + "[tr][th]"
        + _("Path")
        + "[/th][th]"
        + ((_("HeritedParent") + "[/th][th]") if key == "DirectoryName" else "")
        + _("IdentityReference")
        + "[/th][th]"
        + _("FileSystemRights")
        + "[/th][th]"
        + _("FileSystemRights")
        + "[/th][th]"
        + _("PropagationFlags")
        + "[/th][/tr]"
    )

    empty_test = 0
    last_path = ""
    inherited = []
    regx = re.compile("(.*)\\\\.*$")

    # parse extract if not void
    if extract != "":
        tables = attributelist2dict(extract)
    else:
        return ""
    # check version
    if version[0] >= 2:
        # normal mode
        key_name = "Path"
    else:
        # legacy mode
        if key == "DirectoryName":
            key_name = "FileName"
        else:
            key_name = key
    for table in tables:
        # directory ACL
        if key == "DirectoryName":
            # Path of the ACL
            if len(table) < 3:
                if empty_test != 0:
                    empty_test = 0
                    # search which path this is herited
                    temp_path = regx.match(last_path).group(1)
                    while temp_path.lower() not in inherited:
                        temp_path = regx.match(temp_path).group(1)
                    tmp += format_directory_acl(
                        data=[],
                        acl_path=table[key_name],
                        herited_parent=temp_path,
                        herit=True,
                    )
                last_path = table[key_name]
                empty_test += 1
            # ACL
            else:
                if version[0] < 2:
                    last_path = table[key_name]
                elif table["PropagationFlags"] != "None" and last_path not in inherited:
                    # store inheritance ACL
                    inherited.append(last_path.lower())
                tmp += format_directory_acl(acl_path=last_path, data=table, herit=False)
                empty_test = 0

        # Driver or service ACL
        else:
            tmp += format_service_driver_acl(table, key_name)

    return tmp + M("[/table]")


def parse_options_security(extract, db):
    """parse options security from extract

    Arguments
    ---------
    extract : security options to parse from extraction script
    db: OS language security option database
    db_tr(optionnal): User choice language security option database

    Returns
    ---------
    table of all security option parsed with description,name,translated
      name(depend if db_tr != None)
    ,recommanded value,actual value and analyze_
    """
    row = M(
        "[table][title]"
        + _("security options table")
        + "[/title][tr][th]"
        + _("GPO")
        + "[/th][th]"
        + _("Default value")
        + "[/th][th]"
        + _("Recommanded value")
        + "[/th][th]"
        + _("Actual value")
        + "[/th][th]"
        + _("Conformity")
        + "[/th][/tr]"
    )

    for line in extract:
        if len(line) == 2:
            name, value = line
            res = re.search(r'"(.*?)"', name).group(1)
            if res:
                value_db = db.get(res).copy()
                # translate default and expected value
                keys_to_translate = ["default_server", "expected"]
                for key in keys_to_translate:
                    if key in value_db.keys():
                        if value_db[key] == ".":
                            value_db[key] = _("Not defined")
                        else:
                            if (
                                "value" in value_db.keys()
                                and value_db[key] in value_db["value"]
                            ):
                                value_db[key] = value_db["value"][value_db[key]]
                # parse and translate value like <number>,<number>...
                if value in (0, "") or len(value.split(",")[0]) == 1:
                    if value in [".", ""]:
                        value = _("Not defined")
                    elif value in ["0", "1"]:
                        value = value_db["value"][value]
                    elif value == '1,""':
                        value = ""
                    else:
                        if len(value.split(",")) > 1:
                            extracted_value = re.search(
                                r'"(.*|<.*/>)"', value.split(",")[1]
                            )
                            if "value" in value_db:
                                if (
                                    value.split(",")[1]
                                    if extracted_value is None
                                    else extracted_value.group(1)
                                ) in value_db["value"]:
                                    value = value_db["value"][
                                        value.split(",")[1]
                                        if extracted_value is None
                                        else extracted_value.group(1)
                                    ]
                                else:
                                    if value.split(",")[1].isdigit():
                                        value = parse_gpo_value_list(
                                            value.split(",")[1],
                                            value_db["value"],
                                        )
                                    else:
                                        # case if an value field is
                                        # finded but value doesn't
                                        # match any in this case please
                                        # check if the json database is
                                        # up to date and workstation
                                        # Security Options
                                        value = (
                                            value.split(",")[1]
                                            + "\nCaution: Value not find"
                                            " in engine knowledge"
                                            " database"
                                        )
                            else:
                                value = (
                                    value.split(",")[1]
                                    if extracted_value is None
                                    else extracted_value.group(1)
                                )

                row += format_gpo_key(value_db, value)
    return row + M("[/table]")


def parse_gpo_value_list(value, gpo_trad):
    """parse registry key decimal value to a list of decimal
    of value which correspond to a GPO values

    Arguments
    ---------
    value : decimal values to parse
    gpo_trad: list of decimal value which correspond to option

    Returns
    ---------
    list of options (string)
    """
    return_string = ""
    # converse value string to int
    value = int(value)
    # get gpo keys defined greater to the smaller in json database file
    keylist = list(map(int, list(gpo_trad.keys())))
    keylist.sort(reverse=True)
    # check if value equal to 0
    if value == 0:
        if "0" in gpo_trad:
            return gpo_trad["0"]
    # parse value with trad value list
    while value != 0:
        for key in keylist:
            if value >= key:
                value = value - key
                return_string += gpo_trad[str(key)] + "\n"
                break
    # if nothing match
    if return_string == "":
        return_string = M_("Not Defined")

    return return_string


def parse_default_gpo(extract, db):
    """parse extracted GPO and compare them with our referential
    to build a conformity table
    Arguments
    ---------
    extract : GPO extracted
    db: database which contains our referentiel
    for user rights assignements

    Returns
    ---------
        conformity table of all GPO
    """
    re_param = re.compile(r"[^()]+\(([\w\.]+)\)")

    row = M(
        "[table][title]"
        + _("user rigths assignements table")
        + "[/title][tr][th]"
        + _("GPO")
        + "[/th][th]"
        + _("Default value")
        + "[/th][th]"
        + _("Recommanded value")
        + "[/th][th]"
        + _("Actual value")
        + "[/th][th]"
        + _("Conformity")
        + "[/th][/tr]"
    )

    data = separator2table(extract, ":", "\r\n")

    for line in data:
        if len(line) == 2:
            match = re_param.match(line[0])
            if match:
                param = match.group(1)
                value = db.get(param)
                if value:
                    if line[1] == " .":
                        val = _("Not defined")
                    else:
                        val = (line[1].replace(",", ",\n")).strip()
                    row += format_gpo_key(value, val)

    return row + M("[/table]")


def format_task(entry):
    template = M(
        """
        [tr]
        [td]{name:}[/td]
        [td]{status:}[/td]
        [td]{lastrun:}[/td]
        [td]{nextrun:}[/td]
        [td]{author:}[/td]
        [td]{task:}[/td]
        [td]{argument:}[/td]
        [td]{user_perform:}[/td]
        [/tr]
        """
    )

    return template.format(
        name=entry.get("Name"),
        status=entry.get("Status"),
        lastrun=entry.get("LastRunTime") if entry.get("LastRunTime") else "N/A",
        nextrun=entry.get("NextRunTime") if entry.get("NextRunTime") else "N/A",
        author=entry.get("Author") if entry.get("Author") else "N/A",
        task=entry.get("Actions"),
        argument=entry.get("Argument") if entry.get("Argument") else "N/A",
        user_perform=entry.get("RunAs") if entry.get("RunAs") else "N/A",
    )


def conformity_cell(expected, current):
    """
    determine the conformity between expected and current


    Arguments
    ---------
    expected : reference value
    current: value to test

    Returns
    ---------
        OK : expected == current
        NOK : expected != current
        NA :  other
    """
    filter = ["not defined", "enabled", "disabled"]

    # if strings match, then OK
    if expected == current:
        return M("[bg=9ACD32]OK[/bg]")

    # restrict check on word filter in order to reduce false positive
    if (
        (expected.lower() in filter)
        and (current.lower() in filter)
        and expected != current
    ):
        return M("[bg=FF0000]NOK[/bg]")

    # by default
    return M("[bg=B2B2B2]TODO[/bg]")


def format_gpo_key(entry, val):
    template = M(
        """
    [tr][td]{name_output:}[/td]
    [td]{default:}[/td]
    [td]{expected:}\n\n{expected_reco:}[/td]
    [td]{current:}[/td]
    [td]{conformity:}[/td][/tr]
    """
    )
    return template.format(
        name_output=_(entry.get("name")),
        default=_(entry.get("default_server")),
        expected=_(entry.get("expected")) if entry.get("expected") != "" else "",
        expected_reco=_(entry.get("expected_reco"))
        if entry.get("expected_reco") != ""
        else "",
        current=_(val) if val != "" else "",
        conformity=conformity_cell(entry.get("expected"), val),
    )


def format_directory_acl(data, acl_path="", herited_parent="", herit=False):
    template = M(
        """
        [tr]
        [td]{path:}[/td]
        [td]{herited:}[/td]
        [td]{IdentityReference:}[/td]
        [td]{FileSystemRights:}[/td]
        [td]{InheritanceFlags:}[/td]
        [td]{PropagationFlags:}[/td]
        [/tr]
        """
    )
    # directory acl is herited
    if herit:
        return template.format(
            path=acl_path,
            herited=herited_parent,
            IdentityReference="",
            FileSystemRights="",
            InheritanceFlags="",
            PropagationFlags="",
        )
    return template.format(
        path=acl_path,
        herited="No",
        IdentityReference=data["IdentityReference"],
        FileSystemRights=data["FileSystemRights"],
        InheritanceFlags=data["InheritanceFlags"],
        PropagationFlags=data["PropagationFlags"],
    )


def format_service_driver_acl(data, key_path):
    template = M(
        """
        [tr]
        [td]{path:}[/td]
        [td]{IdentityReference:}[/td]
        [td]{FileSystemRights:}[/td]
        [td]{InheritanceFlags:}[/td]
        [td]{PropagationFlags:}[/td]
        [/tr]
        """
    )

    return template.format(
        path=data[key_path],
        IdentityReference=data["IdentityReference"],
        FileSystemRights=data["FileSystemRights"],
        InheritanceFlags=data["InheritanceFlags"],
        PropagationFlags=data["PropagationFlags"],
    )
