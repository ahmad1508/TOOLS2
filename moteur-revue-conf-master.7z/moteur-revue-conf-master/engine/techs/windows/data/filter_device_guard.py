# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_device_guard = {
    "EnableVirtualizationBasedSecurity": {
        "name": N_("Use to enable virtualization-based security"),
        "expected": "1",
        "default": ".",
        "value": {
            "0": N_("Disabled"),
            "1": N_("Enabled"),
            ".": N_("Not defined"),
        },
    },
    "RequirePlatformSecurityFeatures": {
        "name": N_("Specifies the platform security level at the next reboot"),
        "expected": "3",
        "default": "1",
        "value": {
            "1": N_("Turns on VBS with Secure Boot"),
            "3": N_("Turns on VBS with Secure Boot and direct memory access (DMA)"),
            ".": N_("Not defined"),
        },
    },
    "HypervisorEnforcedCodeIntegrity": {
        "name": N_(
            "Specifies the code integrity that will be enforced for the" " hypervisor"
        ),
        "expected": "1",
        "default": "0",
        "value": {
            "0": N_("Disabled"),
            "1": N_("Enabled"),
            ".": N_("Not defined"),
        },
    },
    "DeployConfigCIPolicy": {
        "name": N_("Deploy a Code Integrity Policy"),
        "expected": "1",
        "default": "0",
        "value": {
            "0": N_("Disabled"),
            "1": N_("Enabled"),
            ".": N_("Not defined"),
        },
    },
    "ConfigCIPolicyFilePath": {
        "name": N_("Code Integrity Policy file path"),
        "expected": N_("<path>"),
        "default": N_("Not defined"),
    },
}
