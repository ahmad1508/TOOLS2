# -*- coding: UTF-8 -*-
# Project imports

# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_audit_policy = {
    "status": {
        "0": N_("No Auditing"),
        "1": N_("Success"),
        "2": N_("Failure"),
        "3": N_("Success and Failure"),
    },
    "policy": {
        "section_account_logon": {"section_name": N_("Account Logon")},
        "{0CCE923F-69AE-11D9-BED3-505054503030}": {
            "name": N_("Credential Validation"),
            "expected": "3",
        },
        "{0CCE9242-69AE-11D9-BED3-505054503030}": {
            "name": N_("Kerberos Authentication Service"),
            "expected": "3",
        },
        "{0CCE9240-69AE-11D9-BED3-505054503030}": {
            "name": N_("Kerberos Service Ticket Operations"),
            "expected": "3",
        },
        "{0CCE9241-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Account Logon Events"),
            "expected": "3",
        },
        "section_acct_mgmt": {"section_name": N_("Account Management")},
        "{0CCE9239-69AE-11D9-BED3-505054503030}": {
            "name": N_("Application Group Management"),
            "expected": "0",
        },
        "{0CCE9236-69AE-11D9-BED3-505054503030}": {
            "name": N_("Computer Account Management"),
            "expected": "3",
        },
        "{0CCE9238-69AE-11D9-BED3-505054503030}": {
            "name": N_("Distribution Group Management"),
            "expected": "0",
        },
        "{0CCE923A-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Account Management Events"),
            "expected": "3",
        },
        "{0CCE9237-69AE-11D9-BED3-505054503030}": {
            "name": N_("Security Group Management"),
            "expected": "3",
        },
        "{0CCE9235-69AE-11D9-BED3-505054503030}": {
            "name": N_("User Account Management"),
            "expected": "3",
        },
        "section_tracking": {"section_name": N_("Detailed Tracking")},
        "{0CCE922D-69AE-11D9-BED3-505054503030}": {
            "name": N_("DPAPI Activity"),
            "expected": "3",
        },
        "{0CCE9248-69AE-11D9-BED3-505054503030}": {
            "name": N_("Plug and Play Events"),
            "expected": "1",
        },
        "{0CCE922B-69AE-11D9-BED3-505054503030}": {
            "name": N_("Process Creation"),
            "expected": "3",
        },
        "{0CCE922C-69AE-11D9-BED3-505054503030}": {
            "name": N_("Process Termination"),
            "expected": "0",
        },
        "{0CCE922E-69AE-11D9-BED3-505054503030}": {
            "name": N_("RPC Events"),
            "expected": "0",
        },
        "{0CCE924A-69AE-11D9-BED3-505054503030}": {
            "name": N_("Token Right Adjusted Events"),
            "expected": "0",
        },
        "section_ds_access": {"section_name": N_("DS Access")},
        "{0CCE923E-69AE-11D9-BED3-505054503030}": {
            "name": N_("Detailed Directory Service Replication"),
            "expected": "3",
        },
        "{0CCE923B-69AE-11D9-BED3-505054503030}": {
            "name": N_("Directory Service Access"),
            "expected": "3",
        },
        "{0CCE923C-69AE-11D9-BED3-505054503030}": {
            "name": N_("Directory Service Changes"),
            "expected": "3",
        },
        "{0CCE923D-69AE-11D9-BED3-505054503030}": {
            "name": N_("Directory Service Replication"),
            "expected": "3",
        },
        "section_logon_logoff": {"section_name": N_("Logon/Logoff")},
        "{0CCE9217-69AE-11D9-BED3-505054503030}": {
            "name": N_("Account Lockout"),
            "expected": "3",
        },
        "{0CCE9247-69AE-11D9-BED3-505054503030}": {
            "name": N_("User / Device Claims"),
            "expected": "0",
        },
        "{0CCE921A-69AE-11D9-BED3-505054503030}": {
            "name": N_("IPsec Extended Mode"),
            "expected": "0",
        },
        "{0CCE9249-69AE-11D9-BED3-505054503030}": {
            "name": N_("Group Membership"),
            "expected": "0",
        },
        "{0CCE9218-69AE-11D9-BED3-505054503030}": {
            "name": N_("IPsec Main Mode"),
            "expected": "0",
        },
        "{0CCE9219-69AE-11D9-BED3-505054503030}": {
            "name": N_("IPsec Quick Mode"),
            "expected": "0",
        },
        "{0CCE9216-69AE-11D9-BED3-505054503030}": {
            "name": N_("Logoff"),
            "expected": "1",
        },
        "{0CCE9215-69AE-11D9-BED3-505054503030}": {
            "name": N_("Logon"),
            "expected": "3",
        },
        "{0CCE9243-69AE-11D9-BED3-505054503030}": {
            "name": N_("Network Policy Server"),
            "expected": "3",
        },
        "{0CCE921C-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Logon/Logoff Events"),
            "expected": "3",
        },
        "{0CCE921B-69AE-11D9-BED3-505054503030}": {
            "name": N_("Special Logon"),
            "expected": "1",
        },
        "section_obj_acess": {"section_name": N_("Object Access")},
        "{0CCE9222-69AE-11D9-BED3-505054503030}": {
            "name": N_("Application Generated"),
            "expected": "0",
        },
        "{0CCE9221-69AE-11D9-BED3-505054503030}": {
            "name": N_("Certification Services"),
            "expected": "3",
        },
        "{0CCE9244-69AE-11D9-BED3-505054503030}": {
            "name": N_("Detailed File Share"),
            "expected": "1",
        },
        "{0CCE9224-69AE-11D9-BED3-505054503030}": {
            "name": N_("File Share"),
            "expected": "3",
        },
        "{0CCE921D-69AE-11D9-BED3-505054503030}": {
            "name": N_("File System"),
            "expected": "2",
        },
        "{0CCE9226-69AE-11D9-BED3-505054503030}": {
            "name": N_("Filtering Platform Connection"),
            "expected": "2",
        },
        "{0CCE9225-69AE-11D9-BED3-505054503030}": {
            "name": N_("Filtering Platform Packet Drop"),
            "expected": "0",
        },
        "{0CCE9223-69AE-11D9-BED3-505054503030}": {
            "name": N_("Handle Manipulation"),
            "expected": "0",
        },
        "{0CCE921F-69AE-11D9-BED3-505054503030}": {
            "name": N_("Kernel Object"),
            "expected": "0",
        },
        "{0CCE9227-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Object Access Events"),
            "expected": "3",
        },
        "{0CCE921E-69AE-11D9-BED3-505054503030}": {
            "name": N_("Registry"),
            "expected": "0",
        },
        "{0CCE9245-69AE-11D9-BED3-505054503030}": {
            "name": N_("Removable Storage"),
            "expected": "3",
        },
        "{0CCE9220-69AE-11D9-BED3-505054503030}": {
            "name": N_("SAM"),
            "expected": "0",
        },
        "{0CCE9246-69AE-11D9-BED3-505054503030}": {
            "name": N_("Central Policy Staging"),
            "expected": "0",
        },
        "section_policy_change": {"section_name": N_("Policy Change")},
        "{0CCE922F-69AE-11D9-BED3-505054503030}": {
            "name": N_("Audit Policy Change"),
            "expected": "3",
        },
        "{0CCE9230-69AE-11D9-BED3-505054503030}": {
            "name": N_("Authentication Policy Change"),
            "expected": "3",
        },
        "{0CCE9231-69AE-11D9-BED3-505054503030}": {
            "name": N_("Authorization Policy Change"),
            "expected": "3",
        },
        "{0CCE9233-69AE-11D9-BED3-505054503030}": {
            "name": N_("Filtering Platform Policy Change"),
            "expected": "3",
        },
        "{0CCE9232-69AE-11D9-BED3-505054503030}": {
            "name": N_("MPSSVC Rule-Level Policy Change"),
            "expected": "2",
        },
        "{0CCE9234-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Policy Change Events"),
            "expected": "0",
        },
        "section_priv_use": {"section_name": N_("Privilege Use")},
        "{0CCE9229-69AE-11D9-BED3-505054503030}": {
            "name": N_("Non Sensitive Privilege Use"),
            "expected": "0",
        },
        "{0CCE9228-69AE-11D9-BED3-505054503030}": {
            "name": N_("Sensitive Privilege Use"),
            "expected": "0",
        },
        "{0CCE922A-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other Privilege Use Events"),
            "expected": "3",
        },
        "section_system": {"section_name": N_("System")},
        "{0CCE9213-69AE-11D9-BED3-505054503030}": {
            "name": N_("IPsec Driver"),
            "expected": "3",
        },
        "{0CCE9214-69AE-11D9-BED3-505054503030}": {
            "name": N_("Other System Events"),
            "expected": "3",
        },
        "{0CCE9210-69AE-11D9-BED3-505054503030}": {
            "name": N_("Security State Change"),
            "expected": "1",
        },
        "{0CCE9211-69AE-11D9-BED3-505054503030}": {
            "name": N_("Security System Extension"),
            "expected": "3",
        },
        "{0CCE9212-69AE-11D9-BED3-505054503030}": {
            "name": N_("System Integrity"),
            "expected": "3",
        },
    },
}
