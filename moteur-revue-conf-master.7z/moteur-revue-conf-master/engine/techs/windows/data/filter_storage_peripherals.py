# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_storage_peripherals = {
    "Deny_All": {
        "name": N_("Deny access to all removable storage classes "),
        "expected": "0",
        "default": "0",
    }
}
