# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_autorun_policy = {
    "NoDriveTypeAutorun": {
        "name": N_("Turn off AutoPlay"),
        "expected": "255",
        "default": "149",
    },
    "NoAutorun": {
        "name": N_("Set the default behavior for AutoRun"),
        "expected": "1",
        "default": "1",
    },
}
