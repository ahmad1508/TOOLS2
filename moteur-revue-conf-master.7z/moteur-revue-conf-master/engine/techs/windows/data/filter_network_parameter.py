# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_network_parameter = {
    "DisableIPSourceRouting": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\DisableIPSourceRouting"
        ),
        "desc": N_(
            "Setting this parameter to 2 disables source routing functionality"
            " for IP packets. This feature generally has no legitimate use and"
            " can be used to intercept data:"
        ),
        "type": "REG_DWORD",
        "expected": "2",
        "default": "1",
    },
    "EnableDeadGWDetect": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\EnableDeadGWDetect"
        ),
        "desc": N_(
            "When this value is set to 1, TCP is allowed to perform inactive"
            " gateway detection. This can lead to a change of default gateway,"
            " which, if exploited by an attacker, could lead to data"
            " interception or a denial of service attack. Setting this value"
            " to 0 is therefore recommended:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "EnableICMPRedirect": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\EnableICMPRedirect"
        ),
        "desc": N_(
            "If this feature is enabled, Windows will modify its routing table"
            " in response to an ICMP redirect message sent by a router, for"
            " example. An attacker can exploit these messages to intercept"
            " data or cause a denial of service:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "EnablePMTUDiscovery": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\EnablePMTUDiscovery"
        ),
        "desc": N_(
            "When this parameter is set to 1, the TCP stack tries to discover"
            " the MTU (maximum packet size). This can be exploited by an"
            " attacker through denial of service attacks. When set to 0, this"
            " feature is disabled and the MTU is set to 576 bytes for all"
            " connections to hosts that are not on the local network:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "KeepAliveTime": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\KeepAliveTime"
        ),
        "desc": N_(
            "This parameter controls how often TCP checks that a connection is"
            ' still intact by sending "keep-alive" packets. This function is'
            " not activated by default. The observed value is in milliseconds:"
        ),
        "type": "REG_DWORD",
        "expected": "300000",
        "default": "7200000",
    },
    "PerformRouterDiscovery": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\PerformRouterDiscovery"
        ),
        "desc": N_(
            "This parameter indicates whether the system attempts to discover"
            " routers according to RFC 1256. It is advisable to disable this"
            " function by choosing the value 0:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "SynAttackProtect": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\SynAttackProtect"
        ),
        "desc": N_(
            "This function activates the protection against attacks of type"
            ' "SynFlood". This requires for maximum efficiency to also set the'
            ' key values for "TCPMaxHalfOpen" and "TcpMaxHalfOpenRetried".'
            " This value must be set to 2 in order to provide a maximum"
            " protection:"
        ),
        "type": "REG_DWORD",
        "expected": "2",
        "default": "0",
    },
    "TcpMaxHalfOpen": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\TcpMaxHalfOpen"
        ),
        "desc": N_(
            "This parameter specifies the number of connections allowed in the"
            " SYN-RCVD state before the proctection starts. The recommended"
            " value is 100:"
        ),
        "type": "REG_DWORD",
        "expected": "100",
        "default": "100 (Server) ou 500 (Workstation)",
    },
    "TcpMaxHalfOpenRetried": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters"
            "\\TcpMaxHalfOpenRetried"
        ),
        "desc": N_(
            "This parameter specifies the number of connections allowed in the"
            " SYN-RCVD state for which at least one SYN retransmission has"
            " occurred. The recommended value for this parameter is 80:"
        ),
        "type": "REG_DWORD",
        "expected": "80",
        "default": "80 (Server) ou 400 (Workstation)",
    },
    "NoDefaultExempt": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\PolicyAgent" "\\NoDefaultExempt"
        ),
        "desc": N_(
            "Windows has default exceptions to the IPSec filtering policies,"
            " such as for Kerberos, RSVP protocol or multicast. If using"
            " IPSec, it is recommended to use this key to ensure that all"
            " traffic is filtered:"
        ),
        "type": "REG_DWORD",
        "expected": "3",
        "default": "3",
    },
    "DNSClient": {
        "name": "HKLM\\Software\\Policies\\Microsoft\\Windows NT\\DNSClient",
        "desc": N_(
            "This parameter allows to disable the resolution of broadcast"
            " names, which can be used in LLMNR poisoning attacks:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "AutoShareServer": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\LanManServer"
            "\\Parameters\\AutoShareServer"
        ),
        "desc": N_(
            "The following settings affect the operation of the system's"
            " server layer and related services. Applying these registry keys"
            " will provide additional security. \\nIf the file sharing service"
            " is used, Windows automatically shares all local fixed drives as"
            " hidden administrative shares. These shares can be disabled as"
            " well as the file sharing service with the following registry"
            " keys:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "0",
    },
    "AutoShareWks": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\LanManServer"
            "\\Parameters\\AutoShareWks"
        ),
        "desc": N_(" "),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "1",
    },
    "RefuseReset": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\MrxSmb\\Parameters"
            "\\RefuseReset"
        ),
        "desc": N_(
            "When this parameter is set to 1, it allows the system to ignore"
            ' the "ResetBrowser" frames that allow to trigger an election.'
            " This parameter is evaluated only if the browser service is"
            " running:"
        ),
        "type": "REG_DWORD",
        "expected": "1",
        "default": "0",
    },
    "Hidden": {
        "name": (
            "HKLM\\System\\CurrentControlSet\\Services\\Lanmanserver"
            "\\Parameters\\Hidden"
        ),
        "desc": N_(
            "Setting this parameter to 1 prevents the Server service from"
            " sending advertisements for operation, thus hiding the machine"
            " from the network browser:"
        ),
        "type": "REG_DWORD",
        "expected": "1",
        "default": "0",
    },
    "AutoAdminLogon": {
        "name": (
            "HKLM\\Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Winlogon\\AutoAdminLogon"
        ),
        "desc": N_(
            "Setting this parameter to 0 will completely disable the automatic"
            " login feature for the local administrator account:"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "0",
    },
    "ScreenSaverGracePeriod": {
        "name": (
            "HKLM\\Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Winlogon\\ScreenSaverGracePeriod"
        ),
        "desc": N_(
            "Setting this parameter to 0 disables the Windows screensaver"
            ' "grace period" (the period before which the screensaver can be'
            " disabled without entering its password) :"
        ),
        "type": "REG_DWORD",
        "expected": "0",
        "default": "5",
    },
    "DisabledComponents": {
        "name": (
            "HKLM\\System\\CurrentcontrolSet\\Services\\TCPIP6\\Parameters"
            "\\DisabledComponents"
        ),
        "desc": N_(
            "This parameter allows you to disable the IPv6 protocol on the" " machine :"
        ),
        "type": "REG_DWORD",
        "expected": "0xFFFFFFFF",
        "default": "0x0",
    },
}
