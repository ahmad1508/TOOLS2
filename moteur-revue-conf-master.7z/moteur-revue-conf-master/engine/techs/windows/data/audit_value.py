# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_audit_value = {
    "0": N_("No Auditing"),
    "1": N_("Success"),
    "2": N_("Failure"),
    "3": N_("Success and Failure"),
    ".": N_("Not Defined"),
}
