# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_local_account_auto_lockout_policy = {
    "ScreenSaveActive": {
        "name": N_("Screensaver must be enabled"),
        "expected": "1",
        "default": "1",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "ScreenSaverIsSecure": {
        "name": N_("Password protect the screen saver"),
        "expected": "1",
        "default": ".",
        "value": {
            "0": N_("Screen savers are not password protected"),
            "1": N_("All screen savers are password protected"),
            ".": N_("Not defined: users can turn password protection on and off"),
        },
    },
    "ScreenSaveTimeOut": {
        "name": N_("Screen saver time out"),
        "expected": "300",
        "default": N_("Not defined: no automatic timeout"),
    },
    "SCRNSAVE.EXE": {
        "name": N_("Load a specific theme"),
        "expected": N_("<specific theme>"),
        "default": N_("Not defined"),
    },
}
