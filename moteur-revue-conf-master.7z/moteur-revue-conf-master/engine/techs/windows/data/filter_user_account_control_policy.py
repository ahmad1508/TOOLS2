# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_user_account_control_policy = {
    "FilterAdministratorToken": {
        "name": N_("Admin Approval Mode for the built-in Administrator account"),
        "expected": "1",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "EnableUIADesktopToggle": {
        "name": N_(
            "Allow UIAccess applications to prompt for elevation without using"
            " the secure desktop"
        ),
        "expected": "0",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "ConsentPromptBehaviorAdmin": {
        "name": N_(
            "Behavior of the elevation prompt for administrators in Admin"
            " Approval Mode"
        ),
        "expected": "2",
        "default": "5",
        "value": {
            "0": N_("Elevate without prompting"),
            "1": N_("Prompt for credentials on the secure desktop"),
            "2": N_("Prompt for consent on the secure desktop"),
            "3": N_("Prompt for credentials"),
            "4": N_("Prompt for consent"),
            "5": N_("Prompt for consent for non-Windows binaries"),
        },
    },
    "ConsentPromptBehaviorUser": {
        "name": N_("Behavior of the elevation prompt for standard users"),
        "expected": "3",
        "default": "1",
        "value": {
            "0": N_("Automatically deny elevation requests"),
            "1": N_("Prompt for credentials"),
            "3": N_("Prompt for credentials on the secure desktop"),
        },
    },
    "EnableInstallerDetection": {
        "name": N_("Detect application installations and prompt for elevation"),
        "expected": "1",
        "default": N_("0 (for enterprise versions)\n1 (for other versions)"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "ValidateAdminCodeSignatures": {
        "name": N_("Only elevate executables that are signed and validated"),
        "expected": "0",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "EnableSecureUIAPaths": {
        "name": N_(
            "Only elevate UIAccess applications that are installed in secure"
            " locations"
        ),
        "expected": "1",
        "default": "1",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "EnableLUA": {
        "name": N_("Run all administrators in Admin Approval Mode"),
        "expected": "1",
        "default": "1",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "PromptOnSecureDesktop": {
        "name": N_("Switch to the secure desktop when prompting for elevation"),
        "expected": "1",
        "default": "1",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "EnableVirtualization": {
        "name": N_("Virtualize file and registry write failures to per-user locations"),
        "expected": "1",
        "default": "1",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
}
