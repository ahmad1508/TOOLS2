# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_local_account_lockout_policy = {
    "LockoutDuration": {
        "name": N_("A lockout duration must be configured"),
        "expected": N_(
            "0 if the account will be unblock by an administrator,else 60" " minutes"
        ),
    },
    "ResetLockoutCount": {
        "name": N_("A reset lockout count must be configured"),
        "expected": N_("60 minutes"),
    },
    "LockoutBadCount": {
        "name": N_("A lockout bad count must be configured"),
        "expected": N_("3 try"),
    },
}
