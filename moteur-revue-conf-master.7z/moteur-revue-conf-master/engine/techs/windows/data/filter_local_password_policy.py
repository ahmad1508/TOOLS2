# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_local_password_policy = {
    "PasswordHistorySize": {
        "name": N_("A password history must be enabled"),
        "expected": "5",
    },
    "MaximumPasswordAge": {
        "name": N_("A maximum password age must be configured"),
        "expected": "90",
    },
    "MinimumPasswordAge": {
        "name": N_("A minimum password age must be configured"),
        "expected": "1" + N_("or") + " 2",
    },
    "PasswordComplexity": {
        "name": N_("Password complexity must be enabled"),
        "expected": "1",
    },
    "MinimumPasswordLength": {
        "name": N_("A minimum password length must be configured"),
        "expected": "8",
    },
}
