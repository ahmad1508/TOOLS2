# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_user_right = {
    "SeNetworkLogonRight": {
        "name": N_("Access this computer from the network"),
        "desc": N_(
            "The Access this computer from the network policy setting"
            " determines which users can connect to the computer from the"
            " network. This capability is required by a number of network"
            " protocols, including Server Message Block (SMB)-based protocols,"
            " NetBIOS, Common Internet File System (CIFS), and Component"
            " Object Model Plus (COM+):",
        ),
        "default_dc": N_(
            "Everyone,\nAdministrators,\nAuthenticated Users,\nEnterprise"
            " Domain Controllers,\nPre-Windows 2000 Compatible Access",
        ),
        "default_server": N_(
            "Everyone,\nAdministrators,\nAuthenticated Users,\nEnterprise"
            " Domain Controllers,\nPre-Windows 2000 Compatible Access",
        ),
        "default_workgroup": N_(
            "Everyone,\nAdministrators,\nAuthenticated Users,\nBackup" " Operators",
        ),
        "expected": N_("Authenticated Users,\nAdministrators"),
        "analyze": N_(
            "Ensuring that only legitimate users can access the machine, such"
            " as the Everyone group, is not a good practice.",
        ),
        "expected_reco": N_("If physical access is not privileged"),
    },
    "SeDenyNetworkLogonRight": {
        "name": N_("Deny access to this computer from the network"),
        "desc": N_(
            "In contrast, the users and groups defined in this setting cannot"
            " connect to the server from the network. This parameter has"
            " priority over the previous one: ",
        ),
        "default_dc": N_("Guest"),
        "default_server": N_("Guest"),
        "default_workgroup": N_("Guest"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Assign the Deny access to this computer from the network user"
            " right to the following accounts : \nAnonymous logon, Built-in"
            " local Administrator account, Local Guest account, All service"
            " accounts",
        ),
        "expected_reco": N_(
            "If physical access to the machines is privileged",
        ),
    },
    "SeRemoteInteractiveLogonRight": {
        "name": N_("Allow log on through Remote Desktop Services"),
        "desc": N_(
            "Users and groups defined in this setting can access the server"
            " login screen using the Remote Desktop services. However, logon"
            " may subsequently be blocked.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators,\nRemote Desktop Users"),
        "default_workgroup": N_("Administrators,\nRemote Desktop Users"),
        "expected": N_(" "),
        "analyze": N_(
            "For DC : assign the Allow log on through Remote Desktop Services"
            " suer right only the Administrators group.\nFor other server"
            " roles and end-user computers add the Remote Desktop Users"
            " group.",
        ),
        "expected_reco": N_("Only specifically authorized users"),
    },
    "SeDenyRemoteInteractiveLogonRight": {
        "name": N_("Deny log on through Remote Desktop Services"),
        "desc": N_(
            "In contrast, the following setting defines which users and groups"
            " cannot access the server's authentication test pattern using"
            " Remote Desktop services. This parameter takes precedence over"
            " the previous one:",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_(" "),
        "analyze": N_(
            "Assign the Deny log on through Remote Desktop Services user right"
            " to the built-in local guest account and all service accounts. If"
            " you have installed optional components, such as ASP.NET, you may"
            " want to assign this user right to additional accounts that are"
            " required by those components.",
        ),
        "expected_reco": N_("Allows you to prevent the use of the service"),
    },
    "SeInteractiveLogonRight": {
        "name": N_("Allow log on locally"),
        "desc": N_(
            "This setting specifies which users can start an interactive"
            " session on the server. This privilege is especially necessary"
            " for opening a session following a connection through the Remote"
            " Desktop service.",
        ),
        "default_dc": N_(
            "Account Operators,\nAdministrators,\nBackup Operators\nPrint"
            " Operators\nServer Operators",
        ),
        "default_server": N_("Administrators,\nBackup Operators,\nUsers"),
        "default_workgroup": N_("Administrators,\nBackup Operators,\nUsers"),
        "expected": N_("Authenticated Users"),
        "analyze": N_(
            "Restrict this user right to legitimate users who must log on to"
            " the console of the computer.\nIf you selectively remove default"
            " groups, you can limit the abilities of users who are assigned to"
            " specific administrative roles in your organization.",
        ),
        "expected_reco": N_(" "),
    },
    "SeDenyInteractiveLogonRight": {
        "name": N_("Deny log on locally"),
        "desc": N_(
            "In contrast, this parameter determines which users are not"
            " allowed to start an interactive session on the server. It has"
            " priority over the previous one.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Assign the Deny log on locally user right to the local Guest"
            " account. If you have installed optional components such as"
            " ASP.NET, you may want to assign this user right to additional"
            " accounts that are required by those components.",
        ),
        "expected_reco": N_(" "),
    },
    "SeServiceLogonRight": {
        "name": N_("Log on as a service"),
        "desc": N_(
            "This strategy parameter determines which service accounts can"
            " register a process as a service. Executing a process under a"
            " service account avoids the need for human intervention.",
        ),
        "default_dc": N_("Network Service"),
        "default_server": N_("Network Service"),
        "default_workgroup": N_("Network Service"),
        "expected": N_("Duplicators,\nNetwork Service,\nService Accounts"),
        "analyze": N_(
            "The network service account includes the user right to log in as"
            " a service. This right is not granted through the group policy"
            " setting. It is advisable to reduce the number of accounts with"
            " this user's rights.",
        ),
        "expected_reco": N_(
            "The service accounts group will have to be created",
        ),
    },
    "SeDenyServiceLogonRight": {
        "name": N_("Deny log on as a service"),
        "desc": N_("Not defined"),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "We recommend that you not assign the Deny log on as a service"
            " user right to any accounts. This is the default configuration."
            " Organizations that are extremely concerned about security might"
            " assign this user right to groups and accounts when they are"
            " certain that they will never need to log on to a service"
            " application.",
        ),
        "expected_reco": N_(" "),
    },
    "SeBatchLogonRight": {
        "name": N_("Log on as a batch job"),
        "desc": N_(
            "This security setting exists only to ensure compatibility with"
            " earlier versions of Windows.",
        ),
        "default_dc": N_(
            "Administrators,\nBackup Operators,\nPerformance Log Users",
        ),
        "default_server": N_(
            "Administrators,\nBackup Operators,\nPerformance Log Users",
        ),
        "default_workgroup": N_("Administrators"),
        "expected": N_(" "),
        "analyze": N_(
            "Use the discretionary feature when assigning this right to"
            " specific users for security reasons. The default settings are"
            " sufficient in most cases.",
        ),
        "expected_reco": N_(
            "No users should be listed. This security setting exists only to"
            " ensure compatibility with earlier versions of Windows",
        ),
    },
    "SeDenyBatchLogonRight": {
        "name": N_("Deny log on as a batch job"),
        "desc": N_(
            "This policy setting determines which accounts are prevented from"
            " logging on by using a batch-queue tool to schedule and start"
            " jobs automatically in the future.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Assign the Deny log on as a batch job user right to the local"
            " Guest account.",
        ),
        "expected_reco": N_(" "),
    },
    "SeImpersonatePrivilege": {
        "name": N_("Impersonate a client after authentication"),
        "desc": N_(
            "This setting is used to stop an unauthorized user from convincing"
            " a client to log on to a service he or she has created, and then"
            " borrowing the identity of that client, which would allow that"
            " user's permissions to be raised to an administrative or system"
            " level.",
        ),
        "default_dc": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "default_server": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "default_workgroup": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "expected": N_("Administrators,\nService"),
        "analyze": N_(
            "Ensure that only the Administrators and Service groups (Local"
            " Service, Network Service, and Service) have the Impersonate a"
            " client after authentication user right assigned to them.",
        ),
        "expected_reco": N_(
            "It prevents an unauthorized user from convincing a client to log"
            " on to a service he or she has created and then borrowing that"
            " client's identity",
        ),
    },
    "SeTcbPrivilege": {
        "name": N_("Act as part of the operating system"),
        "desc": N_(
            "This parameter makes it possible to act with the same rights as"
            " the operating system. Rather use the SYSTEM or LocalSystem user"
            " for processes that require this privilege.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Do not assign this right to any user accounts. Only assign this"
            " user right to trusted users.\nIf a service requires this user"
            " right, configure the service to log on by using the local System"
            " account, which inherently includes this user right. Do not"
            " create a separate account and assign this user right to it.",
        ),
        "expected_reco": N_(
            "Only low-level authentication services should require this"
            " privilege as it allows to perform with the same rights as the"
            " operating system. Rather use the SYSTEM or LocalSystem user for"
            " processes that require this privilege",
        ),
    },
    "SeRemoteShutdownPrivilege": {
        "name": N_("Force shutdown from a remote system"),
        "desc": N_(
            "This security setting determines which users can stop a device"
            " from a remote location on the network. This allows members of"
            " the administrator group or specific users to manage computers"
            " (for tasks such as rebooting) from a remote location.",
        ),
        "default_dc": N_("Administrators,\nServer Operators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Restrict the Force shutdown from a remote system user right to"
            " members of the Administrators group or other specifically"
            " assigned roles that require this capability, such as"
            " nonadministrative operations staff.",
        ),
        "expected_reco": N_("No user should be listed"),
    },
    "SeShutdownPrivilege": {
        "name": N_("Shut down the system"),
        "desc": N_(
            "This security setting determines whether a user locally logged on"
            " to a device can shut down Windows.",
        ),
        "default_dc": N_(
            "Administrators,\nBackup Operators,\nServer Operators\n,Print" " Operators",
        ),
        "default_server": N_("Administrators,\nBackup Operators"),
        "default_workgroup": N_("Administrators,\nBackup Operators,\nUsers"),
        "expected": N_("Authenticated Users"),
        "analyze": N_(
            "Ensure that only the Administrators and Backup Operators groups"
            " are assigned the Shut down the system user right on member"
            " servers, and ensure that only the Administrators group is"
            " assigned the user right on domain controllers.",
        ),
        "expected_reco": N_("This parameter can cause DoS"),
    },
    "SeUndockPrivilege": {
        "name": N_("Remove computer from docking station"),
        "desc": N_(
            "This security setting determines whether a user can undock a"
            " portable computer from its docking station without logging on."
            " This policy setting only affects scenarios that involve a"
            " portable computer and its docking station.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_(" "),
        "analyze": N_(" "),
        "expected_reco": N_(
            "When the station lock is motorized and not physically"
            " disengageable, specify the Authenticated Users group. For other"
            " configurations Ensure that only the local Administrators group"
            "and the user account to which the computer is allocated"
            "are assigned the Remove computer from docking station user right."
        ),
    },
    "SeRestorePrivilege": {
        "name": N_("Restore files and directories"),
        "desc": N_(
            "This setting overrides the permissions granted on directories and"
            " files. It should therefore be assigned with care.",
        ),
        "default_dc": N_(
            "Administrators,\nBackup Operators,\nServer Operators",
        ),
        "default_server": N_("Administrators,\nBackup Operators"),
        "default_workgroup": N_("Administrators,\nBackup Operators"),
        "expected": N_(" "),
        "analyze": N_(
            "Ensure that only the local Administrators group is assigned the"
            " Restore files and directories user right unless your"
            " organization has clearly defined roles for backup and for"
            " restore personnel.",
        ),
        "expected_reco": N_(
            "This right takes precedence over the permissions granted on"
            " directories and files. Therefore attribuate this right with"
            " precaution"
        ),
    },
    "SeBackupPrivilege": {
        "name": N_("Back up files and directories"),
        "desc": N_(
            "This user right determines which users can bypass file and"
            " directory, registry, and other persistent object permissions for"
            " the purposes of backing up the system. This user right is"
            " effective only when an application attempts access through the"
            " NTFS backup application programming interface (API) through a"
            " backup tool such as NTBACKUP.EXE. Otherwise, standard file and"
            " directory permissions apply.",
        ),
        "default_dc": N_(
            "Administrators,\nBackup Operators,\nServer Operators",
        ),
        "default_server": N_("Administrators,\nBackup Operators"),
        "default_workgroup": N_("Administrators,\nBackup Operators"),
        "expected": N_(" "),
        "analyze": N_(
            "Restrict the Back up files and directories user right to members"
            " of the IT team who must back up organizational data as part of"
            " their daily job responsibilities. If you are using backup"
            " software that runs under specific service accounts, only these"
            " accounts (and not the IT staff) should have the Back up files"
            " and directories user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeTakeOwnershipPrivilege": {
        "name": N_("Take ownership of files or other objects"),
        "desc": N_(
            "This policy setting determines which users can take ownership of"
            " any securable object in the computer, including Active Directory"
            " objects, NTFS files and folders, printers, registry keys,"
            " services, processes, and threads.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_(" "),
        "analyze": N_(
            "Ensure that only the local Administrators group has the Take"
            " ownership of files or other objects user right.",
        ),
        "expected_reco": N_(
            "Only the administrators are called upon to exploit this" " privilege",
        ),
    },
    "SeTrustedCredManAccessPrivilege": {
        "name": N_("Access Credential Manager as a trusted caller"),
        "desc": N_(
            "The Access Credential Manager as a trusted caller policy setting"
            " is used by Credential Manager during backup and restore. No"
            " accounts should have this privilege because it is assigned only"
            " to the Winlogon service. Saved credentials of users may be"
            " compromised if this privilege is given to other entities.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Do not define the Access Credential Manager as a trusted caller"
            " policy setting for any accounts besides Credential Manager.",
        ),
        "expected_reco": N_("It's a critical part of the system"),
    },
    "SeAuditPrivilege": {
        "name": N_("Generate security audits"),
        "desc": N_(
            "This policy setting determines which accounts can be used by a"
            " process to generate audit records in the Security log. The Local"
            " Security Authority Subsystem Service writes events to the log."
            " You can use the information in the Security log to trace"
            " unauthorized computer access.",
        ),
        "default_dc": N_("Local Service,\nNetwork Service"),
        "default_server": N_("Local Service,\nNetwork Service"),
        "default_workgroup": N_("Local Service,\nNetwork Service"),
        "expected": N_("Local Service"),
        "analyze": N_(
            "Ensure that only the Local Service and Network Service accounts"
            " have the Generate security audits user right assigned to them.",
        ),
        "expected_reco": N_(" "),
    },
    "SeSecurityPrivilege": {
        "name": N_("Manage auditing and security log"),
        "desc": N_(
            "This policy setting determines which users can specify object"
            " access audit options for individual resources such as files,"
            " Active Directory objects, and registry keys. These objects"
            " specify their system access control lists (SACL). A user who is"
            " assigned this user right can also view and clear the Security"
            " log in Event Viewer. ",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Ensure that only the local Administrators group has the Manage"
            " auditing and security log user right.",
        ),
        "expected_reco": N_(
            "A user with this privilege can specify object access auditing"
            " options for individual resources and view and clear the"
            " security log",
        ),
    },
    "SeIncreaseQuotaPrivilege": {
        "name": N_("Adjust memory quotas for a process"),
        "desc": N_(
            "This privilege determines who can change the maximum memory that"
            " can be consumed by a process. This privilege is useful for"
            " system tuning on a group or user basis.",
        ),
        "default_dc": N_("Administrators,\nLocal Service,\nNetwork Service"),
        "default_server": N_(
            "Administrators,\nLocal Service,\nNetwork Service",
        ),
        "default_workgroup": N_(
            "Administrators,\nLocal Service,\nNetwork Service",
        ),
        "expected": N_("Administrators,\nLocal Service,\nNetwork Service"),
        "analyze": N_(
            "Restrict the Adjust memory quotas for a process user right to"
            " users who require it to perform their jobs, such as application"
            " administrators who maintain database management systems or"
            " domain administrators who manage the organization's directory"
            " and its supporting infrastructure.",
        ),
        "expected_reco": N_(
            "Useful for system tuning, but can be used for malicious purposes",
        ),
    },
    "SeIncreaseBasePriorityPrivilege": {
        "name": N_("Increase scheduling priority"),
        "desc": N_(
            "This policy setting determines which user accounts can increase"
            " the base priority class of a process. It is not a privileged"
            " operation to increase relative priority within a priority class."
            " This user right is not required by administrative tools that are"
            " supplied with the operating system, but it might be required by"
            " software development tools.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Verify that only Administrators have the Increase scheduling"
            " priority user right assigned to them.",
        ),
        "expected_reco": N_(
            "A user with this privilege can change the scheduling priority of"
            " a process via the Task Manager user interface",
        ),
    },
    "SeIncreaseWorkingSetPrivilege": {
        "name": N_("Increase a process working set"),
        "desc": N_(
            "This policy setting determines which users can increase or"
            " decrease the size of the working set of a process. The working"
            " set of a process is the set of memory pages currently visible to"
            " the process in physical RAM. These pages are resident, and they"
            " are available for an application to use without triggering a"
            " page fault. The minimum and maximum working set sizes affect the"
            " virtual memory paging behavior of a process.",
        ),
        "default_dc": N_("Users"),
        "default_server": N_("Users"),
        "default_workgroup": N_("Users"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Increase user’s awareness about the impact of increasing the"
            " working set of a process and how to recognize that their system"
            " is adversely affected if they change this setting.",
        ),
        "expected_reco": N_(
            "Increasing the size of the working range for a process reduces"
            " the amount of physical memory available to the rest of the"
            " system. Malicious code can increase its settings to a level that"
            " could seriously degrade system performance",
        ),
    },
    "SeTimeZonePrivilege": {
        "name": N_("Change the time zone"),
        "desc": N_(
            "This policy setting determines which users can adjust the time"
            " zone that is used by the computer for displaying the local time,"
            " which includes the computer's system time plus the time zone"
            " offset.",
        ),
        "default_dc": N_("Administrators,\nUsers"),
        "default_server": N_("Administrators,\nUsers"),
        "default_workgroup": N_("Administrators,\nUsers"),
        "expected": N_(
            "Administrators,\n\nLocal Service,\nAuthenticated Users",
        ),
        "analyze": N_(
            "Countermeasures are not required because system time is not"
            " affected by this setting.",
        ),
        "expected_reco": N_(
            "Non-critical privilege except on applications have been poorly"
            " developed and are based on local time rather than UTC time",
        ),
    },
    "SeLoadDriverPrivilege": {
        "name": N_("Load and unload device drivers"),
        "desc": N_(
            "This policy setting determines which users can dynamically load"
            " and unload device drivers. This user right is not required if a"
            " signed driver for the new hardware already exists in the"
            " Driver.cab file on the computer. Device drivers run as highly"
            " privileged code.",
        ),
        "default_dc": N_("Administrators,\nPrint Operators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Do not assign the Load and unload device drivers user right to"
            " any user or group other than Administrators on member servers."
            " On domain controllers, do not assign this user right to any user"
            " or group other than Domain Admins.",
        ),
        "expected_reco": N_(
            "It is recommended not to assign this privilege to other users",
        ),
    },
    "SeChangeNotifyPrivilege": {
        "name": N_("Bypass traverse checking"),
        "desc": N_(
            "This policy setting determines which users (or a process that"
            " acts on behalf of the user’s account) have permission to"
            " navigate an object path in the NTFS file system or in the"
            " registry without being checked for the Traverse Folder special"
            " access permission. This user right does not allow the user to"
            " list the contents of a folder. It only allows the user to"
            " traverse folders to access permitted files or subfolders.",
        ),
        "default_dc": N_(
            "Administrators,\nAuthenticated Users,\nEveryone,\nLocal"
            " Service,\nNetwork Service,\nPre-Windows 2000 Compatible Access",
        ),
        "default_server": N_(
            "Administrators,\n,Backup Operators,\nUsers,\nEveryone,\nLocal"
            " Service,\nNetwork Service",
        ),
        "default_workgroup": N_(
            "Administrators,\n,Backup Operators,\nUsers,\nEveryone,\nLocal"
            " Service,\nNetwork Service",
        ),
        "expected": N_("Administrators,\n,Backup Operators"),
        "analyze": N_(
            "Use access–based enumeration when you want to prevent users from"
            " seeing any folder or file to which they do not have access.\nUse"
            " the default settings of this policy in most cases. If you change"
            " the settings, verify your intent through testing.",
        ),
        "expected_reco": N_(
            "This allows a user to browse a arborescence even if he does not"
            " have authorization on the directory he is browsing.",
        ),
    },
    "SeCreateSymbolicLinkPrivilege": {
        "name": N_("Create symbolic links"),
        "desc": N_(
            "This user right determines if users can create a symbolic link"
            " from the computer they are logged on to.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Do not assign the Create symbolic links user right to standard"
            " users. Restrict this right to trusted administrators. You can"
            " use the fsutil command to establish a symbolic link file system"
            " setting that controls the kind of symbolic links that can be"
            " created on a computer.",
        ),
        "expected_reco": N_(
            "It is to be granted only to approved users. Symbolic links can"
            " expose security vulnerabilities in applications that are not"
            " designed to address them",
        ),
    },
    "SeCreateGlobalPrivilege": {
        "name": N_("Create global objects"),
        "desc": N_(
            "This policy setting determines which users can create global"
            " objects that are available to all sessions. Users can still"
            " create objects that are specific to their own session if they do"
            " not have this user right.",
        ),
        "default_dc": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "default_server": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "default_workgroup": N_(
            "Administrators,\nLocal Service,\nNetwork Service,\nService",
        ),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Do not assign any user accounts this right. When"
            " non-administrators need to access a server using Remote Desktop,"
            " add the users to the Remote Desktop Users group rather than"
            " assining them this user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeCreatePermanentPrivilege": {
        "name": N_("Create permanent shared objects"),
        "desc": N_(
            "This user right determines which accounts can be used by"
            " processes to create a directory object by using the object"
            " manager. Directory objects include Active Directory objects,"
            " files and folders, printers, registry keys, processes, and"
            " threads. Users who have this capability can create permanent"
            " shared objects, including devices, semaphores, and mutexes.",
        ),
        "default_dc": N_("LocalSystem"),
        "default_server": N_("LocalSystem"),
        "default_workgroup": N_("LocalSystem"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Do not assign the Create permanent shared objects user right to"
            " any users. Processes that require this user right should use the"
            " System account, which already includes this user right, instead"
            " of a separate user account.",
        ),
        "expected_reco": N_(" "),
    },
    "SeCreatePagefilePrivilege": {
        "name": N_("Create a pagefile"),
        "desc": N_(
            "The Windows operating system, by default, designates a section of"
            " the hard drive as virtual memory known as the page file, or more"
            " specifically, as pagefile.sys. It is used to supplement the"
            " computer’s Random Access Memory (RAM) to improve performance for"
            " programs and data that are used frequently. Although the file is"
            " hidden from browsing, you can manage it using the system"
            " settings.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Restrict the Create a pagefile user right to members of the"
            " Administrators group.",
        ),
        "expected_reco": N_(" "),
    },
    "SeCreateTokenPrivilege": {
        "name": N_("Create a token object"),
        "desc": N_(
            "This policy setting determines which accounts a process can use"
            " to create a token, and which accounts it can then use to gain"
            " access to local resources when the process uses NtCreateToken()"
            " or other token-creation APIs.",
        ),
        "default_dc": N_("Local System"),
        "default_server": N_("Local System"),
        "default_workgroup": N_("Local System"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Do not assign the Create a token object user right to any users."
            " Processes that require this user right should use the Local"
            " System account, which already includes it, instead of a separate"
            " user account that has this user right assigned.",
        ),
        "expected_reco": N_(
            "It is recommended that processes that require this privilege use"
            " the SYSTEM or LocalSystem account, which already has this"
            " privilege. Ideally",
        ),
    },
    "SeDebugPrivilege": {
        "name": N_("Debug programs"),
        "desc": N_(
            "This policy setting determines which users can attach to or open"
            " any process, even those they do not own. Developers who are"
            " debugging their own applications do not need to be assigned this"
            " user right. Developers who are debugging new system components"
            " need this user right. This user right provides access to"
            " sensitive and critical operating-system components.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Remove the accounts of all users and groups that do not require"
            " the Debug programs user right.",
        ),
        "expected_reco": N_(
            "No user should be listed except on the development workstations"
            " where the developers called to debug the applications will be"
            " listed",
        ),
    },
    "SeManageVolumePrivilege": {
        "name": N_("Perform volume maintenance tasks"),
        "desc": N_(
            "This policy setting determines which users can perform volume or"
            " disk management tasks, such as defragmenting an existing volume,"
            " creating or removing volumes, and running the Disk Cleanup"
            " tool.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Ensure that only the local Administrators group is assigned the"
            " Perform volume maintenance tasks user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeSystemtimePrivilege": {
        "name": N_("Change the system time"),
        "desc": N_(
            "This policy setting determines which users can adjust the time on"
            " the computer's internal clock. This right allows the computer"
            " user to change the date and time associated with records in the"
            " event logs, database transactions, and the file system. This"
            " right is also required by the process that performs time"
            " synchronization. This setting does not impact the user’s ability"
            " to change the time zone or other display characteristics of the"
            " system time.",
        ),
        "default_dc": N_("Administrators,\nServer Operators,\nLocal Service"),
        "default_server": N_("Administrators,\nLocal Service"),
        "default_workgroup": N_("Administrators,\nLocal Service"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Restrict the Change the system time user right to users with a"
            " legitimate need to change the system time, such as members of"
            " the IT team.",
        ),
        "expected_reco": N_(
            "The implementation of a solution for synchronizing the clocks of"
            " all the stations on the network is desirable in order to"
            " guarantee the time stamping and thus allow the consolidation of"
            " the security logs. Limiting this right makes it possible to"
            " limit the risks of desynchronization",
        ),
    },
    "SeSystemEnvironmentPrivilege": {
        "name": N_("Modify firmware environment values"),
        "desc": N_(
            "This security setting determines who can modify firmware"
            " environment values. Firmware environment values are settings"
            " that are stored in the nonvolatile RAM of non-x86-based"
            " computers. The effect of the setting depends on the processor.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_(" "),
        "analyze": N_(
            "Ensure that only the local Administrators group is assigned the"
            " Modify firmware environment values user right.",
        ),
        "expected_reco": N_(
            "Only administrators need to change system environment variables",
        ),
    },
    "SeRelabelPrivilege": {
        "name": N_("Modify an object label"),
        "desc": N_(
            "This privilege determines which user accounts can modify the"
            " integrity label of objects, such as files, registry keys, or"
            " processes owned by other users. Processes running under a user"
            " account can modify the label of an object owned by that user to"
            " a lower level without this privilege.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Do not give any group this right. If necessary, implement it for"
            " a constrained period of time to a trusted individual to respond"
            " to a specific organizational need.",
        ),
        "expected_reco": N_(" "),
    },
    "SeSystemProfilePrivilege": {
        "name": N_("Profile system performance"),
        "desc": N_(
            "This security setting determines which users can use Windows"
            " performance monitoring tools to monitor the performance of"
            " system processes.",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Ensure that only the local Administrators group is assigned the"
            " Profile system performance user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeProfileSingleProcessPrivilege": {
        "name": N_("Profile single process"),
        "desc": N_(
            "This policy setting determines which users can view a sample"
            " performance of an application process. Typically, you do not"
            " need this user right to use the performance reporting tools"
            " included in the operating system. However, you do need this user"
            " right if the system’s monitor components are configured to"
            " collect data through Windows Management Instrumentation (WMI).",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Administrators"),
        "analyze": N_(
            "Ensure that only the local Administrators group is assigned the"
            " Profile single process user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeAssignPrimaryTokenPrivilege": {
        "name": N_("Replace a process level token"),
        "desc": N_(
            "This policy setting determines which parent processes can replace"
            " the access token that is associated with a child process.",
        ),
        "default_dc": N_("Network Service,\nLocal Service"),
        "default_server": N_("Network Service,\nLocal Service"),
        "default_workgroup": N_("Network Service,\nLocal Service"),
        "expected": N_("Network Service,\nLocal Service"),
        "analyze": N_(
            "For member servers, ensure that only the Local Service and"
            " Network Service accounts have the Replace a process level token"
            " user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeLockMemoryPrivilege": {
        "name": N_("Lock pages in memory"),
        "desc": N_(
            "This policy setting determines which accounts can use a process"
            " to keep data in physical memory, which prevents the computer"
            " from paging the data to virtual memory on a disk.",
        ),
        "default_dc": N_("Not defined"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Do not assign the Lock pages in memory user right to any" " accounts.",
        ),
        "expected_reco": N_(
            "This mechanism is rendered obsolete by the zeroing of the swap."
            " No user should be listed",
        ),
    },
    "SeEnableDelegationPrivilege": {
        "name": N_(
            "Enable computer and user accounts to be trusted for delegation",
        ),
        "desc": N_(
            "This policy setting determines which users can set the Trusted"
            " for Delegation setting on a user or computer object.\nSecurity"
            " account delegation provides the ability to connect to multiple"
            " servers, and each server change retains the authentication"
            " credentials of the original client. Delegation of authentication"
            " is a capability that client and server applications use when"
            " they have multiple tiers. It allows a public-facing service to"
            " use client credentials to authenticate to an application or"
            " database service",
        ),
        "default_dc": N_("Administrators"),
        "default_server": N_("Administrators"),
        "default_workgroup": N_("Administrators"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "The Enable computer and user accounts to be trusted for"
            " delegation user right should be assigned only if there is a"
            " clear need for its functionality. When you assign this right,"
            " you should investigate the use of constrained delegation to"
            " control what the delegated accounts can do. On domain"
            " controllers, this right is assigned to the Administrators group"
            " by default.",
        ),
        "expected_reco": N_(
            "Improper use of this right can leave the network vulnerable to"
            " sophisticated attacks using Trojan programs that assume the"
            " identities of incoming customers and use their credentials to"
            " access network resources",
        ),
    },
    "SeSyncAgentPrivilege": {
        "name": N_("Synchronize directory service data"),
        "desc": N_(
            "This policy setting determines which users and groups have"
            " authority to synchronize all directory service data, regardless"
            " of the protection for objects and properties. This privilege is"
            " required to use LDAP directory synchronization (dirsync)"
            " services.",
        ),
        "default_dc": N_("Enabled"),
        "default_server": N_("Disabled"),
        "default_workgroup": N_("Disabled"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Ensure that no accounts are assigned the Synchronize directory"
            " service data user right.",
        ),
        "expected_reco": N_(" "),
    },
    "SeMachineAccountPrivilege": {
        "name": N_("Add workstations to domain"),
        "desc": N_(
            "This policy setting determines which users can add a computer to"
            " a specific domain. For it to take effect, it must be assigned so"
            " that it applies to at least one domain controller. A user who is"
            " assigned this user right can add up to ten workstations to the"
            " domain.",
        ),
        "default_dc": N_("Authenticated Users"),
        "default_server": N_("Not defined"),
        "default_workgroup": N_("Not defined"),
        "expected": N_("Not defined"),
        "analyze": N_(
            "Configure this setting so that only authorized members of the IT"
            " team are allowed to add computers to the domain.",
        ),
        "expected_reco": N_(
            "Useful only on domain controllers. Implicitly available to"
            " administrators and operators. Allows to set up a new DC that"
            " will inherit a copy of the user base + passwords",
        ),
    },
}
