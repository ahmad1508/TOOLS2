# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_display_extensions = {
    "HideFileExt": {
        "name": N_("Hide file name extension"),
        "expected": "0",
        "default": "0",
    }
}
