# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_

db_wsus_configuration = {
    "NoAUShutdownOption": {
        "name": N_(
            'Do not display "Install updates and Shut Down" option in Shut'
            " Down Windows dialog "
        ),
        "expected": "0",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "NoAUAsDefaultShutdownOption": {
        "name": N_(
            "Do not adjust default option to “Install Updates and Shut Down”"
            " in Shut Down Windows dialog"
        ),
        "expected": "0",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "AUPowerManagement": {
        "name": N_(
            "Enabling Windows Update Power Management to automatically wake up"
            " the computer to install scheduled updates"
        ),
        "expected": "1",
        "default": "0",
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "NoAutoUpdate": {
        "name": N_("Configure automatic updates"),
        "expected": "0",
        "default": "0",
        "value": {"0": N_("Enabled"), "1": N_("Disabled")},
    },
    "AUOptions": {
        "name": N_("Configure automatic updating"),
        "expected": "4",
        "default": "3",
        "value": {
            "2": N_("Notify for download and notify for install"),
            "3": N_("Auto download and notify for install"),
            "4": N_("Auto download and schedule the install"),
            "5": N_("Allow local admin to choose setting"),
        },
        "required": {"NoAutoUpdate": "0"},
    },
    "ScheduledInstallDay": {
        "name": N_("Day of scheduled install"),
        "expected": "0",
        "default": "0",
        "value": {
            "0": N_("Every day"),
            "1": N_("Sunday"),
            "2": N_("Monday"),
            "3": N_("Tuesday"),
            "4": N_("Wednesday"),
            "5": N_("Thursday"),
            "6": N_("Friday"),
            "7": N_("Saturday"),
        },
        "required": {"NoAutoUpdate": "0", "AUOptions": "4"},
    },
    "ScheduledInstallTime": {
        "name": N_("Time of scheduled install"),
        "expected": N_("<Choose an hour>"),
        "default": "3",
        "value": {
            "0": N_("Midnight"),
            "1": "1 AM",
            "2": "2 AM",
            "3": "3 AM",
            "4": "4 AM",
            "5": "5 AM",
            "6": "6 AM",
            "7": "7 AM",
            "8": "8 AM",
            "9": "9 AM",
            "10": "10 AM",
            "11": "11 AM",
            "12": N_("Noon"),
            "13": "1 PM",
            "14": "2 PM",
            "15": "3 PM",
            "16": "4 PM",
            "17": "5 PM",
            "18": "6 PM",
            "19": "7 PM",
            "20": "8 PM",
            "21": "9 PM",
            "22": "10 PM",
            "23": "11 PM",
        },
        "required": {"NoAutoUpdate": "0", "AUOptions": "4"},
    },
    "UseWUServer": {
        "name": N_("Use a WSUS server"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "WUServer": {
        "name": N_("WSUS server to use"),
        "expected": N_("<WSUS server address>"),
        "default": N_("<empty>"),
        "required": {"NoAutoUpdate": "0", "UseWUServer": "1"},
    },
    "WUStatusServer": {
        "name": N_("WSUS server to report to"),
        "expected": N_("<WSUS server address>"),
        "default": N_("<empty>"),
        "required": {"NoAutoUpdate": "0", "UseWUServer": "1"},
    },
    "DetectionFrequencyEnabled": {
        "name": N_("WSUS server to report to"),
        "expected": "1",
        "default": "0",
        "value": {
            "1": N_("Enabled"),
            "0": N_("Disabled (DetectionFrequency=22)"),
        },
        "required": {"NoAutoUpdate": "0", "UseWUServer": "1"},
    },
    "DetectionFrequency": {
        "name": N_("Time between detection cycles (in hours)"),
        "expected": "6",
        "default": "22",
        "required": {
            "NoAutoUpdate": "0",
            "UseWUServer": "1",
            "DetectionFrequencyEnabled": "1",
        },
    },
    "ElevateNonAdmins": {
        "name": N_("Allow non-administrators to receive update notifications"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "EnableFeaturedSoftware": {
        "name": N_("Turn on Software Notification"),
        "expected": "0",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
    },
    "AutoInstallMinorUpdates": {
        "name": N_("Allow Automatic Updates immediate installation"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "IncludeRecommendedUpdates": {
        "name": N_("Turn on recommended updates via Automatic Updates"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
    },
    "NoAutoRebootWithLoggedOnUsers": {
        "name": N_(
            "No auto-restart with logged on users for scheduled automatic"
            " updates installations"
        ),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "RebootRelaunchTimeoutEnabled": {
        "name": N_("Re-prompt for restart with scheduled installations"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "RebootRelaunchTimeout": {
        "name": N_("Time between prompting again for a scheduled restart (in minutes)"),
        "expected": N_("30 minutes"),
        "default": N_("10 minutes"),
        "required": {"NoAutoUpdate": "0", "RebootRelaunchTimeoutEnabled": "1"},
    },
    "RebootWarningTimeoutEnabled": {
        "name": N_("Delay Restart for scheduled installations"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "RebootWarningTimeout": {
        "name": N_(
            "Length, in minutes, of the restart warning countdown after"
            " installing updates with a deadline or scheduled updates"
        ),
        "expected": N_("15 minutes"),
        "default": N_("15 minutes"),
        "required": {"NoAutoUpdate": "0", "RebootWarningTimeoutEnabled": "1"},
    },
    "RescheduleWaitTimeEnabled": {
        "name": N_("Reschedule Automatic Updates scheduled installations"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "RescheduleWaitTime": {
        "name": N_(
            "Time, in minutes, that Automatic Updates should wait at startup"
            " before applying updates from a missed scheduled installation"
            " time"
        ),
        "expected": N_("15 minutes"),
        "default": N_("15 minutes"),
        "required": {"NoAutoUpdate": "0", "RescheduleWaitTimeEnabled": "1"},
    },
    "TargetGroupEnabled": {
        "name": N_("Enable client-side targeting"),
        "expected": "1",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
        "required": {"NoAutoUpdate": "0"},
    },
    "TargetGroup": {
        "name": N_("Name of the computer group to which the computer belongs"),
        "expected": N_("<Name of the group>"),
        "default": N_("<empty>"),
        "required": {"NoAutoUpdate": "0", "TargetGroupEnabled": "1"},
    },
    "AcceptTrustedPublisherCerts": {
        "name": N_(
            "Allow signed updates from an intranet Microsoft update service" " location"
        ),
        "expected": "0",
        "default": "0",
        "value": {"1": N_("Enabled"), "0": N_("Disabled")},
    },
}
