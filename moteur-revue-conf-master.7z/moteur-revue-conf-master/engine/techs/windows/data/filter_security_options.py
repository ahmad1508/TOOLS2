# -*- coding: UTF-8 -*-
# Project imports
from engine.core import i18n

# I18N
N_ = i18n.domain("windows").N_


db_security_options = {
    "Network access: Remotely accessible sub paths and registry paths": {
        "name": N_("Network access: Remotely accessible registry paths and subpaths"),
        "desc": N_(
            "This policy setting determines which registry paths and subpaths"
            " are accessible when an application or process references the"
            " WinReg key to determine access permissions"
        ),
        "default_dc": (
            "System\\CurrentControlSet\\Control\\Print\\Printers,System"
            "\\CurrentControlSet\\Services\\Eventlog,Software\\Microsoft\\OLAP"
            " Server,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Print,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Windows,System\\CurrentControlSet\\Control"
            "\\ContentIndex,System\\CurrentControlSet\\Control\\Terminal"
            " Server,System\\CurrentControlSet\\Control\\Terminal"
            " Server\\\\UserConfig,System\\CurrentControlSet"
            "\\Control\\Terminal"
            " Server\\DefaultUserConfiguration,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Perflib,System\\CurrentControlSet\\Services"
            "\\SysmonLog"
        ),
        "default_server": (
            "System\\CurrentControlSet\\Control\\Print\\Printers,"
            "System\\CurrentControlSet\\Services\\Eventlog,Software\\Microsoft\\OLAP"
            " Server\nSoftware\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Print,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Windows,System\\CurrentControlSet\\Control"
            "\\ContentIndex,System\\CurrentControlSet\\Control\\Terminal"
            " Server,System\\CurrentControlSet\\Control\\Terminal"
            " Server\\\\UserConfig,System\\CurrentControlSet\\Control\\Terminal"
            " Server\\DefaultUserConfiguration,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Perflib,System\\CurrentControlSet"
            "\\Services\\SysmonLog"
        ),
        "default_workgroup": (
            "System\\CurrentControlSet\\Control\\Print\\Printers,System"
            "\\CurrentControlSet\\Services\\Eventlog,Software\\Microsoft\\OLAP"
            " Server,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Print\nSoftware\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Windows,System\\CurrentControlSet\\Control"
            "\\ContentIndex,System\\CurrentControlSet\\Control\\Terminal"
            " Server,System\\CurrentControlSet\\Control\\Terminal"
            " Server\\\\UserConfig,System\\CurrentControlSet"
            "\\Control\\Terminal"
            " Server\\DefaultUserConfiguration,Software\\Microsoft\\Windows"
            " NT\\CurrentVersion\\Perflib,System\\CurrentControlSet\\Services"
            "\\SysmonLog"
        ),
        "expected": ".",
        "applied": N_(
            "Windows Vista\nWindows Server 2008\nWindows 7\nWindows"
            " 8.1\nWindows Server 2008 R2\nWindows Server 2012 R2\nWindows"
            " Server 2012\nWindows 8"
        ),
        "analyze": N_(
            "Configure the Network access: Remotely accessible registry paths"
            " and sub-paths setting to a null value (enable the setting but do"
            " not enter any paths in the text box)"
        ),
        "expected_reco": N_(
            "It is recommended not to configure this parameter unless all the"
            " machines that will be affected by the strategy are identical and"
            " all have the same function. In fact"
        ),
    },
    "Network access: Let Everyone permissions apply to anonymous users": {
        "name": N_("Network access: Let Everyone permissions apply to anonymous users"),
        "desc": N_(
            "This policy setting determines what additional permissions are"
            " granted for anonymous connections to the device. If you enable"
            " this policy setting, anonymous users can enumerate the names of"
            " domain accounts and shared folders and perform certain other"
            " activities. This capability is convenient, for example, when an"
            " administrator wants to grant access to users in a trusted domain"
            " that does not maintain a reciprocal trust"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Network access: Let Everyone permissions apply to"
            " anonymous users setting"
        ),
        "expected_reco": N_("If this policy is disabled"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Named Pipes that can be accessed anonymously": {
        "name": N_("Network access: Named Pipes that can be accessed anonymously"),
        "desc": N_(
            "This policy setting determines which communication sessions, or"
            " pipes, have attributes and permissions that allow anonymous"
            " access"
        ),
        "default_dc": "Netlogon,\nsamr,\nlsarpc",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Network access: Named Pipes that can be accessed"
            " anonymously setting to a null value (enable the setting but do"
            " not specify named pipes in the text box)"
        ),
        "expected_reco": N_(
            "It is recommended not to configure this parameter unless all the"
            " machines that will be affected by the strategy are identical and"
            " all have the same function. In fact"
        ),
    },
    "Network access: Remotely accessible registry path": {
        "name": N_("Network access: Remotely accessible registry paths"),
        "desc": N_(
            "This policy setting determines which registry paths are"
            " accessible when an application or process references the WinReg"
            " key to determine access permissions"
        ),
        "default_dc": (
            "System\\CurrentControlSet\\Control\\ProductOptions\nSystem"
            "\\CurrentControlSet\\Control\\Server"
            " Applications\nSoftware\\Microsoft\\Windows NT\\CurrentVersion"
        ),
        "default_server": (
            "System\\CurrentControlSet\\Control\\ProductOptions\nSystem"
            "\\CurrentControlSet\\Control\\Server"
            " Applications\nSoftware\\Microsoft\\Windows NT\\CurrentVersion"
        ),
        "default_workgroup": (
            "System\\CurrentControlSet\\Control\\ProductOptions\nSystem"
            "\\CurrentControlSet\\Control\\Server"
            " Applications\nSoftware\\Microsoft\\Windows NT\\CurrentVersion"
        ),
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Network access: Remotely accessible registry paths"
            " setting to a null value (enable the setting, but do not enter"
            " any paths in the text box)"
        ),
        "expected_reco": N_(
            "This parameter has an effect only on Windows XP machines. To be"
            " set in a domain policy including XP machines (but not in local"
            " policy on a Windows 7 machine)"
        ),
    },
    "Network access: Shares that can be accessed anonymously": {
        "name": N_("Network access: Shares that can be accessed anonymously"),
        "desc": N_(
            "This policy setting determines which shared folders can be"
            " accessed by anonymous users"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Network access: Shares that can be accessed"
            " anonymously setting to a null value"
        ),
        "expected_reco": N_(
            "It is recommended not to configure this parameter unless all the"
            " machines that will be affected by the strategy are identical and"
            " all have the same function. In fact"
        ),
    },
    "Network access: Sharing and security model for local accounts": {
        "name": N_("Network access: Sharing and security model for local accounts"),
        "desc": N_(
            "This policy setting determines how network logons that use local"
            " accounts are authenticated. If you configure this policy setting"
            " to Classic, network logons that use local account credentials"
            " authenticate with those credentials. If you configure this"
            " policy setting to Guest only, network logons that use local"
            " accounts are automatically mapped to the Guest account. The"
            " Classic model provides precise control over access to resources,"
            " and it enables you to grant different types of access to"
            " different users for the same resource"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "For network servers, configure the Network access: Sharing and"
            " security model for local accounts setting to Classic – local"
            " users authenticate as themselves. On end-user computers,"
            " configure this policy setting to Guest only – local users"
            " authenticate as guest"
        ),
        "expected_reco": N_(
            "This setting only affects Windows 7 Professional workstations in"
            " workgroups"
        ),
        "value": {
            "0": N_("Classic (local users authenticate as themselves)"),
            "1": N_("Guest only - local  users authenticate as Guest "),
        },
    },
    "Network access: Do not allow anonymous enumeration of SAM accounts and shares": {
        "name": N_(
            "Network access: Do not allow anonymous enumeration of SAM"
            " accounts and shares"
        ),
        "desc": N_(
            "This policy setting determines which additional permissions will"
            " be assigned for anonymous connections to the device. Windows"
            " allows anonymous users to perform certain activities, such as"
            " enumerating the names of domain accounts and network shares"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network access: Do not allow anonymous enumeration of"
            " SAM accounts and shares setting"
        ),
        "expected_reco": N_(
            "If you do not wish to allow anonymous listing of SAM accounts and"
            " shares"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Do not allow anonymous enumeration of SAM accounts": {
        "name": N_(
            "Network access: Do not allow anonymous enumeration of SAM accounts"
        ),
        "desc": N_(
            "This policy setting determines which additional permissions will"
            " be assigned for anonymous connections to the device. Windows"
            " allows anonymous users to perform certain activities, such as"
            " enumerating the names of domain accounts and network shares"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network access: Do not allow anonymous enumeration of"
            " SAM accounts setting"
        ),
        "expected_reco": N_(
            "This option replaces Everyone with Authenticated Users in the"
            " security permissions for resources. This policy has no impact on"
            " domain controllers"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Allow anonymous SID/Name translation": {
        "name": N_("Network access: Allow anonymous SID/Name translation"),
        "desc": N_(
            "This policy setting enables or disables the ability of an"
            " anonymous user to request security identifier (SID) attributes"
            " for another user"
        ),
        "default_dc": "1",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Network access: Allow anonymous SID/Name translation"
            " setting"
        ),
        "expected_reco": N_("If this policy is enabled"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Restrict anonymous access to Named Pipes and Shares": {
        "name": N_(
            "Network access: Restrict anonymous access to Named Pipes and Shares"
        ),
        "desc": N_(
            "This policy setting enables or disables the restriction of"
            " anonymous access to only those shared folders and pipes that are"
            " named in the Network access: Named pipes that can be accessed"
            " anonymously and Network access: Shares that can be accessed"
            " anonymously settings"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network access: Restrict anonymous access to Named"
            " Pipes and Shares setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Do not allow storage of credentials or .NET Passports for network authentication": {  # noqa: B950
        "name": N_(
            "Network access: Do not allow storage of passwords and credentials"
            " for network authentication"
        ),
        "desc": N_(
            "This security setting determines whether Credential Manager saves"
            " passwords and credentials for later use when it gains domain"
            " authentication"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network access: Do not allow storage of passwords and"
            " credentials for network authentication setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network access: Restrict clients allowed to make remote calls to SAM": {
        "name": N_(
            "Network access: Restrict clients allowed to make remote calls to SAM"
        ),
        "desc": N_(
            "The SAMRPC protocol makes it possible for a low privileged user"
            " to query a machine on a network for data. For example, a user"
            " can use SAMRPC to enumerate users, including privileged accounts"
            " such as local or domain administrators, or to enumerate groups"
            " and group memberships from the local SAM and Active Directory."
            " This information can provide important context and serve as a"
            " starting point for an attacker to compromise a domain or"
            " networking environment"
        ),
        "default_dc": (
            "Windows Server 2016 domain controller (reading Active Directory)"
            " : Everyone has read permissions to preserve"
            " compatibility,\nEarlier domain controller : No access check is"
            " performed by default"
        ),
        "default_server": (
            "Windows10, version1607 : (O:SYG:SYD:(A;;RC;;;BA))\\Owner:"
            " NTAUTHORITY/SYSTEM (WellKnownGroup) (S-1-5-18),\nPrimary group:"
            " NTAUTHORITY/SYSTEM (WellKnownGroup)"
            " (S-1-5-18),\nDACL:\nRevision: 0x02,\nSize: 0x0020,\nAce Count:"
            " 0x001,\nAceType:0x00"
            " (ACCESS_ALLOWED_ACE_TYPE),\nAceSize:0x0018,\nInheritFlags:0x00"
            ",\nAccess"
            " Mask:0x00020000,\nAceSid: BUILTIN\\Administrators (Alias)"
            " (S-1-5-32-544),\nSACL: Not present"
        ),
        "default_workgroup": (
            "Windows10, version1607 : (O:SYG:SYD:(A;;RC;;;BA))\\Owner:"
            " NTAUTHORITY/SYSTEM (WellKnownGroup) (S-1-5-18),\nPrimary group:"
            " NTAUTHORITY/SYSTEM (WellKnownGroup)"
            " (S-1-5-18),\nDACL:\nRevision: 0x02,\nSize: 0x0020,\nAce Count:"
            " 0x001,\nAceType:0x00"
            " (ACCESS_ALLOWED_ACE_TYPE),\nAceSize:0x0018,\nInheritFlags:0x00,"
            "\nAccess"
            " Mask:0x00020000,\nAceSid: BUILTIN\\Administrators (Alias)"
            " (S-1-5-32-544),\nSACL: Not present"
        ),
        "expected": " ",
        "applied": N_(
            "Windows10, version1607 et versions ultérieures,\nWindows10,"
            " version1511 avec la mise à jour KB4103198,\nWindows10,"
            " version1507 avec la mise à jour KB4012606,\nWindows8.1 avec la"
            " mise à jour KB4102219,\nWindows7 avec la mise à jour"
            " KB4012218,\nWindows Server2016,\nWindows Server2012R2 avec la"
            " mise à jour KB4012219,\nWindows Server2012 avec la mise à jour"
            " KB4012220,\nWindows Server2008 R2 avec la mise à jour KB4012218"
        ),
        "analyze": N_(
            "You can mitigate this vulnerability by enabling the Network"
            " access: Restrict clients allowed to make remote calls to SAM"
            " security policy setting and configuring the SDDL for only those"
            " accounts that are explicitly allowed access"
        ),
        "expected_reco": N_(
            "Defined, along with the security descriptor for users and groups"
            " who are allowed or denied to use SAMRPC to remotely access"
            " either the local SAM or Active Directory."
        ),
    },
    "Shutdown: Clear virtual memory pagefile on shutdown": {
        "name": N_("Shutdown: Clear virtual memory pagefile"),
        "desc": N_(
            "This policy setting determines whether the virtual memory paging"
            " file is cleared when the device is shut down. Virtual memory"
            " support uses a system paging file to swap pages of memory to"
            " disk when they are not used. On a running device, this paging"
            " file is opened exclusively by the operating system, and it is"
            " well protected. However, devices that are configured to allow"
            " other operating systems to start should verify that the system"
            " paging file is cleared as the device shuts down"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Shutdown: Clear virtual memory page file setting. This"
            " configuration causes the operating system to clear the paging"
            " file when the device is shut down. The amount of time that is"
            " required to complete this process depends on the size of the"
            " page file. Because the process overwrites the storage area that"
            " is used by the page file several times, it could be several"
            " minutes before the device completely shuts down"
        ),
        "expected_reco": N_(
            "This ensures that sensitive information from process memory that"
            " may be in the swap file is not available to an unauthorized user"
            " attempting to access the swap file directly. When this strategy"
            " is enabled"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Shutdown: Allow system to be shut down without having to log on": {
        "name": N_("Shutdown: Allow system to be shut down without having to log on"),
        "desc": N_(
            "This policy setting determines whether a device can be shut down"
            " without having to log on to Windows. If you enable this policy"
            " setting, the Shut Down option is available on the logon screen"
            " in Windows. If you disable this policy setting, the Shut Down"
            " option is removed from the logon screen. This configuration"
            " requires that users are able to log on to the device"
            " successfully and that they have the Shut down the system user"
            " right before they can perform a shutdown"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Shutdown: Allow system to be shut down without having"
            " to log on setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Audit: Shut down system immediately if unable to log Security audits": {
        "name": N_(
            "Audit: Shut down system immediately if unable to log security audits"
        ),
        "desc": N_(
            "The Audit: Shut down system immediately if unable to log security"
            " audits policy setting determines whether the system shuts down"
            " if it is unable to log security events. This policy setting is a"
            " requirement for Trusted Computer System Evaluation Criteria"
            " (TCSEC)-C2 and Common Criteria certification to prevent"
            " auditable events from occurring if the audit system is unable to"
            " log those events"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": N_("Enabled or Disabled"),
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Audit: Shut down system immediately if unable to log"
            " security audits setting to ensure that security auditing"
            " information is captured for review"
        ),
        "expected_reco": N_(
            "Activate on a workstation for which accountability is preferred"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Audit: Audit the access of global system objects": {
        "name": N_("Audit: Audit the access of global system objects"),
        "desc": N_(
            "If you enable this policy setting, a default system access"
            " control list (SACL) is applied when the device creates system"
            " objects such as mutexes, events, semaphores, and MS-DOS®"
            " devices. If you also enable the Audit object access audit"
            " setting, access to these system objects is audited"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Audit: Audit the access of global system objects setting"
        ),
        "expected_reco": N_(
            "Activating this strategy generates a large number of records in"
            " the event logs. It is therefore advisable to activate it only if"
            " you are sure that you can use these records"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Audit: Audit the use of backup and restore privilege": {
        "name": N_("Audit: Audit the use of Backup and Restore privilege"),
        "desc": N_(
            "The Audit: Audit the use of Backup and Restore privilege policy"
            " setting determines whether to audit the use of all user rights,"
            " including Backup and Restore, when the Audit privilege use"
            " policy setting is configured. Enabling both policy settings"
            " generates an audit event for every file that is backed up or"
            " restored"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Audit: Audit the use of Backup and Restore privilege"
            " setting. Alternatively, implement automatic log backup by"
            " configuring the AutoBackupLogFiles registry key. If you enable"
            " this option when the Audit privilege use setting is also"
            " enabled, an audit event is generated for every file that is"
            " backed up or restored. This information could help you to"
            " identify an account that was used to accidentally or maliciously"
            " restore data in an unauthorized manner. For more information"
            " about configuring this key, see Eventlog Key"
        ),
        "expected_reco": N_(
            "Activating this strategy generates a large number of records in"
            " the event logs. It is therefore advisable to activate it only if"
            " you are sure that you can use these records"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Audit: Force audit policy subcategory settings ,Windows Vista or later, to override audit policy category settings": {  # noqa: B950
        "name": N_(
            "Audit: Force audit policy subcategory settings (Windows Vista or"
            " later) to override audit policy category settings"
        ),
        "desc": N_(
            "You can manage your audit policy in a more precise way by using"
            " audit policy subcategories"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable audit policy subcategories as needed to track specific events"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "System cryptography: Use FIPS compliant algorithms for encryption, hashing, and signing": {  # noqa: B950
        "name": N_(
            "System cryptography: Use FIPS compliant algorithms for"
            " encryption, hashing, and signing"
        ),
        "desc": N_(
            "The Federal Information Processing Standard (FIPS) 140 is a"
            " security implementation that is designed for certifying"
            " cryptographic software. Windows implements these certified"
            " algorithms to meet the requirements and standards for"
            " cryptographic modules for use by departments and agencies of the"
            " United States federal government"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the System cryptography: Use FIPS compliant algorithms for"
            " encryption, hashing, and signing setting"
        ),
        "expected_reco": N_(
            "(can be turned enabled, but edge effects can be important)"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Microsoft network client: Digitally sign communications ,if server agrees": {
        "name": N_(
            "Microsoft network client: Digitally sign communications (if"
            " server agrees)"
        ),
        "desc": N_(
            "The Server Message Block (SMB) protocol provides the basis for"
            " Microsoft file and print sharing and many other networking"
            " operations, such as remote Windows administration. To prevent"
            " man-in-the-middle attacks that modify SMB packets in transit,"
            " the SMB protocol supports the digital signing of SMB packets."
            " This policy setting determines whether SMB packet signing must"
            " be negotiated before further communication with the Server"
            " service is permitted"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the settings as follows:\nDisable Microsoft Network"
            " Client: Digitally Sign Communications (Always)\nDisable"
            " Microsoft Network Server: Digitally Sign Communications"
            " (Always)\nEnable Microsoft Network Client: Digitally Sign"
            " Communications (If Server Agrees)\nEnable Microsoft Network"
            " Server: Digitally Sign Communications (If Client Agrees)\nIn"
            " highly secure environments we recommend that you configure all"
            " of these settings to Enabled. However, that configuration may"
            " cause slower performance on client computers and prevent"
            " communications with earlier SMB applications and operating"
            " systems"
        ),
        "expected_reco": N_(
            "The Microsoft network client will ask the server to sign SMB"
            " packages during the session installation. If packet signing is"
            " enabled on the server"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Microsoft network client: Digitally sign communications ,always": {
        "name": N_("Microsoft network client: Digitally sign communications (always)"),
        "desc": N_(
            "The Server Message Block (SMB) protocol provides the basis for"
            " file and print sharing and many other networking operations,"
            " such as remote Windows administration. To prevent"
            " man-in-the-middle attacks that modify SMB packets in transit,"
            " the SMB protocol supports the digital signing of SMB packets"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable Microsoft network client: Digitally sign communications (always)"
        ),
        "expected_reco": N_(
            "Requires the SMB client to sign packages. The client cannot then"
            " establish a session with a server for which SMB signing is not"
            " enabled"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Microsoft network client: Send unencrypted password to third-party SMB servers": {
        "name": N_(
            "Microsoft network client: Send unencrypted password to"
            " third-party SMB servers"
        ),
        "desc": N_(
            "The Server Message Block (SMB) protocol provides the basis for"
            " file and print sharing and many other networking operations,"
            " such as remote Windows administration. This policy setting"
            " allows or prevents the SMB redirector to send plaintext"
            " passwords to a non-Microsoft server service that does not"
            " support password encryption during authentication"
        ),
        "default_dc": "0",
        "location": "",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Microsoft network client: Send unencrypted password"
            " to connect to third-party SMB servers setting"
        ),
        "expected_reco": N_("Sending unencrypted passwords is a security risk"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Accounts: Limit local account use of blank passwords to console logon only": {
        "name": N_(
            "Accounts: Limit local account use of blank passwords to console"
            " logon only"
        ),
        "desc": N_(
            "The Accounts: Limit local account use of blank passwords to"
            " console logon only policy setting determines whether remote"
            " interactive logons by network services such as Remote Desktop"
            " Services (formerly Terminal Services), Telnet, and File Transfer"
            " Protocol (FTP) are allowed for local accounts that have blank"
            " passwords"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Accounts: Limit local account use of blank passwords"
            " to console logon only setting"
        ),
        "expected_reco": N_(
            "Local accounts that are not password-protected allow you to login"
            " only on the computer keyboard"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Accounts: Administrator account status": {
        "name": N_("Accounts: Administrator account status"),
        "desc": N_(
            "Ce paramètre de sécurité détermine si le compte d’administrateur"
            " local est activé ou désactivés"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Accounts: Administrator account status setting so"
            " that the built-in Administrator account cannot be used in a"
            " normal system startup. If it is very difficult to maintain a"
            " regular schedule for periodic password changes for local"
            " accounts, you can disable the built-in Administrator account"
            " instead of relying on regular password changes to protect it"
            " from attack"
        ),
        "expected_reco": N_(
            "A support account that is a member of the Local Administrators"
            " group must be created with a different password on all"
            " workstations"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Accounts: Guest account status": {
        "name": N_("Accounts: Guest account status"),
        "desc": N_(
            "The Accounts: Guest account status policy setting determines"
            " whether the Guest account is enabled or disabled. This account"
            " allows unauthenticated network users to gain access to the"
            " system by logging on as a Guest with no password. Unauthorized"
            " users can access any resources that are accessible to the Guest"
            " account over the network. This means that any network shared"
            " folders with permissions that allow access to the Guest account,"
            " the Guests group, or the Everyone group will be accessible over"
            " the network"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Accounts: Guest account status setting so that the"
            " built-in Guest account cannot be used"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Accounts: Block Microsoft Accounts": {
        "name": N_("Accounts: Block Microsoft accounts"),
        "desc": N_(
            "This policy setting prevents users from adding new Microsoft"
            " accounts on a computer"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Require only domain accounts in your enterprise by limiting the"
            " use of Microsoft accounts. Click the Users can’t add Microsoft"
            " accounts setting option so that users will not be able to create"
            " new Microsoft accounts on a computer, switch a local account to"
            " a Microsoft account, or connect a domain account to a Microsoft"
            " account"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Interactive logon: Display user information when the session is locked": {
        "name": N_(
            "Interactive logon: Display user information when the session is locked"
        ),
        "desc": N_(
            "When a session is locked in a Windows operating system (meaning"
            " the user at the computer pressed CTRL+ALT+DEL and the Secure"
            " Desktop is displayed), user information is displayed. By"
            " default, this information is in the form of <user name> is"
            " logged on. The displayed user name is the user’s full name as"
            " set on the Properties page for that user"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "3",
        "applied": N_(" "),
        "analyze": N_(
            "Enabling this policy setting allows the operating system to hide"
            " certain user information from being displayed on the Secure"
            " Desktop (after the computer has been booted or when the session"
            " has been locked by using CTRL+ALT+DEL). However, user"
            " information is displayed if the Switch user feature is used so"
            " that the logon tiles are displayed for each logged on user."
        ),
        "expected_reco": N_(" "),
        "value": {
            "1": N_("User display name, domain and user names"),
            "2": N_("User display name only"),
            "3": N_("Do not display user information"),
            "4": N_("Domain and user names only"),
        },
    },
    "Recovery console: Allow automatic administrative logon": {
        "name": N_("Recovery console: Allow automatic administrative logon"),
        "desc": N_(
            "This policy setting determines whether the Administrator account"
            " password must be provided before access to the computer is"
            " granted. If you enable this setting, the Administrator account"
            " is automatically logged on to the computer at the Recovery"
            " Console; no password is required"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "This section describes how an attacker might exploit a feature or"
            " its configuration, how to implement the countermeasure, and the"
            " possible negative consequences of countermeasure implementation"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Recovery console: Allow floppy copy and access to all drives and all folders": {
        "name": N_(
            "Recovery console: Allow floppy copy and access to all drives and"
            " folders"
        ),
        "desc": N_(
            "This policy setting enables or disables the Recovery Console SET"
            " command, which allows you to set the following Recovery Console"
            " environment variables"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Recovery console: Allow floppy copy and access to"
            " drives and folders setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Admin Approval Mode for the built-in Administrator account": {  # noqa: B950
        "name": N_(
            "User Account Control: Admin Approval Mode for the Built-in"
            " Administrator account"
        ),
        "desc": N_(
            "This policy setting determines the behavior of Admin Approval"
            " Mode for the built-in Administrator account.When the Admin"
            " Approval Mode is enabled, the local Administrator account"
            " functions like a standard user account, but it has the ability"
            " to elevate privileges without logging on by using a different"
            " account"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Admin Approval Mode for the"
            " Built-in Administrator account setting if you have the built-in"
            " Administrator account enabled"
        ),
        "expected_reco": N_(
            "Integrated Administrator account runs all applications with full"
            " administrative privileges"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Switch to the secure desktop when prompting for elevation": {
        "name": N_(
            "User Account Control: Switch to the secure desktop when prompting"
            " for elevation"
        ),
        "desc": N_(
            "This policy setting determines whether the elevation request"
            " prompts on the interactive user desktop or on the secure"
            " desktop.The secure desktop presents the logon UI and restricts"
            " functionality and access to the system until the logon"
            " requirements are satisfied"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Switch to the secure desktop"
            " when prompting for elevation setting. The secure desktop helps"
            " protect against input and output spoofing by presenting the"
            " credentials dialog box in a protected section of memory that is"
            " accessible only by trusted system processes"
        ),
        "expected_reco": N_(
            "\\All elevation requests go to the secure desktop regardless of"
            " the prompt behavior policy settings for administrators and"
            " standard users"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Allow UIAccess applications to prompt for elevation without using the secure desktop": {  # noqa: B950
        "name": N_(
            "User Account Control: Allow UIAccess applications to prompt for"
            " elevation without using the secure desktop"
        ),
        "desc": N_(
            "This security setting controls whether User Interface"
            " Accessibility (UIAccess or UIA) programs can automatically"
            " disable the secure desktop for elevation prompts that are used"
            " by a standard user"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the User Account Control: Allow UIAccess applications to"
            " prompt for elevation without using the secure desktop setting"
        ),
        "expected_reco": N_(
            "The Secure Desktop can be disabled only by the interactive"
            " desktop user or by disabling the policy setting User Account"
            " Control: Switch to Secure Desktop on elevation request"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode": {  # noqa: B950
        "name": N_(
            "User Account Control: Behavior of the elevation prompt for"
            " administrators in Admin Approval Mode"
        ),
        "desc": N_(
            "This policy setting determines the behavior of the elevation"
            " prompt for accounts that have administrative credentials"
        ),
        "default_dc": "5",
        "default_server": "5",
        "default_workgroup": "5",
        "expected": "Requesting credentials",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the User Account Control: Behavior of the elevation"
            " prompt for administrators in Admin Approval Mode setting to"
            " Prompt for consent"
        ),
        "expected_reco": N_(
            "Administrators must authenticate when privileges are raised"
        ),
        "value": {
            "0": N_("Elevate without prompting"),
            "1": N_("Prompt for credential on the secure desktop"),
            "2": N_("Prompt for consent on the secure desktop"),
            "3": N_("Prompt for credentials"),
            "4": N_("Prompt for consent"),
            "5": N_("Prompt for consent for non-Windows binaries"),
        },
    },
    "User Account Control: Behavior of the elevation prompt for standard users": {
        "name": N_(
            "User Account Control: Behavior of the elevation prompt for"
            " standard users"
        ),
        "desc": N_(
            "This policy setting determines the behavior of the elevation"
            " prompt for standard users"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the User Account Control: Behavior of the elevation"
            " prompt for standard users to Automatically deny elevation"
            " requests. This setting requires the user to log on with an"
            " administrative account to run programs that require elevation of"
            " privilege. As a security best practice, standard users should"
            " not have knowledge of administrative passwords. However, if your"
            " users have both standard and administrator-level accounts, we"
            " recommend setting Prompt for credentials so that the users do"
            " not choose to always log on with their administrator"
            " accounts,and they shift their behavior to use the standard user"
            " account"
        ),
        "expected_reco": N_(
            "A standard user will be automatically denied privilege"
            " escalation. To be modulated if it turns out that certain tasks"
            " require higher privileges"
        ),
        "value": {
            "0": N_("Automatically deny elevation request"),
            "1": N_("Prompt for credential on the secure desktop"),
            "2": N_("Prompt for credentials"),
        },
    },
    "User Account Control: Detect application installations and prompt for elevation": {
        "name": N_(
            "User Account Control: Detect application installations and prompt"
            " for elevation"
        ),
        "desc": N_(
            "This policy setting determines the behavior of application"
            " installation detection for the entire system.Some software might"
            " attempt to install itself after being given permission to run."
            " The user may give permission for the program to run because the"
            " program is trusted"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Detect application installations"
            " and prompt for elevation setting"
        ),
        "expected_reco": N_(
            "Software installations will require a privilege upgrade. This"
            " setting can be temporarily disabled when deploying a new"
            " application"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Only elevate UIAccess applications that are installed in secure locationsn": {  # noqa: B950
        "name": N_(
            "User Account Control: Only elevate UIAccess applications that are"
            " installed in secure locations"
        ),
        "desc": N_(
            "This policy setting enforces the requirement that applications"
            " that request running with a UIAccess integrity level (by means"
            " of a marking of UIAccess=true in their application manifest),"
            " must reside in a secure location on the file system"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Only elevate UIAccess"
            " applications that are installed in secure locations setting"
        ),
        "expected_reco": N_(
            "The only applications that will be eligible for privilege"
            " escalation must be located in protected locations"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Only elevate executables that are signed and validated": {
        "name": N_(
            "User Account Control: Only elevate executables that are signed"
            " and validated"
        ),
        "desc": N_(
            "This policy setting enforces public key infrastructure (PKI)"
            " signature checks on any interactive application that requests"
            " elevation of privilege. Enterprise administrators can control"
            " the applications that are allowed to run through the population"
            " of certificates in the local computer's Trusted Publishers store"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Only elevate executables that"
            " are signed and validated"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Run all administrators in Admin Approval Mode": {
        "name": N_(
            "User Account Control: Run all administrators in Admin Approval Mode"
        ),
        "desc": N_(
            "This policy setting determines the behavior of all User Account"
            " Control (UAC) policies for the entire system. This is the"
            " setting that turns UAC on or off"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Run all users, including"
            " administrators, as standard users setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "User Account Control: Virtualize file and registry write failures to per-user locations": {  # noqa: B950
        "name": N_(
            "User Account Control: Virtualize file and registry write failures"
            " to per-user locations"
        ),
        "desc": N_(
            "This policy setting enables or disables the redirection of the"
            " write failures of earlier applications to defined locations in"
            " the registry and the file system"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the User Account Control: Virtualize file and registry"
            " write failures to per-user locations setting"
        ),
        "expected_reco": N_(
            "Application write failures are redirected at runtime to defined"
            " locations in both the file system and the registry"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain controller: LDAP server signing requirements": {
        "name": N_("Domain controller: LDAP server signing requirements"),
        "desc": N_(
            "This policy setting determines whether the Lightweight Directory"
            " Access Protocol (LDAP) server requires LDAP clients to negotiate"
            " data signing"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Domain controller: LDAP server signing requirements"
            " setting to Require signature"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("None"), "1": N_("require signing")},
    },
    "Domain controller: Allow server operators to schedule tasks": {
        "name": N_("Domain controller: Allow server operators to schedule tasks"),
        "desc": N_(
            "This policy setting determines whether server operators are"
            " allowed to submit jobs by means of the at command. If you enable"
            " this policy setting, jobs that are created by server operators"
            " by means of the at command run in the context of the account"
            " that runs the Task Scheduler service. By default, that is the"
            " Local System account"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Domain controller: Allow server operators to schedule"
            " tasks setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain controller: Refuse machine account password changes": {
        "name": N_("Domain controller: Refuse machine account password changes"),
        "desc": N_(
            "This policy setting enables or disables blocking a domain"
            " controller from accepting password change requests for computer"
            " accounts"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": N_("Not applicable"),
        "expected": " ",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Domain controller: Refuse machine account password"
            " changes setting"
        ),
        "expected_reco": N_(
            " Ensure that this setting conforms to your overall security"
            " policy for the domain."
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "System cryptography: Force strong key protection for user keys stored on the computer": {  # noqa: B950
        "name": N_(
            "System cryptography: Force strong key protection for user keys"
            " stored on the computer"
        ),
        "desc": N_(
            "This policy setting determines whether users can use private"
            " keys, such as their Secure/Multipurpose Internet Mail Extensions"
            " (S/MIME) key, without a password"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the System cryptography: Force strong key protection"
            " for user keys stored on the computer setting to User must enter"
            " a password each time they use a key so that users must provide a"
            " password that is distinct from their domain password every time"
            " they use a key. This configuration makes it more difficult for"
            " an attacker to access locally stored user keys, even if the"
            " attacker takes control of the user's computer and determines the"
            " logon password"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("User input is not required when new keys are stored and used"),
            "1": N_("User is prompted when the key is first used"),
            "2": N_("User must enter a password each time they use a key"),
        },
    },
    "DCOM: Machine access restrictions in security descriptor definition language ,SDLL, syntax": {  # noqa: B950
        "name": N_(
            "DCOM: Machine Access Restrictions in Security Descriptor"
            " Definition Language (SDDL) syntax"
        ),
        "desc": N_(
            "This policy setting allows administrators to define additional"
            " computer-wide controls that govern access to all Distributed"
            " Component Object Model (DCOM)–based applications on a computer."
            " These controls restrict call, activation, or launch requests on"
            " the computer"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "To protect individual COM-based applications or services, set the"
            " DCOM: Machine Access Restrictions in Security Descriptor"
            " Definition Language (SDDL) syntax setting to an appropriate"
            " computer-wide ACL"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "DCOM: Machine launch restrictions in security descriptor definition language ,SDLL, syntax": {  # noqa: B950
        "name": N_(
            "DCOM: Machine Launch Restrictions in Security Descriptor"
            " Definition Language (SDDL) syntax"
        ),
        "desc": N_(" "),
        "location": "",
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "To protect individual COM-based applications or services, set"
            " this policy setting to an appropriate computer-wide ACL"
        ),
        "expected_reco": N_(" "),
    },
    "Domain member: Encrypt secure channel data ,when possible": {
        "name": N_(
            "Domain member: Digitally encrypt secure channel data (when possible)"
        ),
        "desc": N_(
            "This setting determines whether all secure channel traffic that"
            " is initiated by the domain member meets minimum security"
            " requirements. Specifically, it determines whether all secure"
            " channel traffic that is initiated by the domain member must be"
            " encrypted. Logon information that is transmitted over the secure"
            " channel is always encrypted regardless of whether the encryption"
            " of all other secure channel traffic is negotiated"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Select one of the following settings as appropriate for your"
            " environment to configure the computers in your domain to encrypt"
            " or sign secure channel data:\nDomain member: Digitally encrypt"
            " or sign secure channel data (always)\nDomain member: Digitally"
            " encrypt secure channel data (when possible)\nDomain member:"
            " Digitally sign secure channel data (when possible)"
        ),
        "expected_reco": N_(
            "Guarantees that all secure channel traffic is encrypted if the"
            " partner domain controller is also capable of encrypting secure"
            " channel traffic"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain member: Encrypt or sign secure channel data ,always": {
        "name": N_(
            "Domain member: Digitally encrypt or sign secure channel data (always)"
        ),
        "desc": N_(
            "This setting determines whether all secure channel traffic that"
            " is initiated by the domain member meets minimum security"
            " requirements. Specifically, it determines whether all secure"
            " channel traffic that is initiated by the domain member must be"
            " signed or encrypted. Logon information that is transmitted over"
            " the secure channel is always encrypted regardless of whether the"
            " encryption of all other secure channel traffic is negotiated"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Select one of the following settings as appropriate for your"
            " environment to configure the computers in your domain to encrypt"
            " or sign secure channel data:\nDomain member: Digitally encrypt"
            " or sign secure channel data (always)\nDomain member: Digitally"
            " encrypt secure channel data (when possible)\nDomain member:"
            " Digitally sign secure channel data (when possible)"
        ),
        "expected_reco": N_(
            "A secure channel cannot be established with a domain controller"
            " that cannot sign or encrypt all data on the secure channel"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain member: Disable machine account password changes": {
        "name": N_("Domain member: Disable machine account password changes"),
        "desc": N_(
            "The Domain member: Disable machine account password changes"
            " policy setting determines whether a domain member periodically"
            " changes its computer account password"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Verify that the Domain member: Disable machine account password"
            " changes setting is configured to Disabled"
        ),
        "expected_reco": N_(
            "The domain member attempts to change his or her computer account"
            " password as specified by the Domain Member: Maximum Computer"
            " Account Password Anteriority setting"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain member: Require strong ,Windows 2000 or later, session key": {
        "name": N_("Domain member: Require strong (Windows 2000 or later) session key"),
        "desc": N_(
            "The Domain member: Require strong (Windows 2000 or later) session"
            " key policy setting determines whether a secure channel can be"
            " established with a domain controller that is not capable of"
            " encrypting secure channel traffic with a strong, 128-bit"
            " session key"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Domain member: Require strong (Windows 2000 or later)"
            " session key setting.f you enable this policy setting, all"
            " outgoing secure channel traffic requires a strong encryption"
            " key. If you disable this policy setting, the key strength is"
            " negotiated. You should enable this policy setting only if the"
            " domain controllers in all trusted domains support strong keys."
            " By default, this policy setting is disabled"
        ),
        "expected_reco": N_(
            "The secure channel is not established unless 128-bit encryption"
            " can be performed"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain member: Digitally sign secure channel data": {
        "name": N_("Domain member: Digitally sign secure channel data (when possible)"),
        "desc": N_(
            "This setting determines whether all secure channel traffic that"
            " is initiated by the domain member meets minimum security"
            " requirements. Specifically, it determines whether all secure"
            " channel traffic that is initiated by the domain member must be"
            " signed"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Select one of the following settings as appropriate for your"
            " environment to configure the computers in your domain to encrypt"
            " or sign secure channel data:\nDomain member: Digitally encrypt"
            " or sign secure channel data (always)\nDomain member: Digitally"
            " encrypt secure channel data (when possible)\nDomain member:"
            " Digitally sign secure channel data (when possible)"
        ),
        "expected_reco": N_(
            "Guarantees that all traffic on the secure channel is signed if"
            " the partner domain controller is also able to sign all traffic"
            " on the secure channel"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Domain member: Maximum machine account password age": {
        "name": N_("Domain member: Maximum machine account password age"),
        "desc": N_(
            "The Domain member: Maximum machine account password age policy"
            " setting determines the maximum allowable age for a computer"
            " account password"
        ),
        "default_dc": ("30"),
        "default_server": ("30"),
        "default_workgroup": ("30"),
        "expected": ("30"),
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Domain member: Maximum machine account password age"
            " setting to 30 days"
        ),
        "expected_reco": N_("days"),
    },
    "System objects: Require case insensitivity for non-Windows subsystems": {
        "name": N_(
            "System objects: Require case insensitivity for non-Windows subsystems"
        ),
        "desc": N_(
            "This policy setting determines whether case insensitivity is"
            " enforced for all subsystems. The Microsoft Win32 subsystem is"
            " not case sensitive; however, the kernel supports case"
            " sensitivity for other subsystems, such as Portable Operating"
            " System Interface for UNIX (POSIX)"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the System objects: Require case insensitivity for"
            " non-Windows subsystems setting"
        ),
        "expected_reco": N_("All directory objects"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "System objects: Strengthen default permissions of internal system objects ,e.g. Symbolic Links": {  # noqa: B950
        "name": N_(
            "System objects: Strengthen default permissions of internal system"
            " objects (e.g. Symbolic Links)"
        ),
        "desc": N_(
            "This policy setting determines the strength of the default"
            " discretionary access control list (DACL) for objects. Windows"
            " Server 2003 maintains a global list of shared system resources"
            " such as MS-DOS device names, mutexes, and semaphores"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the System objects: Strengthen default permissions of"
            " global system objects (for example, Symbolic Links) setting"
        ),
        "expected_reco": N_("Strengthen the default DACL"),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Interactive logon: Require smart card": {
        "name": N_("Interactive logon: Require smart card"),
        "desc": N_(
            "The Interactive logon: Require smart card policy setting requires"
            " users to log on to a computer by using a smart card"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "For users with access to computers that contain sensitive data,"
            " issue smart cards to users and configure the Interactive logon:"
            " Require smart card setting to Enabled"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("Disabled"),
            "1": N_("Enabled (if smart card authentication) otherwise Disabled"),
        },
    },
    "Interactive logon: Smart card removal behavior": {
        "name": N_("Interactive logon: Smart card removal behavior"),
        "desc": N_(
            "This policy setting determines what happens when the smart card"
            " for a logged-on user is removed from the smart card reader"
        ),
        "location": "",
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Smart card removal behavior"
            " setting to Lock Workstation. If you select Lock Workstation for"
            " this policy setting, the workstation locks when the smart card"
            " is removed. Users can leave the area, take their smart card with"
            " them, and still maintain a protected session. This behavior is"
            " similar to the setting that requires users to log on when"
            " resuming work on the computer after the screen saver has"
            " started. If you select Force Logoff for this policy setting, the"
            " user is automatically logged off when the smart card is removed."
            " This setting is useful when a computer is deployed as a public"
            " access point, such as a kiosk or other type of shared computer"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("No Action"),
            "1": N_("Lock Workstation"),
            "2": N_("Force Logoff"),
            "3": N_("Disconnect if a Remote Desktop Services session"),
        },
    },
    "Interactive logon: Message text for users attempting to log on": {
        "name": N_("Interactive logon: Message text for users attempting to log on"),
        "desc": N_(
            "The Interactive logon: Message text for users attempting to log"
            " on and Interactive logon: Message title for users attempting to"
            " log on policy settings are closely related. Interactive logon:"
            " Message text for users attempting to log on specifies a text"
            " message to be displayed to users when they log on. Interactive"
            " logon: Message title for users attempting to log on specifies a"
            " title to appear in the title bar of the window that contains the"
            " text message"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": "Message text",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Message text for users"
            " attempting to log on and Interactive logon: Message title for"
            " users attempting to log on settings to an appropriate value for"
            " your organization"
        ),
        "expected_reco": N_(" "),
    },
    "Interactive logon: Do not display last user name": {
        "name": N_("Interactive logon: Do not display last user name"),
        "desc": N_(
            "This security setting determines whether the name of the last"
            " user to log on to the computer is displayed on the Secure"
            " Desktop"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Interactive logon: Do not display last user name setting"
        ),
        "expected_reco": N_(
            "The name of the last user to successfully log in is not"
            " displayed. The display of the last user name can be used by an"
            " attacker to identify the naming convention of users or"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Interactive logon: o not require CTRL+ALT+DEL": {
        "name": N_("Interactive logon: Do not require CTRL+ALT+DEL"),
        "desc": N_(
            "This security setting determines whether pressing CTRL+ALT+DEL is"
            " required before a user can log on"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Interactive logon: Do not require CTRL+ALT+DEL setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Interactive logon: Require Domain Controller authentication to unlock workstation": {  # noqa: B950
        "name": N_(
            "Interactive logon: Require Domain Controller authentication to"
            " unlock workstation"
        ),
        "desc": N_(
            "Unlocking a locked computer requires logon information. For"
            " domain accounts, the Interactive logon: Require Domain"
            " Controller authentication to unlock workstation policy setting"
            " determines whether it is necessary to contact a domain"
            " controller to unlock a computer. Enabling this policy setting"
            " requires a domain controller to authenticate the domain account"
            " that is being used to unlock the computer"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Require Domain Controller"
            " authentication to unlock workstation setting to Enabled and"
            " configure the Interactive logon: Number of previous logons to"
            " cache (in case domain controller is not available) setting to 0"
        ),
        "expected_reco": N_(
            "A domain controller must authenticate the domain account that is"
            " used to unlock the computer. Portable or mobile workstations:"
            " Disabled"
        ),
        "value": {
            "0": N_("Disabled"),
            "1": N_("Fixed workstations : Enabled"),
        },
    },
    "Interactive logon: Prompt user to change password before expiration": {
        "name": N_(
            "Interactive logon: Prompt user to change password before expiration"
        ),
        "desc": N_(
            "The Interactive logon: Prompt user to change password before"
            " expiration policy setting determines how many days in advance"
            " users are warned that their passwords are about to expire"
        ),
        "default_dc": ("14"),
        "default_server": ("14"),
        "default_workgroup": ("14"),
        "expected": ("14"),
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Prompt user to change password"
            " before expiration setting to 14 days"
        ),
        "expected_reco": N_("days"),
    },
    "Interactive logon: Message title for users attempting to log on": {
        "name": N_("Interactive logon: Message title for users attempting to log on"),
        "desc": N_(
            "This security setting allows you to specifiy a title that appears"
            " in the title bar of the window that contains the Interactive"
            " logon: Message text for users attempting to log on. This text is"
            " often used for legal reasons—for example, to warn users about"
            " the ramifications of misusing company information, or to warn"
            " them that their actions might be audited"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": "Message title",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Message text for users"
            " attempting to log on and Interactive logon: Message title for"
            " users attempting to log on settings to an appropriate value for"
            " your organization"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Interactive logon: Number of previous logons to cache, in case domain controller is not available": {  # noqa: B950
        "name": N_(
            "Interactive logon: Number of previous logons to cache (in case"
            " domain controller is not available)"
        ),
        "desc": N_(
            "The Interactive logon: Number of previous logons to cache (in"
            " case domain controller is not available) policy setting"
            " determines whether a user can log on to a Windows domain by"
            " using cached account information. Logon information for domain"
            " accounts can be cached locally so that, if a domain controller"
            " cannot be contacted on subsequent logons, a user can still"
            " log on"
        ),
        "default_dc": N_("10 logons"),
        "default_server": N_("10 logons"),
        "default_workgroup": N_("10 logons"),
        "expected": " ",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Interactive logon: Number of previous logons to"
            " cache (in case domain controller is not available) setting to 0,"
            " which disables the local caching of logon information."
            " Additional countermeasures include enforcement of strong"
            " password policies and physically secure locations for the"
            " computers"
        ),
        "expected_reco": N_(
            "Trusted networks and fixed workstations: 0 to disable"
            " caching\nMobile workstations: 1 log-in if not shared, otherwise"
            " 2 or 3"
        ),
    },
    "Interactive logon: Machine inactivity limit": {
        "name": N_("Interactive logon: Machine inactivity limit"),
        "desc": N_(
            "Windows détecte l’inactivité de l’entrée utilisateur d’une"
            " session de connexion (ouverture de session) à l’aide du"
            " paramètre de stratégie de sécurité connexion interactive: limite"
            " d’inactivitéde l’ordinateur"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Set the time for elapsed user-input inactivity time by using the"
            " security policy setting Interactive logon: Machine inactivity"
            " limit based on the computer’s usage and location requirements"
        ),
        "expected_reco": N_(" "),
    },
    "Interactive logon: Machine account lockout threshold": {
        "name": N_("Interactive logon: Machine account lockout threshold"),
        "desc": N_(
            "The security setting allows you to set a threshold for the number"
            " of failed logon attempts that causes the computer or device to"
            " be locked by using BitLocker"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Use this policy setting in conjunction with your other failed"
            " account logon attempts policy. For example, if the Account"
            " lockout threshold policy setting is set at 4, then setting"
            " Interactive logon: Machine account lockout threshold at 6 allows"
            " the user to restore access to resources without having to"
            " restore access to the computer or device resulting from a"
            " BitLocker lock out"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "System settings: Optional subsystems": {
        "name": N_("System settings: Optional subsystems"),
        "desc": N_(
            "This policy setting determines which subsystems support your"
            " applications. You can use this security setting to specify as"
            " many subsystems as your environment demands"
        ),
        "default_dc": "POSIX",
        "default_server": "POSIX",
        "default_workgroup": "POSIX",
        "expected": N_("Define subsystems used"),
        "applied": N_(" "),
        "analyze": N_(
            "Configure the System settings: Optional subsystems setting to a"
            " null value. The default value is POSIX"
        ),
        "expected_reco": N_(" "),
    },
    "System settings: Use certificate rules on Windows Executables for Software restriction policies": {  # noqa: B950
        "name": N_(
            "System settings: Use Certificate Rules on Windows Executables for"
            " Software Restriction Policies"
        ),
        "desc": N_(
            "This policy setting determines whether digital certificates are"
            " processed when software restriction policies are enabled and a"
            " user or process attempts to run software with an .exe file name"
            " extension"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the System settings: Use Certificate Rules on Windows"
            " Executables for Software Restriction Policies setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Devices:Restrict CD-ROM access to locally logged-on user only": {
        "name": N_("Devices: Restrict CD-ROM access to locally logged-on user only"),
        "desc": N_(
            "This policy setting determines whether a CD is accessible to"
            " local and remote users simultaneously"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Devices: Restrict CD-ROM drive access to locally"
            " logged-on user only setting"
        ),
        "expected_reco": N_(
            "Allows only the user who has performed an interactive login to"
            " access the removable CD-ROM media"
        ),
        "value": {"0": "Disabled", "1": "Enabled"},
    },
    "Devices: Allow undock without having to log on": {
        "name": N_("Devices: Allow undock without having to log on"),
        "desc": N_(
            "This policy setting enables or disables the ability of a user to"
            " remove a portable computer from a docking station without"
            " logging on"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Disable the Devices: Allow undock without having to log on setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Devices: Prevent users from installing printer drivers": {
        "name": N_("Devices: Prevent users from installing printer drivers"),
        "desc": N_(
            "The Devices: Prevent users from installing printer drivers policy"
            " setting determines who can install a printer driver as part of"
            " adding a network printer"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Devices: Prevent users from installing printer drivers"
            " setting"
        ),
        "expected_reco": N_(
            "Only Administrators can install a printer driver when connecting"
            " to a shared printer"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Devices: Restrict floppy access to locally logged-on user only": {
        "name": N_("Devices: Restrict floppy access to locally logged-on user only"),
        "desc": N_(
            "This policy setting determines whether removable floppy disks are"
            " accessible to local and remote users simultaneously"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Devices: Restrict floppy access to locally logged-on"
            " user only setting"
        ),
        "expected_reco": N_(
            "Allows only the interactively logged-in user to access removable media"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Devices: Allowed to format and eject removable media": {
        "name": N_("Devices: Allowed to format and eject removable media"),
        "desc": N_(
            "This policy setting determines who is allowed to format and eject"
            " removable media"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": ".",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Devices: Allowed to format and eject removable"
            " media setting to Administrators"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("Administrators"),
            "1": N_("Administrators and Power Users"),
            "2": N_("Administrators and Interactive Users"),
        },
    },
    "Network security: LDAP client signing requirements": {
        "name": N_("Network security: LDAP client signing requirements"),
        "desc": N_(
            "This policy setting determines the level of data signing that is"
            " requested on behalf of client computers that issue LDAP BIND"
            " requests"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Network security: LDAP server signing requirements"
            " setting to Require signature"
        ),
        "expected_reco": N_(
            "The default value of this parameter makes signature negotiation"
            " mandatory before a client can connect to an Active Directory"
            " LDAP server"
        ),
        "value": {
            "0": N_("None"),
            "1": N_("Negotiate signing"),
            "2": N_("Require signing"),
        },
    },
    "Network security: Force logoff when logon hours expire": {
        "name": N_("Network security: Force logoff when logon hours expire"),
        "desc": N_(
            "This security setting determines whether to disconnect users who"
            " are connected to the local computer outside their user account's"
            " valid logon hours. This setting affects the Server Message Block"
            " (SMB) component"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network security: Force logoff when logon hours expire"
            " setting. This policy setting does not apply to administrator"
            " accounts"
        ),
        "expected_reco": N_(
            "Client sessions established with the SMB server are forced to"
            " disconnect when client session time expires"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network security: Do not store LAN Manager hash value on next password change": {
        "name": N_(
            "Network security: Do not store LAN Manager hash value on next"
            " password change"
        ),
        "desc": N_(
            "This policy setting determines whether LAN Manager is prevented"
            " from storing hash values for the new password the next time the"
            " password is changed"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Network security: Do not store LAN Manager hash value"
            " on next password change setting. Require all users to set new"
            " passwords the next time they log on to the domain so that LAN"
            " Manager hashes are removed"
        ),
        "expected_reco": N_(
            "The LAN Manager hash is relatively weak and vulnerable to attacks"
            " compared to the Windows NT hash"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network security: LAN Manager authentication level": {
        "name": N_("Network security: LAN Manager authentication level"),
        "desc": N_(
            "This policy setting determines which challenge or response"
            " authentication protocol is used for network logons. LAN Manager"
            " (LM) includes client computer and server software from Microsoft"
            " that allows users to link personal computers together on a"
            " single network"
        ),
        "default_dc": "3",
        "default_server": "3",
        "default_workgroup": ".",
        "expected": "5",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the Network security: LAN Manager Authentication Level"
            " setting to Send NTLMv2 responses only. Microsoft and a number of"
            " independent organizations strongly recommend this level of"
            " authentication when all client computers support NTLMv2"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("Send LM & NTLM responses"),
            "1": N_("Send LM & NTLM - use NTLMv2 session security if negotiated"),
            "2": N_("Send LM & NTLM responses only"),
            "3": N_("Send NTLMv2 response only"),
            "4": N_("Send NTLMv2 response only, Refuse LM"),
            "5": N_("Send NTLMv2 response only, Refuse LM & NTLM"),
        },
    },
    "Network security: Minimum session security for NTLM SSP based clients": {
        "name": N_(
            "Network security: Minimum session security for NTLM SSP based"
            " (including secure RPC) clients"
        ),
        "desc": N_(
            "This policy setting allows a client computer to require the"
            " negotiation of 128-bit encryption or NTLMv2 session security."
            " These values are dependent on the Network security: LAN Manager"
            " Authentication Level policy setting value"
        ),
        "default_dc": "536870912",
        "default_server": "536870912",
        "default_workgroup": "536870912",
        "expected": "537395200",
        "applied": N_(" "),
        "analyze": N_(
            "Enable all options that are available for the Network security:"
            " Minimum session security for NTLM SSP based (including secure"
            " RPC) clients policy setting"
        ),
        "expected_reco": N_(" "),
        "value": {
            "536870912": "Require 128-bit encryption,",
            "524288": "Require NTLMv2 session security",
            "537395200": (
                "Require NTLMv2 session security,\nRequire 128-bit encryption"
            ),
        },
    },
    "Network security: Minimum session security for NTLM SSP based servers": {
        "name": N_(
            "Network security: Minimum session security for NTLM SSP based"
            " (including secure RPC) servers"
        ),
        "desc": N_(
            "This policy setting allows a client computer to require the"
            " negotiation of 128-bit encryption or NTLMv2 session security."
            " These values are dependent on the Network security: LAN Manager"
            " Authentication Level policy setting value"
        ),
        "default_dc": "536870912",
        "default_server": "536870912",
        "default_workgroup": "536870912",
        "expected": "537395200",
        "applied": N_(" "),
        "analyze": N_(
            "Enable all options that are available for the Network security:"
            " Minimum session security for NTLM SSP based (including secure"
            " RPC) servers policy setting"
        ),
        "expected_reco": N_(" "),
        "value": {
            "536870912": "Require 128-bit encryption,",
            "524288": "Require NTLMv2 session security",
            "537395200": (
                "Require NTLMv2 session security,\nRequire 128-bit encryption"
            ),
        },
    },
    "Network security: Allow LocalSystem NULL session fallback": {
        "name": N_("Network security: Allow LocalSystem NULL session fallback"),
        "desc": N_(
            "The setting Network security: Allow LocalSystem NULL session"
            " fallback determines whether services that request the use of"
            " session security are allowed to perform signature or encryption"
            " functions with a well-known key for application compatibility"
        ),
        "default_dc": N_("Not applicable"),
        "default_server": N_("Not applicable"),
        "default_workgroup": N_("Not applicable"),
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "You can configure the computer to use the computer identity for"
            " Local System with the policy Network security: Allow Local"
            " System to use computer identity for NTLM"
        ),
        "expected_reco": N_(
            "The use of NULL sessions by system services using the"
            " SystèmeLocal account implies that the data exchanged is not"
            " protected (neither encryption nor reliable signature). It is"
            " preferable that the services concerned always use the identity"
            " of the computer and not a NULL session"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network security: Allow PKU2U authentication requests to this computer to use online identities": {  # noqa: B950
        "name": N_(
            "Network Security: Allow PKU2U authentication requests to this"
            " computer to use online identities"
        ),
        "desc": N_(
            "This extension SSP is treated as an authentication protocol by"
            " the Windows operating system, and it supports SSPs from"
            " Microsoft, including PKU2U"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "Set this policy to Disabled or do not configure this security"
            " policy for domain-joined computers"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network security: Allow Local System to use computer identity for NTLM": {
        "name": N_(
            "Network security: Allow Local System to use computer identity for NTLM"
        ),
        "desc": N_(
            "When a service connects with the computer identity, signing and"
            " encryption are supported to provide data protection"
        ),
        "default_dc": N_("Not applicable"),
        "default_server": N_("Not applicable"),
        "default_workgroup": ".",
        "expected": "0",
        "applied": N_(" "),
        "analyze": N_(
            "You can configure the Network security: Allow Local System to use"
            " computer identity for NTLM security policy setting to allow"
            " Local System services that use Negotiate to use the computer"
            " identity when reverting to NTLM authentication"
        ),
        "expected_reco": N_(
            "Local System services that use the Negotiate option when"
            " returning to NTLM authentication will authenticate anonymously"
        ),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Network security: Configure encryption types allowed for Kerberos": {
        "name": N_("Network security: Configure encryption types allowed for Kerberos"),
        "desc": N_(
            "This policy setting allows you to set the encryption types that"
            " the Kerberos protocol is allowed to use. If it is not selected,"
            " the encryption type will not be allowed. This setting might"
            " affect compatibility with client computers or services and"
            " applications. Multiple selections are permitted"
        ),
        "default_dc": N_(
            "None of these encryption types that are available in this policy"
            " are allowed"
        ),
        "default_server": N_(
            "None of these encryption types that are available in this policy"
            " are allowed"
        ),
        "default_workgroup": N_(
            "None of these encryption types that are available in this policy"
            " are allowed"
        ),
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Do not configure this policy. This will force the computers"
            " running Windows Server 2008 R2 and Windows 7 to use the AES or"
            " RC4 cryptographic suites"
        ),
        "expected_reco": N_("To be configured on the Domain Controller"),
        "value": {
            "2147483650": "RC4_HMAC (40 bits)",
            "2147483648": "Futur encryption types",
            "18": "AES256_CTS_HMAC_SHA1_96",
            "16": "AES128_CTS_HMAC_SHA1_96",
            "2": "DES_CBC_MD5",
            "1": "DES_CBC_CRC",
        },
    },
    "Network security: Restrict NTLM:Add server exceptions in this domain": {
        "name": N_(
            "Network security: Restrict NTLM: Add server exceptions in this domain"
        ),
        "desc": N_(
            "The Network security: Restrict NTLM: Add server exceptions in"
            " this domain policy setting allows you to create an exception"
            " list of servers in this domain to which client computers are"
            " allowed to use NTLM pass-through authentication if any of the"
            " deny options are set in the Network Security: Restrict NTLM:"
            " NTLM authentication in this domain policy setting"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "When you use Network Security: Restrict NTLM: NTLM authentication"
            " in this domain in audit-only mode, you can determine by"
            " reviewing which client applications are making NTLM"
            " authentication requests to the pass-through authentication"
            " servers. When assessed, you will have to determine on a"
            " case-by-case basis if NTLM authentication still minimally meets"
            " your security requirements"
        ),
        "expected_reco": N_("To be configured on the Domain Controller"),
    },
    "Network security: Restrict NTLM:Add remote server exceptions for NTLM authentication": {  # noqa: B950
        "name": N_(
            "Network security: Restrict NTLM: Add remote server exceptions for"
            " NTLM authentication"
        ),
        "desc": N_(
            "The Network security: Restrict NTLM: Add server exceptions for"
            " NTLM authentication policy setting allows you to create an"
            " exception list of remote servers to which client computers are"
            " allowed to use NTLM authentication if the Network Security:"
            " Restrict NTLM: Outgoing NTLM traffic to remote servers policy"
            " setting is configured"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "When you use Network Security: Restrict NTLM: Outgoing NTLM"
            " traffic to remote servers in audit-only mode, you can determine"
            " by reviewing which client applications are making NTLM"
            " authentication requests to the remote servers in your"
            " environment. When assessed, you will have to determine on a"
            " case-by-case basis if NTLM authentication still minimally meets"
            " your security requirements. If not, the client application has"
            " to be upgraded to use something other than NTLM authentication"
        ),
        "expected_reco": N_("To be configured on the Domain Controller"),
    },
    "Network security: Restrict NTLM: Audit NTLM authentication in this domain": {
        "name": N_(
            "Network Security: Restrict NTLM: Audit NTLM authentication in"
            " this domain"
        ),
        "desc": N_(
            "The Network Security: Restrict NTLM: Audit NTLM authentication in"
            " this domain policy setting allows you to audit on the domain"
            " controller NTLM authentication in that domain"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Restrict access to the log files when this policy setting is"
            " enabled in your production environment"
        ),
        "expected_reco": N_("To be configure on domain controller"),
        "value": {
            "0": N_("Disable"),
            "1": N_("Enable for domain accounts to domain servers"),
            "2": N_("Enable for domain accounts"),
            "3": N_("Enable for domain server"),
            "4": N_("Enable for all"),
        },
    },
    "Network security: Restrict NTLM: Audit Incoming NTLM Traffic": {
        "name": N_("Network Security: Restrict NTLM: Audit Incoming NTLM Traffic"),
        "desc": N_(
            "The Network Security: Restrict NTLM: Audit Incoming NTLM Traffic"
            " policy setting allows you to audit incoming NTLM traffic"
        ),
        "location": "",
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "Restrict access to the log files when this policy setting is"
            " enabled in your production environment"
        ),
        "expected_reco": N_("To be configure on domain controller"),
        "value": {
            "0": N_("Disable"),
            "1": N_("Enable auditing for domain accounts"),
            "2": N_("Enable auditing for all accounts"),
        },
    },
    "Network security: Restrict NTLM: NTLM authentication in this domain": {
        "name": N_(
            "Network Security: Restrict NTLM: NTLM authentication in this domain"
        ),
        "desc": N_(
            "The Network Security: Restrict NTLM: NTLM authentication in this"
            " domain policy setting allows you to deny or allow NTLM"
            " authentication within a domain from this domain controller"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "When it has been determined that the NTLM authentication protocol"
            " should not be used within a network because you are required to"
            " use a more secure protocol such as the Kerberos protocol, then"
            " you can select one of several options that this security policy"
            " setting offers to restrict NTLM usage within the domain"
        ),
        "expected_reco": N_("To be configure on domain controller"),
        "value": {
            "0": N_("Disable"),
            "1": N_("Deny for domain accounts to domain servers"),
            "2": N_("Deny for domain accounts"),
            "3": N_("Deny for domain server"),
            "4": N_("Deny for all"),
        },
    },
    "Network security: Restrict NTLM: Incoming NTLM Traffic": {
        "name": N_("Network Security: Restrict NTLM: Incoming NTLM Traffic"),
        "desc": N_(
            "The Network Security: Restrict NTLM: Incoming NTLM Traffic policy"
            " setting allows you to deny or allow incoming NTLM traffic from"
            " client computers, other member servers, or a domain controller"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "When it has been determined that the NTLM authentication protocol"
            " should not be used within a network because you are required to"
            " use a more secure protocol such as Kerberos, you can select one"
            " of several options that this security policy setting offers to"
            " restrict NTLM usage"
        ),
        "expected_reco": N_("To be configure on domain controller"),
        "value": {
            "0": N_("Allow all"),
            "1": N_("Deny all domain accounts"),
            "2": N_("Deny all accounts"),
        },
    },
    "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers": {
        "name": N_(
            "Network Security: Restrict NTLM: Outgoing NTLM traffic to remote"
            " servers"
        ),
        "desc": N_(
            "The Network Security: Restrict NTLM: Outgoing NTLM traffic to"
            " remote servers policy setting allows you to deny or audit"
            " outgoing NTLM traffic from a computer running Windows 7 or"
            " Windows Server 2008 R2 to any remote server running the Windows"
            " operating system"
        ),
        "default_dc": ".",
        "default_server": ".",
        "default_workgroup": ".",
        "expected": ".",
        "applied": N_(" "),
        "analyze": N_(
            "When it has been determined that the NTLM authentication protocol"
            " should not be used within a network because you are required to"
            " use a more secure protocol such as Kerberos, then you can select"
            " from several options to restrict NTLM usage to servers"
        ),
        "expected_reco": N_("To be configure on domain controller"),
        "value": {
            "0": N_("Allow all"),
            "1": N_("Audit all"),
            "2": N_("Deny all"),
        },
    },
    "Microsoft network server: Digitally sign communications ,if server agrees": {
        "name": N_(
            "Microsoft network server: Digitally sign communications (if"
            " client agrees)"
        ),
        "desc": N_(
            "This policy setting determines whether SMB packet signing must be"
            " negotiated before further communication with the Server service"
            " is permitted"
        ),
        "default_dc": "1",
        "default_server": ".",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the settings as follows:\nDisable Microsoft Network"
            " Client: Digitally Sign Communications (Always)\nDisable"
            " Microsoft Network Server: Digitally Sign Communications"
            " (Always)\nEnable Microsoft Network Client: Digitally Sign"
            " Communications (If Server Agrees)\nEnable Microsoft Network"
            " Server: Digitally Sign Communications (If Client Agrees)\nIn"
            " highly secure environments we recommend that you configure all"
            " of these settings to Enabled. However, that configuration may"
            " cause slower performance on client computers and prevent"
            " communications with earlier SMB applications and operating"
            " systems"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Microsoft network server: Digitally sign communications ,always": {
        "name": N_("Microsoft network server: Digitally sign communications (always)"),
        "desc": N_(
            "This policy setting determines whether SMB packet signing must be"
            " negotiated before further communication with the Server service"
            " is permitted"
        ),
        "default_dc": "1",
        "default_server": ".",
        "default_workgroup": "0",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Configure the settings as follows:\nDisable Microsoft Network"
            " Client: Digitally Sign Communications (Always)\nDisable"
            " Microsoft Network Server: Digitally Sign Communications"
            " (Always)\nEnable Microsoft Network Client: Digitally Sign"
            " Communications (If Server Agrees)\nEnable Microsoft Network"
            " Server: Digitally Sign Communications (If Client Agrees)\nIn"
            " highly secure environments we recommend that you configure all"
            " of these settings to Enabled. However, that configuration may"
            " cause slower performance on client computers and prevent"
            " communications with earlier SMB applications and operating"
            " systems"
        ),
        "expected_reco": N_(" "),
    },
    "Microsoft network server: Disconnect clients when logon hours expire": {
        "name": N_(
            "Microsoft network server: Disconnect clients when logon hours expire"
        ),
        "desc": N_(
            "This policy setting enables or disables the forced disconnection"
            " of users who are connected to the local computer outside their"
            " user account's valid logon hours"
        ),
        "default_dc": "1",
        "default_server": "1",
        "default_workgroup": "1",
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "Enable the Microsoft network server: Disconnect clients when"
            " logon hours expire setting"
        ),
        "expected_reco": N_(" "),
        "value": {"0": N_("Disabled"), "1": N_("Enabled")},
    },
    "Microsoft network server: Amount of idle time required before suspending session": {  # noqa: B950
        "name": N_(
            "Microsoft network server: Amount of idle time required before"
            " suspending session"
        ),
        "desc": N_(
            "The Microsoft network server: Amount of idle time required before"
            " suspending session policy setting determines the amount of"
            " continuous idle time that must pass in an SMB session before the"
            " session is suspended due to inactivity"
        ),
        "default_dc": N_("15"),
        "default_server": N_("15"),
        "default_workgroup": N_("15"),
        "expected": N_("15"),
        "applied": N_(" "),
        "analyze": N_(
            "The default behavior on a server mitigates this threat by design"
            " in Windows Server 2003 and later"
        ),
        "expected_reco": N_("minutes"),
    },
    "Microsoft network server: Server SPN target name validation level": {
        "name": N_("Microsoft network server: Server SPN target name validation level"),
        "desc": N_(
            "This policy setting controls the level of validation that a"
            " server with shared folders or printers performs on the service"
            " principal name (SPN) that is provided by the client computer"
            " when the client computer establishes a session by using the"
            " Server Message Block (SMB) protocol"
        ),
        "default_dc": N_("Validation level check not implemented"),
        "default_server": N_("Validation level check not implemented"),
        "default_workgroup": N_("Validation level check not implemented"),
        "expected": "1",
        "applied": N_(" "),
        "analyze": N_(
            "For countermeasures that are appropriate to your environment, see"
            " Possible values above"
            " :\nhttps://docs.microsoft.com/en-us"
            "/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012"
            "/jj852272(v=ws.11)"
        ),
        "expected_reco": N_(" "),
        "value": {
            "0": N_("Off"),
            "1": N_("Accept if provided by client"),
            "2": N_("Required from client"),
        },
    },
    "Microsoft network server: Attempt S4U2Self to obtain claim information": {
        "name": N_(
            "Microsoft network server: Attempt S4U2Self to obtain claim information"
        ),
        "desc": N_(
            "This setting determines whether the local file server will"
            " attempt to use Kerberos Service-for-User-to-Self (S4U2Self)"
            " functionality to obtain a network client principal’s claims from"
            " the client’s account domain"
        ),
        "default_dc": "0",
        "default_server": "0",
        "default_workgroup": "0",
        "expected": " ",
        "applied": N_(" "),
        "analyze": N_("Not applicable"),
        "expected_reco": N_(
            "This setting should be set to Default so that the file server can"
            " automatically evaluate whether claims are needed for the user."
            " You should explicitly configure this setting to Enabled only if"
            " there are local file access policies that include user claims."
        ),
        "value": {"0": N_("Default"), "1": N_("Enabled"), "2": N_("Disabled")},
    },
}
