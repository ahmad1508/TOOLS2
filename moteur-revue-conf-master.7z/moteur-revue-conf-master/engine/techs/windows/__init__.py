# -*- coding: utf-8 -*-

"""Load the Windows filters"""

# Project imports
import engine.techs.windows.filters
