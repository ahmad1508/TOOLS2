# -*- coding: UTF-8 -*-
# Standard libraries
import re

# Project imports
from engine.bbcode import Markup as M
from engine.core import i18n
from engine.techs.common import separator2table

# I18N
_ = i18n.domain("windows")._
M_ = i18n.domain("windows").M_
pgettext = i18n.domain("windows").pgettext


def parse_ntfs_permissions(entries):
    rights = {
        "F": "Full access",
        "M": "Modify access",
        "RX": "Read and execute access",
        "R": "Read-only access",
        "W": "Write-only access",
        "D": "Delete",
        "RC": "Read control",
        "WDAC": "Write DAC",
        "WO": "Write owner",
        "S": "Synchronize",
        "AS": "Access system security",
        "MA": "Maximum allowed",
        "GR": "Generic read",
        "GW": "Generic write",
        "GE": "Generic execute",
        "GA": "Generic all",
        "RD": "Read data/list directory",
        "WD": "Write data/add file",
        "AD": "Append data/add subdirectory",
        "REA": "Read extended attributes",
        "WEA": "Write extended attributes",
        "X": "Execute/traverse",
        "DC": "Delete child",
        "RA": "Read attributes",
        "WA": "Write attributes",
        #        "OI": "Object inherit",
        #        "CI": "Container inherit",
        #        "IO": "Inherit only",
        #        "NP": "Do not propagate inherit"
    }
    perm = {}
    for entry in [e for e in entries if len(e.split(":")) == 2]:
        to_treat = entry.split(":")
        if to_treat[0] not in perm.keys():
            perm[to_treat[0]] = []

        for p in [d for d in to_treat[1].split(")") if d]:
            key = p.replace("(", "")
            if "," in key:
                for k in key.split(","):
                    if k in rights and not rights[k] in perm[to_treat[0]]:
                        perm[to_treat[0]].append(rights[k])
            elif key in rights and not rights[key] in perm[to_treat[0]]:
                perm[to_treat[0]].append(rights[key])

    result = ""
    for k in perm:
        if perm[k]:
            result += k + ":\n"
        for v in perm[k]:
            result += "        " + v + "\n"
    return result


def parse_default_network(extract, db):
    re_param = re.compile(r"[^()]+\(([\w\.]+)\)")

    data = separator2table(extract, ":", "\r\n")

    row = M(
        "[table][title]"
        + _("network parameters")
        + "[/title][tr][th]"
        + _("Registry key")
        + "[/th][th]"
        + _("Default value")
        + "[/th][th]"
        + _("Recommanded value")
        + "[/th][th]"
        + _("Current value")
        + "[/th][/tr]"
    )
    for line in data:
        if 2 <= len(line):
            match = re_param.match(line[0])
            if match:
                param = match.group(1)
                value = db.get(param)
                if value:
                    if line[1] == " .":
                        val = M_("Not configured")
                    else:
                        val = line[1]
                    row += format_registry_key(value, val)
    return row + M("[/table]")


def format_registry_key(entry, val):
    template = M(
        """
    [tr]
    [td]{name:}[/td]
    [td]{default:}[/td]
    [td]{expected:}[/td]
    [td]{current:}[/td]
    [/tr]
    """
    )

    return template.format(
        name=entry.get("name"),
        default=entry.get("default"),
        expected=entry.get("expected"),
        current=val,
    )


def format_network_share(entry):
    template = M(
        """
    [tr]
    [td]{name:}[/td]
    [td]{desc:}[/td]
    [td]{path:}[/td]
    [td]{ntfs:}[/td]
    [td]{share:}[/td]
    [/tr]
    """
    )

    return template.format(
        name=entry.get("Name"),
        desc=entry.get(" Description"),
        path=entry.get(" Path"),
        ntfs=parse_ntfs_permissions(entry.get("NTFS ACL")),
        share="\n".join(entry.get("Share ACL")),
    )
