#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Standard libraries
import json

# open json file to parse and clean
with open("techs/windows/data/filter_user_right.json", "r") as json_file:
    data_in = json.load(json_file)

# initialize json output
