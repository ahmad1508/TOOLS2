#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""CLI interface

This module handle the CLI part of the engine and do the interface
with the core engine
"""

# Standard libraries
import argparse
import sys

# Project imports
from engine import logger
from engine.core.engine import Engine, InvalidArgumentException


def get_parser():
    """Create the option parser"""
    parser = argparse.ArgumentParser(
        description=(
            "Prend en entrée des extracts et la technologie utilisée "
            "(Linux, VMware, etc.) et génère la plateforme d'audit "
            "correspondante."
        ),
    )
    # Add self-sufficient actions
    action_group = parser.add_mutually_exclusive_group(required=False)
    action_group.add_argument(
        "--list-techs",
        help="liste les technologies supportées par le moteur",
        action="store_true",
    )
    action_group.add_argument(
        "--list-templates",
        help=(
            "liste les templates et langues supportés la technologie définie "
            "par --type ou toutes les technologie si --type n’est pas spécifié"
        ),
        action="store_true",
    )
    action_group.add_argument(
        "--list-formats",
        help="liste les formats de sortie supportés par le moteur",
        action="store_true",
    )
    # Add arguments to run the engine
    parser.add_argument(
        "--type",
        "-t",
        help="type de technologie à utiliser",
        metavar="TYPE",
        choices=Engine.get_available_techs(),
    )
    parser.add_argument(
        "--input",
        "-i",
        help=(
            "fichiers d'extraction à analyser. Chaque chemin de fichier peut "
            "être précédé par un nom et séparé par un égal (=). Si le chemin "
            "comporte un égal, et que vous ne souhaitez pas de nom, il faut "
            "faire commencer le chemin par égal (c’est-à-dire avoir un nom "
            "vide)."
        ),
        metavar="[NAME=]PATH",
        nargs="+",
    )
    parser.add_argument(
        "--output",
        "-o",
        help="chemin du fichier de sortie",
    )
    parser.add_argument(
        "--format",
        "-f",
        metavar="FORMAT",
        help="type de fichier de sortie",
        choices=[a for b in Engine.get_available_formats() for a in b],
    )
    parser.add_argument(
        "--language",
        "-l",
        metavar="LANG",
        help="langue du rapport de sortie",
        choices=Engine.get_available_languages(),
    )
    parser.add_argument(
        "--template",
        "-m",
        help="template du rapport de sortie",
    )
    parser.add_argument(
        "--timing",
        "-T",
        help="afficher des statistiques de temps",
        action="store_true",
    )
    verb_grp = parser.add_mutually_exclusive_group()
    verb_grp.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="suppress output",
    )
    verb_grp.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="increase verbosity",
    )
    return parser


def list_techs():
    """Manage action for the --list-techs option."""
    print(
        "Technologies disponibles :\n{0}".format(
            "\n".join(["  [+] %s" % t for t in Engine.get_available_techs()]),
        ),
    )


def list_templates(tech):
    """Manage action for the --list-templates option."""
    # resolve the tech to display
    if tech:
        techs = [tech]
    else:
        techs = Engine.get_available_techs()

    # print each tech template
    print("Templates disponibles :")
    for tech_name in techs:
        tpls, def_tpl, def_lang = Engine.get_tech_templates(tech_name)
        print("  [+] %s" % tech_name)
        print(
            "      Valeurs par défaut: template=%s, language=%s" % (def_tpl, def_lang),
        )
        for tpl in tpls:
            print("    [-] %s" % tpl)
            for lang in tpls[tpl]:
                print("      [·] %s" % lang)
        print()


def list_formats():
    """Manage action for the --list-formats option."""
    print(
        "Format disponibles :\n{0}".format(
            "\n".join(["  [+] %s" % t[0] for t in Engine.get_available_formats()]),
        ),
    )


# Fonction main
# -------------
def main(argv=sys.argv[1:]):  # pylint: disable=dangerous-default-value
    """Dat main"""
    # first parse arguments
    parser = get_parser()
    options = parser.parse_args(argv)

    # manage self-sufficient actions if provided, prior to checking
    # other options
    if options.list_techs:
        return list_techs()
    if options.list_templates:
        return list_templates(options.type)
    if options.list_formats:
        return list_formats()

    if not options.type:
        parser.error(
            """Argument "type" non renseigné.

    Veuillez spécifier un type.

    Types disponibles :
{0}""".format(
                "\n".join(["  [+] %s" % t for t in Engine.get_available_techs()]),
            ),
        )

    if not options.input:
        parser.error(
            """Argument "input" non renseigné.

    Veuillez spécifier le nom du fichier d'extraction.""",
        )

    if not options.output:
        parser.error(
            """Argument "output" non renseigné.

    Veuillez spécifier le nom du fichier de sortie.""",
        )

    # configure the logger based on options
    level = logger.INFO
    if options.verbose:
        level = logger.DEBUG
    elif options.quiet:
        level = logger.CRITICAL

    logger.setup(sys.stdout, level)

    # global catch all
    try:
        # instantiate core engine and run it
        engine = Engine(options.type, options.template, options.language)
        return engine.review(
            options.input,
            options.output,
            options.format,
            options.timing,
        )
    except InvalidArgumentException as e:
        # raised when the Engine states that provided arguments are not
        # valid
        parser.error(str(e))
    except Exception:  # pylint: disable=broad-except
        logger.getLogger(__name__).error(
            "Échec lors de la revue de configuration",
            exc_info=True,
        )
        # return a failure
        return False


if __name__ == "__main__":
    if main():
        sys.exit(0)
    else:
        sys.exit(1)
