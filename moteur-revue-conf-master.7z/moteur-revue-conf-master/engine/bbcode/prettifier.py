# -*- coding: utf-8 -*-

"""Provides functions to prettify the BBcode tree

It removes unecessary newlines strip some spaces, etc.
"""

# Project imports
from engine import logger
from engine.bbcode import ElementNode, parse_bbcode, RootNode, TextNode
from engine.bbcode.text_wrapper import TextWrapper, unwrap


# main functions to easily prettify bbcode
def prettify_bbcode_tree(tree, is_wrapped=False):
    """Prettify a BBcode tree


    Args:
        tree (RootNode): bbcode to prettify.
        is_wrapped (bool, optional): whether the input text is already
            wrapped.

    Returns:
        RootNode: the pretty bbcode

    """
    return Prettifier(tree, is_wrapped).prettify()


def prettify_bbcode(bbcode, is_wrapped=False, width=79):
    """Interprete BBcode to prettify it.


    Args:
        bbcode (str): bbcode to prettify.
        is_wrapped (bool, optional): whether the input text is already
            wrapped.
        width (int, optional): the max width of the text to be rendered

    Returns:
        str: the pretty bbcode

    """
    prettifier = Prettifier(parse_bbcode(bbcode), is_wrapped)
    prettifier.prettify()
    return prettifier.render(width=width)


class Prettifier:
    """Class to prettify bbcode

    Input text may already be wrapped, meaning only double newlines
    will be treated as a new paragraph. This behavior can be controlled
    with the ``is_wrapped`` argument.

    This prettifier supports any tags, however, unknown
    tags will always be treated as inline tags:

    - Inline tags are considered as part of a line (e.g. [b], [i], …).
      No special processing is done on them, but they can be wrapped to
      80 characters.
    - Block tags are considered to be always rendered as their own
      paragraph (e.g. [list], [table]). These tags will always be
      written in the own line and they can be wrapped to 80 characters.
    - Pre blocks tags are similar to block tags except that they should
      not be wrapped (e.g. [codeblock])
    - indented blocks tags are similar to block tags but they will be
      indended when rendered (e.g. [tr], [td], [th])

    Currently, the following for tags are supported:

    - [b][/b]:                 emphasize the text
    - [e][/e]:                 emphasize2 the text
    - [i][/i]:                 italicize the text
    - [u][/u]:                 underline the text
    - [code][/code]:           print text as code
    - [list][*][/list]:        create a bullet list
    - [url][/url]:             create a link
    - [url=XXX][/url]:         create a link with replacement text
    - [table][/table]:         create a table
    - [tr][/tr]:               create a table row
    - [th][/th]:               create a table header cell
    - [td][/td]:               create a table cell
    - [bg=XX][/bg]:            define the background of the current
                               cell (need [th] or [td] parent)
    - [title][/title]:         create caption for a table
                               (need [table] parent)
    - [codeblock][/codeblock]: print text as code
    - [section=XX][/section]:  Create a new section
    - [help=XXX][/help]        create an info box

    """

    # This dict is used to classify tags
    TAG_KINDS = {
        "inline": ["b", "e", "i", "u", "code", "url"],
        "block": ["table", "list", "section", "help"],
        "listitem": ["listitem"],  # special kind for list items ([*])
        "pre": ["codeblock"],
        "indented": ["title", "tr", "th", "td", "bg"],
    }

    # Computed list of block tags for cleaning nodes
    BLOCKS_TAG = sum(
        map(TAG_KINDS.__getitem__, ("block", "listitem", "pre", "indented")),
        [],
    )

    def __init__(self, tree, is_wrapped):
        """Init the class and prettify text.

        Args:
            text (str): bbcode to be parsed and prettify
            is_wrapped (bool): whether the text is already wrapped

        """
        self.content = None
        self.is_wrapped = is_wrapped
        self.lstrip_next_node = False
        self.tree = tree
        self._cur_indent = 0

    def __str__(self):
        """Return the pretty code"""
        return str(self.content)

    # Functions to clean the tree (remove newlines/spaces)
    def prettify(self):
        """Prettify the whole tree and return it."""
        self.clean_node(self.tree)
        return self.tree

    def clean_node(self, node):
        """Clean the subtree of a node

        Cleaning a node means:

        - Unwrap all text nodes
        - Strip spaces

        """
        # First unwrap all text nodes
        if isinstance(node, TextNode):
            if self.is_wrapped:
                node.text = unwrap(node.text)
            # text nodes do not need anymore processing
            return

        # For RootNode & ElementNode, ensure children are clean fisrt
        # unless within a pre block
        if not (
            isinstance(node, ElementNode) and node.tagname in self.TAG_KINDS["pre"]
        ):
            self.clean_children(node)

        # All children are cleaned and text is unwrapped
        # The rest of the cleaning is:
        # - For Block elements to strip starting & ending text
        # - To rstrip text elements before blocks
        # - To lstrip text elements after blocks
        if (
            isinstance(node, ElementNode)
            and len(node.children) > 0
            and node.tagname in self.BLOCKS_TAG
        ):
            # lstrip first
            if isinstance(node.children[0], TextNode):
                node.children[0].text = node.children[0].text.lstrip(" ")
            # rstrip last
            if isinstance(node.children[-1], TextNode):
                node.children[-1].text = node.children[-1].text.rstrip(" ")

        for i, n in enumerate(node.children):
            # can only strip text nodes
            if not isinstance(n, TextNode):
                continue
            # check previous
            if i > 0:
                if (
                    isinstance(node.children[i - 1], ElementNode)
                    and node.children[i - 1].tagname in self.BLOCKS_TAG
                ):
                    n.text = n.text.lstrip(" ")
            # check next
            if i < len(node.children) - 1:
                if (
                    isinstance(node.children[i + 1], ElementNode)
                    and node.children[i + 1].tagname in self.BLOCKS_TAG
                ):
                    n.text = n.text.rstrip(" ")

    def clean_children(self, node):
        """Clean all children nodes"""
        for n in node.children:
            self.clean_node(n)

    # Functions to render tree to text
    def render(self, width):
        """Render the tree"""
        self.content = TextWrapper(width)
        self.render_node(self.tree)
        return str(self.content)

    def render_node(self, node):
        """Render a node"""
        # the rendering depends on the node type
        if isinstance(node, RootNode):
            self.render_children(node)
        if isinstance(node, TextNode):
            self.render_text(node.text)
        if isinstance(node, ElementNode):
            # redirect to the right action, if any
            # unknown tags treat as inline
            if node.tagname in self.TAG_KINDS["block"]:
                self.render_block(node)
            elif node.tagname in self.TAG_KINDS["pre"]:
                self.render_pre(node)
            elif node.tagname in self.TAG_KINDS["indented"]:
                self.render_indented(node)
            elif node.tagname in self.TAG_KINDS["listitem"]:
                self.render_listitem(node)
            elif node.tagname in self.TAG_KINDS["inline"]:
                self.render_inline(node)
            else:
                logger.getLogger(__name__).warning(
                    "Unknown tag [%s] found: ignore it",
                    node.tagname,
                )
                self.render_inline(node)

    def render_children(self, node):
        """Render all children from a node"""
        for n in node.children:
            self.render_node(n)

    def render_inline(self, node):
        """Render inline tags like [b] or [i]"""
        # add the opening tag, as non breakable
        if node.attribute is None:
            self.content.add_unwrap("[%s]" % node.tagname)
        else:
            self.content.add_unwrap("[%s=%s]" % (node.tagname, node.attribute))

        # Add the content
        self.render_children(node)

        # Add the closing tag, as non breakable
        self.content.add_unwrap("[/%s]" % node.tagname)

    def render_listitem(self, node):
        """Render listitem tags"""
        # add the opening tag, as non breakable in a dedicated para
        self.content.ensure_new_line()
        self.content.add_unwrap("[*] ")

        # Add the content while stripping
        self.render_children(node)

    def render_block(self, node):
        """Render block tags like [help] or [table]"""
        # add the opening tag, as non breakable in a dedicated para
        self.content.ensure_new_line()
        if node.attribute is None:
            self.content.add_unwrap("[%s]" % node.tagname)
        else:
            self.content.add_unwrap("[%s=%s]" % (node.tagname, node.attribute))
        self.content.new_line()

        # Add the content while stripping
        self.render_children(node)

        # Add the closing tag, as non breakable in a dedicated paragraph
        self.content.ensure_new_line()
        self.content.add_unwrap("[/%s]" % node.tagname)
        self.content.new_line()

    def render_indented(self, node):
        """Render indented block tags like [td]"""
        # indented blocks can be displayed as inline, if it contains
        # no blocks
        inline = True
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in self.BLOCKS_TAG:
                inline = False
                break

        # increment indent
        self._cur_indent += 1

        # add the opening tag, as non breakable in a new line
        self.content.ensure_new_line()
        if node.attribute is None:
            self.content.add_unwrap("%s[%s]" % ("  " * self._cur_indent, node.tagname))
        else:
            self.content.add_unwrap(
                "%s[%s=%s]" % ("  " * self._cur_indent, node.tagname, node.attribute),
            )

        # start a new line for content if not in inline mode
        if not inline:
            self.content.new_line()

        # Add the content while stripping
        self.render_children(node)

        # Add the closing tag, as non breakable
        # when not in inline mode do it in a dediceted line, with indent
        if inline:
            self.content.add_unwrap("[/%s]" % node.tagname)
        else:
            self.content.ensure_new_line()
            self.content.add_unwrap("%s[/%s]" % ("  " * self._cur_indent, node.tagname))
        self.content.new_line()

        # decrement indent
        self._cur_indent -= 1

    def render_pre(self, node):
        """Render pre block tags like [codeblock]"""
        # start a new paragraph
        self.content.ensure_new_line()
        # Add the whole block as non breakable (including tags)
        # this ensure the structure wont be modified
        if node.attribute is None:
            self.content.add_unwrap(
                "[{tagname}]{content}[/{tagname}]".format(
                    tagname=node.tagname,
                    content=self.render_as_text(node),
                ),
            )
        else:
            self.content.add_unwrap(
                "[{tagname}={attribute}]{content}[/{tagname}]".format(
                    tagname=node.tagname,
                    attribute=node.attribute,
                    content=self.render_as_text(node),
                ),
            )
        # start a new paragraph
        self.content.new_line()

    def render_as_text(self, node):
        """Render a tree as text"""
        ret = ""
        for n in node.children:
            if isinstance(n, TextNode):
                # add the text while escaping square brackets
                ret += n.text.replace("[", "[[").replace("]", "]]")
            elif isinstance(n, ElementNode):
                # Add tag & recurse to add the inner as text
                if n.attribute is None:
                    ret += "[%s]" % n.tagname
                else:
                    ret += "[%s=%s]" % (n.tagname, n.attribute)
                ret += self.render_as_text(n)
                ret += "[/%s]" % n.tagname
        return ret

    def render_text(self, text):
        """Just render text"""
        # Add the text to the content while escaping square brackets
        self.content.add_text(text.replace("[", "[[").replace("]", "]]"))
