# -*- coding: utf-8 -*-

"""Provides classes to be able to wrap bbcode text"""

# Standard libraries
import re


def unwrap(txt):
    """Unwrap a text wrapped with TextWrapper"""
    # Need to remove all odd number of newlines (starting at 3)
    # to prevent space at the start of paragraph
    txt = re.sub(r"(?<!\n)((\n\n)+)\n(?!\n)", r"\1", txt)
    # Paragraph are separated with 2 line returns
    par = txt.split("\n\n")

    # Remaining newlines (single) should be spaces
    return "\n".join(map(lambda s: s.replace("\n", " "), par))


class Text:
    """Base class to represent text for TextWrapper."""

    __slots__ = ("text",)

    def __init__(self, text):
        self.text = text

    def __repr__(self):
        return "%s(%r)" % (type(self).__name__, self.text)

    def wrap(self, width, offset):
        """Wrap text to the given width

        Args:
            width (int): max length of a line
            offset (int): initial offset on the first line

        Returns:
            List[str]: list of lines with wrapped text

        """
        raise NotImplementedError("wrap() is not implemented")


class UnbreakableText(Text):
    """Text which cannot be broken."""

    def wrap(self, width, offset):
        """Wrap text to the given width

        Args:
            width (int): max length of a line
            offset (int): initial offset on the first line

        Returns:
            List[str]: list of lines with wrapped text

        """
        # Either the text fit in the line or start a new line
        # Also need to check offset to prevent empty lines, if
        # the text is longer than width & that the offset is null
        if offset > 0 and len(self.text) + offset > width:
            return ["", self.text]
        return [self.text]


class BreakableText(Text):
    """Text which cannot be broken."""

    def wrap(self, width, offset):
        """Wrap text to the given width

        Args:
            width (int): max length of a line
            offset (int): initial offset on the first line

        Returns:
            List[str]: list of lines with wrapped text

        """
        ret = []
        # compute the minimal length which needs to be added
        minl = self.text.find(" ")
        if minl == -1:
            minl = len(self.text)  # case with no space
        # manage the case when the text cannot be appended to the line
        # Also need to check offset to prevent empty lines, if
        # the text is longer than width & that the offset is null
        if offset > 0 and offset + minl > width:
            # finish the first line
            ret.append("")
            offset = 0

        # wrap the rest of the text
        # add the offset
        text = "x" * offset + self.text
        wrapped = self.wrapline(text, width)
        # strip the initial offset
        wrapped[0] = wrapped[0][offset:]
        ret.extend(wrapped)
        return ret

    @staticmethod
    def wrapline(text, width):
        """Wrap a line"""
        # Cannot rely on a regex to efficiently split

        # Manage small lines
        if len(text) <= width:
            return [text]

        # Analyse the first chars
        chars = text[: width + 1]
        if " " in chars:
            # split of the last space
            line = chars.rsplit(" ", 1)[0]
            return [line] + BreakableText.wrapline(text[len(line) + 1 :], width)

        # Case of line longer than width-chars
        # either split on first space or return all
        if " " in text:
            line = text.split(" ", 1)[0]
            return [line] + BreakableText.wrapline(text[len(line) + 1 :], width)
        return [text]


class TextWrapper:
    """This class helps to wrap text

    Python library textwrap is not suffisant to cover all necessary
    feature.

    This provides 3 main methods to add text:

    - :py:meth:`add_text` to add wrappable text to the last paragraph.
    - :py:meth:`add_unwrap` to add unwrappable text to the last
      paragraph.
    - :py:meth:`new_line` to start a new line.
    - :py:meth:`ensure_new_line` to start a new line if not one.
    - :py:meth:`new_paragraph` to start a new paragraph.
    - :py:meth:`ensure_new_paragraph` to start a new paragraph if not on
      one yet.
    """

    def __init__(self, max_width=79):
        """Initialize the instance"""
        self.max_w = max_width
        self.par = [[]]

    def __str__(self):
        """Render the text"""
        return "\n".join(map(self.wrap_paragraph, self.par))

    def wrap_paragraph(self, parts):
        """Wrap a whole paragraph"""
        ret = [""]
        # add each parts
        for part in parts:
            # always keep the last line to append when possible
            wrapped = part.wrap(self.max_w, len(ret[-1]))
            # append the last line while managing spaces:
            # BreakableText may start or end with spaces. If
            # The split occurs within between 2 text instances,
            # the BreakableText must be stripped
            if wrapped[0] == "" and len(wrapped) > 1:
                # strip the BreakableText part
                if isinstance(part, BreakableText):
                    wrapped[1] = wrapped[1].lstrip(" ")
                else:
                    ret[-1] = ret[-1].rstrip(" ")
            ret[-1] += wrapped[0]
            # add new lines
            ret.extend(wrapped[1:])
        # return the paragraph while striping lines
        return "\n".join(ret)

    def add_text(self, txt):
        """Add wrappable text"""
        # manage txt with several paragraphes
        paragraphs = txt.split("\n")
        for i, par in enumerate(paragraphs):
            if par:
                # to be sure text will not be break between
                # 2 text but only on space, need to merge the first
                # word with the previous symbol
                if len(self.par[-1]) == 0:
                    # First text of the line ==> nothing to do
                    self.par[-1].append(BreakableText(par))
                elif isinstance(self.par[-1][-1], BreakableText):
                    # last is also breakable ==> Merge both
                    self.par[-1][-1].text += txt
                else:
                    # if a space in text ==> only merge first word
                    # if no space in text ==> merge whole text
                    if " " in par:
                        first, remain = par.split(" ", 1)
                        self.par[-1][-1].text += first
                        self.par[-1].append(BreakableText(" " + remain))
                    else:
                        self.par[-1][-1].text += par

            # Unless it is the last line, add a new paragraph
            if i != len(paragraphs) - 1:
                self.new_paragraph()

    def add_unwrap(self, txt):
        """Add unwrappable text"""
        if txt:
            # same as add_text:
            # to be sure text will not be break between
            # 2 text but only on space, need to merge the last
            # word of previous text aith it, unless it is also
            # unbreakable text
            if len(self.par[-1]) == 0:
                # First text of the line ==> nothing to do
                self.par[-1].append(UnbreakableText(txt))
            elif isinstance(self.par[-1][-1], UnbreakableText):
                # last is also unbreakable ==> Merge both
                self.par[-1][-1].text += txt
            else:
                # if a space in prev text ==> merge last word
                # if no space in prev text ==> there are 2 cases:
                #   - either it is the first of the line ==> merge prev
                #   - or it is not and par[-1][-2] is unbreakable
                #     (because if 2 text of similar type are added
                #     sequently, they are merged into 1 single instance)
                #     ==> Merge all 3 text into a single unbreakable
                if " " in self.par[-1][-1].text:
                    # merge last word
                    remain, last = self.par[-1][-1].text.rsplit(" ", 1)
                    self.par[-1][-1].text = remain + " "
                    self.par[-1].append(UnbreakableText(last + txt))
                else:
                    if len(self.par[-1]) == 1:
                        # previous is also first of line
                        self.par[-1][0] = UnbreakableText(self.par[-1][-1].text + txt)
                    else:
                        # par[-1][-2] exists and is unbreakable
                        self.par[-1][-2].text += self.par[-1][-1].text + txt
                        del self.par[-1][-1]

    def new_line(self):
        """Add a new paragraph"""
        self.par.append([])

    def ensure_new_line(self):
        """Add a new paragraph"""
        if len(self.par[-1]) > 0:
            self.new_line()

    def new_paragraph(self):
        """Add a new paragraph"""
        self.par.append([])
        self.par.append([])

    def ensure_new_paragraph(self):
        """Add a new paragraph"""
        # Only add one line if already on an empty line
        if len(self.par[-1]) > 0:
            self.new_paragraph()
        elif len(self.par) >= 2 and len(self.par[-2]) > 0:
            self.new_line()
