# -*- coding: utf-8 -*-

"""Provides a lexer/parser for the intermediate language

This language is based on BBCode and is very similar. It is heavily used
to format reports

This package exposes:

Exceptions
----------
LexerError, ParserError -- raised respectively by the lexer and the
                           parser upon errors

Classes
-------
Lexer -- an unspecialized regex-based lexer
BBcodeParser -- the parser specialized in parsing the intermediate
                language

DocumentTreeNode -- base class for a node in the abstract document tree
RootNode, ElementNode, TextNode -- nodes which compose the document tree

Markup -- a class to mark string as safe. Such string won't be escaped
          by the `escape` function

Functions
---------
escape -- function to escape characters interpreted by BBcodeParser

Variables
----------
bbcode_lexer -- a instance of Lexer specialized for BBCode lexing

"""

# The way this package works is simple. It follows classical
# lexer/parser principles:
#   * The lexer transforms a stream of characters into a stream of
#       tokens which can be seen as a lexically-similar typed string.
#   * The parser gives the semantic to the generated stream of tokens.
#       It gives them the meaning considering the current context.


# Project imports
from engine.bbcode.errors import LexerError, ParserError
from engine.bbcode.lexer import BBcodeLexer, Lexer
from engine.bbcode.markup import escape, Markup
from engine.bbcode.parser import BBcodeParser
from engine.bbcode.tree import (
    DocumentTreeNode,
    ElementNode,
    RootNode,
    TextNode,
)

__all__ = [
    LexerError,
    ParserError,
    Lexer,
    BBcodeLexer,
    BBcodeParser,
    DocumentTreeNode,
    RootNode,
    ElementNode,
    TextNode,
    escape,
    Markup,
]


def parse_bbcode(text):
    """Parse the BBcode-like presentation language

    If the given text is not an `Markup` object, it will be treated
    as BBcode-safe. Treat it with caution.

    It uses the BBcodeParser and return a document tree structure.
    See help(DocumentTreeNode) for more info.

    Arguments
    ---------
    text -- text to parse

    Returns
    -------
    The DocumentTreeNode generated from the parsing

    """
    # do the parsing
    parser = BBcodeParser(BBcodeLexer())
    return parser.parse(Markup(text))
