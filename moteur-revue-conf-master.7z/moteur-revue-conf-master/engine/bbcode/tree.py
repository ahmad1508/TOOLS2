# -*- coding: utf-8 -*-

"""Provide all classes for the abstract document tree

Classes
-------
DocumentTreeNode -- base class for a node in the abstract document tree
RootNode -- node at the root of the tree
ElementNode -- nodes which describe a BBCode element
TextNode -- nodes which only contain text
"""

# Standard libraries
from itertools import chain


class DocumentTreeNode(object):
    """Node in the document tree constructed by the parser

    In the document tree, each node represents a tag or text and all
    children nodes are data contained within the tag. All leaf nodes
    (= final nodes) are text node.

    Three subclasses exist which represent different part of the tree:
      - RootNode is the main starting node,
      - ElementNode represent a tag node,
      - TextNode is a leaf which only contains text
    """

    __slots__ = ()

    @property
    def _slots(self):
        """Retrieve all slots attributes"""
        return chain.from_iterable(
            getattr(cls, "__slots__", []) for cls in type(self).__mro__
        )

    def __repr__(self):
        """Provide a human-readable description of the node"""
        return "<{klass} {parameters}>".format(
            klass=self.__class__.__name__,
            parameters=", ".join(
                [
                    attr + "=" + repr(getattr(self, attr))
                    for attr in self._slots
                    if attr != "parent"
                ],
            ),
        )


class RootNode(DocumentTreeNode):
    """Root node, i.e. main node at the top of the tree

    It exposes several properties:
      - children: list of all children node,

    It can also be stringified (with str()) to get the text
    representation of the node (including subnodes).
    """

    __slots__ = ("children", "parent")

    def __init__(self, children):
        """Initialize the root node with all properties"""
        # save all properties
        self.children = children

        # register the current node a parent of the children
        for c in self.children:
            c.parent = self

    def __str__(self):
        """Return a string of the node and its children"""
        # The string representation is just the text content of the tag
        return "".join([str(c) for c in self.children])


class ElementNode(DocumentTreeNode):
    """Element node, i.e. node which represents a tag

    It exposes several properties:
      - parent: point to the parent node,
      - children: list of all children node,
      - tagname: name of the tag,
      - attribute: optional attribute of the tag (None if no
        attribute is defined).

    It can also be stringified (with str()) to get the text
    representation of the node (including subnodes).
    """

    __slots__ = ("children", "parent", "tagname", "attribute")

    def __init__(self, tagname, attribute, children):
        """Initialize the element node with all properties"""
        # save all properties
        self.tagname = tagname
        self.attribute = attribute
        self.children = children
        self.parent = None

        # register the current node a parent of the children
        for c in self.children:
            c.parent = self

    def __str__(self):
        """Return a string of the node and its children"""
        # The string representation is just the text content of the tag
        return "".join([str(c) for c in self.children])


class TextNode(DocumentTreeNode):
    """Text node, i.e. node which represents a text content

    It exposes several properties:
      - parent: point to the parent node,
      - text: text of the node.

    It can also be stringified (with str()) to get the text content.
    """

    __slots__ = ("text", "parent")

    def __init__(self, text):
        """Initialize the element node with all properties"""
        # save properties
        self.text = text
        self.parent = None

    def __str__(self):
        """Return a string of the node"""
        return self.text

    def append(self, text):
        """Append text node within the current text node"""
        self.text += text.text
