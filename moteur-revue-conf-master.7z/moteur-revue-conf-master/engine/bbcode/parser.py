# -*- coding: utf-8 -*-

"""Provides a Parser for the intermediate language

Classes
-------
BBcodeParser -- the BBcode parser
"""


# Project imports
from engine.bbcode.errors import ParserError
from engine.bbcode.lexer import Token
from engine.bbcode.tree import (
    DocumentTreeNode,
    ElementNode,
    RootNode,
    TextNode,
)

# Lexer and parser are based on code from
# Eli Bendersky (eliben@gmail.com)
#      https://github.com/eliben/code-for-blog/tree/master/
#       2009/py_rd_parser_example


# eBNF of the parser:
#
# <text>    : TEXT
#           | [[                                            { "["; }
#           | ]]                                            { "]"; }
#
# <bbcode>  : <bbc_t>*
# <bbc_t>   : <text>
#           | <tag>
#           | <item>
#
# <tag>     : [ TAGNAME (= ATTR)? ] <bbcode> [/ TAGNAME ]
#
# <item>    : LISTITEM <itemcode>
#
# <itemcode>: <itemc_t>*
# <itemc_t> : <text>
#           | <tag>
#

# Be careful when modify the parser grammar to stay LL(1)
# Also be careful with recursive rules. Python maximum recursion depth
# may quicly be exceeded.
#


def symbol(*first_symbols):
    """Decorate nonterminal symbol functions in the parser

    It handles creation on rule-parsing context.
    It also create a method to easily check whether we can
    branch to the symbol: branchable()

    To use it, gives it a list of first seen symbols. Symbols between
    `<` and `>` are considered sub nonterminal symbols. For instance:

    @symbol("NL", "WS", "<tag>")
    def sym_bbcode(self):
        pass

    It is important to use the naming convention sym_*
    """

    # dynamically create the decorator
    def deco(func):
        # check naming convention
        if not func.__name__.startswith("sym_"):
            raise SyntaxError(
                "Bad symbol naming convention for the parser. Expecting sym_*",
            )

        # wrapper function to return from the decorator
        def wrapper(self):
            # create a new parsing context
            self.saved_values.append(self.parsed_tokens)
            self.parsed_tokens = []
            tok = self.cur_token
            ret = func(self)
            # remove the parsing context
            self.parsed_tokens = self.saved_values.pop()
            self.parsed_tokens.append(Token(func.__name__[4:], ret, tok.pos))

        # create the branchable() function on the wrapper
        def branchable(self):
            for s in first_symbols:
                # check symbols between `<` and `>` for sub symbol
                # resolution.
                # Else do a normal compare between the current token
                # and the iterated first token
                if s[0] == "<" and s[-1] == ">":
                    subsymbol = getattr(self, "sym_" + s[1:-1], None)
                    if subsymbol is not None and subsymbol.branchable(self):
                        return True
                elif self.cur_token.type == s:
                    return True
            return False

        wrapper.branchable = branchable
        wrapper.symbol = "<" + func.__name__[4:] + ">"
        return wrapper

    return deco


class BBcodeParser(object):
    """Simple Recursive Descent parser for our BBcode-like code

    This class implement a simple RD parser for LL(1) grammar only.
    Any other kind of grammar may cause unexpected results
    """

    def __init__(self, lexer):
        """Create a grammar parser.

        Arguments
        ---------
        lexer -- Lexer instance to use as input

        Note
        ----
        Caution with the grammar! This parser only support
        LL(1) grammar. Other kind of grammar, including left-recursive
        grammar will end up in a infinite recursion!
        There are no watchdogs to prevent such infinite recursion. Just
        be careful with what you are parsing.

        """
        self.lexer = lexer
        self.cur_token = None
        self.parser_tree = []

    def parse(self, text):
        """Parse the given text

        Parse some text with the grammar and create a document tree
        structure representing the parsed text.

        Arguments
        ---------
        text -- the text to parse with the grammar

        Return
        ------
        The main element of the tree structure

        Exceptions
        ----------
        ParserError -- can be raised in case of parsing errors.

        """
        # init lexer
        self.lexer.set_input(text)
        self._get_next_token()

        # init parser
        self.tag_tree = []
        self.saved_values = []
        self.parsed_tokens = []

        # run parser
        self.sym_bbcode()

        # check the whole buffer was parsed
        if self.cur_token is not Token.EOFToken:
            self._error("Parser ended before the whole text was parsed")

        # create and return the root node fo the document tree
        return RootNode(self.parsed_tokens[0].val)

    def _error(self, msg, token=None):
        # get the right erronous token position
        if token is None:
            token = self.cur_token
        # Handles the case where the cur_token is the final None token
        pos = token.pos
        if pos is None:
            pos = len(self.lexer.buf) - 1
        raise ParserError(msg, self.lexer.buf, pos)

    def _eof_error(self):
        """Error generation when EOF is reached prematurely"""
        self._error(
            "Premature end of file reached: "
            "Following tags need to be closed: %s"
            % (", ".join(["[" + t + "]" for t in self.tag_tree])),
        )

    def _get_next_token(self):
        self.cur_token = self.lexer.token()

        if self.cur_token is None:
            self.cur_token = Token.EOFToken

    def check_type(self, types):
        """Check the type of the next token aginst a given list"""
        if not isinstance(types, (list, tuple)):
            types = [types]
        if self.cur_token.type in types:
            return self.cur_token.type
        else:
            return None

    def match(self, types):
        """Try to match different token types

        It:
            * Verifies that the current token is one of the given types
            * save the token value
            * Returns the token type
            * Reads in the next token

        If no token matcs, an error is raised
        """
        tok_type = self.check_type(types)
        if tok_type:
            self.parsed_tokens.append(self.cur_token)
            self._get_next_token()
            return tok_type
        elif self.cur_token is Token.EOFToken:
            self._eof_error()
        else:
            self._error(
                "Unmatched token: expecting one of '%s' got '%s'"
                % (
                    types,
                    self.cur_token.type,
                ),
            )

    def optional_match(self, types):
        """Try to match different token types like match()

        The only difference with match is that it does not raise error
        when no valid token is found, but it returns None
        """
        tok_type = self.check_type(types)
        if tok_type:
            self.parsed_tokens.append(self.cur_token)
            self._get_next_token()
            return tok_type
        else:
            self.parsed_tokens.append(Token.NullToken)
            return None

    def optional_branch(self, sym):
        """Branch to a nonterminal symbol if possible"""
        if sym.branchable(self):
            sym()
            return True
        else:
            self.parsed_tokens.append(Token.NullToken)
            return False

    def match_branch(self, syms):
        """Branch to one of the given nonterminal symbols"""
        for s in syms:
            if s.branchable(self):
                s()
                return
        if self.cur_token is Token.EOFToken:
            self._eof_error()
        else:
            self._error(
                "Unmatched token: expecting nonterminal symbol "
                "among %s" % ([f.symbol for f in syms]),
            )

    #
    # <text>    : TEXT
    #           | [[                                            { "["; }
    #           | ]]                                            { "]"; }
    #
    @symbol("TEXT", "[[", "]]")
    def sym_text(self):
        """Parse a <text> symbol"""
        # parse the token
        sym = self.match(["TEXT", "[[", "]]"])

        # return a text node representing the text
        # [[ and ]] must be shorten into [ and ]
        if sym == "[[":
            return TextNode("[")
        elif sym == "]]":
            return TextNode("]")
        else:
            return TextNode(self.parsed_tokens[0].val)

    #
    # <bbcode>  : <bbc_t>*
    #
    @symbol("<bbc_t>")
    def sym_bbcode(self):
        """Parse a <bbcode> symbol"""
        # parse all <bbc_t> nonterminal symbols while it is possible
        while self.sym_bbc_t.branchable(self):
            self.sym_bbc_t()

        # concat all parsed DocumentTreeNode into a list of nodes
        # all sequential TextNodes are also merged
        nodes = []
        last_n = None
        for tok in self.parsed_tokens:
            n = tok.val
            # sanity check on nodes. They should all be DocumentTreeNode
            if isinstance(n, DocumentTreeNode):
                # try to merge TextNodes
                if isinstance(last_n, TextNode) and isinstance(n, TextNode):
                    last_n.append(n)
                else:
                    nodes.append(n)
                    last_n = n
            else:
                # this should not happen
                raise self._error("Internal error: Unexpected type '%s'" % (type(n)))
        # return all parsed nodes
        return nodes

    #
    # <bbc_t>   : <text>
    #           | <tag>
    #           | <item>
    #
    @symbol("<text>", "<tag>", "<item>")
    def sym_bbc_t(self):
        """Parse a <bbc_t> symbol"""
        # match the first nonterminal symbol
        self.match_branch([self.sym_text, self.sym_tag, self.sym_item])
        return self.parsed_tokens[0].val

    #
    # <tag>    : [ TAGNAME (= ATTR)? ] <bbcode> [/ TAGNAME ]  { tag(); }
    #
    @symbol("[")
    def sym_tag(self):
        """Parse a <tag> symbol"""
        self.match("[")

        self.match("TAGNAME")
        # optional attribute
        if self.optional_match("="):
            self.match("ATTR")
        else:
            self.parsed_tokens.append(Token.NullToken)
        # close the tag
        self.match("]")

        # starting here, we are in a tag context
        self.tag_tree.append(self.parsed_tokens[1].val.lower())

        self.sym_bbcode()

        # define a custom error handler to be able to show the
        # opening tag
        try:
            self.match("[/")
            self.match("TAGNAME")
            self.match("]")
        except ParserError as e:
            e.pos = self.parsed_tokens[0].pos
            raise

        # check the tags are matching and exit from the tag context
        cur_tag_context = self.tag_tree.pop()
        closed_tag = self.parsed_tokens[7].val.lower()
        if closed_tag != cur_tag_context:
            self._error(
                "Expecting tag [/%s] got [/%s]" % (cur_tag_context, closed_tag),
                self.parsed_tokens[6],
            )

        # if everything is OK, create the element node
        return ElementNode(
            cur_tag_context,  # tagname
            self.parsed_tokens[3].val,  # attribute
            self.parsed_tokens[5].val,  # children
        )

    #
    # <item>    : LISTITEM <itemcode>                        { item(); }
    #
    @symbol("LISTITEM")
    def sym_item(self):
        """Parse a <item> symbol"""
        self.match("LISTITEM")
        self.sym_itemcode()
        # create a LISTITEM element node
        return ElementNode(
            "listitem",  # tagname
            None,  # attribute
            self.parsed_tokens[1].val,  # children
        )

    #
    # <itemcode>: <itemc_t>*                               { concat(); }
    #
    @symbol("<itemc_t>")
    def sym_itemcode(self):
        """Parse a <itemcode> symbol"""
        # parse all <itemc_t> nonterminal symbols while it is possible
        while self.sym_itemc_t.branchable(self):
            self.sym_itemc_t()

        # concat all parsed DocumentTreeNode into a list of nodes
        # all sequential TextNodes are also merged
        nodes = []
        last_n = None
        for tok in self.parsed_tokens:
            n = tok.val
            # sanity check on nodes. They should all be DocumentTreeNode
            if isinstance(n, DocumentTreeNode):
                # try to merge TextNodes
                if isinstance(last_n, TextNode) and isinstance(n, TextNode):
                    last_n.append(n)
                else:
                    nodes.append(n)
                    last_n = n
            else:
                # this should not happen
                raise self._error("Internal error: Unexpected type '%s'" % (type(n)))
        # return all parsed tokens
        return nodes

    #
    # <itemc_t> : <text>
    #           | <tag>
    #
    @symbol("<text>", "<tag>")
    def sym_itemc_t(self):
        """Parse a <itemc_t> symbol"""
        # match the first nonterminal symbol
        self.match_branch([self.sym_text, self.sym_tag])
        return self.parsed_tokens[0].val
