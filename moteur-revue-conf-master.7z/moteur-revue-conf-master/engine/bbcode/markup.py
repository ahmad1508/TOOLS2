# -*- coding: utf-8 -*-

"""Provide interfaces to easily manage escaping strings

Implement an `escape` function and a Markup class which handles BBcode
escaping.
"""

# The markup code is based on code from
# Pallets' markupsafe module
#   https://github.com/pallets/markupsafe
#


def escape(s):
    """Escape characters which would be decoded as BBcode

    Replace the characters `[` and `]`
    the string with BBcode-safe sequences. Use this if you need to
    display text that might contain such characters in BBcode.

    If the object has an ``__bbcode__`` method, it is called and the
    return value is assumed to already be safe for BBcode.

    Arguments
    ---------
    s -- an object to be converted to a string and escaped.

    Returns
    -------
    A `Markup` string with the escaped text.

    """
    if hasattr(s, "__bbcode__"):
        return Markup(s.__bbcode__())
    return Markup(
        str(s).replace("[", "[[").replace("]", "]]"),
    )


def _escape_argspec(obj, iterable, escape):
    """Escape all items of an iterable

    Arguments
    ---------
    obj -- object to update with the escaped items
    iterable -- iterable to escape
    escape -- escape function to use to escape items

    """
    for key, value in iterable:
        if hasattr(value, "__bbcode__") or isinstance(value, (str,)):
            obj[key] = escape(value)
    return obj


def _make_simple_escaping_wrapper(name):
    """Create a proxy function which escape str"""
    orig = getattr(str, name)

    def func(self, *args, **kwargs):
        args = _escape_argspec(list(args), enumerate(args), self.escape)
        _escape_argspec(kwargs, kwargs.items(), self.escape)
        return self.__class__(orig(self, *args, **kwargs))

    func.__name__ = orig.__name__
    func.__doc__ = orig.__doc__
    return func


class Markup(str):
    """Wrapper class to mark a string as BBcode-safe

    A string that is ready to be safely inserted into a BBcode
    document, either because it was escaped or because it was marked
    safe.
    Passing an object to the constructor converts it to text and wraps
    it to mark it safe without escaping. To escape the text, use the
    `escape` class method instead.

    >>> Markup('Hello, [b]World[/b]!')
    Markup('Hello,  [b]World[/b]!')
    >>> Markup(42)
    Markup('42')
    >>> Markup.escape('Hello, [b]World[/b]!')
    Markup('Hello [[b]]World[[/b]]!')

    This implements the `__bbcode__()` interface.
    Passing an object that implements `__bbcode__()` will wrap the
    output of that method, marking it safe.
    >>> class Foo:
    ...     def __bbcode__(self):
    ...         return '[url=/foo]foo[/url]'
    ...
    >>> Markup(Foo())
    Markup('[url=/foo]foo[/url]')

    This is a subclass of the text type (`str` in Python 3,
    `unicode` in Python 2). It has the same methods as that type, but
    all methods escape their arguments and return a `Markup` instance.
    >>> Markup('[i]%s[/i]') % 'foo [bar]'
    Markup('[i]foo [[bar]][/i]')
    >>> Markup('[i]Hello[/i] ') + '[foo]'
    Markup('[i]Hello[/i] [[foo]]')
    """

    __slots__ = ()

    def __new__(cls, base="", encoding=None, errors="strict"):
        """Create an instance of Markup and handle __bbcode__"""
        if hasattr(base, "__bbcode__"):
            base = base.__bbcode__()
        if encoding is None:
            return str.__new__(cls, base)
        return str.__new__(cls, base, encoding, errors)

    def __bbcode__(self):
        """Return a BBCode-safe representation of the instance"""
        return self

    def __add__(self, other):
        """Implement an interface for concatenation

        It is possible to concatenate both Markup and strings
        >>> Markup("[*] ") + "[text]"
        Markup("[*] [[text]]")
        >>> Markup("[*] ") + Markup("[text]")
        Markup("[*] [text]")
        """
        if isinstance(other, (str,)) or hasattr(other, "__bbcode__"):
            return self.__class__(
                super(Markup, self).__add__(self.escape(other)),
            )
        return NotImplemented

    def __radd__(self, other):
        """Implement an interface for reverse concatenation

        It is possible to concatenate both Markup and strings
        >>> "[*] " + Markup("[text]")
        Markup("[[*]] [text]")
        >>> Markup("[*] ") + Markup("[text]")
        Markup("[*] [text]")
        """
        if hasattr(other, "__bbcode__") or isinstance(other, (str,)):
            return self.escape(other).__add__(self)
        return NotImplemented

    def __mul__(self, num):
        """Implement an interface for multiply

        >>> Markup("[*] ") * 3
        Markup("[*] [*] [*] ")
        """
        if isinstance(num, (int,)):
            return self.__class__(str.__mul__(self, num))
        return NotImplemented

    __rmul__ = __mul__

    def __mod__(self, arg):
        """Implement an interface for % formating

        >>> Markup("[*] %s") % "[text]"
        Markup("[*] [[text]]")
        >>> Markup("[*] %s") % Markup("[text]")
        Markup("[*] [text]")
        """
        if isinstance(arg, tuple):
            arg = tuple(_MarkupEscapeHelper(x, self.escape) for x in arg)
        else:
            arg = _MarkupEscapeHelper(arg, self.escape)
        return self.__class__(str.__mod__(self, arg))

    def __repr__(self):
        """Implement an interface for repr()

        >>> repr(Markup("[*] text"))
        Markup("[*] text")
        """
        return "%s(%s)" % (self.__class__.__name__, str.__repr__(self))

    def join(self, seq):
        """Implement an interface to join strings

        >>> Markup(" [*] ").join(["[text1]", Markup("[text2]")])
        Markup("[[text1]] [*] [text2]")
        """
        return self.__class__(str.join(self, map(self.escape, seq)))

    join.__doc__ = str.join.__doc__

    def split(self, *args, **kwargs):
        """Implement an interface to split into strings

        >>> Markup("[text1],[text2]").split(",")
        [Markup("[text1]"), Markup("[text2]")]
        """
        return list(
            map(
                self.__class__,
                str.split(self, *args, **kwargs),
            ),
        )

    split.__doc__ = str.split.__doc__

    def rsplit(self, *args, **kwargs):
        """Implement an interface to split into strings

        >>> Markup("[text1],[text2],[text3]").rsplit(",", 1)
        [Markup("[text1],[text2]"), Markup("[text3]")]
        """
        return list(
            map(
                self.__class__,
                str.rsplit(self, *args, **kwargs),
            ),
        )

    rsplit.__doc__ = str.rsplit.__doc__

    def splitlines(self, *args, **kwargs):
        r"""Implement an interface to split into lines

        >>> Markup("[text1]\n[text2]\n[text3]").splitlines()
        [Markup("[text1]"), Markup("[text2]"), Markup("[text3]")]
        """
        return list(
            map(
                self.__class__,
                str.splitlines(self, *args, **kwargs),
            ),
        )

    splitlines.__doc__ = str.splitlines.__doc__

    def unescape(self):
        """Convert escaped markup back into a text string

        It replaces double square brackets to single square brackets.
        >>> Markup('Main ]] [i]About[/i]').unescape()
        'Main ] [i]About[/i]'
        """
        return self.replace("[[", "[").replace("]]", "]")

    @classmethod
    def escape(cls, s):
        """Escape a string

        It calls `escape` and ensures that for subclasses the correct
        type is returned.
        """
        rv = escape(s)
        if rv.__class__ is not cls:
            return cls(rv)
        return rv

    # Proxify several methods from str
    for method in (
        "__getitem__",
        "capitalize",
        "title",
        "lower",
        "upper",
        "replace",
        "ljust",
        "rjust",
        "lstrip",
        "rstrip",
        "center",
        "strip",
        "translate",
        "expandtabs",
        "swapcase",
        "zfill",
    ):
        locals()[method] = _make_simple_escaping_wrapper(method)

    def partition(self, sep):
        """Implement a similar interface as str.partition"""
        return tuple(
            map(
                self.__class__,
                str.partition(self, self.escape(sep)),
            ),
        )

    def rpartition(self, sep):
        """Implement a similar interface as str.rpartition"""
        return tuple(
            map(
                self.__class__,
                str.rpartition(self, self.escape(sep)),
            ),
        )

    def format(self, *args, **kargs):  # noqa: A003
        """Implement a similar interface as str.format"""
        return self.__class__(
            str.format(
                self,
                *tuple(_MarkupEscapeHelper(x, self.escape) for x in args),
                **{k: _MarkupEscapeHelper(kargs[k], self.escape) for k in kargs},
            ),
        )

    # not in python 3
    if hasattr(str, "__getslice__"):
        __getslice__ = _make_simple_escaping_wrapper("__getslice__")

    del method


class _MarkupEscapeHelper(object):
    """Helper for Markup.__mod__"""

    def __init__(self, obj, escape):
        self.obj = obj
        self.escape = escape

    def __getitem__(self, item):
        return _MarkupEscapeHelper(self.obj[item], self.escape)

    def __str__(self):
        return str(self.escape(self.obj))

    __unicode__ = __str__

    def __repr__(self):
        return str(self.escape(repr(self.obj)))

    def __int__(self):
        return int(self.obj)

    def __float__(self):
        return float(self.obj)
