# -*- coding: utf-8 -*-

"""Provide Exceptions raised by the lexer and parser

Exceptions:
-----------
ContextualError: main class for both LexerError and ParserError
LexerError: error raised by the lexer
ParserError: error raised by the parser
"""


class ContextualError(Exception):
    """Exception which provides information on error location"""

    CONTEXT_LEN = 20

    def __init__(self, msg, buf, pos):
        """Initialize the exception with its context

        Arguments
        ---------
        msg -- Message of the error
        buf -- Buffer currently being parsed.
        pos -- Position in the input line where the error occurred.

        """
        self.msg = msg
        self.pos = pos
        self.buf = buf

    def _printable(self, txt):
        """Convert txt into a printable version"""
        return (
            txt.replace("\r", r"\r")
            .replace("\n", r"\n")
            .replace("\v", r"\v")
            .replace("\t", r"\t")
            .replace("\f", r"\f")
        )

    def __str__(self):
        """Override the defaut conversion of errors to strings"""
        ret = "Error at position %d: %s\n" % (self.pos, self.msg)
        # create a string showing the erronous token
        mi = max(0, self.pos - self.CONTEXT_LEN)
        ma = min(len(self.buf), self.pos + self.CONTEXT_LEN + 1)
        a = self._printable(self.buf[mi : self.pos])
        b = self._printable(self.buf[self.pos])
        c = self._printable(self.buf[self.pos + 1 : ma])
        ret += "\t" + a + b + c + "\n"
        ret += "\t" + "-" * len(a) + "^" * len(b) + "-" * len(c)
        return ret


class LexerError(ContextualError):
    """Implements ContextualError to be raised from the lexer"""


class ParserError(ContextualError):
    """Implements ContextualError to be raised from the parser"""
