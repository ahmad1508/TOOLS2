$(document).ready(function () {
  // Calcul de la largeur de la barre de navigation
  $("#header-navbar").width($("#main").width());

  // Initialisation des modules
  // --------------------------

  // Chargement de la barre de défilement de la sidebar
  $("#sidebar-scroll").slimScroll({
    height: "auto",
  });

  // Binding des événements "click"
  // ------------------------------

  // Affichage/Masquage de la sidebar sur les petites résolutions
  $("[data-toggle=offcanvas]").click(function () {
    $(".sidebar-offcanvas").toggleClass("active");
  });

  $("body").bind("Custom.Start", function (ev) {
    $("#myPleaseWait").modal("show");
  });

  $("body").bind("Custom.End", function (ev) {
    $("#myPleaseWait").modal("hide");
  });

  // Dépliage de tous les éléments de la partie principale
  $(".open_all").click(function () {
    $("body").trigger("Custom.Start");
    setTimeout(function () {
      try {
        $("#main").find('.collapse:not(".in")').collapse("show");
        $("#myPleaseWait").modal("hide");
      } finally {
        $("body").trigger("Custom.End");
      }
    }, 0);
  });

  // Repliage de tous les éléments de la partie principale
  $(".close_all").click(function () {
    $("body").trigger("Custom.Start");
    setTimeout(function () {
      try {
        $("#main").find(".collapse.in").collapse("hide");
        $("#myPleaseWait").modal("hide");
      } finally {
        $("body").trigger("Custom.End");
      }
    }, 0);
  });

  // Dépliage de tous les éléments d'une section donnée
  $(".open_section").click(function () {
    $(this).closest(".section").find('.collapse:not(".in")').collapse("show");
  });

  // Repliage de tous les éléments d'une section donnée
  $(".close_section").click(function () {
    $(this).closest(".section").find(".collapse.in").collapse("hide");
  });

  // Dépliage de tous les éléments d'un extract donné
  $(".open_extract").click(function () {
    $(this)
      .closest(".extract-section")
      .find('.collapse:not(".in")')
      .collapse("show");
  });

  // Repliage de tous les éléments d'un extract donné
  $(".close_extract").click(function () {
    $(this).closest(".extract-section").find(".collapse.in").collapse("hide");
  });

  // Dépliage de tous les éléments de la sidebar
  $(".open_sidebar").click(function () {
    $("#sidebar").find('.collapse:not(".in")').collapse("show");
  });

  // Repliage de tous les éléments de la sidebar
  $(".close_sidebar").click(function () {
    $("#sidebar").find(".collapse.in").collapse("hide");
  });

  // Parse the content to recreate dynamically the sidebar
  function get_sections(root, head_level) {
    var ret = [];
    root.find(".section > h" + head_level).each(function () {
      ret.push({
        level: $(this).parents(".section").length,
        num: $(this).children(".num").text(),
        title: $(this).children(".titre").text(),
        sub: get_sections(
          $(this).siblings(".section-content"),
          head_level + 1
        ),
      });
    });
    return ret;
  }

  titles = get_sections($(document), 3);

  // Create the sidebar
  sidebar = $("#stacked-menu");
  for (title1 of titles) {
    // create the level 2 part
    sect_lvl2 = $("<ul/>", {
      id: "sidebar-part-" + title1.num,
      class: "nav nav-stacked collapse",
    });
    for (title2 of title1.sub) {
      sect_lvl2.append(
        $("<li/>").append(
          $("<a/>", {
            href: "#section-" + title2.num.replaceAll(".", "-"),
          }).append(
            $("<span/>", { class: "num2" }).text(title2.num),
            " ",
            $("<span/>", { class: "titre2" }).text(title2.title)
          )
        )
      );
    }
    // Add the divider
    sect_lvl2.append("<li/>", { class: "nav-divider" });

    // create the level part
    sidebar.append(
      $("<li/>").append(
        $("<a/>", {
          class: "nav-container collapsed",
          href: "#sidebar-part-" + title1.num,
          "data-toggle": "collapse",
          "data-parent": "#stacked-menu",
        }).append(
          $("<span/>", { class: "num1" }).text(title1.num),
          " ",
          $("<span/>", { class: "titre1" }).text(title1.title)
        ),
        sect_lvl2
      )
    );
  }
  // Activate collapse on sidebar
  $("#stacked-menu .collapse").collapse({ parent: "#stacked-menu" });
});

// Recalcul de la largeur de la barre de navigation lors du redimensionnement de la fenêtre
$(window).resize(function () {
  $("#header-navbar").width($("#main").width());
});
