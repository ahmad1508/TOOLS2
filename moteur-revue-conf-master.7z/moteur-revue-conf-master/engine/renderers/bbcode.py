# -*- coding: utf-8 -*-

"""Provides a renderer for BBcode.

The renderer use the BBcode prettifier to render pretty reports.
"""

# Project imports
from engine.bbcode.prettifier import prettify_bbcode
from engine.core.renderer import Renderer


class BbcodeRenderer(Renderer):
    """Renderer for BBCode format"""

    desc = {
        "extensions": ["bbcode", "txt"],
    }

    def render(self, tech_name, content):
        """Render a report from the layout

        This method overrides the base method

        Args:
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        Returns:
            bytes: the rendered output as bytes

        """
        # Render the BBcode as pretty BBcode
        return prettify_bbcode(content, is_wrapped=True, width=79).encode("utf-8")
