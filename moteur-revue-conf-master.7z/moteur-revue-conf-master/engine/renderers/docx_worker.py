# -*- coding: utf-8 -*-

"""Provides a docx generation"""

# Standard libraries
from io import BytesIO
import os
import re
import unicodedata

# Third party libraries
# Work directly on OpenXML element to greatly speed up the creation
from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE
from docx.oxml.parser import parse_xml
from docx.oxml.ns import nsdecls, qn
from docx.oxml.text.paragraph import CT_P
from docx.oxml.text.run import CT_Text
from docx.shared import Cm

# Project imports
from engine import logger
from engine.bbcode import ElementNode, Markup, parse_bbcode, RootNode, TextNode
from engine.bbcode.prettifier import prettify_bbcode_tree
from engine.core import i18n
from engine.core.renderer import Renderer

# I18N
_ = i18n.domain("renderers")._


# decorator functions to generate some simple tag
def format_runs(func):
    """Wrap a function called to generate runs

    The decorated function is called on each run to do the
    formatting

    The decorator should be used as such:
    ```
    @format_runs
    def tag_generation(self, run, doc_part):
        run.style = "my_style"
        return run

    @format_runs
    def tag_generation_with_attribute(self, run, doc_part, attr=None):
        run.style = "my_style %s" % attr
        return run
    ```

    If None is returned, the Run given as argument is kept
    """

    def _wrapper(self, node, doc_part):
        # postordering BF search algorithm ==> need to render children
        # first
        children = self.render_children(node, doc_part)

        # ensure that everything is turned into a run
        children = self.ensure_runs(children)

        # format each non-empty run
        ret = []
        for run in children:
            # skip empty runs
            if run is None:
                continue
            # map with the return of func
            if node.attribute is not None:
                ret.append(func(self, run, doc_part, node.attribute))
            else:
                ret.append(func(self, run, doc_part))
            # keep the current run if None is returned
            if ret[-1] is None:
                ret[-1] = run

        return ret

    return _wrapper


def format_paragraphs(func):
    """Wrap a function called to generate paragraphs

    The decorated function is called on each paragraph to do the
    formatting

    The decorator should be used as such:
    ```
    @format_paragraphs
    def tag_generation(self, para, doc_part, first=False, last=False):
        para.style = "my_style"
        return para

    @format_paragraphs
    def tag_generation_with_attribute(self, para, doc_part, attr=None,
                                      first=False, last=False):
        para.style = "my_style %s" % attr
        return para
    ```

    If None is returned, the Paragraph given as argument is kept
    """

    def _wrapper(self, node, doc_part):
        # postordering BF search algorithm ==> need to render children
        # first
        children = self.render_children(node, doc_part)

        # ensure that everything is turned into a paragraph
        children = self.ensure_paragraphs(children)

        # format each paragraph
        ret = []
        for i, paragraph in enumerate(children):
            first = i == 0
            last = i == len(children) - 1
            # map with the return of func
            if node.attribute is not None:
                ret.append(
                    func(
                        self,
                        paragraph,
                        doc_part,
                        node.attribute,
                        first=first,
                        last=last,
                    ),
                )
            else:
                ret.append(func(self, paragraph, doc_part, first=first, last=last))
            # keep the current paragraph if None is returned
            if ret[-1] is None:
                ret[-1] = paragraph

        return ret

    return _wrapper


class WordRenderer(Renderer):
    """Renderer for Word 2007 documents"""

    desc = {
        "extensions": ["docx"],
    }

    DOCX_STYLE_ROOT_DOC = {
        "listBullet1": "Listepuces",
        "listBullet2": "Listepuces2",
        "listBullet3": "Listepuces3",
        "emphasize": "Accentuation",
        "emphasize2": "MiseEnValeur2Car",
        "normal": "Normal",
        "inlineCode": "InlineCodeCar",
        "code": "Code",
        "heading1": "Titre1",
        "heading2": "Titre2",
        "heading3": "Titre3",
        "heading4": "Titre4",
        "link": "Lienhypertexte",
        "caption": "TitreTableau2",
        "table": "Wavestone",
        "infobox": "Information",
    }
    DOCX_STYLE_TABLE = {
        "listBullet1": "PuceTableau1",
        "listBullet2": "Puce2Tableau",
        "emphasize": "Accentuation",
        "normal": "NormalTbl",
        "inlineCode": "InlineCodeCar",
        "code": "Code",
        "link": "Lienhypertexte",
        "caption": "TitreTableau2",
        "table": "Wavestone",
        "infobox": "Information",
    }

    # Prevent rendering to many table lines
    MAX_DATA_THRES = 100

    def __init__(self, *args, **kargs):
        """Initialize the renderer"""
        super().__init__(*args, **kargs)
        # render environment
        self.docx_style = self.DOCX_STYLE_ROOT_DOC
        self._current_section_lvl = 0
        self._current_list_lvl = 0
        self._tbl_count = 0

    def render(self, tech_name, content):
        """Render a report from the layout

        This method implement the base method

        Args:
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        Returns:
            bytes: the rendered output as bytes

        """
        # Reset the renderer options
        self.docx_style = self.DOCX_STYLE_ROOT_DOC
        self._current_section_lvl = 0
        self._current_list_lvl = 0
        self._tbl_count = 0

        document = Document(
            os.path.join(
                os.path.join(os.path.dirname(os.path.abspath(__file__)), "docx"),
                "document_template.docx",
            ),
        )
        # We parse and generate the content of the report
        document._body._body.extend(  # pylint: disable=protected-access
            self.docx_simple_bbcode(content, document.part),
        )

        # save the document in memory to retrieve it as string
        content = BytesIO()
        document.save(content)
        return content.getvalue()

    @staticmethod
    def remove_control_char(s):  # pylint: disable=invalid-name
        """Remove control characters from the string"""
        return "".join(ch for ch in s if unicodedata.category(ch)[0] != "C")

    @staticmethod
    def get_w_oxml(name, attr=None):
        """Create an OpenXML element in the w: namespace"""
        if attr is not None:
            attributes = " ".join("w:{0}='{1}'".format(k, attr[k]) for k in attr)
        else:
            attributes = ""
        return parse_xml(
            "<w:{name} {namespace} {attr}/>".format(
                name=name,
                namespace=nsdecls("w"),
                attr=attributes,
            ),
        )

    @staticmethod
    def get_cell_color_oxml(color):
        """Create the OpenXML element for cell color"""
        return parse_xml(
            r"<w:shd {namespace} w:fill='{color}'/>".format(
                namespace=nsdecls("w"),
                color=color,
            ),
        )

    @staticmethod
    def get_table_oxml():
        """Create the OpenXML element for a table"""
        return parse_xml(
            r"<w:tbl {namespace} ><w:tblPr/><w:tblGrid/></w:tbl>".format(
                namespace=nsdecls("w"),
            ),
        )

    # A list of tags for run elements
    RUN_TAGS = (qn("w:r"), qn("w:hyperlink"))

    def ensure_runs(self, items):
        """Ensure the items are all runs

        This helper is usefull when a run ElementNode contains TextNodes
        as first children

        The only known conversion is from CT_Text to CT_R

        Arguments
        ---------
        items -- items to transform as paragraph

        """
        ret = []
        for item in items:
            tag = item.tag if item is not None else None
            if tag in self.RUN_TAGS + (None,):
                ret.append(item)
            elif isinstance(item, CT_Text):
                element = self.get_w_oxml("r")
                element.append(item)
                ret.append(element)
            else:
                logger.getLogger(__name__).error(
                    "Unexpected type %s to turn to Run",
                    type(item).__name__,
                )
        return ret

    # A list of tags for paragraph elements
    PARAGRAPH_TAGS = (qn("w:p"), qn("w:tbl"))

    def ensure_paragraphs(self, items):
        """Ensure the items are all paragraphs

        This helper is usefull when a paragraph ElementNode contains
        TextNodes as first children.

        The only known conversion is from CT_Text and CT_R to CT_P

        Arguments
        ---------
        items -- items to transform as paragraph

        """
        ret = []
        cur_par = []
        for item in items:
            tag = item.tag if item is not None else None
            # check for an end of paragraph
            if tag in self.PARAGRAPH_TAGS + (None,) and len(cur_par) > 0:
                # end of current paragraph
                # transform all runs into a single paragraph
                paragraph = self.get_w_oxml("p")
                paragraph.extend(self.ensure_runs(cur_par))
                cur_par = []
                ret.append(paragraph)

            if tag in self.PARAGRAPH_TAGS:
                # Add paragraph types as such
                ret.append(item)
            elif tag is None:
                # Do nothing with None (i.e. end of line) except
                # discarding them
                pass
            else:
                # Keep track of runs to be inserted within the paragraph
                cur_par.append(item)

        if len(cur_par) > 0:
            # end the last paragraph, if any
            # transform all runs into a single paragraph
            paragraph = self.get_w_oxml("p")
            paragraph.extend(self.ensure_runs(cur_par))
            ret.append(paragraph)
        return ret

    @staticmethod
    def fix_keepwithnext(paragraphs):
        """Search keepwithprevious in paragraphs toggle keepwithnext"""
        prev = None
        for p in paragraphs:
            if isinstance(prev, CT_P):
                # only do work when we have access to the previous §
                if hasattr(p, "keepwithprevious") and p.keepwithprevious:
                    prev.get_or_add_pPr().get_or_add_keepNext()
            prev = p
        return paragraphs

    def get_paragraph(self, text, style=None):
        """Create and return a populated text paragraph

        New lines are not handled. This method should not be called
        with uncontrolled inputs.

        Arguments
        ---------
        text -- text to be inserted within the paragraph
        style -- optional paragraph style

        """
        # create all OpenXML elements
        paragraph = self.get_w_oxml("p")
        run = self.get_w_oxml("r")
        txt = self.get_text(text)

        # populate parent/child relationships
        run.append(txt)
        paragraph.append(run)

        # change style
        if style is not None:
            paragraph.style = style
        return paragraph

    def get_text(self, text):
        """Create and return a Text OpenXML element"""
        # TODO handle conversion of tabs
        clean_text = self.remove_control_char(text)
        element = self.get_w_oxml("t")
        element.text = clean_text

        # ensure text won't be stripped (add attribute
        # xml:space="preserve")
        if len(clean_text.strip()) < len(clean_text):
            element.set(qn("xml:space"), "preserve")

        return element

    def get_table_caption(self, text):
        """Create a caption for tables

        Arguments
        ---------
        text -- text or runs of the caption

        """
        # pylint: disable=invalid-name
        # create the base OpenXML paragraph
        paragraph = self.get_paragraph(_("Tableau "), self.docx_style["caption"])

        # Add the dynamic field
        # start field
        r = self.get_w_oxml("r")
        r.append(self.get_w_oxml("fldChar", {"fldCharType": "begin"}))
        paragraph.append(r)
        # field definition
        r = self.get_w_oxml("r")
        c = self.get_w_oxml("instrText")
        c.text = "SEQ Tableau \\* ARABIC"
        r.append(c)
        paragraph.append(r)
        # field separator
        r = self.get_w_oxml("r")
        r.append(self.get_w_oxml("fldChar", {"fldCharType": "separate"}))
        paragraph.append(r)
        # pre-computed value for the sequence
        self._tbl_count += 1
        r = self.get_w_oxml("r")
        r.append(self.get_text(str(self._tbl_count)))
        paragraph.append(r)
        # end field
        r = self.get_w_oxml("r")
        r.append(self.get_w_oxml("fldChar", {"fldCharType": "end"}))
        paragraph.append(r)

        # Add the rest of the caption
        r = self.get_w_oxml("r")
        r.append(self.get_text(" : "))
        paragraph.append(r)
        # text can be either a text or a list of runs
        if isinstance(text, (list, tuple)):
            for r in self.ensure_runs(text):
                paragraph.append(r)
        else:
            r = self.get_w_oxml("r")
            r.append(self.get_text(str(text)))
            paragraph.append(r)

        return paragraph

    def docx_simple_bbcode(self, txt, doc_part):
        """Interprete BBcode to transform it into docx

        Be aware that this method WILL modify the current docx document

        Currently, the following for tags are supported
         * [b][/b]:             emphasize the text
         * [e][/e]:             emphasize2 the text
         * [i][/i]:             italicize the text
         * [u][/u]:             underline the text
         * [code][/code]:       print text as code
         * [codeblock][/codeblock]:       print text as a block of code
         * [list][*][/list]:    create a bullet list
         * [table][/table]:     create a table
         * [tr][/tr]:           create a table row
         * [th][/th]:           create a table header cell
         * [td][/td]:           create a table cell
         * [url][/url]:         create an hyperlink
         * [url=XX][/url]:      create an hyperlink
         * [bg=XX][/bg]:        define the background of the current
                                cell (need [th] or [td] parent)
         * [title][/title]:     create caption for a table
                                (need [table] parent)
         * [section=XX][/section]:          Create a new section
         * [help=XXX][/help]    create an info box

        To parse the BBcode and construct the docx document, a
        postordering Depth-first search algorithm is used. The OpenXML
        elements are created starting from leaves until the body.
        Each leaf create a list of OpenXML elements which are then
        re-used by the parent to wrap them and create its own OpenXML
        elements.

        Arguments
        ---------
        txt -- text to be parsed and rendered
        doc_part -- Document part
        force_escape -- whether to escape the text of BBcode tags.
                        Default False

        """
        # Parse the text
        tree = parse_bbcode(txt)

        # render the tree
        return self.render_node(prettify_bbcode_tree(tree, is_wrapped=True), doc_part)

    def render_node(self, node, doc_part):
        """Render a node and its children"""
        # Defines actions for all tags
        tags = {
            "b": self.emphasis_tag,  # noqa: E241
            "e": self.emphasis2_tag,  # noqa: E241
            "i": self.italic_tag,  # noqa: E241
            "u": self.underline_tag,  # noqa: E241
            "code": self.inlinecode_tag,  # noqa: E241
            "codeblock": self.code_tag,  # noqa: E241
            "table": self.table_tag,  # noqa: E241
            "list": self.list_tag,  # noqa: E241
            "listitem": self.item_tag,  # noqa: E241
            "url": self.link_tag,  # noqa: E241
            "section": self.section_tag,  # noqa: E241
            "help": self.help_tag,  # noqa: E241
        }

        # the rendering depends on the node type
        if isinstance(node, RootNode):
            return self.fix_keepwithnext(
                self.ensure_paragraphs(
                    self.render_children(node, doc_part),
                ),
            )

        if isinstance(node, TextNode):
            return self.render_text(node.text, doc_part)

        if isinstance(node, ElementNode):
            # redirect to the right action, if any
            # unknown tags are discarded
            if node.tagname in tags:
                return tags[node.tagname](node, doc_part)
            logger.getLogger(__name__).warning(
                "Unknown tag [%s] found: ignore it",
                node.tagname,
            )
            # default to not doing anything: only render children
            return self.render_children(node, doc_part)

        raise RuntimeError("Unexpected Node in AST: %s" % type(node).__name__)

    def render_children(self, node, doc_part):
        """Render all the children of the given node"""
        # only need to concatenate the rendering of each children
        ret = []
        for n in node.children:
            ret.extend(self.render_node(n, doc_part))
        return ret

    @format_runs
    def italic_tag(self, run, doc_part):
        """Render a [i] tag"""
        rpr = run.get_or_add_rPr()
        rpr._set_bool_val("i", True)

    @format_runs
    def emphasis_tag(self, run, doc_part):
        """Render a [b] tag"""
        run.style = self.docx_style["emphasize"]

    @format_runs
    def emphasis2_tag(self, run, doc_part):
        """Render a [e] tag"""
        run.style = self.docx_style["emphasize2"]

    @format_runs
    def underline_tag(self, run, doc_part):
        """Render a [u] tag"""
        rpr = run.get_or_add_rPr()
        rpr._set_bool_val("u", True)

    @format_runs
    def inlinecode_tag(self, run, doc_part):
        """Render a [code] tag"""
        run.style = self.docx_style["inlineCode"]

    @format_paragraphs
    def code_tag(self, paragraph, doc_part, first=False, last=False):
        """Render a [codeblock] tag"""
        paragraph.style = self.docx_style["code"]
        # add the keepwithprevious attribute to later set keepwithnext
        if first:
            paragraph.keepwithprevious = True

    @format_runs
    def title_tag(self, run, doc_part):
        """Render a [title] tag"""
        # nothing is to be done

    def help_tag(self, node, doc_part):
        """Render a [help] tag"""
        # Help tags are rendered a single cell table
        # create the table with the content
        ret = self.docx_simple_bbcode(
            "[table][tr][td][b]%s[/b][/td][/tr][/table]" % node.attribute,
            doc_part,
        )
        # update the table style
        ret[0].tblPr.style = self.docx_style["infobox"]
        # remove the keepwithprevious tag
        ret[0].keepwithprevious = False

        # save the current style and change for table styles
        cur_style = self.docx_style
        self.docx_style = self.DOCX_STYLE_TABLE
        # render children and append it to the cell
        children = self.ensure_paragraphs(
            self.render_children(node, doc_part),
        )
        # ensure a normal style is applied
        for p in children:
            if isinstance(p, CT_P) and p.style is None:
                p.style = self.docx_style["normal"]
        ret[0].tr_lst[0].tc_lst[0].extend(children)
        # restore previous styles
        self.docx_style = cur_style

        return ret

    def section_tag(self, node, doc_part):
        """Render a [section] tag"""
        # update the current level
        self._current_section_lvl += 1
        ret = []
        # add the title paragraph
        ret.append(
            self.get_paragraph(
                node.attribute,
                style=self.docx_style["heading{0}".format(self._current_section_lvl)],
            ),
        )
        # render children
        children = self.render_children(node, doc_part)

        # transform all children as paragraph
        children = self.ensure_paragraphs(children)
        ret.extend(children)

        # update the current level
        self._current_section_lvl -= 1

        return ret

    def table_tag(self, node, doc_part):
        """Render a [table] tag"""
        # save the current style and change for table styles
        cur_style = self.docx_style
        self.docx_style = self.DOCX_STYLE_TABLE

        # render all row children
        children = []
        caption = None
        max_cols = 0
        count = 0
        first = first_row = first_col = True
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in "tr":
                if count < self.MAX_DATA_THRES:
                    element, cols, fr, fc = self.line_tag(n, doc_part)
                    max_cols = max(cols, max_cols)
                    children.extend(element)
                    # update first_row & first_col
                    first_col &= fc
                    if first:
                        first_row = fr
                        first = False
                count += 1
            elif isinstance(n, ElementNode) and n.tagname in "title":
                caption = self.title_tag(n, doc_part)

        # create the table with the content
        tbl = self.get_table_oxml()
        tbl.extend(children)

        # update the table with its properties
        tblpr = tbl.tblPr
        tblpr.style = self.docx_style["table"]
        tblpr.append(
            self.get_w_oxml(
                "tblLook",
                {
                    "val": "0620",  # noqa: E241
                    "firstRow": "1" if first_row else "0",  # noqa: E241
                    "lastRow": "0",  # noqa: E241
                    "firstColumn": "1" if first_col else "0",  # noqa: E241
                    "lastColumn": "0",  # noqa: E241
                    "noHBand": "1",  # noqa: E241
                    "noVBand": "1",  # noqa: E241
                },
            ),
        )

        # change table size
        #   width: 16.38cm
        #   ident & alignment are handle within table style
        col_w = Cm(16.38 / max_cols)
        # TODO handle alignement
        # using tblpr.alignment = WD_TABLE_ALIGNMENT.LEFT
        tblpr.append(
            self.get_w_oxml(
                "tblW",
                {
                    "type": "dxa",
                    "w": str(col_w.twips * max_cols),
                },
            ),
        )

        # Define the tblGrid. Use a same-width layout even if it will be
        # overriden by the the table layout algorithm
        grid = tbl.tblGrid
        for _ in range(max_cols):
            grid.add_gridCol().w = col_w

        # restore previous styles
        self.docx_style = cur_style

        # add a caption to the table
        if caption is not None:
            # add keepwithnext to the last row
            p = tbl.tr_lst[-1].tc_lst[0].p_lst[0]
            p.get_or_add_pPr().get_or_add_keepNext()
            # add the caption paragraph
            ending_paragraph = self.get_table_caption(caption)
        else:
            # add an empty paragraph after the table
            ending_paragraph = self.get_paragraph("")

        # add the keepwithprevious attribute to later set keepwithnext
        tbl.keepwithprevious = True

        # add a warning text when lines were stripped
        if count > self.MAX_DATA_THRES:
            warning = self.docx_simple_bbcode(
                Markup(
                    (
                        "[b]ATTENTION[/b] : {0:d} ligne(s) ont été supprimée(s) du "
                        "tableau ci-dessous. Utiliser un format de sortie de "
                        "limitant pas la taille des tableaux pour avoir la liste "
                        "exhaustive (par exemple : csv)"
                    ).format(
                        count - self.MAX_DATA_THRES,
                    ),
                ),
                doc_part,
            )
            return warning + [tbl, ending_paragraph]
        # else return without a warning
        return [tbl, ending_paragraph]

    def line_tag(self, node, doc_part):
        """Render a [tr] tag

        Returns
        -------
        A tuple (
            OpenXML element -- the rendered element
            Column count -- the number of (virtual) columns in the row
            First line -- whether the line is a header row (full of th)
            First col -- whether the line has header col (start with th)
        )

        """
        # render all children: only [th] & [td] should be rendered
        children = []
        nb_cols = 0
        first = first_row = first_col = True
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in ["td", "th"]:
                element, cols = self.cell_tag(n, doc_part)
                nb_cols += cols
                children.extend(element)
                # update first_row & first_col
                first_row &= n.tagname == "th"
                if first:
                    first_col = n.tagname == "th"
                    first = False

        # create the table row with the content
        row = self.get_w_oxml("tr")
        row.extend(children)

        # update the row with its properties
        trpr = row.get_or_add_trPr()
        # can't split the lines
        trpr.append(self.get_w_oxml("cantSplit"))

        return [row], nb_cols, first_row, first_col

    def cell_tag(self, node, doc_part):
        """Render a [td] or [th] tag

        Returns
        -------
        A tuple (
            OpenXML element -- the rendered element
            Column count -- the number of (virtual) columns of the cell
        )

        """
        # try to find possible background color for the cell
        # background color is configured using the [bg] tag which must
        # be placed as a child of a cell tag.
        content_n = node
        color = None
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "bg":
                # store the color for later
                color = self.check_color(n.attribute)
                # the children to be rendered are [bg] node children
                content_n = n
                break

        # postordering BF search algorithm ==> need to render children
        # first
        children = self.render_children(content_n, doc_part)

        # transform all children as paragraph and stylize the
        # paragraphs with the table normal style, if no style is
        # already defined
        children = self.ensure_paragraphs(children)
        for p in children:
            if isinstance(p, CT_P) and p.style is None:
                p.style = self.docx_style["normal"]

        # <w:tc> requires to contains at least a paragraph, even empty
        if len(children) == 0:
            children = [self.get_w_oxml("p")]

        # create the table cell with the content
        cell = self.get_w_oxml("tc")
        cell.extend(children)

        # update the cell with its properties
        tcpr = cell.get_or_add_tcPr()
        tcw = self.get_w_oxml("tcW")
        tcpr.append(tcw)
        # autofit on cells width
        tcw.type = "auto"
        tcw.w = 0
        # handle colspan
        nb_cols = 1
        if node.attribute is not None and str.isnumeric(node.attribute):
            nb_cols = int(node.attribute)
            tcpr.grid_span = nb_cols
        # handle cell color
        if color is not None:
            shd = self.get_cell_color_oxml(color)
            tcpr.append(shd)
        return [cell], nb_cols

    def list_tag(self, node, doc_part):
        """Render a [list] tag"""
        # update the current level
        self._current_list_lvl += 1
        # render children list items
        ret = []
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "listitem":
                ret.extend(self.render_node(n, doc_part))
        # update the current level
        self._current_list_lvl -= 1

        # add the keepwithprevious attribute to later set keepwithnext
        if len(ret) > 0:
            ret[0].keepwithprevious = True
        return ret

    def item_tag(self, node, doc_part):
        """Render a item of a list ([*])"""
        # render children
        # item tags should strip inner content (to prevent undesired
        # newlines)
        ret = []
        ret.extend(self.render_children(node, doc_part))

        # transform all items into a paragraph with the right style
        style = "listBullet{lvl}".format(lvl=self._current_list_lvl)
        # sanity check the style
        if style not in self.docx_style:
            logger.getLogger(__name__).warning(
                "Unknown style %s: defaults to Normal",
                style,
            )
            style = "normal"

        # transform to a list of paragraph
        ret = self.ensure_paragraphs(ret)
        for p in ret:
            # only change style of paragraph without styles
            # to preserve nested lists styles
            # Can have strange behaviours on text with bad semantic
            if p.style is None:
                p.style = self.docx_style[style]

        return ret

    @format_runs
    def link_tag(self, run, doc_part, attr=None):
        """Render a [url] tag"""
        # resolve url
        if attr is None:
            url = self.check_url(run.text)
        else:
            url = self.check_url(attr)

        # create the _rel counter part of the URL
        r_id = doc_part.relate_to(url, RELATIONSHIP_TYPE.HYPERLINK, is_external=True)

        # Create the w:hyperlink tag and add needed values
        hyperlink = self.get_w_oxml("hyperlink")
        hyperlink.set(qn("r:id"), r_id)
        hyperlink.append(run)

        # Apply the link style to the run
        run.style = self.docx_style["link"]

        return hyperlink

    def render_text(self, text, doc_part):
        """Render a TextNode

        Transform the TextNode into a list of OpenXML <w:t> element

        Arguments
        ---------
        text -- the text of the TextNode

        Returns
        -------
        A list of OpenXML <w:t> element or None. One item for each line.
        None corresponds to a end of line (i.e. a paragraph)

        """
        # This function *should be* the only one adding text to our
        # document
        ret = []
        for line in text.split("\n"):
            if line != "":
                # create the <w:t> element for non-empty lines
                ret.append(self.get_text(line))
            # anyway add a end of line element
            ret.append(None)
        # strip the last None which does not correspond to a \n
        return ret[:-1]

    SAFE_COLOR = re.compile(r"^#?([a-fA-F0-9]{6})$")

    def check_color(self, color):
        """Check color is safe to be included within a document"""
        if self.SAFE_COLOR.match(color):
            return color[-6:]
        raise RuntimeError("Invalid color: %s" % color)

    SAFE_URL = re.compile(r"^https?://[-a-z0-9+&@#/%?=~_|!:,.;\(\)]+$", re.I)

    def check_url(self, url):
        """Check url is safe to be included within a document"""
        if self.SAFE_URL.match(url):
            return url
        raise RuntimeError("Invalid URL: %s" % url)
