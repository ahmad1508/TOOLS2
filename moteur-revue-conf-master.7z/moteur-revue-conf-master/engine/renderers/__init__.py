# -*- coding: utf-8 -*-

"""Contain all renderers to render reports

They are loaded automatically from the Renderer class
"""

# Standard libraries
import os

# dynamically create __all__ from the listing of the current directory
__all__ = []
base = os.path.dirname(__file__)
for entry in os.listdir(base):
    # skip all entries starting with "_"
    if entry[0] == "_":
        continue

    # keep all python files and valid packages
    if entry.endswith(".py") and os.path.isfile(os.path.join(base, entry)):
        __all__.append(entry[:-3])
    elif os.path.isdir(os.path.join(base, entry)) and os.path.isfile(
        os.path.join(base, entry, "__init__.py"),
    ):
        __all__.append(entry)
