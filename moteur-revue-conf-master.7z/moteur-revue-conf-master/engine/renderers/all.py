# -*- coding: utf-8 -*-

"""Provides a wrapper to generate all outputs"""

# Standard libraries
import threading

# Project imports
from engine.core.renderer import Renderer


class AllRenderer(Renderer):
    """Renderer all formats"""

    desc = {
        "extensions": ["all"],
    }

    def render_report(self, filename, tech_name, content):
        """Render and save a report from the layout

        This method override the base method

        Args:
            filename (str): name of the file to render in
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        """
        # Run all renderers in a different thread
        threads = []
        for renderer in Renderer.plugins():
            # prevent rendering itself
            if renderer is not AllRenderer:
                threads.append(
                    threading.Thread(
                        target=renderer().render_report,
                        args=(
                            "%s.%s" % (filename, renderer.extensions[0]),
                            tech_name,
                            content,
                        ),
                    ),
                )
                threads[-1].start()

        # wait for all threads to stop
        for thr in threads:
            thr.join()
