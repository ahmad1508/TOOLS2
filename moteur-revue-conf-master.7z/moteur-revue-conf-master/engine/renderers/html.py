# -*- coding: utf-8 -*-

"""Provides an html generation"""

# Standard libraries
import os
import random
import re
import string

# Project imports
from engine import logger
from engine.bbcode import ElementNode, Markup, parse_bbcode, RootNode, TextNode
from engine.bbcode.prettifier import prettify_bbcode_tree
from engine.core.renderer import Renderer

try:
    # Third party libraries
    from jinja2 import Environment, escape, FileSystemLoader
except ImportError:
    raise ImportError("This script requires the package Jinja2")


class HtmlRenderer(Renderer):
    """Renderer for HTML format"""

    desc = {
        "extensions": ["html", "htm"],
    }

    # Prevent rendering to many table lines
    MAX_DATA_THRES = 500

    def __init__(self):
        """Initialize the renderer"""
        # defines jinja environment
        self.env = Environment(
            autoescape=True,
            loader=FileSystemLoader(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "html",
                ),
            ),
            trim_blocks=False,
        )
        self.env.filters["bbcode"] = self.jinja_simple_bbcode

        self._tbl_count = 0
        self._current_section_nums = []
        self._help_count = 0
        self.prev_ids = []

    def render(self, tech_name, content):
        """Render a report from the layout

        This method implements the base method

        Args:
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        Returns:
            bytes: the rendered output as bytes

        """
        # reset render env
        self._tbl_count = 0
        self._current_section_nums = [0]
        self._help_count = 0
        self.prev_ids = []

        # run jinja
        return (
            self.env.get_template("template.html")
            .render(
                {
                    "type": tech_name,
                    "content": content,
                },
            )
            .encode("utf-8")
        )

    def jinja_simple_bbcode(self, txt, escape_html=True):
        """Interprete BBcode to transform it into html

        It is defined as a Jinja filter

        Currently, the following for tags are supported
         * [b][/b]:                 emphasize the text
         * [e][/e]:                 emphasize2 the text
         * [i][/i]:                 italicize the text
         * [u][/u]:                 underline the text
         * [code][/code]:           print text as code
         * [list][*][/list]:        create a bullet list
         * [url][/url]:             create a link
         * [url=XXX][/url]:         create a link with replacement text
         * [table][/table]:         create a table
         * [tr][/tr]:               create a table row
         * [th][/th]:               create a table header cell
         * [td][/td]:               create a table cell
         * [bg=XX][/bg]:            define the background of the current
                                    cell (need [th] or [td] parent)
         * [title][/title]:         create caption for a table
                                    (need [table] parent)
         * [codeblock][/codeblock]: print text as code
         * [tabs][tab][/tab][/tabs]: print text as tabs
         * [section=XX][/section]:  Create a new section
         * [help=XXX][/help]        create an info box

        It also handles newlines

        The default behavior is to ensure the text is escaped. It can be
        changed by calling the filter with a parameter.
        """
        txt = Markup(txt)
        if escape_html:
            txt = escape(txt)

        # Parse the text
        tree = parse_bbcode(txt)

        return self.render_node(prettify_bbcode_tree(tree, is_wrapped=True))

    def render_node(self, node):
        """Render a node"""
        # Defines actions for all tags
        tags = {
            "b": self.simple_tag,  # noqa: E241
            "e": self.emphasis_tag,  # noqa: E241
            "i": self.simple_tag,  # noqa: E241
            "u": self.simple_tag,  # noqa: E241
            "code": self.simple_tag,  # noqa: E241
            "table": self.table_tag,  # noqa: E241
            "list": self.list_tag,  # noqa: E241
            "listitem": self.item_tag,  # noqa: E241
            "url": self.link_tag,  # noqa: E241
            "codeblock": self.codeblock_tag,  # noqa: E241
            "tabs": self.tabs_tag,  # noqa: E241
            "added": self.added_tag,  # noqa: E241
            "removed": self.removed_tag,  # noqa: E241
            "section": self.section_tag,  # noqa: E241
            "help": self.help_tag,  # noqa: E241
        }

        # the rendering depends on the node type
        if isinstance(node, RootNode):
            return self.render_children(node)

        if isinstance(node, TextNode):
            return self.render_text(node.text)

        if isinstance(node, ElementNode):
            # redirect to the right action, if any
            # unknown tags are discarded
            if node.tagname in tags:
                return tags[node.tagname](node)
            logger.getLogger(__name__).warning(
                "Unknown tag [%s] found: ignore it",
                node.tagname,
            )
            return str(node)

        raise RuntimeError("Unexpected Node in AST: %s" % type(node).__name__)

    def render_children(self, node):
        """Render all children from a node"""
        return "".join([self.render_node(n) for n in node.children])

    # list of actions to parse the tree
    def simple_tag(self, node):
        """Render simple tags like [b] or [i]"""
        # Note: the parser ensure that tagname is in the class
        # [a-zA-Z0-9_]
        # It is safe to include it in markups
        return "<{0}>{1}</{0}>".format(
            node.tagname,
            self.render_children(node),
        )

    def added_tag(self, node):
        """Render tags"""
        return "<span class='added'>{0}</span>".format(
            self.render_children(node),
        )

    def removed_tag(self, node):
        """Render tags"""
        return "<span class='removed'>{0}</span>".format(
            self.render_children(node),
        )

    def emphasis_tag(self, node):
        """Render [e] tags"""
        return "<b class='emphasis2'>{0}</b>".format(
            self.render_children(node),
        )

    def codeblock_tag(self, node):
        """Render [codeblock] tags"""
        # enclose into pre tag
        # also remove newline which should already be transformed into
        # <br> in render_children()
        return (
            "<pre class='pre-scrollable'>"
            + self.render_children(node).replace("\n", "")
            + "</pre>"
        )

    def section_tag(self, node):
        """Render [section] tags"""
        # Increase section number
        self._current_section_nums[-1] += 1

        # render inner text
        self._current_section_nums.append(0)
        content = self.render_children(node)
        self._current_section_nums.pop()

        return (
            "<div class='section' id='section-{sectid}'>"
            "  <h{sectlevel}>"
            "    <div class='btn-group pull-right'>"
            "      <a href='#content-{sectid}' class='btn btn-default' "
            "         data-toggle='collapse' title='Déplier/replier'>"
            "      </a>"
            "    </div>"
            "    <span class='num'>{sectnum}</span><span class='titre'>{title}</span>"
            "  </h{sectlevel}>"
            "  <div id='content-{sectid}' class='section-content collapse in'><p>"
            "  {content}"
            "  </p></div>"
            "</div>"
        ).format(
            sectid="-".join(map(str, self._current_section_nums)),
            sectlevel=len(self._current_section_nums) + 2,
            sectnum=".".join(map(str, self._current_section_nums)),
            title=node.attribute,
            content=content,
        )

    def help_tag(self, node):
        """Render [help] tags"""
        content = self.render_children(node)
        self._help_count += 1
        return (
            "<div class='panel panel-default'>"
            "  <div class='panel-heading'>"
            "    <strong class='panel-title'>{title}</strong>"
            "    <div class='btn-group pull-right'>"
            "      <a href='#help-{helpid}' class='btn btn-default' "
            "         data-toggle='collapse' title='Déplier/replier'>"
            "      </a>"
            "    </div>"
            "  </div>"
            "  <div id='help-{helpid}' class='panel-body collapse'>"
            "    {content}"
            "  </div>"
            "</div>"
        ).format(
            title=node.attribute,
            content=content,
            helpid=self._help_count,
        )

    def title_tag(self, node):
        """Render a [title] tag"""
        self._tbl_count += 1
        return "<p class='text-center'><i>Tableau {0:d} : {1}</i></p>".format(
            self._tbl_count,
            self.render_children(node),
        )

    def table_tag(self, node):
        """Render [table] tags"""
        children = []
        caption = ""
        count = 0
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in "tr":
                if count < self.MAX_DATA_THRES:
                    children.append(self.line_tag(n))
                count += 1
            elif isinstance(n, ElementNode) and n.tagname in "title":
                caption = self.title_tag(n)

        # add a warning text when lines were stripped
        warning = ""
        if count > self.MAX_DATA_THRES:
            warning = self.jinja_simple_bbcode(
                Markup(
                    (
                        "[b]ATTENTION[/b] : {0:d} ligne(s) ont été supprimée(s) du "
                        "tableau ci-dessous. Utiliser un format de sortie de "
                        "limitant pas la taille des tableaux pour avoir la liste "
                        "exhaustive (par exemple : csv)"
                    ).format(
                        count - self.MAX_DATA_THRES,
                    ),
                ),
            )

        return (
            warning
            + "<div style='overflow-x: auto;'>"
            + "<table class='table table-striped'>"
            + "".join(children)
            + "</table>"
            + "</div>"
            + caption
        )

    def line_tag(self, node):
        """Render a [tr] tag"""
        # render all children: only [th] & [td] should be rendered
        children = []
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in ["td", "th"]:
                children.append(self.table_cell_tag(n))
        return "<tr>" + "".join(children) + "</tr>"

    def table_cell_tag(self, node):
        """Render [td] and [th] tags"""
        # Note: the parser ensure that tagname is in the class
        # [a-zA-Z0-9_]
        # It is safe to include it in markups
        attributes = [node.tagname]

        # try to find possible background color for the cell
        # background color is configured using the [bg] tag which must
        # be placed as a child of a cell tag.
        content_n = node
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "bg":
                content_n = n
                if n.attribute is not None:
                    attributes.append(
                        "style='background-color: #%s'" % self.check_color(n.attribute),
                    )
                break

        # check whether a colspan is set up
        if node.attribute is not None and str.isnumeric(node.attribute):
            attributes.append("colspan='%d'" % int(node.attribute))

        return "<{0}>{1}</{2}>".format(
            " ".join(attributes),
            self.render_children(content_n),
            attributes[0],
        )

    def list_tag(self, node):
        """Render [list] tags"""
        # only print items
        content = ""
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "listitem":
                content += self.render_node(n)
        return "<ul>" + content + "</ul>"

    def item_tag(self, node):
        """Render list items ([*])"""
        # item tags should strip inner content (to prevent undesired
        # newlines)
        content = self.render_children(node)
        if node.attribute is None:
            return "<li>" + content + "</li>"
        return f"<li class='{node.attribute}'>" + content + "</li>"

    def link_tag(self, node):
        """Render [url] tags"""
        # handle both case with ou without attribute
        if node.attribute is None:
            # [url]http://exemple.org[/url]
            return "<a href='{0}'>{0}</a>".format(self.check_url(str(node)))
        # [url=http://exemple.org]Replacement text[/url]
        return "<a href='{0}'>{1}</a>".format(
            self.check_url(node.attribute),
            self.render_children(node),
        )

    def render_text(self, text):
        """Just render text"""
        return self.convert_newlines(text)

    @staticmethod
    def convert_newlines(content):
        """Convert newlines into html newlines"""
        return content.replace("\n", "<br/>\n")

    SAFE_URL = re.compile(r"^https?://[-a-z0-9+&@#/%?=~_|!:,.;\(\)]+$", re.I)

    def check_url(self, url):
        """Check url is safe to be included within a document"""
        if self.SAFE_URL.match(url):
            return url
        raise RuntimeError("Jinja: Invalid URL: %s" % url)

    SAFE_COLOR = re.compile(r"^#?([a-fA-F0-9]{6})$")

    def check_color(self, color):
        """Check color is safe to be included within a document"""
        if self.SAFE_COLOR.match(color):
            return color[-6:]
        raise RuntimeError("Jinja: Invalid color: %s" % color)

    def rnd_id(self):
        """Generate a random id"""
        i = "".join(random.choice(string.ascii_letters) for _ in range(20))  # nosec
        if i in self.prev_ids:
            i = self.rnd_id()
        else:
            self.prev_ids.append(i)
        return i

    def tabs_tag(self, node):
        """Render [tabs][tab][/tabs] tags"""
        id_pre = self.rnd_id()
        # render each tab
        tabs = []
        i = 0
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "tab":
                i += 1
                if n.attribute is None:
                    title = "Tab %d" % i
                else:
                    title = n.attribute
                tabs.append((title, self.render_children(n)))

        headings = "".join(
            "<li class='%s'><a href='#%s_%d' data-toggle='tab'>%s</a></li>"
            % (
                "active" if i == 0 else "",
                id_pre,
                i,
                v[0],
            )
            for i, v in enumerate(tabs)
        )
        contents = "".join(
            "<div class='tab-pane%s' id='%s_%d'>%s</div>"
            % (
                " active" if i == 0 else "",
                id_pre,
                i,
                v[1],
            )
            for i, v in enumerate(tabs)
        )
        return (
            "<ul class='nav nav-tabs'>"
            "%s"
            "</ul>"
            "<div class='tab-content'>"
            "%s"
            "</div>"
        ) % (headings, contents)
