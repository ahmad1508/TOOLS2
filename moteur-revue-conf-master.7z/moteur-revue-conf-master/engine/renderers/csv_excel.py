# -*- coding: utf-8 -*-

"""Provides Excel CSV generation of all tables"""

# Project imports
from engine.renderers.csv import CsvRenderer


class CsvExcelRenderer(CsvRenderer):
    """Renderer for Excel CSV format"""

    desc = {
        "extensions": ["csv_excel"],
    }

    SEPARATOR = ";"  # For Excel compatibility
    NEW_LINE = "\n"  # For Excel compatibility
