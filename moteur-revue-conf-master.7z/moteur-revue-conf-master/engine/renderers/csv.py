# -*- coding: utf-8 -*-

"""Provides CSV generation of all tables"""

# Standard libraries
import os
import pathlib
import re
import unicodedata

# Project imports
from engine import logger
from engine.bbcode import ElementNode, parse_bbcode, RootNode, TextNode
from engine.bbcode.prettifier import prettify_bbcode_tree
from engine.core.renderer import Renderer

_slugify_strip_re = re.compile(r"[^\w\s-]")
_slugify_hyphenate_re = re.compile(r"[-\s]+")


def _slugify(value):
    """Normalize string

    converts to lowercase, removes non-alpha characters,
    and converts spaces to hyphens.

    Based on code from http://code.activestate.com/recipes/577257/
    """
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    value = _slugify_strip_re.sub("", value).strip().lower()
    return _slugify_hyphenate_re.sub("-", value)


class CsvRenderer(Renderer):
    """Renderer for CSV format"""

    desc = {
        "extensions": ["csv"],
    }

    MAX_TITLE_LEN = 30  # Max length for the titles
    ENCODING = "cp1252"  # For Excel compatibility
    SEPARATOR = ","  # For Excel compatibility
    NEW_LINE = "\r\n"  # For RFC 4180 compatibility
    LIST_PREPEND = [
        "",
        "/ ",
        "  - ",
        "    » ",
        "      * ",
    ]

    def __init__(self, *args, **kargs):
        """Initialize the renderer"""
        super().__init__(*args, **kargs)
        # render environment
        self._current_list_lvl = 0
        self._tbl_count = 0

    def render_report(self, filename, tech_name, content):
        """Render and save a report from the layout

        This method override the base method

        Args:
            filename (str): name of the file to render in
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        """
        # Create the directory if needed
        pathlib.Path(filename).mkdir(parents=True, exist_ok=True)

        # reset render env
        self._current_list_lvl = 0
        self._tbl_count = 0

        # Start rendering of the report
        self.csv_simple_bbcode(filename, content)

    def csv_simple_bbcode(self, path, review):
        """Interprete BBcode to extract the tables

        Currently, the following for tags are supported
         * [url][/url]:             create an hyperlink
         * [url=XX][/url]:          create an hyperlink
         * [list][*][/list]:        create a bullet list
         * [table][/table]:         create a table
         * [tr][/tr]:               create a table row
         * [th][/th]:               create a table header cell
         * [td][/td]:               create a table cell
         * [title][/title]:         create caption for a table
                                    (need [table] parent)

        """
        # Parse the text
        tree = parse_bbcode(review)
        self.render_node(path, prettify_bbcode_tree(tree, is_wrapped=True))

    def render_node(self, path, node):
        """Render a node"""
        # Defines actions for all tags
        tags = {
            "table": self.table_tag,  # noqa: E241
            "list": self.list_tag,  # noqa: E241
            "url": self.link_tag,  # noqa: E241
        }
        # the rendering depends on the node type
        if isinstance(node, RootNode):
            return self.render_children(path, node)

        if isinstance(node, TextNode):
            # return the text
            return self.render_text(node.text)

        if isinstance(node, ElementNode):
            # redirect to the right action, if any
            if node.tagname in tags:
                return tags[node.tagname](path, node)
            # unknown tags are discarded silently to render the content
            return self.render_children(path, node)

        raise RuntimeError("Unexpected Node in AST: %s" % type(node).__name__)

    def render_children(self, path, node):
        """Render all children from a node"""
        return "".join([self.render_node(path, n) for n in node.children])

    def render_text(self, text):
        """Just render text"""
        return self.convert_newlines(text)

    @staticmethod
    def convert_newlines(content):
        """Convert newlines"""
        return content.replace("\r\n", "\n")

    def table_tag(self, path, node):
        """Render [table] tags"""
        table = []
        name = None
        # Render the table as CSV
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in "tr":
                table.append(self.line_tag(path, n))
            elif isinstance(n, ElementNode) and n.tagname in "title":
                name = self.title_tag(path, n)

        # Create a name if no title is defined
        if name is None:
            name = "Uncaptioned-table"

        # save the table as a CSV
        # prepend the file name with an increasing number to ensure
        # filenames will keep the same order as tables
        self._tbl_count += 1
        fname = "{0:03d}_{1:s}.csv".format(self._tbl_count, name)

        # save file in a try-except to be able to continue
        try:
            with open(os.path.join(path, fname), "w", encoding=self.ENCODING) as f:
                f.write(self.NEW_LINE.join(table) + self.NEW_LINE)
        except Exception as exc:  # pylint: disable=broad-except
            logger.getLogger(__name__).warning(
                "Error while saving CSV file `%s'",
                fname,
                exc_info=exc,
            )

        # Return an empty string not to break the renderer
        return ""

    def title_tag(self, path, node):
        """Render a [title] tag"""
        return _slugify(self.render_children(path, node))[: self.MAX_TITLE_LEN]

    def line_tag(self, path, node):
        """Render a [tr] tag"""
        # render all children: only [th] & [td] should be rendered
        children = []
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname in ["td", "th"]:
                children.append(self.table_cell_tag(path, n))
        return self.SEPARATOR.join(children)

    def table_cell_tag(self, path, node):
        """Render [td] and [th] tags"""
        # try to find possible background color for the cell
        # background color is configured using the [bg] tag which must
        # be placed as a child of a cell tag.
        content_n = node
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "bg":
                # render the content of this node
                content_n = n
                break

        # check whether a colspan is set up
        if node.attribute is not None and str.isnumeric(node.attribute):
            span = int(node.attribute)
        else:
            span = 1

        # Ensure double quotes are escape
        # RFC 4180 states: If double-quotes are used to enclose fields,
        # then a double-quote must be represented by two double-quote
        # characters.
        txt = self.render_children(path, content_n)
        txt = txt.replace('"', '""')

        # Return a quoted version of the cell
        #  + as many empty cells as necessary to manage the span
        return '"%s"' % txt + self.SEPARATOR * (span - 1)

    def list_tag(self, path, node):
        """Render a [list] tag"""
        # update the current level
        self._current_list_lvl += 1

        # render children list items
        children = []
        for n in node.children:
            if isinstance(n, ElementNode) and n.tagname == "listitem":
                children.append(self.item_tag(path, n))

        # update the current level
        self._current_list_lvl -= 1

        return (
            "\n"  # ensure the first item is on a new line
            + "\n".join(children)
            # add a new line after the last item
            # only top-level items must be treated. The above join
            # already handle adding new lines after, for lower-level
            # lists
            + ("\n" if self._current_list_lvl == 0 else "")
        )

    def item_tag(self, path, node):
        """Render list items ([*])"""
        # item tags should strip inner content (to prevent undesired
        # newlines)
        content = self.render_children(path, node)

        # compute list prepend
        if self._current_list_lvl < len(self.LIST_PREPEND):
            pre = self.LIST_PREPEND[self._current_list_lvl]
        else:
            pre = " " * (2 * self._current_list_lvl)
        return pre + content

    def link_tag(self, path, node):
        """Render [url] tags"""
        # handle both case with ou without attribute
        if node.attribute is None:
            # [url]http://exemple.org[/url]
            return self.check_url(str(node))
        # [url=http://exemple.org]Replacement text[/url]
        return "{1} ({0})".format(
            self.check_url(node.attribute),
            self.render_children(path, node),
        )

    SAFE_URL = re.compile(r"^https?://[-a-z0-9+&@#/%?=~_|!:,.;\(\)]+$", re.I)

    def check_url(self, url):
        """Check url is safe to be included within a document"""
        if self.SAFE_URL.match(url):
            return url
        raise RuntimeError("Invalid URL: %s" % url)
