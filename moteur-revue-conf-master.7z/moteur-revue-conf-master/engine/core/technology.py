# -*- coding: utf-8 -*-

"""Provide a base classes for technologies

Classes:
    Technology: a plugable class which should be extend by every
        reviewable technology
"""


# Standard libraries
import sys

# Project imports
from engine import logger
from engine.bbcode import escape
from engine.bbcode import Markup as M  # noqa: N814
from engine.bbcode.prettifier import prettify_bbcode
from engine.core import i18n
from engine.core.extracts import Extracts
from engine.core.findings import Findings
from engine.core.plugable import Plugable
from engine.techs.common import to_utf8
from engine.utils import classproperty

# I18N
_ = i18n.domain("core")._


class Technology(Plugable):
    """This class is a base class for all technologies

    The class is sub-classed by different versions of the class to
    keep retrocompatibility.
    It must be extended by all technology classes

    This technology allows:

    * The use of any kind of input data
    * The use of multiple input extracts

    To extend this class, one may extend the following methods:

    * ``parse_input`` called to parse the input file
    * ``preprocessors```called once input file were parsed, to perform
      some preprocessing

    Attributes:
        name (str): name of the technology
        hostname (str): name of the reviewed device. It is the
            responsability of each technology do define it within
            preprocessors.
        layout (str): path of the layout file
        errors (list): list of raised errors
        extracts (Any): extracts
        artifacts (dict): a dict to store all artifacts
        all_findings (Findings): all findings of the technology
        findings (BoundFindings): the findings of the current filter.
            Everytime a filter is called, findings is updated for this
            filter. This is done within the wrapper for templates.
            The name of the section will be the name of the filter
            function. When called outside of a filter context, findings
            will be bound to ``default`` section.
            The :py:attribute:`findings` attribute may also be retrieved
            on the filter functions (only within the templates) to
            directly get access to the findings of the function.

    """

    # packages where pluging may be located
    packages = ["engine.techs"]

    # Empty definition of desc
    desc = {}

    def __init__(self):
        """Initialize a technology."""
        # init variables
        self.hostname = None
        self.errors = []
        self.extracts = None
        self.artifacts = {}
        self.all_findings = Findings()
        self.findings = self.all_findings.bind("default")

    @classmethod
    def get_by_name(cls, name):
        """Retrieve a technology class from its name"""
        for m in cls.plugins():
            if m.name == name:
                return m
        return None

    @classproperty
    def name(cls):
        """Resolve the name of the technology

        If the class property `desc[name]` is defined, we use it
        If not, we resolve it from class name:
            - we use the class name in lowercase
            - we strip "Tech" "Techs" "Technology" or "Technologies"
              at the end of the class name

        **Important**: obviously, it is recommended to use an explicit
        name definition

        e.g. all following classes would correspond to the same
        technology `linux`
        ```
        class MyReviewer(Technology):
            desc = {"name": "linux"}

        class Linux(Technology):
            pass

        class LinuxTech(Technology):
            pass

        class LinuxTechs(Technology):
            pass

        class LinuxTechnology(Technology):
            pass

        class LinuxTechTechnologies(Technology):
            pass

        ```
        """
        # check `desc[name]` first
        if "name" in cls.desc:
            return cls.desc["name"]

        # resolve from class name
        name = cls.__name__
        for suffix in ["Tech", "Techs", "Technology", "Technologies"]:
            if name.endswith(suffix):
                name = name[: -len(suffix)]
        return name.lower()

    @classproperty
    def default_language(cls):
        """Get the default language of the technology."""
        return cls.desc.get("default language", {})

    @classproperty
    def default_template(cls):
        """Get the default template of the technology."""
        return cls.desc.get("default template", {})

    @classproperty
    def templates(cls):
        """Get the templates of the technology."""
        return cls.desc.get("templates", {})

    @classmethod
    def get_template(cls, language, template_name):
        """Return the path to the template.

        The list of templates and languages and defined within the class
        property `desc[templates]`. It follows the following format:

        .. code-block:: python

            {
                "templates": {
                    "full": {
                        "fr": "linux_full.fr.jinja",
                        "en": "linux_full.en.jinja",
                    },
                    "light": {
                        "fr": "linux_light.fr.jinja",
                        "en": "linux_light.en.jinja",
                    },
                }
            }

        In case language or template_name are `None`, it uses the
        values of `desc[default language]` or `desc[default templates]`.

        Args:
            language (Any[str,None]): language to be used
            template_name (Any[str,None]): template to find

        Returns:
            str: the path of the template to load or None if not found.

        """
        # Use default values if None is provided
        language = language or cls.default_language
        template_name = template_name or cls.default_template

        # return the templates to be used or None
        return cls.desc.get("templates", {}).get(template_name, {}).get(language)

    @property
    def has_errors(self):
        """Return wether the technology has faced errors"""
        return len(self.errors) > 0

    def parse_input(self, extract):
        """Parse the input file.

        This method take the path to a file/folder (or anything else
        which is given in the ``-i`` option). It shuold open the file
        and provide extractions within ``self.extracts``.

        This methods can be extended to change the parsing behavior.
        Defaults behavior is to open as binary file.

        Args:
            extract (str): the file name to be parsed

        """
        with open(extract, "rb") as f:
            self.extracts = f.read()

    def preprocessors(self):
        """Perform preprocessors on extracts.

        This method is used to analyze/parse extracts prior to
        templating filters. This method can store parsed data within
        the ``dict`` :py:attr:`self.artifacts`.

        To be better handle multi-input reviews, this methods should
        also set the :py:attr:`self.hostname` of the reviewed device,
        when possible.

        The default behavior is to do nothing.
        """

    @property
    def wrapper(self):
        """Create a wrapper to ease call of filter from templates.

        Wrapped calls to filter will manage:

        * Exceptions to have a default behavior
        * Calling filter function if not called in template

        Returns:
            Class: a wrapping class which is provided to templates.

        """

        class TechnologyWrapper:
            """Wrapper for a technology."""

            def __init__(self, tech):
                self.tech = tech

            def __getattr__(self, name):
                if not hasattr(self.tech, name):
                    raise AttributeError(
                        "%s has no attribute %s" % (type(self.tech).__name__, name),
                    )

                attr = getattr(self.tech, name)
                # manage case of non-function attribute = not a filter
                if not callable(attr):
                    return attr

                # create a wrapper for filters
                class Wrapper:
                    """Wrapper of a filter function

                    Auto-call the function if rendered as:

                    .. code-block:: jinja2

                        {{ tech.my_filter }}

                    """

                    def __init__(self, tech, func):
                        self.tech = tech
                        self.func = func

                    def __call__(self, *args, **kargs):
                        # Update the findings for the section
                        self.tech.findings = self.tech.all_findings.bind(
                            self.func.__name__,
                        )
                        # Call the filter and handle exception
                        try:
                            return prettify_bbcode(escape(self.func(*args, **kargs)))
                        except Exception:  # pylint: disable=broad-except
                            self.tech.errors.append(sys.exc_info())
                            # print an error message
                            logger.getLogger(__name__).error(
                                "An exception occured while running filters",
                                exc_info=True,
                            )
                            return prettify_bbcode(
                                escape(self.tech.review_error(name, *args, **kargs)),
                            )

                    def __str__(self):
                        return self()

                    @property
                    def findings(self):
                        """Get the findings associated to the filter."""
                        return self.tech.all_findings[self.func.__name__]

                return Wrapper(self.tech, attr)

        return TechnologyWrapper(self)

    def review_error(
        self,
        name,
        *args,
        **kargs,
    ):  # pylint: disable=no-self-use,unused-argument
        """Manage erroneous filters.

        Args:
            name (str): name of the filter which failed.
            *args (tuple): positional arguments given to the filter
            **kargs (dict): named arguments given to the filter

        Returns:
            Markup: the part of the report to be included on error

        """
        return (
            M(
                _(
                    "[help=Review Error]"
                    "The review failed with an error on filter [code]%s[/code]. "
                    "[b]Please do the review manually.[/b]"
                    "[/help]\n",
                ),
            )
            % name
        )


class TechnologyV1(Technology):
    """This class is a base class for V1 technologies.

    It provides old-style review capabilities.
    """

    _is_plugin = False  # prevent this class to be register as a tech

    def parse_input(self, extract):
        """Parse input file.

        Extend the parent method to parse files as Extracts

        Args:
            extract (str): the file name to be parsed

        """
        log = logger.getLogger(__name__)

        # The file must be opened as binary to prevent decoding issues
        # in case the extraction contains binary parts or use a non-UTF8
        # encoding
        with open(extract, "rb") as inp:
            content = inp.read()

        self.extracts = Extracts(content)
        log.info("Found %d extracts...", len(self.extracts))

    def run_filter(self, filter_name, extract_name):
        """Run a filter on the extract

        Args:
            filter_name (str): name of the filter to run
            extract_name (str): name of the extract to use

        Returns:
            str: The Review or an error message if the extract does
                not exist

        """
        log = logger.getLogger(__name__)
        # for extract part, we retrieve the extract targeted by
        # the `target` property of the part, and filter it with
        # the `filter` filter
        source = self.extracts.get(extract_name, None)
        # Check that an extract could be found
        if source is None:
            log.info("Extract '%s' introuvable...", extract_name)
            return M(
                _(
                    "[help=Review Error]"
                    "The extract '{name}' could not be found"
                    "[/help]",
                ),
            ).format(name=extract_name)

        # Even if TechnologyV1 are not required to support findings,
        # update findings to match the filter and `run_filter`
        self.findings = self.all_findings.bind(filter_name)

        # Try to filter the extract
        if filter_name != "" and hasattr(self, filter_name):
            return getattr(self, filter_name)(source)
        # fall back to the default behavior
        return self.default_filter(source)

    def default_filter(self, extract):  # pylint: disable=no-self-use
        """Filter an extract without doing anything."""
        return M("[codeblock]\n%s\n[/codeblock]") % to_utf8(extract.strip())

    def review_error(self, name, *args, **kargs):
        """Manage erroneous filters.

        Extend parent method to keep compatibility behavior.

        Args:
            name (str): name of the filter which failed.

        Returns:
            Markup: the part of the report to be included on error

        """
        if name == "run_filter" and len(args) == 2:
            filter_name, extract_name = args
            return M("%s%s\n") % (
                super().review_error(filter_name),
                self.default_filter(self.extracts.get(extract_name, None)),
            )
        return super().review_error(name)
