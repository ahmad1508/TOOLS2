# -*- coding: utf-8 -*-

"""Provide an interface for findings"""


class Findings:
    """Main class to declare findings

    Example::

        f = Findings()
        f.vuln("Authentication", "This is a vuln")
        f.improvement("Authentication", "This could be better")

    """

    categories = ["good", "vuln", "improvement"]

    def __new__(cls, *args, **kargs):
        """Instanciate the class"""
        self = super().__new__(cls, *args, **kargs)
        # keep a per-instance copy of categories
        self.categories = []
        # dynamically create a category function
        for cat in cls.categories:
            self.new_category(cat)
        return self

    def __init__(self, findings=None):
        """Iniatilize a finding, possibly with a pre-existing one"""
        self.findings = {} if findings is None else findings

    def new_category(self, name):
        """Define new category functions."""
        self.categories.append(name)

        # Create the function to declare finding of the category
        def declare(section, description):
            self._ensure_section(section)
            self.findings[section][name].append(description)

        setattr(self, name, declare)

        # create a function to get all finding in the category
        def getter():
            ret = []
            for section in self.findings.values():
                ret.extend(section[name])
            return ret

        setattr(self, name + "s", getter)

    def _ensure_section(self, section):
        """Ensure a section is properly initialized before use"""
        if section not in self.findings:
            self.findings[section] = {cat: [] for cat in self.categories}

    def bind(self, section):
        """Create a findings bound to a section"""
        self._ensure_section(section)
        return BoundFindings(self, section)

    def __getitem__(self, key):
        """Create a findings bound to a section like bind()."""
        return self.bind(key)

    def __len__(self):
        """Get the number of findings"""
        # sum the length of each categories
        return sum(len(getattr(self, cat + "s")()) for cat in self.categories)


class BoundFindings:
    """Wrapper to Findings to ease working with sections

    This is usually such an instance which is exposed to filters
    """

    def __init__(self, findings, section):
        """Initialize the finding with a section and a Findings"""
        self.f = findings
        self.section = section

        # declare wrapper for each category
        for category in self.f.categories:
            self.new_category(category)

    @property
    def findings(self):
        """Expose findings of the bound Findings"""
        return self.f.findings[self.section]

    def new_category(self, name):
        """Define new category functions."""

        # Create the function to declare finding of the category
        def declare(description):
            return getattr(self.f, name)(self.section, description)

        setattr(self, name, declare)

        # create a function to get all finding in the category
        def getter():
            return self.findings[name]

        setattr(self, name + "s", getter)

    def __len__(self):
        """Get the number of findings"""
        # sum the length of each categories
        return sum(len(getattr(self, cat + "s")()) for cat in self.f.categories)
