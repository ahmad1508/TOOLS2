# -*- coding: utf-8 -*-

"""Provides a base class for classes with plugins

Classes
-------
PlugableMeta -- metaclass of Plugable
Plugable -- abstract class which should be extended by any class which
            need to accept plugins
"""


# Standard libraries
import importlib


class PlugableMeta(type):
    """Metaclass for Plugable classes

    This metaclass is used to create automatically a class property
    which is uniq per-class. It is used to keep track of plugins
    initialization

    If using a class property defined in Plugable, changing its value
    in the Plugable class would change it in all sub-classes, what
    we don't want.
    """

    def __new__(cls, name, bases, dct):
        """Instanciate a new Plugable instance

        It create dynamically a `_plugin_initialized` class attribute
        """
        # per-class class properties to keep track of plugins
        dct["_plugin_initialized"] = False
        dct["_plugins"] = []

        # check whether a subclass should be register as a plugin
        is_plugin = dct.pop("_is_plugin", True)

        # create the class
        ret = super(PlugableMeta, cls).__new__(cls, name, bases, dct)

        # Register the created class as a plugin of the parents, if
        # applicable
        if is_plugin:
            for parent in bases:
                if type(parent) is cls:
                    parent.register(ret)

        return ret


class Plugable(object, metaclass=PlugableMeta):
    """This class is a base class for all plugin classes

    It must be extended for all plugin classes. The class property
    `packages` must be defined and contains a list of packages where
    plugins should be searched

    This class provides several properties and methods.

    Methods
    ----------
    plugins -- return a list of loaded plugins

    """

    @classmethod
    def plugins(cls):
        """List all registered plugins"""
        # first load plugins if not done yet
        if not cls._plugin_initialized:
            cls.__init_plugins()
        return list(cls._plugins)

    @classmethod
    def __init_plugins(cls):
        """Initialize the plugins

        This method is called lazily, when plugins are listed for the
        first time. It should not be called directly
        """
        pkg = []
        if hasattr(cls, "packages"):
            pkg = cls.packages
            # ensure pkg is a list or tuple
            if isinstance(pkg, str):
                pkg = [pkg]

        # import all required packages
        for p in pkg:
            cls.import_package(p)

        # state plugins as initialized
        cls._plugin_initialized = True

    @classmethod
    def register(cls, plugin):
        """Register a new plugin"""
        if plugin not in cls._plugins:
            # register it at class level
            cls._plugins.append(plugin)
            # also register it in parent classes
            # this allows heritance in plugable classes
            for parent in cls.__bases__:
                if type(parent) is PlugableMeta:
                    parent.register(plugin)

    @classmethod
    def unregister(cls, plugin):
        """Unregister a plugin"""
        if plugin in cls._plugins:
            # unregister it at class level
            cls._plugins.remove(plugin)
            # also unregister it in parent classes
            for parent in cls.__bases__:
                if type(parent) is PlugableMeta:
                    parent.unregister(plugin)

    @staticmethod
    def import_package(name):
        """Import a package

        This mimics `from pkg import *`: it import the package and all
        modules defined in __all__
        """
        # do import the package
        pkg = importlib.import_module(name)

        # import modules in __all__, if defined
        if hasattr(pkg, "__all__"):
            for m in pkg.__all__:
                # only import modules when their name is provided
                if isinstance(m, str):
                    importlib.import_module("%s.%s" % (name, m))
