# -*- coding: utf-8 -*-

"""Provide the primitives to handle internationalization

Methodes:
    domain(domain): get the translation for the domain
    change_language(language): change the language
    list_languages(): list available languages

Examples:
    In a module, i18n should used as such

    ```python
    from engine.core import i18n

    _ = i18n.domain("core")._
    pgettext = i18n.domain("core").pgettext

    def meth():
        print(_("My localized string"))
        print(pgettext("My context", "My localized string and context"))
    ```

    Anywhere in the code, the language can be changed like this:
    ```python
    from engine.core import i18n

    i18n.change_language("en")
    ```

"""

# Standard libraries
import gettext
import os
import sys

# Project imports
from engine.bbcode import Markup

LOCALES_DIR = os.path.realpath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "..",
        "locales",
    ),
)


# a dictionnary to store each translation for each active domain
translations = {}
# to store the current language
language = None


def domain(domain):
    """Return the translation for the domain"""
    # first create the translation proxy for the current domain
    # if needed
    if domain not in translations:
        translations[domain] = DomainBoundTranslationsProxy(domain)

    # return the translation
    return translations[domain]


def change_language(language):
    """Change the current language

    Arguments
    language -- the language for the translation

    """
    # change the language
    global lang
    lang = language
    # recompute all translations
    for v in translations.values():
        v.change_language(language)


def list_languages():
    """List available languages"""
    ret = []
    for entry in os.listdir(LOCALES_DIR):
        # only keeps directories which contains LC_MESSAGES
        if os.path.isdir(os.path.join(LOCALES_DIR, entry)) and os.path.isdir(
            os.path.join(LOCALES_DIR, entry, "LC_MESSAGES"),
        ):
            ret.append(entry)
    return ret


# generate a wrapper for every function of gettext
# a wrapper will just delegate the call to the currently configured
# language
def _wrap_to_lang(name):
    """Generate a w,rapper to call a function on lang"""

    def wrapper(self, *args, **kargs):
        return getattr(self.lang, name)(*args, **kargs)

    return wrapper


def _context_msg(ctx, msg):
    """Create a contexte message to search for"""
    return "%s\x04%s" % (ctx, msg)


class DomainBoundTranslationsProxy(object):
    """Proxify the translation

    This class provides a proxy for translations, while bounding the
    domain and defering the langage resolution

    The use of proxies is preffered to creating translations, because
    it allows importing proxies' gettext methods and later change the
    language, without requiring redefinitions of gettext methods in the
    modules.
    """

    def __init__(self, domain):
        """Initialize with a domain"""
        self.domain = domain
        self.lang = None
        self.change_language(None)

    def change_language(self, language):
        """Change the language"""
        if language is None:
            self.lang = gettext.NullTranslations()
        else:
            self.lang = gettext.translation(
                self.domain,
                localedir=LOCALES_DIR,
                languages=[language],
                fallback=True,
            )

    for name in ["gettext", "ngettext", "lgettext", "lngettext"]:
        locals()[name] = _wrap_to_lang(name)

    # context based functions ==> added in py3.8
    if sys.version_info >= (3, 8):
        for name in ["pgettext", "npgettext"]:
            locals()[name] = _wrap_to_lang(name)
    else:
        # mimics the functions otherwise
        def pgettext(self, context, message):
            """Do the same thing as gettext but with context"""
            return self.gettext(_context_msg(context, message))

        def npgettext(self, context, singular, plural, num):
            """Do the same thing as ngettext but with context"""
            return self.ngettext(
                _context_msg(context, singular),
                _context_msg(context, plural),
                num,
            )

    # Also add a wrapper for _()
    locals()["_"] = _wrap_to_lang("gettext")

    # Also add a function N_() as proposed in GNU gettext documentation
    # to defer the resolution
    # N_() will not do anything, but will be kept by xgettext, if said
    # so
    @staticmethod
    def N_(msg):  # noqa: N802
        """Defer a message resolution

        Examples:
            >>> arr = {"en": N_("first sentence to translate"),
            ...        "fr": N_("second sentence to translate")}
            >>> for l in arr:
            ...     setup_language(l)
            ...     print(_(arr[l]))
            ...

            This will result in:
            first sentence to translate
            seconde phrase à traduire

            The extraction with `xgettext -kN_` would also extract to
            words
            to be defered

        """
        return msg

    def M_(self, msg):
        """Combine BBcode markup with a translation resolution."""
        return Markup(self.gettext(msg))
