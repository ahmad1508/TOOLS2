# -*- coding: utf-8 -*-

"""
This module provide a class to manage the templates.
"""

# Third party libraries
from jinja2 import contextfunction, Environment, PackageLoader

# Project imports
from engine import logger
from engine.bbcode import escape, Markup
from engine.core import i18n


class Template:
    """Class for a template of report."""

    def __init__(self, file):
        """Initialize the template from a file.

        Args:
            file (str): path to the template of report

        """
        self.rendered = None

        # create the environment for jinja
        self.environment = Environment(  # nosec
            # cannot use autoescape with bbcode
            autoescape=False,
            loader=PackageLoader("engine", "templates"),
            extensions=["jinja2.ext.do", "jinja2.ext.i18n"],
        )
        self.environment.filters["escape"] = do_escape
        self.environment.filters["e"] = do_escape
        self.environment.filters["safe"] = do_safe
        self.environment.filters["log"] = do_log
        self.environment.filters["all"] = all
        self.environment.filters["any"] = any
        self.environment.filters["combine_reviews"] = do_combine_reviews
        self.environment.globals["log"] = do_log
        self.environment.globals["catch_and_warn"] = do_catch_and_warn
        # install i18n
        self.environment.install_gettext_callables(  # pylint: disable=no-member
            newstyle=True,
            **{
                f: wrap_gettext(f)
                for f in ("gettext", "ngettext", "pgettext", "npgettext")
            },
        )

        # initialize the template
        self.template = self.environment.get_template(file)

    def render(self, techs):
        """Render the template for a technology.

        Args:
            techs (List[Technology]): list of technology to support the
                rendering.

        Returns:
            str: the rendered template

        """
        # use wrapper around techs instead of techs directly
        # (to manage errors)
        techs = [tech.wrapper for tech in techs]

        # render the template
        self.rendered = self.template.render(techs=techs)
        return self.rendered


def do_escape(text):
    """Escape the text for jinja"""
    return escape(text)


def do_safe(text):
    """Mark a text as safe for jinja"""
    return Markup(text)


def do_log(msg, level="info"):
    """Print to the logger"""
    getattr(logger.getLogger(__name__), level)(msg)


def do_catch_and_warn(caller, on_exception):
    """Catch exceptons and print an error"""
    try:
        return caller()
    except Exception:  # pylint: disable=broad-except
        # print an error message
        logger.getLogger(__name__).error(
            "An exception occured while running filters:",
            exc_info=True,
        )
        return on_exception


def do_combine_reviews(reviews, title_for_all):
    """Combine several reviews into common sections"""
    # detect hosts with similar reviews
    combined = {}
    for name, review in reviews.items():
        # only add review with content
        if len(review.strip()) > 0:
            # reviews are considered to be safe beacause they directly
            # comes from rendered section of template
            combined.setdefault(Markup(review), [])
            combined[Markup(review)].append(name)
        # if all reviews are the same (and no empty section is present)
        # do a unique section
        if len(combined) == 1 and len(list(combined.values())[0]) == len(reviews):
            return Markup("[section=%s]%s[/section]") % (
                title_for_all,
                list(combined.keys())[0],
            )

    # else do a section for all similar reviews
    ret = ""
    for review, names in combined.items():
        ret += Markup("[section=%s]%s[/section]") % (", ".join(names), review)
    return ret


# functions to wrap gettext functions and change the domain based on
# the template
def wrap_gettext(func_name):
    """Wrap gettext global functions to dynamically resolve domain"""

    # real global function
    @contextfunction
    def do_gettext(context, *args, **kargs):
        # retrieve the domain from the current template name
        # e.g. linux/fr/general_info/server_id.jinja ==> linux
        # e.g. hadoop.jinja ==> hadoop
        # because the divider is always /, cannot rely on os.path
        if "/" in context.name:
            # only use first level directory
            domain = context.name.split("/", 1)[0]
        else:
            # strip extension
            domain = context.name.rsplit(".", 1)[0]

        # retrieve the right translation
        return getattr(i18n.domain(domain), func_name)(*args, **kargs)

    return do_gettext
