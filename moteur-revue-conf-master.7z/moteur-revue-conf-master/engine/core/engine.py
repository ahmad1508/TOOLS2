# -*- coding: utf-8 -*-

"""Provide the core class of the engine

Classes:
    Engine:
        It manages the whole sequence of review:

         - Loading extracts
         - Filtering
         - Generating output

"""

# Project imports
from engine import logger
from engine.core import i18n
from engine.core.renderer import Renderer
from engine.core.technology import Technology
from engine.core.template import Template
from engine.core.timing import Timing


class InvalidArgumentException(RuntimeError):
    """Class to indicate provided arguments are not good"""


class Engine:
    """The Engine is the central engine to manage the workflow

    The Engine is to be used to manage the workflow of configuration
    review.
    """

    def __init__(self, tech, template=None, language=None):
        """Initialize the engine for the given technology

        Args:
            tech (str): name of the technology to use
            template (str): the name of the template for the report.
                None means, default template.
            language (str): the language of the output report.
                None means, default language.

        """
        # create the logger
        self.log = logger.getLogger(__name__)

        # ensure the tech is valid before loading anything
        if tech not in self.get_available_techs():
            raise RuntimeError("Invalid technology name %s" % tech)

        # Load the technology filter
        self.log.info("Chargement du moteur %s", tech)
        self.tech = Technology.get_by_name(tech)
        self.reviewers = []

        # Load the right template
        tpl_path = self.tech.get_template(language, template)
        if tpl_path is not None:
            self.template = Template(tpl_path)
        else:
            raise InvalidArgumentException(
                "Le couple de paramètres --template (%s) et --language (%s) "
                "n’est pas supporté par la technologie %s. Pour voir la liste "
                "des technologies et les paramètres supportés, utiliser "
                "l’option --list-templates."
                % (
                    "non spécifié" if template is None else template,
                    "non spécifié" if language is None else language,
                    tech,
                ),
            )

        # Create a timing object
        self.timing = Timing()

        # setup the language
        i18n.change_language(language or self.tech.desc.get("default language"))

    @staticmethod
    def get_available_techs():
        """List all available technologies"""
        return [m.name for m in Technology.plugins()]

    @staticmethod
    def get_tech_templates(tech):
        """List all template of a technology and its default.

        Args:
            tech (str): name of the template to search for

        Returns:
            tuple: composed of the templates, the default template, the
                default language
        """
        tech_instance = Technology.get_by_name(tech)
        return (
            tech_instance.templates,
            tech_instance.default_template,
            tech_instance.default_language,
        )

    @staticmethod
    def get_available_formats():
        """List all available output formats

        Returns
        -------
        A list of list. The first list correspond to each renderer while
        the second level contains all extensions supported by the it

        """
        return [m.extensions for m in Renderer.plugins()]

    @staticmethod
    def get_available_languages():
        """List all available languages"""
        return i18n.list_languages()

    def render(self, output_path, out_format=None):
        """Render the layout into the output file

        Args:
            output_path (str): path to the output file
            out_format (str, optional): format for the output file.
                If None, the format is resolved from the out file name

        """
        # get the renderer
        if out_format is None:
            renderer_cls = Renderer.get_by_filename(output_path)
        else:
            renderer_cls = Renderer.get_by_extension(out_format)

        # Ensure a renderer could be found
        if renderer_cls is None:
            raise RuntimeError("Invalid output format: no renderer found")

        # Render & save
        renderer = renderer_cls()
        renderer.render_report(output_path, self.tech.name, self.template.rendered)

        self.log.info("Et voilà ! Le rapport a été créé ici : %s", output_path)

    # Main class entrypoint
    def review(
        self,
        inputs,
        output_path,
        format_name=None,
        stats=False,
    ):
        """Do the review.

        Main method to call on an Engine instance

        Args:
            inputs (List[str]): paths to the input files
            output_path (str): path to the output file
            format_name (str): output format to use
            stats (bool): whether to print stats

        Returns:
            bool: True if the review was performed without error,
                False otherwise

        """
        # First parse the inputs as (name, path)
        parsed_inputs = []
        for inp in inputs:
            if "=" in inp:
                parsed_inputs.append(inp.split("=", 1))
            else:
                parsed_inputs.append((None, inp))

        # Do the review in 4 steps
        #   - load extracts
        #   - Run preprocessors
        #   - filter extracts
        #   - render the report

        # instanciate a reviewer for each input file
        idx = 1
        self.log.info("Chargement des fichiers d’entrée")
        with self.timing("Chargement des fichiers d’entrée"):
            for name, input_file in parsed_inputs:
                # instanciate the reviewer
                rev = self.tech()
                self.reviewers.append(rev)
                # update hostname (either the provided one or an
                # incremental name, like linux1, linux2, etc.
                rev.hostname = name or rev.name + str(idx)
                # parse input
                rev.parse_input(input_file)
                # next index
                idx += 1

        self.log.info("Éxecution des pre-processeurs")
        with self.timing("Éxecution des pre-processeurs"):
            for rev in self.reviewers:
                rev.preprocessors()

        self.log.info("Filtrage des extracts")
        with self.timing("Filtrage des extracts"):
            self.template.render(self.reviewers)

        self.log.info("Génération du fichier de sortie")
        with self.timing("Génération du fichier de sortie"):
            self.render(output_path, format_name)

        # print timing statistics if asked for
        self.timing.end()
        if stats:
            self.timing.print_stat()

        # return the status of the review
        return not any(rev.has_errors for rev in self.reviewers)
