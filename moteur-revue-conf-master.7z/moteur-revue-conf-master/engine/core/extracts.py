# -*- coding: utf-8 -*-

"""Provides a class to store extracts

Classes
-------
Extracts -- Represent a extract once parsed. It inherit dict
"""

# Standard libraries
import re


class Extracts(dict):
    """This class is used to store the extraction file

    This class extends dict with a method to parse extract files
    """

    # Compile regular expressions used to match a title in the extracts
    # For windows system, newlines are composed with \r\n: multilines
    # must match all kind of newlines
    _BASE_RE = rb"""["']?%s\s+(\S|\S.*\S)\s+%s['"]?\r?\n"""
    TITLES_RE = [
        # H1
        re.compile(_BASE_RE % (b"=====", b"====="), re.MULTILINE),
        # H2
        re.compile(_BASE_RE % (b"--===", b"===--"), re.MULTILINE),
        # H3
        re.compile(_BASE_RE % (b"--", b"--"), re.MULTILINE),
    ]

    def __init__(self, data=None):
        """Initialize the extract

        An optional data can be given. In this case, it is parsed. This
        is strictly equivalent to
        >>> ext = Extract()
        >>> ext.parse(data)
        """
        if data is not None:
            self.parse(data)

    def parse(self, data, _lvl=0):
        """Parse the data from the extraction file

        The extraction file can be splitted into several sections using
        the following title separators:
            - Heading 1: `===== Name =====`
            - Heading 2: `--=== Name ===--`
            - Heading 3: `-- Name --`

        A special key `ALL` is also added to contains the whole file

        This method is recursive and should be called externally without
        the `_lvl` argument.

        Arguments
        ---------
        data -- data to parse
        _lvl -- title level to parse. Used internally for recursion

        """
        # safe guard to stop recursion
        if _lvl == len(self.TITLES_RE):
            return

        # Split the data into sections, using the given level of title
        #
        # To split into bsections, we split each section on the title
        # sequence. We then convert it to a dict, indexed with the title
        # The sections for each level of title is stored into the list
        # sections

        # do the split
        splits = self.TITLES_RE[_lvl].split(data)

        # splits is a list of titles and contents
        # its first item is the text before the first split
        # e.g.
        # >>> [
        # ...   b"text before\n",
        # ...   b"title 1", b"content of title 1\n",
        # ...   b"title 2", b"content of title 2\n"
        # ...  ]
        #
        # The text before and all contents must be parsed to find
        # lower level titles

        # We first parse subsections to prioritize higher level titles
        # Doing so, similar higher levels titles will override existing
        # titles
        for sp in splits[0::2]:
            self.parse(sp, _lvl + 1)

        # update the sections with the sections of the current level
        self.update(
            zip(
                # decode titles in UTF-8 and strip it
                map(lambda x: x.decode("utf-8").strip(), splits[1::2]),
                # keep the contents as such
                splits[2::2],
            ),
        )

        # Create the ALL section
        # Keeping it at the end ensure the ALL key override previously
        # defined keys, through the call to update()
        self["ALL"] = data
