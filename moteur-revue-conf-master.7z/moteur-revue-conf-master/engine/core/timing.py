# -*- coding: utf-8 -*-

"""Provide a way to get timing statistics

It is mainly used within the Engine to get timing statistics on
the engine

Classes
-------
Timing -- class used to get the statistics
"""

# Standard libraries
import collections
from contextlib import contextmanager
import functools
import math
import sys
import time


class Timing(object):
    """This class provides an interface to follow timing statistics

    This class should be instantiated. On the instance, only the
    following methods will be useful:
        * start(name): start a new timer named _name_
        * stop(name): stop the timer named _name_
        * end(): stop all timing analysis
        * print_stat(): print all timing statistics
    """

    def __init__(self):
        """Initialize the required structures"""
        self._start = time.time()
        self._stop = None
        self._timers = collections.OrderedDict()
        self.timings = collections.OrderedDict()
        self._use_colors = sys.stdout.isatty()

    def start(self, name):
        """Start a new timer"""
        if name not in self._timers and self._stop is None:
            self._timers[name] = time.time()

    def stop(self, name):
        """Stop a timer"""
        if name in self._timers:
            self.timings[name] = time.time() - self._timers[name]
            del self._timers[name]

    def wrap(self, name):
        """Wrap a function which needs timing statistics

        It should be used as a decorator

        Usage:
        ```python
        from core.engine.timing import Timing

        timing = Timing()
        @timing.wrap("Name for my function")
        def my_func():
            do_something()
        ```

        This is similar as doing:
        ```python
        from core.engine.timing import Timing

        timing = Timing()
        def my_func():
            timing.start("Name for my function")
            do_something()
            timing.end("Name for my function")
        ```
        """

        # dynamic decorator
        def deco(func):
            @functools.wraps(func)
            def wrapper(*args, **kargs):
                self.start(name)
                ret = func(*args, **kargs)
                self.stop(name)
                return ret

            return wrapper

        return deco

    @contextmanager
    def __call__(self, name):
        """Implement a context manager way of calling.

        Example::

            timing = Timing()
            with timing("Doing something long"):
                do_something_long()

        Args:
            name (str): name for the timer.

        """
        self.start(name)
        yield
        self.stop(name)

    @staticmethod
    def self_wrap(attr, name):
        """Wrap a bounded function which needs timing statistics

        It is similar to the @wrap decorator but instead it retrieve
        an attribute from self to do timing

        Usage
        -----
        ```python
        from engine.core.timing import Timing

        class myClass(object):
            def __init__(self):
                self.timing = Timing()

            @Timing.self_wrap("timing", "Name for my function")
            def my_func(self):
                do_something()
        ```
        """

        # dynamic decorator
        def deco(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kargs):
                timing = getattr(self, attr)
                timing.start(name)
                ret = func(self, *args, **kargs)
                timing.stop(name)
                return ret

            return wrapper

        return deco

    def end(self):
        """Stop all timers"""
        # stop previously started timers
        for name in list(self._timers.keys()):
            self.stop(name)
        # stop the global timing
        if self._stop is None:
            self._stop = time.time()

    def print_stat(self):
        """Print current timing statistics"""
        # stop all timers if not done yet
        self.end()

        # print timing statistics
        print(self._underscore("Execution Time"))
        total = self._stop - self._start
        parts = []
        for name in self.timings:
            timing = self._format_time(self.timings[name])
            percent = self.timings[name] * 100 // total
            bar = self._get_bar(percent)
            parts.append((name, timing, bar, "%d%%" % percent))

        if len(parts) > 0:
            max_l = [
                max(map(len, (part[i] for part in parts))) for i in range(len(parts[0]))
            ]
            for part in parts:
                cols = []
                cols.append(self._timer_color("%-*s" % (max_l[0], part[0])))
                for i in range(1, len(part)):
                    cols.append(
                        self._timing_color("%*s" % (max_l[i], part[i])),
                    )
                print("  ".join(cols))
        print(self._total_color("Total %s" % self._format_time(total)))

    @staticmethod
    def _format_time(diff):
        """Format time in ms if diff is lower than 1, else in s"""
        if diff < 1.0:
            return "%dms" % int(diff * 1000)
        else:
            return "%.1fs" % diff

    def _get_bar(self, percent, total_len=10):
        """Get a percentage bar"""
        bar_len = math.ceil(percent * total_len / 100)
        if self._use_colors:
            ret = "\x1b[7m"
            ret += " " * bar_len
            ret += "\x1b[27m"
            ret += " " * (total_len - bar_len)
        else:
            ret = "#" * bar_len + " " * (total_len - bar_len)
        return "|%s|" % ret

    def _add_console_code(self, pre, post, txt):
        """Prepend and append txt with console codes"""
        if self._use_colors:
            return "\x1b[%dm%s\x1b[%dm" % (pre, txt, post)
        else:
            return txt

    def _underscore(self, txt):
        """Return a text as underlined"""
        return self._add_console_code(4, 24, txt)

    def _timer_color(self, txt):
        """Return a text as colored for timer names"""
        return self._add_console_code(0, 0, txt)

    def _timing_color(self, txt):
        """Return a text as colored for timing"""
        return self._add_console_code(34, 0, txt)

    def _total_color(self, txt):
        """Return a text as colored for total line"""
        return self._add_console_code(31, 0, txt)
