# -*- coding: utf-8 -*-

"""Provide a base class for renderers

Classes:
    Renderer: a plugable class which should be extend by every renderer

"""


# Project imports
from engine.core.plugable import Plugable
from engine.utils import classproperty


class Renderer(Plugable):
    """This class is a base class for all renderers

    It must be extended by all renderer classes

    This class exposes several properties and methods to render
    a report

    Attributes:
        extensions (list): a list of extensions handled by the renderer

    """

    # packages where plugins may be located
    packages = ["engine.renderers"]

    @classmethod
    def get_by_extension(cls, extension):
        """Retrieve a renderer class from its extension

        The retrieval from the extension is to be done in a
        case-insensitive manner.

        Args:
            extension (str): extension to search the renderer

        Returns:
            Renderer: the renderer class matching the extension

        """
        for m in cls.plugins():
            # m.extensions is always a lowercase string
            if extension.lower() in m.extensions:
                return m
        return None

    @classmethod
    def get_by_filename(cls, filename):
        """Retrieve a renderer class from a output filename"""
        return cls.get_by_extension(filename.rsplit(".", 1)[-1])

    @classproperty
    def extensions(cls):
        """Resolve the extension of a renderer

        If the class property `desc[extensions]` is defined, we use it
        If not, we resolve it from class name:
            - we use the class name in lowercase
            - we strip "Renderer" or "Renderers" at the end of the class
              name
            - we enclose it as a list of 1 element

        **Important**: obviously, it is recommended to use an explicit
        name definition

        e.g. all following classes would correspond to the same
        renderer with extensions `["html"]`:
        ```
        class MyRenderer(Renderer):
            desc = {"extensions": ["html"]}

        class Html(Renderer):
            pass

        class HtmlRenderer(Renderer):
            pass

        class HtmlRenderers(Renderer):
            pass
        ```
        """
        # check `desc[extensions]` first
        if hasattr(cls, "desc") and "extensions" in cls.desc:
            return [m.lower() for m in cls.desc["extensions"]]

        # resolve from class name
        name = cls.__name__
        for suffix in ["Renderer", "Renderers"]:
            if name.endswith(suffix):
                name = name[: -len(suffix)]
        return [name.lower()]

    def render_report(self, filename, tech_name, content):
        """Render and save a report from the layout

        This method delegate to the Renderer's render

        Args:
            filename (str): name of the file to render in
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        """
        output = self.render(tech_name, content)
        # ensure the renderer returned a bytes()
        if not isinstance(output, bytes):
            raise RuntimeError("Expecting Renderer to return a bytes()")
        self.save(filename, output)

    def render(self, tech_name, content):
        """Render a report from the layout

        This method should be overridden within child classes

        Args:
            tech_name (str): name of the rendered technology
            content (str): bbcode content of the report

        Returns:
            bytes: the rendered output as bytes

        """
        raise NotImplementedError("The render has not been overridden")

    @staticmethod
    def save(filename, content):
        """Save the report to a file

        Args:
            filename (str): name of the file which should be written
            content (bytes): content to save (must be bytes)

        """
        with open(filename, "wb") as f:
            f.write(content)
