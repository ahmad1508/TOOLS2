# TODO List

## Oracle

Actuellement, les extractions sont **trop lourdes** et ne peuvent pas être
traitées sans une manipulation qui détruit une grande partie de l'extract. Ce
problème est causé par deux raisons principales :

- Trop d'indicateurs sont récupérés dans l'extract. Il serait donc judicieux
  d'identifier les **indicateurs les plus importants** (les plus sensibles,
  sachant qu'en général un auditeur n'a que 0,5 jours pour auditer une
  configuration Oracle), et de **séparer le fichier en deux parties** pour ne
  conserver dans un fichier que les indicateurs les plus intéressants /
  critiques.

- Les bases de données Oracle **ne permettent pas d'obtenir un export au format
  CSV** (avec un échappement correct des données). Il est donc nécessaire
  d'utiliser une **largeur fixe pour les colonnes**, et cette valeur est fixée
  pour tout le script d'extraction (à 10000 caractères). Le fichier final est
  donc rempli d'espaces, et pèse plusieurs centaines de Mégaoctets.

La principale action à entreprendre est donc d'identifier les indicateurs les
plus importants et les générer dans un deuxième fichier, plus léger. Le premier
fichier reste exhaustif et permet de retrouver l'intégralité des données
nécessaires.
