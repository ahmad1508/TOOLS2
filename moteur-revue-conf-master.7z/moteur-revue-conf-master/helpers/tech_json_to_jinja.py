#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""
This script takes a json tech file and transform it to a jinja template.
"""

# Standard libraries
import argparse
import json
import re


def format_paragraph(text):
    """Format a paragraph in a clean way"""
    ret = []
    first = True
    # Need to treat paragraph separately
    for par in prettify_bbcode(text).splitlines():
        # Add an empty line before paragraph, unless fist one
        if first:
            first = False
        else:
            # dont doubly split if starting with PREVENT_SPLIT
            # this is used with prettify_bbcode
            if par.startswith(PREVENT_SPLIT):
                par = par[len(PREVENT_SPLIT) :]
            else:
                ret.append("")

        # Split line to max 80 char
        ret.extend(wrapline(par))
    return "\n".join(ret)


def wrapline(text):
    """Wrap lines to 79 chars + newline.

    This methods create lines of at most 79 chars, unless a line
    cannot be splitted, e.g. an URL which has no spaces

    Args:
        text (str): text to be splitted

    Returns:
        list: the list of lines

    """
    # Cannot rely on a regex to efficiently split

    # Manage small lines
    if len(text) < 80:
        return [text]

    # Analyse the first 80 chars
    chars = text[:80]
    if " " in chars:
        # split of the last space
        line = chars.rsplit(" ", 1)[0]
        return [line] + wrapline(text[len(line) + 1 :])

    # Case of line longer than 80 chars
    # either split on first space or return all
    if " " in text:
        line = text.split(" ", 1)[0]
        return [line] + wrapline(text[len(line) + 1 :])
    return [text]


PREVENT_SPLIT = "τγ"


def prettify_bbcode(text):
    """Prettify the BBCode with newlines around blocks"""
    nl = f"\n{PREVENT_SPLIT}"
    text = re.sub(r"\s?\[codeblock\]\s?", f"{nl}[codeblock]{nl}", text)
    text = re.sub(r"\s?\[/codeblock\]\s?", f"{nl}[/codeblock]{nl}", text)
    text = re.sub(r"\s?\[list\]\s?", f"{nl}[list]", text)
    text = re.sub(r"\s?\[/list\]\s?", f"{nl}[/list]\n", text)
    text = re.sub(r"\s?\[\*\]\s?", f"{nl}[*] ", text)

    # /tr must be kept above to prevent next sub to remove \n
    # before PREVENT_SPLIT
    text = re.sub(r"\s?\[/tr\]\s?", f"{nl}  [/tr]", text)
    text = re.sub(r"\s?\[/table\]\s?", f"{nl}[/table]{nl}", text)
    text = re.sub(r"\s?\[table\]\s?", f"{nl}[table]", text)
    text = re.sub(r"\s?\[title\]\s?", f"{nl}  [title]", text)
    text = re.sub(r"\s?\[tr\]\s?", f"{nl}  [tr]", text)
    text = re.sub(r"\s?\[td\]\s?", f"{nl}    [td]", text)
    text = re.sub(r"\s?\[th\]\s?", f"{nl}    [th]", text)
    return text


def format_top_section(section, english):
    """Format the first level section"""
    # start the section
    ret = f"[section={section['title']}]\n\n"

    # Add desc if any
    if "desc" in section and section["desc"] != "":
        ret += "%s\n\n" % format_paragraph(section["desc"])

    # Add each sublection
    for sub in section["content"]:
        ret += "%s\n" % format_sub_section(sub, english)

    # end the section
    ret += "[/section]\n"
    return ret


def format_sub_section(section, english):
    """Format the second level section"""
    # start the section
    ret = f"[section={section['title']}]\n\n"

    # Add desc if any
    if "desc" in section and section["desc"] != "":
        ret += "%s\n\n" % format_paragraph(section["desc"])

    # Add analyze if any
    if "analyze" in section and section["analyze"] != "":
        title = "Analyze" if english else "Analyse"
        ret += "[help=%s]\n%s\n[/help]\n\n" % (
            title,
            format_paragraph(section["analyze"]),
        )

    # Add extract
    # if there are several extracts, create a new section for each
    # else only add the extract
    if len(section["extract"]) == 1:
        ret += "%s\n" % format_extract(section["extract"][0], english)
    else:
        for ext in section["extract"]:
            ret += f"[section={ext['title']}]\n\n"
            ret += "%s\n" % format_extract(ext, english)
            ret += "\n[/section]\n"

    # Add rec if any
    if "rec" in section and section["rec"] != "":
        title = "Recommendation" if english else "Recommandation"
        ret += "[help=%s]\n%s\n[/help]\n\n" % (
            title,
            format_paragraph(
                section["rec"],
            ),
        )

    # end the section
    ret += "[/section]\n"
    return ret


def format_extract(extract, english):
    """Format a extract entry"""
    ret = ""
    if "cmd" in extract and extract["cmd"] != "":
        title = "Command" if english else "Commande"
        # pretty print as block or line
        if "\n" in extract["cmd"]:
            ret += "[help=%s]\n[codeblock]\n%s\n[/codeblock]\n[/help]\n\n" % (
                title,
                extract["cmd"],
            )
        else:
            ret += "[help=%s][codeblock]%s[/codeblock][/help]\n\n" % (
                title,
                extract["cmd"],
            )

    # Get the target
    target = extract.get("target", extract["title"])
    if "filter" in extract:
        ret += "{{ common.oldstyle_review(techs, %r, %r) }}\n" % (
            extract["filter"],
            target,
        )

    return ret


def generetate_jinja(data, english):
    """Generate the Jinja template from a json"""
    ret = '{% import "common.jinja" as common %}\n\n'
    for section in data:
        ret += format_top_section(section, english)
    # strip the end of each line
    return re.sub(r"[ \t]+$", "", ret, 0, re.M)


def main():
    """Do the work."""
    parser = argparse.ArgumentParser(
        description="Transform a technology JSON file to Jinja",
    )
    parser.add_argument("--en", help="whether input is english", action="store_true")
    parser.add_argument("src", help="path of the input JSON file")
    parser.add_argument("dst", help="path of the output Jinja file")
    opt = parser.parse_args()

    # Read the data
    with open(opt.src) as f:
        data = json.load(f)

    # Generate the template
    with open(opt.dst, "w") as f:
        f.write(generetate_jinja(data, opt.en))


if __name__ == "__main__":
    main()
