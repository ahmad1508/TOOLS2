// raw_sock.c
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<net/if.h>
#include<netinet/ip.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define BUFSIZE             4096
int main(int argc, char *argv[]) {
    // Structs that contain source IP addresses
    struct sockaddr_in serveraddr;
    char source_addr[INET_ADDRSTRLEN];
    char dest_addr[INET_ADDRSTRLEN];

    int packet_size;

    if (argc < 3) {
        printf("Usage: %s <local IP> <protocol> [<iface>]\n", argv[0]);
	exit(1);
    }

    // Allocate string buffer to hold incoming packet data
    unsigned char *buffer = (unsigned char *)malloc(BUFSIZE);
    // Open the raw socket
    int sock = socket (PF_INET, SOCK_RAW, atoi(argv[2]));
    if(sock == -1)
    {
        //socket creation failed, may be because of non-root privileges
        perror("Failed to create socket");
        exit(1);
    }
    // Bind the raw socket
    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    inet_pton(AF_INET, argv[1], &serveraddr.sin_addr);
    bind(sock, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
    // Bind to interface
    if (argc == 4) {
        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), argv[3]);
        if (setsockopt(sock, SOL_SOCKET, SO_BINDTODEVICE, (void *)&ifr, sizeof(ifr)) < 0) {
            perror("Failed to bind socket to device");
            exit(1);
        }
    }
    
    // Read all packets
    while(1) {
      // recvfrom is used to read data from a socket
      packet_size = recvfrom(sock, buffer, BUFSIZE, 0 , NULL, NULL);
      if (packet_size == -1) {
        printf("Failed to get packets\n");
        return 1;
      }

      struct iphdr *ip_packet = (struct iphdr *)buffer;

      inet_ntop(AF_INET, &ip_packet->saddr, source_addr, sizeof(source_addr));
      inet_ntop(AF_INET, &ip_packet->daddr, dest_addr, sizeof(dest_addr));

      printf("Incoming Packet: \n");
      printf("Packet Size (bytes): %d\n",ntohs(ip_packet->tot_len));
      printf("Source Address: %s\n", source_addr);
      printf("Destination Address: %s\n", dest_addr);
    }

    return 0;
}
