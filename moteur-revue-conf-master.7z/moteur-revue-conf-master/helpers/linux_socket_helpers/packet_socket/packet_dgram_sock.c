// raw_sock.c
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<net/if.h>
#include<sys/ioctl.h>
#include<netinet/ip.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<linux/if_packet.h>
#include<linux/if_ether.h>

#define BUFSIZE             4096
int main(int argc, char * argv[]) {
    int packet_size;
    struct sockaddr_ll addr;

    if (argc < 2) {
        printf("Usage: %s <protocol> [<iface>]\n", argv[0]);
        exit(1);
    }

    // Allocate string buffer to hold incoming packet data
    unsigned char *buffer = (unsigned char *)malloc(BUFSIZE);
    // Open the packet socket
    int sock = socket (AF_PACKET, SOCK_DGRAM, htons(atoi(argv[1])));
    if(sock == -1)
    {
        //socket creation failed, may be because of non-root privileges
        perror("Failed to create socket");
        exit(1);
    }
    // Bind to interface
    if (argc == 3) {
        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), argv[2]);
        if (ioctl(sock, SIOCGIFINDEX, &ifr) == -1) {
            perror("Invalid interface name\n");
            exit(1);
        }
        memset(&addr, 0, sizeof(addr));
        addr.sll_family = AF_PACKET;
        addr.sll_ifindex = ifr.ifr_ifindex;
        bind(sock, (struct sockaddr *)&addr, sizeof(addr));
    }
    
    // Read all packets
    while(1) {
      // recvfrom is used to read data from a socket
      packet_size = recvfrom(sock, buffer, BUFSIZE, 0, NULL, NULL);
      if (packet_size == -1) {
        printf("Failed to get packets\n");
        return 1;
      }
    }

    return 0;
}

