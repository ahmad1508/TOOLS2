# Linux Socket Helpers

This directory contains a set of Linux C programs which create all types of
sockets. It should be used during the extraction of Linux test configurations.

The helpers create sockets with types:

- TCP
- UDP
- Raw
- Packet

with both IPv4 and IPv6 and with binding to interfaces.

## Compilation

In order to compile the socket programs, a bare C development environment
should be available. In Debian, this can easily be configured with:

```shell
apt-get install build-essential
```

The compilation can then easily be done with `make`:

```shell
cd helpers/linux_socket_helpers
make
```

## Usage

A shell script perform everything needed:

```shell
./create_all.sh
```

In another shell, you can then launch the extraction script.
