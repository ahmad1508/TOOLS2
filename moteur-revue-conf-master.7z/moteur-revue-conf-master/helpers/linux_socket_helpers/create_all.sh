#!/bin/bash


cd "${0%/*}"
BIN="bin/"

# do the make, if binaries are not yet compiled
if ! [[ -d "$BIN" ]]; then
    echo "Programs not yet compiled"
    make || { echo >&2 "Error while compiling"; exit 1; }
fi

# trap to kill all background jobs on exit
trap 'kill `jobs -p`' INT

# get the local ipv4
declare local_ip4="$(ip a | \
    grep "inet " | grep "scope global" | \
    awk '{split($2,a,"/");print a[1]}' | \
    head -n1)"

# get the local ipv6
declare local_ip6="$(ip a | \
    grep "inet6 " | grep "scope global" | \
    awk '{split($2,a,"/");print a[1]}' | \
    grep -vE "^f[de]" | \
    head -n1)"

echo "Found local IP  : $local_ip4"
echo "Found local IPv6: $local_ip6"

declare -a ip4=("0.0.0.0" "127.0.0.1" "$local_ip4")
declare -a ip6=("::" "::1" "$local_ip6")
declare -i port=1234

# wrapper to postpone the backgroud for $((port++)) to work
d(){ "$@" &}

# TCP & UDP sockets
for ip in "${ip4[@]}"; do
    for iface in lo eth0 ""; do
        for transport in tcp udp; do
            d "$BIN/${transport}_socket/${transport}_sock" "$ip" "$((port++))" $iface
            d "$BIN/${transport}_socket/${transport}46_sock" "::ffff:$ip" "$((port++))" $iface
        done
    done
done
for ip in "${ip6[@]}"; do
    for iface in lo eth0 ""; do
        for transport in tcp udp; do
            d "$BIN/${transport}_socket/${transport}46_sock" "$ip" "$((port++))" $iface
            d "$BIN/${transport}_socket/${transport}6_sock" "$ip" "$((port++))" $iface
        done
    done
done

# Raw sockets
for proto in 6 255; do
    for iface in lo eth0 ""; do
        for ip in "${ip4[@]}"; do
            d "$BIN/raw_socket/raw_sock" "$ip" "$proto" $iface
        done
        for ip in "${ip6[@]}"; do
            d "$BIN/raw_socket/raw6_sock" "$ip" "$proto" $iface
        done
    done
done

# Packet sockets
for proto in 3 $((0x0806)) $((0x0801)); do
    for iface in lo eth0 ""; do
        d "$BIN/packet_socket/packet_raw_sock" "$proto" $iface
        d "$BIN/packet_socket/packet_dgram_sock" "$proto" $iface
    done
done

wait
