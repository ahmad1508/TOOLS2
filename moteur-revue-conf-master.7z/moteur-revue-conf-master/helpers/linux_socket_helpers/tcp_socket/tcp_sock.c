// raw_sock.c
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<net/if.h>
#include<netinet/ip6.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define BUFSIZE             4096
int main(int argc, char * argv[]) {
    // Structs that contain source IP addresses
    struct sockaddr_in serveraddr;
    struct sockaddr_in clientaddr;
    //char source_addr[INET_ADDRSTRLEN];
    //char dest_addr[INET_ADDRSTRLEN];
    int childfd;
    socklen_t childlen;

    long packet_size;
    int size_recv;

    if (argc < 3) {
        printf("Usage: %s <local IP> <local port> [<iface>]\n", argv[0]);
	exit(1);
    }

    // Allocate string buffer to hold incoming packet data
    unsigned char *buffer = (unsigned char *)malloc(BUFSIZE);
    // Open the raw socket
    int sock = socket (AF_INET, SOCK_STREAM, 0);
    if(sock == -1)
    {
        //socket creation failed, may be because of non-root privileges
        perror("Failed to create socket");
        exit(1);
    }
    // Bind the TCP socket
    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port   = htons(atoi(argv[2]));
    inet_pton(AF_INET, argv[1], &serveraddr.sin_addr);
    bind(sock, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
    // Bind to interface
    if (argc == 4) {
        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), argv[3]);
        if (setsockopt(sock, SOL_SOCKET, SO_BINDTODEVICE, (void *)&ifr, sizeof(ifr)) < 0) {
            perror("Failed to bind socket to device");
            exit(1);
        }
    }

    // start listening
    if (listen(sock, 5) != 0) {
        perror("Failed to start listening");
        exit(1);
    }

    // accept all connections
    childlen = sizeof(clientaddr);
    while(1) {
        childfd = accept(sock, (struct sockaddr *)&clientaddr, &childlen);
        packet_size = 0;

        // receive all data
        while ((size_recv = recv(childfd, buffer, BUFSIZE, 0)) > 0) {
            packet_size += size_recv;
        }
        if (size_recv < 0) {
            perror("Failed to get stream");
            exit(1);
        }

        printf("Incoming TCP connection: \n");
        printf("Packet Size (bytes): %ld\n", packet_size);
        printf("Source Address: %s\n", inet_ntop(AF_INET, &clientaddr.sin_addr, (char *)buffer, BUFSIZE));
        printf("Source Port: %d\n", ntohs(clientaddr.sin_port));
    }

    return 0;
}
